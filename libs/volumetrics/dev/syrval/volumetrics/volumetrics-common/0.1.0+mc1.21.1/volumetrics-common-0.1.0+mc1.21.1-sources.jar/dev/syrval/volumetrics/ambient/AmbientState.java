package dev.syrval.volumetrics.ambient;

import dev.syrval.volumetrics.api.MediumBuoyancy;
import dev.syrval.volumetrics.sim.AmbientProfile;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;

/**
 * What a level's air is like for gas that floats in it: the density at every height, the default speed of that
 * floating, and the media whose buoyancy the server has set. Immutable, so the thread that simulates may be handed it
 * from any other.
 *
 * @param media the buoyancy the server sets for a medium, by its id; it replaces the medium's own, if any
 */
public record AmbientState(AmbientProfile profile, float buoyancySpeed, Map<ResourceLocation, MediumBuoyancy> media) {
    public AmbientState {
        media = Map.copyOf(media);
    }

    /** One line for the log: sea level, the heights the profile covers and its shape. */
    public String describe() {
        String shape = "flat";
        if (!profile.isFlat()) {
            float[] densities = profile.densities();
            double scale = densities.length > 1 ? -1 / Math.log(densities[1] / densities[0]) : Double.NaN;
            shape = "scale height " + Math.round(scale);
        }
        return "sea level " + profile.seaLevel() + ", y " + profile.minY() + ".." + profile.maxY() + ", " + shape
                + ", buoyancy speed " + buoyancySpeed;
    }
}
