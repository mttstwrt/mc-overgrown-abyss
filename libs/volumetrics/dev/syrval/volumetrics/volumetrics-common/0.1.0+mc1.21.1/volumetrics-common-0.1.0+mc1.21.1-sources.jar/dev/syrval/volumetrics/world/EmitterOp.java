package dev.syrval.volumetrics.world;

/** A change to the emitters made from code, in the order it was made, on its way to the simulation thread. */
sealed interface EmitterOp {
    /** The emitter with this id now is this; it is new, or it moved, or its rate changed. */
    record Put(long id, Emitter emitter) implements EmitterOp {}

    record Remove(long id) implements EmitterOp {}
}
