// One triangle that covers the screen, made from the number of each of its three vertices: no vertex buffer.
// texCoord runs from 0 to 1 across the part of it that is on the screen.

out vec2 texCoord;

void main() {
    vec2 corner = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);
    texCoord = corner;
    gl_Position = vec4(corner * 2.0 - 1.0, 0.0, 1.0);
}
