package dev.syrval.volumetrics.mixin;

import dev.syrval.volumetrics.client.EmitterHolder;
import dev.syrval.volumetrics.world.LevelEmitters;
import net.minecraft.client.multiplayer.ClientLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

/**
 * Keeps the emitters that mods make from code on the level they are made in, which is what lets another mod
 * reach them with nothing static in between. It adds a field and nothing else: no method of the game's is
 * touched, so a Minecraft update can break nothing here but the name of the class.
 */
@Mixin(ClientLevel.class)
abstract class ClientLevelEmittersMixin implements EmitterHolder {
    @Unique
    private final LevelEmitters volumetrics$levelEmitters = new LevelEmitters();

    @Override
    public LevelEmitters volumetrics$emitters() {
        return volumetrics$levelEmitters;
    }
}
