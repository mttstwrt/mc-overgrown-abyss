package dev.syrval.volumetrics.client.render.gl;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferUploader;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL31;

/**
 * Draws fullscreen passes with this mod's own programs in the middle of the game's frame, and leaves OpenGL as
 * the game had it.
 *
 * <p>Everything the game keeps track of is set through its own state manager and never around it: the
 * framebuffer, the program, the viewport, textures, blending, the vertex array. The game remembers what it last
 * set there and skips what looks like a repeat, and so do Sodium (the viewport) and Iris (the framebuffer and
 * the program), inside those same methods. One call past them and the next thing drawn goes somewhere else.
 */
public final class ScreenPass implements AutoCloseable {
    /** How a pass's colour is laid over what its target holds. */
    public enum Blend {
        /** It replaces it. */
        NONE,
        /** By the pass's alpha. */
        ALPHA,
        /** By the pass's alpha, its colour being multiplied by that alpha already. */
        PREMULTIPLIED_ALPHA
    }

    /** An empty one: the vertex shader makes its triangle from the vertex's number, but OpenGL wants one bound. */
    private final int vertexArray = GlStateManager._glGenVertexArrays();
    private int programBefore;

    /** Before the first pass of a frame. */
    public void begin() {
        programBefore = GlStateManager._getInteger(GL20.GL_CURRENT_PROGRAM);
        GlStateManager._glBindVertexArray(vertexArray);
    }

    /** Draws one pass over the whole of a target. The program's textures and blocks are set before this. */
    public void draw(GlFramebuffer target, GlProgram program, Blend blend) {
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, target.id());
        GlStateManager._viewport(0, 0, target.width(), target.height());
        switch (blend) {
            case NONE -> RenderSystem.disableBlend();
            case ALPHA -> {
                RenderSystem.enableBlend();
                RenderSystem.blendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_ALPHA);
            }
            case PREMULTIPLIED_ALPHA -> {
                RenderSystem.enableBlend();
                RenderSystem.blendFuncSeparate(GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_ALPHA);
            }
        }
        program.use();
        GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
    }

    /**
     * After the last pass of a frame: the state the game leaves behind it when it has drawn the level, which is
     * where these passes are drawn, with the main target bound again.
     */
    public void end(RenderTarget main) {
        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
        GlStateManager._glUseProgram(programBefore);
        GlStateManager._activeTexture(GL13.GL_TEXTURE0);
        GlStateManager._glBindBuffer(GL31.GL_UNIFORM_BUFFER, 0);
        // As the game does when it lets go of a vertex array: it would otherwise take its own to be bound still.
        BufferUploader.invalidate();
        GlStateManager._glBindVertexArray(0);
        main.bindWrite(true);
    }

    @Override
    public void close() {
        GlStateManager._glDeleteVertexArrays(vertexArray);
    }
}
