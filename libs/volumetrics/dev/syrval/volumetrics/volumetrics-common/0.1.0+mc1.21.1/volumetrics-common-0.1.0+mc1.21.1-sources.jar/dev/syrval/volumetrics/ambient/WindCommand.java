package dev.syrval.volumetrics.ambient;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.syrval.volumetrics.api.wind.Wind;
import java.util.Locale;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

/**
 * The server-side dev command {@code /volumetrics-wind set <x> <z>} and {@code clear}: a wind for every level, in
 * blocks per second, that wins over the registered provider until cleared. The loaders register it only when the
 * system property {@code volumetrics.dev} is true. Needs op level 2.
 */
public final class WindCommand {
    /** Whether the dev command is wanted: {@code -Dvolumetrics.dev=true}. */
    public static boolean enabled() {
        return Boolean.getBoolean("volumetrics.dev");
    }

    private WindCommand() {}

    public static LiteralArgumentBuilder<CommandSourceStack> create() {
        float max = Wind.MAX_SPEED;
        return Commands.literal("volumetrics-wind")
                .requires(/*? if >=26.1 {*//*Commands.hasPermission(Commands.LEVEL_GAMEMASTERS)*//*?} else {*/source -> source.hasPermission(Commands.LEVEL_GAMEMASTERS)/*?}*/)
                .then(Commands.literal("set")
                        .then(Commands.argument("x", FloatArgumentType.floatArg(-max, max))
                                .then(Commands.argument("z", FloatArgumentType.floatArg(-max, max))
                                        .executes(context -> {
                                            float x = FloatArgumentType.getFloat(context, "x");
                                            float z = FloatArgumentType.getFloat(context, "z");
                                            ServerWind.setDevWind(Wind.uniform(x, z));
                                            context.getSource().sendSuccess(() -> Component.literal(
                                                    String.format(Locale.ROOT, "Wind set to %.1f, %.1f blocks/s", x, z)), true);
                                            return 1;
                                        }))))
                .then(Commands.literal("clear")
                        .executes(context -> {
                            ServerWind.setDevWind(null);
                            context.getSource().sendSuccess(() -> Component.literal("Wind handed back to the provider"), true);
                            return 1;
                        }));
    }
}
