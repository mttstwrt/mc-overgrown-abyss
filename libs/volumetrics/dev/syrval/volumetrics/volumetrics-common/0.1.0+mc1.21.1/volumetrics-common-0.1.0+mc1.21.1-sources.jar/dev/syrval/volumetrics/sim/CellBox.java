package dev.syrval.volumetrics.sim;

/** A box of cells in a grid: from the {@code min} cell on each axis up to, but not including, the {@code max} one. */
public record CellBox(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
    public CellBox {
        if (minX >= maxX || minY >= maxY || minZ >= maxZ) {
            throw new IllegalArgumentException("Not a box of cells: " + minX + ", " + minY + ", " + minZ + " to " + maxX + ", " + maxY + ", " + maxZ);
        }
    }
}
