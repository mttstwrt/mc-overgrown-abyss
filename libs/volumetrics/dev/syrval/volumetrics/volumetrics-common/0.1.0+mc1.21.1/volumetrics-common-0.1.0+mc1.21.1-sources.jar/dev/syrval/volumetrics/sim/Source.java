package dev.syrval.volumetrics.sim;

/**
 * Something that makes gas: every open cell whose centre lies in the shape gains {@code rate} density per
 * second, up to the medium's max density.
 *
 * @param weight how many sources of this shape and rate, in this very place, it stands for: things that give
 *               off gas closer together than a cell is wide are told apart by nothing but their number
 * @param flow   how it pushes the gas around it, or null if it does not
 */
public record Source(SourceShape shape, float rate, float weight, SourceFlow flow) {
    public Source {
        if (shape == null) {
            throw new IllegalArgumentException("A source needs a shape");
        }
        if (!Float.isFinite(rate) || rate < 0) {
            throw new IllegalArgumentException("Rate must be finite and not negative, got " + rate);
        }
        if (!Float.isFinite(weight) || weight <= 0) {
            throw new IllegalArgumentException("Weight must be finite and positive, got " + weight);
        }
    }

    public Source(SourceShape shape, float rate, float weight) {
        this(shape, rate, weight, null);
    }

    public Source(SourceShape shape, float rate) {
        this(shape, rate, 1f);
    }
}
