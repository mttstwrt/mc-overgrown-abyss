package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.sim.SourceShape;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Every emitter made from code, found by where it is: a hash of buckets of {@link #BUCKET} blocks, each holding the
 * emitters whose shape bounds touch it. A shape spanning more than {@link #MAX_BUCKETS} buckets is kept in a list
 * checked by every query instead. Owned by the simulation thread.
 */
final class EmitterIndex {
    static final int BUCKET = 64;
    static final int MAX_BUCKETS = 64;

    private final Map<Long, Entry> byId = new HashMap<>();
    private final Map<Long, Set<Entry>> buckets = new HashMap<>();
    private final Set<Entry> large = new HashSet<>();
    private int stamp;

    private static final class Entry {
        final Emitter emitter;
        final boolean isLarge;
        final int minX, minY, minZ, maxX, maxY, maxZ;
        int stamp;

        Entry(Emitter emitter) {
            this.emitter = emitter;
            SourceShape shape = emitter.source().shape();
            double x0 = Math.floor(shape.minX() / BUCKET);
            double x1 = Math.floor(shape.maxX() / BUCKET);
            double y0 = Math.floor(shape.minY() / BUCKET);
            double y1 = Math.floor(shape.maxY() / BUCKET);
            double z0 = Math.floor(shape.minZ() / BUCKET);
            double z1 = Math.floor(shape.maxZ() / BUCKET);
            double count = (x1 - x0 + 1) * (y1 - y0 + 1) * (z1 - z0 + 1);
            this.isLarge = !(count <= MAX_BUCKETS);
            if (isLarge) {
                minX = minY = minZ = maxX = maxY = maxZ = 0;
            } else {
                minX = (int) x0;
                maxX = (int) x1;
                minY = (int) y0;
                maxY = (int) y1;
                minZ = (int) z0;
                maxZ = (int) z1;
            }
        }
    }

    void apply(EmitterOp op) {
        switch (op) {
            case EmitterOp.Put put -> {
                remove(put.id());
                Entry entry = new Entry(put.emitter());
                byId.put(put.id(), entry);
                if (entry.isLarge) {
                    large.add(entry);
                } else {
                    for (int x = entry.minX; x <= entry.maxX; x++) {
                        for (int y = entry.minY; y <= entry.maxY; y++) {
                            for (int z = entry.minZ; z <= entry.maxZ; z++) {
                                buckets.computeIfAbsent(key(x, y, z), k -> new HashSet<>()).add(entry);
                            }
                        }
                    }
                }
            }
            case EmitterOp.Remove remove -> remove(remove.id());
        }
    }

    private void remove(long id) {
        Entry entry = byId.remove(id);
        if (entry == null) {
            return;
        }
        if (entry.isLarge) {
            large.remove(entry);
            return;
        }
        for (int x = entry.minX; x <= entry.maxX; x++) {
            for (int y = entry.minY; y <= entry.maxY; y++) {
                for (int z = entry.minZ; z <= entry.maxZ; z++) {
                    long key = key(x, y, z);
                    Set<Entry> bucket = buckets.get(key);
                    bucket.remove(entry);
                    if (bucket.isEmpty()) {
                        buckets.remove(key);
                    }
                }
            }
        }
    }

    /** How many emitters are held. */
    int size() {
        return byId.size();
    }

    /**
     * Adds to {@code out}, once each, the emitters whose shapes a window of {@code size} cells at {@code placement}
     * reaches: one beyond the window would feed nothing there, and would still keep its gas one of the few kinds a
     * window holds at once.
     */
    void gather(GridPlacement placement, GridSize size, List<Emitter> out) {
        if (byId.isEmpty()) {
            return;
        }
        int query = ++stamp;
        int cell = placement.cellSize();
        long loX = (long) placement.originX() * cell;
        long loY = (long) placement.originY() * cell;
        long loZ = (long) placement.originZ() * cell;
        long hiX = ((long) placement.originX() + size.x()) * cell;
        long hiY = ((long) placement.originY() + size.y()) * cell;
        long hiZ = ((long) placement.originZ() + size.z()) * cell;
        for (Entry entry : large) {
            offer(entry, placement, size, query, out);
        }
        if (buckets.isEmpty()) {
            return;
        }
        int x0 = (int) Math.floorDiv(loX, BUCKET);
        int x1 = (int) Math.floorDiv(hiX, BUCKET);
        int y0 = (int) Math.floorDiv(loY, BUCKET);
        int y1 = (int) Math.floorDiv(hiY, BUCKET);
        int z0 = (int) Math.floorDiv(loZ, BUCKET);
        int z1 = (int) Math.floorDiv(hiZ, BUCKET);
        for (int x = x0; x <= x1; x++) {
            for (int y = y0; y <= y1; y++) {
                for (int z = z0; z <= z1; z++) {
                    Set<Entry> bucket = buckets.get(key(x, y, z));
                    if (bucket != null) {
                        for (Entry entry : bucket) {
                            offer(entry, placement, size, query, out);
                        }
                    }
                }
            }
        }
    }

    private static void offer(Entry entry, GridPlacement placement, GridSize size, int query, List<Emitter> out) {
        if (entry.stamp == query) {
            return;
        }
        entry.stamp = query;
        if (placement.reaches(size, entry.emitter.source().shape())) {
            out.add(entry.emitter);
        }
    }

    private static long key(int x, int y, int z) {
        return ((x & 0x1FFFFFL) << 43) | ((z & 0x1FFFFFL) << 22) | (y & 0x3FFFFFL);
    }
}
