package dev.syrval.volumetrics.client;

import dev.syrval.volumetrics.client.render.Quality;
import dev.syrval.volumetrics.sim.CascadeLayout;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ContainerObjectSelectionList;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import org.jspecify.annotations.Nullable;
//? if >=26.1 {
/*import net.minecraft.client.gui.GuiGraphicsExtractor;
*///?} else {
import net.minecraft.client.gui.GuiGraphics;
//?}

/**
 * The screen over the client settings file, from the mod list's config button, Mod Menu, or {@code /volumetrics
 * settings}. Its Settings section holds what a player sets; its Experiments and Debug sections hold every {@link
 * Experiments experiment} of that {@link Experiments.Category category}, a row each built from the registry, so that an
 * experiment added there shows up here with no code of its own. It reads the file again when it opens, so a hand edit counts, and makes its changes when it closes, each as its
 * command would: written to the file, and in effect from then on.
 */
public final class SettingsScreen extends Screen {
    private static final int ROW_HEIGHT = 24;
    private static final int WIDGET_WIDTH = 120;
    private static final int RESET_WIDTH = 40;
    private static final int GAP = 4;

    private enum Section {
        SETTINGS("Settings", "How the gas looks and what it costs your machine."),
        EXPERIMENTS("Experiments", "Techniques still being tried out, and the choices between them. They change how the gas "
                + "is simulated or drawn and may look or perform worse; Reset puts a row back."),
        DEBUG("Debug", "Views and measurements for looking into the gas: debug colours over the world, timings in "
                + "/volumetrics stats, log lines. Not for normal play; Reset puts a row back.");

        private final String title;
        private final String tooltip;

        Section(String title, String tooltip) {
            this.title = title;
            this.tooltip = tooltip;
        }
    }

    private final @Nullable Screen parent;
    private final List<Row> settings;
    private final List<Row> experiments;
    private final List<Row> debug;
    private Section section = Section.SETTINGS;
    private HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);
    private @Nullable RowList list;

    public SettingsScreen(@Nullable Screen parent, VolumetricsClient client) {
        super(Component.literal("Volumetrics settings"));
        this.parent = parent;
        client.reloadSettings();
        ClientSettings fallback = ClientSettings.DEFAULT;
        settings = List.of(
                new Row("Gas", "Turns all volumetric gas (fog, mist, steam, smoke from mods and datapacks) on or off. Off, "
                        + "nothing is simulated or drawn and the mod costs nothing. Turning it back on starts the gas from "
                        + "nothing; it builds up again within a few seconds.",
                        Experiments.Rebuild.GAS, new Experiments.Values.Flag(), String.valueOf(fallback.enabled()),
                        String.valueOf(client.enabled()), text -> client.setEnabled(Boolean.parseBoolean(text)))
                        .performance(Experiments.Impact.HIGH, "Gas costs about 1 to 14% of the frame time, depending on Quality: "
                                + "1 to 2% on low, 2 to 5% on medium, 4 to 14% on high. The top of each range is when looking "
                                + "through a lot of gas, since every pixel with gas in front of it needs its own ray. Turning "
                                + "it off gets all of that back."),
                new Row("Quality", "Sets the resolution the gas and fog are drawn at, and how finely each ray samples them. "
                        + "The gas is ray-marched into a smaller image and upscaled to the screen: low aims for 360 rows of "
                        + "pixels, medium 540, high 720 (never more than a third of the screen's height on low, or half on "
                        + "medium and high). Along each ray, low samples every 2 blocks up to 48 samples, medium every block "
                        + "up to 80, high every half block up to 128. Higher gives sharper edges against blocks and less "
                        + "grain in thin mist; lower is softer and cheaper.", Experiments.Rebuild.NOTHING,
                        new Experiments.Values.Choice(Arrays.stream(Quality.values()).map(Quality::getSerializedName).toList()),
                        fallback.quality().getSerializedName(), client.quality().getSerializedName(),
                        text -> Arrays.stream(Quality.values()).filter(quality -> quality.getSerializedName().equals(text))
                                .findFirst().ifPresent(client::setQuality))
                        .performance(Experiments.Impact.HIGH, "What the gas costs at each level: low about 1 to 2% of the frame "
                                + "time, medium 2 to 5%, high 4 to 14%. Each step up draws more pixels and takes more samples "
                                + "per ray, so the cost grows with the amount of gas on screen and with screen resolution."),
                new Row("Render scale", "Only for shader packs that draw the world at a lower resolution and then upscale it "
                        + "(often called render scale or TAA upscaling in the pack's own settings). Set this to the same value as "
                        + "the pack so the gas lines up with the world. Without such a pack, leave it at 1: anything else "
                        + "can put the gas in the wrong place.", Experiments.Rebuild.NOTHING,
                        new Experiments.Values.Range(ClientSettings.MIN_SCALE, ClientSettings.MAX_SCALE), String.valueOf(fallback.scale()),
                        String.valueOf(client.scale()), text -> client.setScale(Float.parseFloat(text))),
                new Row("Simulation reach", "The gas is simulated in nested levels around you: a detailed one close by and coarser "
                        + "ones further out. This sets how large each level is. At 1 the detailed level reaches furthest; "
                        + "lower values shrink every level, so gas a little way off is simulated in less detail and more "
                        + "levels are needed to cover your render distance. Changing it clears all gas, which then builds "
                        + "up again.", Experiments.Rebuild.GAS, new Experiments.Values.Range(CascadeLayout.MIN_REACH, CascadeLayout.MAX_REACH),
                        String.valueOf(fallback.reach()), String.valueOf(client.reach()), text -> client.setReach(Float.parseFloat(text)))
                        .performance(Experiments.Impact.LOW, "Not measured yet. It mostly changes work for the processor, not the "
                                + "graphics card: at 1 the simulation has 2 levels, at 0.25 about 4. The simulation runs beside "
                                + "the game, so the frame rate should barely change."));
        experiments = experimentRows(client, Experiments.Category.EXPERIMENT);
        debug = experimentRows(client, Experiments.Category.DEBUG);
        List<Row> advanced = new ArrayList<>(experiments);
        advanced.addAll(debug);
        // Off, the gas does nothing, so nothing else does either; an experiment also needs the values it requires,
        // as they stand in the screen, so that turning one on here wakes the rows that need it at once.
        Row gas = settings.getFirst();
        Map<String, Row> byName = new HashMap<>();
        advanced.forEach(row -> byName.put(row.label, row));
        for (Row row : settings.subList(1, settings.size())) {
            row.blocked = () -> gasOff(gas);
        }
        for (Row row : advanced) {
            List<Experiments.Requirement> requirements = Experiments.byName(row.label).requirements();
            row.blocked = () -> {
                String off = gasOff(gas);
                if (off != null) {
                    return off;
                }
                for (Experiments.Requirement requirement : requirements) {
                    Row needed = byName.get(requirement.experiment().name());
                    if (needed != null && !needed.value.equals(String.valueOf(requirement.value()))) {
                        return requirement.reason();
                    }
                }
                return null;
            };
        }
    }

    private static @Nullable String gasOff(Row gas) {
        return gas.value.equals("false") ? "Gas is turned off in the Settings tab, so this does nothing. Turn Gas on to use it." : null;
    }

    private static List<Row> experimentRows(VolumetricsClient client, Experiments.Category category) {
        return Experiments.all().stream().filter(experiment -> experiment.category() == category)
                .map(experiment -> experimentRow(client, experiment)).toList();
    }

    private static Row experimentRow(VolumetricsClient client, Experiments.Experiment<?> experiment) {
        String fallback = String.valueOf(experiment.fallback());
        Row row = new Row(experiment.name(), experiment.help(), experiment.rebuild(), experiment.values(), fallback,
                String.valueOf(client.experiments().get(experiment)),
                text -> client.setExperiment(experiment, text.equals(fallback) ? "default" : text));
        row.impact = experiment.impact();
        row.performance = experiment.performance();
        return row;
    }

    /** Shows the screen in place of whatever is open, to go back to nothing when it closes. */
    public static void open(VolumetricsClient client) {
        show(Minecraft.getInstance(), new SettingsScreen(null, client));
    }

    private static void show(Minecraft minecraft, @Nullable Screen screen) {
        //? if >=26.1 {
        /*minecraft.gui.setScreen(screen);
        *///?} else {
        minecraft.setScreen(screen);
        //?}
    }

    @Override
    protected void init() {
        layout = new HeaderAndFooterLayout(this);
        LinearLayout tabs = layout.addToHeader(LinearLayout.horizontal().spacing(GAP));
        for (Section each : Section.values()) {
            Button tab = tabs.addChild(Button.builder(Component.literal(each.title), button -> {
                section = each;
                rebuildWidgets();
            }).width(100).tooltip(Tooltip.create(Component.literal(each.tooltip))).build());
            tab.active = each != section;
        }
        list = layout.addToContents(new RowList(switch (section) {
            case SETTINGS -> settings;
            case EXPERIMENTS -> experiments;
            case DEBUG -> debug;
        }));
        layout.addToFooter(Button.builder(CommonComponents.GUI_DONE, button -> onClose()).width(200)
                .tooltip(Tooltip.create(Component.literal("Close and apply the changes (Escape does too). Changed rows have a yellow name."))).build());
        layout.visitWidgets(widget -> addRenderableWidget(widget));
        repositionElements();
    }

    @Override
    protected void repositionElements() {
        layout.arrangeElements();
        if (list != null) {
            list.updateSize(width, layout);
        }
    }

    @Override
    public void onClose() {
        show(minecraft, parent);
    }

    @Override
    public void removed() {
        for (Row row : settings) {
            row.applyIfChanged();
        }
        for (Row row : experiments) {
            row.applyIfChanged();
        }
        for (Row row : debug) {
            row.applyIfChanged();
        }
    }

    /** What happens when a change of this kind is made, for a player. */
    private static String whenApplied(Experiments.Rebuild needs) {
        return switch (needs) {
            case NOTHING -> "A change takes effect as soon as you close this screen.";
            case SHADERS -> "When you close this screen the gas shaders are rebuilt: a short hitch.";
            case RENDERER -> "When you close this screen the gas renderer is made again: a short hitch.";
            case GAS -> "When you close this screen the gas simulation restarts: all gas goes and builds up again.";
        };
    }

    /** A row's tooltip: why it is greyed out if it is, what it does, what it costs, when a change shows, its default. */
    private static Component tooltip(Row row, @Nullable String blocked) {
        MutableComponent text = Component.empty();
        if (blocked != null) {
            text.append(Component.literal(blocked + "\n\n").withStyle(ChatFormatting.GOLD));
        }
        text.append(Component.literal(row.help));
        if (row.impact != null) {
            text.append(Component.literal("\n\nPerformance impact: " + row.impact).withStyle(impactFormat(row.impact)));
            if (row.performance != null) {
                text.append(Component.literal("\n" + row.performance).withStyle(ChatFormatting.GRAY));
            }
        }
        text.append(Component.literal("\n\n" + whenApplied(row.needs) + "\nDefault: " + row.fallback).withStyle(ChatFormatting.GRAY));
        return text;
    }

    private static ChatFormatting impactFormat(Experiments.Impact impact) {
        return switch (impact) {
            case LOW -> ChatFormatting.GREEN;
            case MEDIUM -> ChatFormatting.YELLOW;
            case HIGH -> ChatFormatting.RED;
        };
    }

    /** One line of the screen: what it sets, its value as text, and how a new value is made. */
    private static final class Row {
        private final String label;
        private final String help;
        private final Experiments.Rebuild needs;
        private final Experiments.Values values;
        private final String fallback;
        private final Consumer<String> apply;
        private String current;
        private String value;
        private Experiments.@Nullable Impact impact;
        private @Nullable String performance;
        /** Why the row can do nothing as the screen stands, or null if it can. */
        private Supplier<@Nullable String> blocked = () -> null;

        private Row(String label, String help, Experiments.Rebuild needs, Experiments.Values values, String fallback,
                    String current, Consumer<String> apply) {
            this.label = label;
            this.help = help;
            this.needs = needs;
            this.values = values;
            this.fallback = fallback;
            this.current = current;
            this.value = current;
            this.apply = apply;
        }

        private boolean changed() {
            return !value.equals(current);
        }

        private Row performance(Experiments.Impact impact, String performance) {
            this.impact = impact;
            this.performance = performance;
            return this;
        }

        private void applyIfChanged() {
            if (changed()) {
                apply.accept(value);
                current = value;
            }
        }
    }

    /** A number between the ends of a range, kept as text in its row to two decimals. */
    private static final class Slider extends AbstractSliderButton {
        private final Row row;
        private final Experiments.Values.Range range;

        private Slider(Row row, Experiments.Values.Range range) {
            super(0, 0, WIDGET_WIDTH, 20, Component.empty(), 0);
            this.row = row;
            this.range = range;
            set(row.value);
        }

        private void set(String text) {
            value = Math.clamp((Float.parseFloat(text) - range.min()) / (range.max() - range.min()), 0.0, 1.0);
            updateMessage();
        }

        private String text() {
            return Float.toString(Math.round((range.min() + (float) value * (range.max() - range.min())) * 100) / 100f);
        }

        @Override
        protected void updateMessage() {
            setMessage(Component.literal(text()));
        }

        @Override
        protected void applyValue() {
            row.value = text();
        }
    }

    private final class RowList extends ContainerObjectSelectionList<RowEntry> {
        private RowList(List<Row> rows) {
            super(SettingsScreen.this.minecraft, SettingsScreen.this.width, layout.getContentHeight(), layout.getHeaderHeight(), ROW_HEIGHT);
            rows.forEach(row -> addEntry(new RowEntry(row)));
        }

        @Override
        public int getRowWidth() {
            return Math.min(360, SettingsScreen.this.width - 24);
        }
    }

    /** A row's name, what a change of it needs, its widget, and a button that puts it back to its default. */
    private final class RowEntry extends ContainerObjectSelectionList.Entry<RowEntry> {
        private final Row row;
        private final AbstractWidget widget;
        private final Button reset;
        private boolean shown;
        private @Nullable String blockedReason;

        private RowEntry(Row row) {
            this.row = row;
            widget = switch (row.values) {
                case Experiments.Values.Flag flag -> CycleButton.onOffBuilder(Boolean.parseBoolean(row.value)).displayOnlyValue()
                        .create(0, 0, WIDGET_WIDTH, 20, Component.literal(row.label), (button, on) -> row.value = String.valueOf(on));
                //? if >=26.1 {
                /*case Experiments.Values.Choice choice -> CycleButton.<String>builder(Component::literal, row.value)
                *///?} else {
                case Experiments.Values.Choice choice -> CycleButton.<String>builder(Component::literal).withInitialValue(row.value)
                //?}
                        .withValues(choice.choices()).displayOnlyValue()
                        .create(0, 0, WIDGET_WIDTH, 20, Component.literal(row.label), (button, text) -> row.value = text);
                case Experiments.Values.Range range -> new Slider(row, range);
            };
            reset = Button.builder(Component.literal("Reset"), button -> reset()).size(RESET_WIDTH, 20)
                    .tooltip(Tooltip.create(Component.literal("Puts " + row.label + " back to its default, " + row.fallback
                            + ", when you close this screen."))).build();
            refresh();
        }

        @SuppressWarnings("unchecked")
        private void reset() {
            row.value = row.fallback;
            switch (widget) {
                case Slider slider -> slider.set(row.fallback);
                case CycleButton<?> button when row.values instanceof Experiments.Values.Flag ->
                        ((CycleButton<Boolean>) button).setValue(Boolean.parseBoolean(row.fallback));
                case CycleButton<?> button -> ((CycleButton<String>) button).setValue(row.fallback);
                default -> {}
            }
        }

        /** Greys the row out or wakes it as the values it needs change, with the reason in its tooltip. */
        private void refresh() {
            String reason = row.blocked.get();
            if (shown && Objects.equals(reason, blockedReason)) {
                return;
            }
            shown = true;
            blockedReason = reason;
            widget.active = reason == null;
            reset.active = reason == null;
            widget.setTooltip(Tooltip.create(tooltip(row, reason)));
        }

        private int labelColor() {
            if (blockedReason != null) {
                return 0xFF808080;
            }
            return row.changed() ? 0xFFFFFF55 : 0xFFFFFFFF;
        }

        private String hintText() {
            return blockedReason != null ? "does nothing now: hover for why" : needsText();
        }

        /** The impact after the name, coloured, or null for none or while greyed out. */
        private @Nullable String impactText() {
            return blockedReason == null && row.impact != null ? "impact: " + row.impact : null;
        }

        private int impactColor() {
            // The same colours as the impact line in the tooltip: green, yellow, red.
            return row.impact == null ? 0xFFA0A0A0 : switch (row.impact) {
                case LOW -> 0xFF55FF55;
                case MEDIUM -> 0xFFFFFF55;
                case HIGH -> 0xFFFF5555;
            };
        }

        private String needsText() {
            return switch (row.needs) {
                case NOTHING -> "applies at once";
                case SHADERS -> "rebuilds the gas shaders";
                case RENDERER -> "remakes the gas renderer";
                case GAS -> "restarts the gas";
            };
        }

        private void place(int left, int top, int width) {
            reset.setPosition(left + width - RESET_WIDTH, top);
            widget.setPosition(left + width - RESET_WIDTH - GAP - WIDGET_WIDTH, top);
        }

        @Override
        public List<? extends GuiEventListener> children() {
            return List.of(widget, reset);
        }

        @Override
        public List<? extends NarratableEntry> narratables() {
            return List.of(widget, reset);
        }

        //? if >=26.1 {
        /*@Override
        public void extractContent(GuiGraphicsExtractor graphics, int mouseX, int mouseY, boolean hovering, float partialTick) {
            refresh();
            int left = getContentX();
            int top = getContentY();
            graphics.text(font, row.label, left, top + 1, labelColor());
            String impact = impactText();
            if (impact != null) {
                graphics.text(font, impact, left + font.width(row.label + "  "), top + 1, impactColor());
            }
            graphics.text(font, hintText(), left, top + 11, 0xFFA0A0A0);
            place(left, top, getContentWidth());
            widget.extractRenderState(graphics, mouseX, mouseY, partialTick);
            reset.extractRenderState(graphics, mouseX, mouseY, partialTick);
        }
        *///?} else {
        @Override
        public void render(GuiGraphics graphics, int index, int top, int left, int width, int height, int mouseX, int mouseY,
                           boolean hovering, float partialTick) {
            refresh();
            graphics.drawString(font, row.label, left, top + 1, labelColor());
            String impact = impactText();
            if (impact != null) {
                graphics.drawString(font, impact, left + font.width(row.label + "  "), top + 1, impactColor());
            }
            graphics.drawString(font, hintText(), left, top + 11, 0xFFA0A0A0);
            place(left, top, width);
            widget.render(graphics, mouseX, mouseY, partialTick);
            reset.render(graphics, mouseX, mouseY, partialTick);
        }
        //?}
    }
}
