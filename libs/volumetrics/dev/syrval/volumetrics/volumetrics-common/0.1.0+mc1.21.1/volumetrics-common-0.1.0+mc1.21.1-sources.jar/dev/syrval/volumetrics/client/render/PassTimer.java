package dev.syrval.volumetrics.client.render;

import dev.syrval.volumetrics.client.render.gl.GlTimestamps;
import java.util.Arrays;
import java.util.OptionalLong;

/**
 * Times stretches of a frame's GPU work, for the performance figures. One frame is measured at a time, the next
 * once the GPU has reported the last. A figure is the median of recent measurements: other programs share the
 * GPU, and now and then one of them gets its turn in the middle of a measurement.
 */
final class PassTimer implements AutoCloseable {
    private static final int HISTORY = 31;
    /** The game's own timer cycles through three sets of queries rather than reuse one straight away; so does this. */
    private static final int ROTATIONS = 3;

    private final int stretches;
    private final GlTimestamps pool;
    private final long[][] history;
    private int rotation;
    private int marks;
    private int measured;
    private boolean awaiting;

    /** @param stretches how many stretches one frame is cut into: one more {@link #mark} than this a frame */
    PassTimer(int stretches) {
        this.stretches = stretches;
        this.pool = new GlTimestamps(ROTATIONS * (stretches + 1));
        this.history = new long[stretches][HISTORY];
    }

    /** Whether this GPU and driver can time anything; without it there is no timer to make. */
    static boolean supported() {
        return GlTimestamps.supported();
    }

    /** Whether this frame is to be measured. If so, call {@link #mark} before the first stretch and after each. */
    boolean begin() {
        if (awaiting && !collect()) {
            return false;
        }
        rotation = (rotation + 1) % ROTATIONS;
        marks = 0;
        return true;
    }

    void mark() {
        pool.write(rotation * (stretches + 1) + marks);
        marks++;
        awaiting = marks == stretches + 1;
    }

    /** Median GPU time of one stretch in nanoseconds, or 0 before anything has been measured. */
    long nanos(int stretch) {
        int count = Math.min(measured, HISTORY);
        if (count == 0) {
            return 0;
        }
        long[] sorted = Arrays.copyOf(history[stretch], count);
        Arrays.sort(sorted);
        return sorted[count / 2];
    }

    @Override
    public void close() {
        pool.close();
    }

    private boolean collect() {
        long[] stamps = new long[stretches + 1];
        for (int mark = 0; mark <= stretches; mark++) {
            OptionalLong stamp = pool.nanos(rotation * (stretches + 1) + mark);
            if (stamp.isEmpty()) {
                return false;
            }
            stamps[mark] = stamp.getAsLong();
        }
        for (int stretch = 0; stretch < stretches; stretch++) {
            history[stretch][measured % HISTORY] = stamps[stretch + 1] - stamps[stretch];
        }
        measured++;
        awaiting = false;
        return true;
    }
}
