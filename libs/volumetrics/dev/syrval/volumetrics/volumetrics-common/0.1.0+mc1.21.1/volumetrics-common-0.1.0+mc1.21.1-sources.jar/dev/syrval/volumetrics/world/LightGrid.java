package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.sim.GridShift;
import dev.syrval.volumetrics.sim.GridSize;
import java.nio.ByteBuffer;
import java.util.Arrays;

/**
 * Sky light and block light for every cell of the window, which is what lights the gas: the game has no shadow
 * maps to ask. Simulation thread only. Kept as the renderer sends it, two bytes a cell, sky then block light, each
 * scaled so that full light is 255. Slices changed since they were last handed to the renderer are remembered, so
 * only those are sent.
 */
final class LightGrid {
    private static final int MAX_LIGHT = 15;
    private static final int BYTES_PER_CELL = 2;

    private final GridSize size;
    private final byte[] texels;
    private final boolean[] sliceDirty;
    private boolean moved = true;

    LightGrid(GridSize size) {
        this.size = size;
        this.texels = new byte[size.cells() * BYTES_PER_CELL];
        this.sliceDirty = new boolean[size.y()];
        Arrays.fill(sliceDirty, true);
    }

    /** @param skyLight   0 to 15
     *  @param blockLight 0 to 15 */
    void set(int cellX, int cellY, int cellZ, int skyLight, int blockLight) {
        int at = size.index(cellX, cellY, cellZ) * BYTES_PER_CELL;
        byte sky = (byte) (skyLight * 255 / MAX_LIGHT);
        byte block = (byte) (blockLight * 255 / MAX_LIGHT);
        if (texels[at] != sky || texels[at + 1] != block) {
            texels[at] = sky;
            texels[at + 1] = block;
            sliceDirty[cellY] = true;
        }
    }

    /** Follows the window as its origin moves. Entering cells are dark until scanned; every slice is re-sent. */
    void shift(int cellsX, int cellsY, int cellsZ) {
        GridShift.shift(texels, size, BYTES_PER_CELL, cellsX, cellsY, cellsZ, (byte) 0);
        Arrays.fill(sliceDirty, true);
        moved = true;
    }

    /**
     * Whether the window has moved since {@link #allSlicesTaken}, or nothing has been taken yet. What the renderer
     * holds is then for another place, slice by slice, and must be replaced whole and at once: gas lit by some
     * slices from before the move and some from after flashes dark where the old place was inside a hill.
     */
    boolean hasMoved() {
        return moved;
    }

    /** Called once every slice has been taken after a move. */
    void allSlicesTaken() {
        moved = false;
    }

    boolean isSliceDirty(int cellY) {
        return sliceDirty[cellY];
    }

    /** How many slices have changed since they were last taken. */
    int dirtySlices() {
        int dirty = 0;
        for (boolean slice : sliceDirty) {
            if (slice) {
                dirty++;
            }
        }
        return dirty;
    }

    /** Writes one slice to the start of a buffer, two bytes a cell, and marks the slice as sent. */
    void takeSlice(int cellY, ByteBuffer out) {
        out.put(0, texels, size.index(0, cellY, 0) * BYTES_PER_CELL, size.x() * size.z() * BYTES_PER_CELL);
        sliceDirty[cellY] = false;
    }
}
