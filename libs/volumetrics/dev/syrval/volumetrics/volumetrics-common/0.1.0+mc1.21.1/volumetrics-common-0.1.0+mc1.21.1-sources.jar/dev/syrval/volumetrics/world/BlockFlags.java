package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.Volumetrics;
import it.unimi.dsi.fastutil.objects.Reference2IntOpenHashMap;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * What the section scan needs to know of each block state, worked out once on the client thread so that the scan
 * itself never asks the game: whether the state is air, whether it keeps gas out, and which block emitter rules it
 * matches. Indexed by {@link Block#getId}. Nothing changes it once built, so any thread may read it: it keeps its own
 * map from state to index, so the scan thread does not read the game's.
 *
 * <p>Whether a state is a full block, to look at or to walk into, is asked with an empty world at the origin, which
 * is how the game fills the shape cache each state keeps: for every state that has that cache, the answer is the
 * game's own. A block whose shape depends on where it stands, and which therefore has no cache, is judged by the
 * shape it has standing alone; that is an approximation.
 */
final class BlockFlags {
    private static final byte AIR = 1;
    private static final byte FLUID = 1 << 1;
    private static final byte SOLID_RENDER = 1 << 2;
    private static final byte FULL_COLLISION = 1 << 3;
    private static final int[] NO_RULES = {};

    private final Reference2IntOpenHashMap<BlockState> indices;
    private final byte[] flags;
    private final int[][] rules;

    private BlockFlags(Reference2IntOpenHashMap<BlockState> indices, byte[] flags, int[][] rules) {
        this.indices = indices;
        this.flags = flags;
        this.rules = rules;
    }

    /** Client thread only: it reads block shapes and the rules' block tags. */
    static BlockFlags build(List<BlockEmitterRule> rules) {
        long start = System.nanoTime();
        int states = 0;
        for (BlockState state : Block.BLOCK_STATE_REGISTRY) {
            states = Math.max(states, Block.getId(state) + 1);
        }
        Reference2IntOpenHashMap<BlockState> indices = new Reference2IntOpenHashMap<>(states);
        indices.defaultReturnValue(-1);
        byte[] flags = new byte[states];
        int[][] matching = new int[states][];
        Arrays.fill(matching, NO_RULES);
        int[] found = new int[rules.size()];
        for (BlockState state : Block.BLOCK_STATE_REGISTRY) {
            int id = Block.getId(state);
            indices.put(state, id);
            if (state.isAir()) {
                flags[id] = AIR;
                continue;
            }
            byte stateFlags = 0;
            if (!state.getFluidState().isEmpty()) {
                stateFlags |= FLUID;
            }
            if (state.isSolidRender(/*? if <26.1 {*/EmptyBlockGetter.INSTANCE, BlockPos.ZERO/*?}*/)) {
                stateFlags |= SOLID_RENDER;
            }
            if (state.isCollisionShapeFullBlock(EmptyBlockGetter.INSTANCE, BlockPos.ZERO)) {
                stateFlags |= FULL_COLLISION;
            }
            flags[id] = stateFlags;
            int count = 0;
            for (int rule = 0; rule < rules.size(); rule++) {
                if (rules.get(rule).matches(state)) {
                    found[count++] = rule;
                }
            }
            if (count > 0) {
                matching[id] = Arrays.copyOf(found, count);
            }
        }
        Volumetrics.LOGGER.info("Gas block table: {} block states, {} block emitter rules, built in {} ms",
                states, rules.size(), String.format(Locale.ROOT, "%.1f", (System.nanoTime() - start) / 1e6));
        return new BlockFlags(indices, flags, matching);
    }

    /** The state's index in this table, or -1 for a state the game had not made when the table was built. */
    int index(BlockState state) {
        return indices.getInt(state);
    }

    boolean isAir(int index) {
        return index >= 0 && (flags[index] & AIR) != 0;
    }

    /**
     * Gas is kept out of water and lava, and out of anything that is a full block either to walk into (glass) or to
     * look at (mud, which is a little short of full to walk on). It drifts through everything else: slabs, fences,
     * plants.
     */
    boolean keepsGasOut(int index) {
        return index >= 0 && (flags[index] & (FLUID | SOLID_RENDER | FULL_COLLISION)) != 0;
    }

    /** The indices of the rules the state matches, in the order of the rules; empty if none. Not to be changed. */
    int[] rules(int index) {
        return index >= 0 ? rules[index] : NO_RULES;
    }
}
