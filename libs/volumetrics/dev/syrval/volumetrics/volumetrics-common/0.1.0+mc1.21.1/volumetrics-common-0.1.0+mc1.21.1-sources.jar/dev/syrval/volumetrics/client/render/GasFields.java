package dev.syrval.volumetrics.client.render;

import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.client.render.gl.GlTexture;
import dev.syrval.volumetrics.world.GasWorld;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * Where the gas the renderer draws comes from: the textures the march reads and the numbers that say where each level
 * lies in them. It owns the textures, makes them, grows them and closes them; the renderer only borrows them for a
 * frame. Used on the render thread only.
 */
interface GasFields extends AutoCloseable {
    /**
     * Brings the textures up to date for this frame.
     *
     * @return false if nothing can be drawn yet
     */
    boolean prepare(GasWorld world, Vec3 camera);

    /** Whether any level holds gas to draw, as of {@link #prepare}. */
    boolean hasGas();

    /** This frame's numbers for each drawn level, the finest first; after {@link #prepare} returned true. */
    FieldLevel[] levels();

    /** The kind of gas in each slot, null for a free slot. */
    @Nullable Medium[] slotMedia();

    /** One of the two density textures; a level's {@link FieldLevel#newest} says which holds its newest step. */
    GlTexture density(int index);

    GlTexture light();

    GlTexture bricks();

    /** How many pages of the density textures each drawn level holds, the finest first. */
    String pages();

    /** Render-thread time it took to hand the last simulation step to the GPU, in nanoseconds. */
    long uploadNanos();

    /** Render-thread time it last took to send a level's light whole after the level had moved, in nanoseconds. */
    long lightMoveNanos();

    /** False makes the march walk through every brick, gas or none; from the next upload of gas. */
    void setSkipEmptySpace(boolean skipEmptySpace);

    FieldSource source();

    @Override
    void close();
}
