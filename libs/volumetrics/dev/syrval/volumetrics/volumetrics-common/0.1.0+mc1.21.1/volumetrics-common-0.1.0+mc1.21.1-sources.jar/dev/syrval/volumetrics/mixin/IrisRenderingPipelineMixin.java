package dev.syrval.volumetrics.mixin;

import dev.syrval.volumetrics.client.render.FarTerrainDepth;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Sees Iris's pipeline for a shader pack, one for each dimension, made, drawing the level and destroyed, so that what
 * a pack's programs are given is kept for the pipeline they belong to. Applied only when Iris is installed, like
 * {@link IrisProgramSamplersMixin}.
 */
@Pseudo
@Mixin(targets = "net.irisshaders.iris.pipeline.IrisRenderingPipeline", remap = false)
abstract class IrisRenderingPipelineMixin {
    @Inject(method = "<init>(Lnet/irisshaders/iris/shaderpack/programs/ProgramSet;)V", at = @At("RETURN"), require = 0, remap = false)
    private void volumetrics$made(CallbackInfo info) {
        FarTerrainDepth.pipelineMade(this);
    }

    @Inject(method = "beginLevelRendering()V", at = @At("HEAD"), require = 0, remap = false)
    private void volumetrics$drawing(CallbackInfo info) {
        FarTerrainDepth.pipelineDrawing(this);
    }

    @Inject(method = "finalizeLevelRendering()V", at = @At("HEAD"), require = 0, remap = false)
    private void volumetrics$drawn(CallbackInfo info) {
        FarTerrainDepth.pipelineDrawn();
    }

    @Inject(method = "destroy()V", at = @At("HEAD"), require = 0, remap = false)
    private void volumetrics$destroyed(CallbackInfo info) {
        FarTerrainDepth.pipelineDestroyed(this);
    }
}
