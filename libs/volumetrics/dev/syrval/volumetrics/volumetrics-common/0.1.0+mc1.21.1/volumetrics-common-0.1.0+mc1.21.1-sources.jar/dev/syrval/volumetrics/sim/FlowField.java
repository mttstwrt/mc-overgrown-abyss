package dev.syrval.volumetrics.sim;

import java.util.ArrayList;
import java.util.List;

/**
 * The sideways push the sources with a {@link SourceFlow} give one kind of gas in one window, cell by cell, as the
 * share of a cell's gas it moves east and south in a step (negative: west, north). The {@link GasStepper} moves the gas
 * by it after the rest of the step.
 *
 * <p>Each source pushes the cells whose centres lie within its reach of the box around its shape: fully inside the box,
 * and by {@code (1 - d / reach)^2} at {@code d} blocks from it. A source pushing towards a point slows over the last
 * {@link #TAPER_CELLS} cells to it, so gas comes to rest there. Where reaches overlap, the pushes are summed and divided
 * by the sum of their weights where that is above 1: one source alone pushes by its own weight, several overlapping
 * fully push by their weighted mean, so overlapping sources around one point do not push faster than one, and opposite
 * pushes cancel. The result is held to {@link Push#MAX}, then to {@link #MAX_SHARE} of a cell's gas a step, keeping
 * its direction.
 *
 * <p>Made from nothing but the sources and where the window is, so every machine with the same emitters makes the same
 * field. Kept by brick; a brick no reach touches, or where every push cancels, has none.
 */
final class FlowField {
    /** Over this many cells to a point it pushes towards, a source's push slows to nothing. */
    static final int TAPER_CELLS = 2;
    /** The most of a cell's gas the push moves out of it in a step, both axes together. */
    static final float MAX_SHARE = 0.5f;
    private static final int BRICK_CELLS = GridSize.BRICK * GridSize.BRICK * GridSize.BRICK;

    final GridSize size;
    /** By brick, null for none, then by cell in the brick (X fastest, then Z, then Y): the share moved east, and south. */
    final float[][] shareX;
    final float[][] shareZ;
    /** The bricks that have a push, in order. */
    final int[] bricks;
    private final List<Source> sources;
    private final GridPlacement placement;
    private final float dt;

    private FlowField(GridSize size, float[][] shareX, float[][] shareZ, int[] bricks, List<Source> sources,
                      GridPlacement placement, float dt) {
        this.size = size;
        this.shareX = shareX;
        this.shareZ = shareZ;
        this.bricks = bricks;
        this.sources = sources;
        this.placement = placement;
        this.dt = dt;
    }

    /** The cell's place in its brick's arrays. */
    static int inBrick(int x, int y, int z) {
        return (x & (GridSize.BRICK - 1)) + GridSize.BRICK * ((z & (GridSize.BRICK - 1)) + GridSize.BRICK * (y & (GridSize.BRICK - 1)));
    }

    boolean has(int brick) {
        return shareX[brick] != null;
    }

    boolean isEmpty() {
        return bricks.length == 0;
    }

    /** Whether this is the field {@link #build} makes of the same sources for the same window and step. */
    boolean builtFrom(List<Source> flowing, GridPlacement placement, float dt) {
        return this.dt == dt && this.placement.equals(placement) && sources.equals(flowing);
    }

    /**
     * @param flowing the sources feeding the kind in the window that have a flow, in the order they are given
     * @param dt      seconds a step
     */
    static FlowField build(List<Source> flowing, GridSize size, GridPlacement placement, float dt) {
        int cellSize = placement.cellSize();
        double taper = (double) TAPER_CELLS * cellSize;
        int brickCount = size.brickCount();
        float[][] sumX = new float[brickCount][];
        float[][] sumZ = new float[brickCount][];
        float[][] sumWeight = new float[brickCount][];
        for (Source source : flowing) {
            SourceFlow flow = source.flow();
            SourceShape shape = source.shape();
            double reach = flow.reach();
            int minX = Math.max(0, placement.localX(shape.minX() - reach));
            int minY = Math.max(0, placement.localY(shape.minY() - reach));
            int minZ = Math.max(0, placement.localZ(shape.minZ() - reach));
            int maxX = Math.min(size.x() - 1, placement.localX(shape.maxX() + reach));
            int maxY = Math.min(size.y() - 1, placement.localY(shape.maxY() + reach));
            int maxZ = Math.min(size.z() - 1, placement.localZ(shape.maxZ() + reach));
            for (int y = minY; y <= maxY; y++) {
                double dy = outside(placement.centreY(y), shape.minY(), shape.maxY());
                for (int z = minZ; z <= maxZ; z++) {
                    double centreZ = placement.centreZ(z);
                    double dz = outside(centreZ, shape.minZ(), shape.maxZ());
                    for (int x = minX; x <= maxX; x++) {
                        double centreX = placement.centreX(x);
                        double dx = outside(centreX, shape.minX(), shape.maxX());
                        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
                        double weight;
                        if (distance <= 0) {
                            weight = 1;
                        } else if (distance < reach) {
                            double fade = 1 - distance / reach;
                            weight = fade * fade;
                        } else {
                            continue;
                        }
                        double pushX;
                        double pushZ;
                        if (flow.toward()) {
                            double toX = flow.x() - centreX;
                            double toZ = flow.z() - centreZ;
                            double away = Math.sqrt(toX * toX + toZ * toZ);
                            if (away > 0) {
                                double speed = flow.speed() * Math.min(1, away / taper);
                                pushX = speed * toX / away;
                                pushZ = speed * toZ / away;
                            } else {
                                pushX = 0;
                                pushZ = 0;
                            }
                        } else {
                            pushX = flow.speed() * flow.x();
                            pushZ = flow.speed() * flow.z();
                        }
                        int brick = size.brickOfCell(x, y, z);
                        if (sumWeight[brick] == null) {
                            sumX[brick] = new float[BRICK_CELLS];
                            sumZ[brick] = new float[BRICK_CELLS];
                            sumWeight[brick] = new float[BRICK_CELLS];
                        }
                        int cell = inBrick(x, y, z);
                        sumX[brick][cell] += (float) (weight * pushX);
                        sumZ[brick][cell] += (float) (weight * pushZ);
                        sumWeight[brick][cell] += (float) weight;
                    }
                }
            }
        }

        double perStep = dt / cellSize;
        List<Integer> pushing = new ArrayList<>();
        for (int brick = 0; brick < brickCount; brick++) {
            if (sumWeight[brick] == null) {
                continue;
            }
            boolean any = false;
            float[] x = sumX[brick];
            float[] z = sumZ[brick];
            for (int cell = 0; cell < BRICK_CELLS; cell++) {
                double weight = Math.max(1, sumWeight[brick][cell]);
                double pushX = x[cell] / weight;
                double pushZ = z[cell] / weight;
                double length = Math.sqrt(pushX * pushX + pushZ * pushZ);
                if (length > Push.MAX) {
                    pushX *= Push.MAX / length;
                    pushZ *= Push.MAX / length;
                }
                double shareX = pushX * perStep;
                double shareZ = pushZ * perStep;
                double share = Math.abs(shareX) + Math.abs(shareZ);
                if (share > MAX_SHARE) {
                    shareX *= MAX_SHARE / share;
                    shareZ *= MAX_SHARE / share;
                }
                x[cell] = (float) shareX;
                z[cell] = (float) shareZ;
                any |= x[cell] != 0f || z[cell] != 0f;
            }
            if (any) {
                pushing.add(brick);
            } else {
                sumX[brick] = null;
                sumZ[brick] = null;
            }
        }
        int[] bricks = pushing.stream().mapToInt(Integer::intValue).toArray();
        return new FlowField(size, sumX, sumZ, bricks, List.copyOf(flowing), placement, dt);
    }

    /** How far a coordinate lies outside a range, 0 inside it. */
    private static double outside(double at, double min, double max) {
        return at < min ? min - at : at > max ? at - max : 0;
    }
}
