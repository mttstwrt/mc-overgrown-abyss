package dev.syrval.volumetrics.sim;

import java.util.List;
import java.util.Map;

/** The engines there are, by the name they are chosen by. */
public final class SimEngines {
    public static final String DEFAULT = CellularEngine.NAME;

    private static final Map<String, SimEngine.Factory> FACTORIES = Map.of(
            CellularEngine.NAME, CellularEngine.factory(),
            DecayOnlyEngine.NAME, DecayOnlyEngine.factory());

    private SimEngines() {}

    /** Whether there is an engine of this name. */
    public static boolean exists(String name) {
        return name != null && FACTORIES.containsKey(name);
    }

    /** The names of all engines, sorted. */
    public static List<String> names() {
        return FACTORIES.keySet().stream().sorted().toList();
    }

    /** The factory of the engine called {@code name}, or the default engine's if there is none. */
    public static SimEngine.Factory byName(String name) {
        SimEngine.Factory factory = name == null ? null : FACTORIES.get(name);
        return factory != null ? factory : FACTORIES.get(DEFAULT);
    }

    /**
     * The same, with settled bricks asleep or not, for an engine that lets them sleep (see {@link CellularEngine}); off
     * is for comparison.
     */
    public static SimEngine.Factory byName(String name, boolean sleep) {
        SimEngine.Factory factory = byName(name);
        return factory == FACTORIES.get(CellularEngine.NAME) ? CellularEngine.factory(sleep) : factory;
    }
}
