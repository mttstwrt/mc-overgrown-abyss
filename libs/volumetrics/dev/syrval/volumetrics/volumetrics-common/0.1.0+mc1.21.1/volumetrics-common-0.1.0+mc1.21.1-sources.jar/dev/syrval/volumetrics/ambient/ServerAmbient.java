package dev.syrval.volumetrics.ambient;

import dev.syrval.volumetrics.world.LevelHeight;
import java.nio.file.Path;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/**
 * The server's side of the air gas floats in: the settings from the config file, and the payload that tells a
 * player what their level's air is like. The loaders call {@link #load} when a server starts and
 * {@link #payloadFor} when a player joins, respawns or changes dimension. No loader API in here.
 */
public final class ServerAmbient {
    private static volatile ServerSettings settings = ServerSettings.DEFAULT;

    private ServerAmbient() {}

    /** Reads {@code config/volumetrics-server.json}, writing it with the defaults if it is not there. */
    public static void load(Path configDir) {
        settings = ServerSettings.load(configDir.resolve(ServerSettings.FILE_NAME));
    }

    public static ServerSettings settings() {
        return settings;
    }

    /**
     * What the air of the player's current level is like. The sea level comes from the level's generator: before
     * 26.1 the level itself answers 63 whatever its generator says.
     */
    public static AmbientPayload payloadFor(ServerPlayer player) {
        ServerLevel level = (ServerLevel) player.level();
        ResourceLocation dimension = level.dimension()./*? if >=26.1 {*//*identifier*//*?} else {*/location/*?}*/();
        return new AmbientPayload(dimension,
                settings.stateFor(dimension, level.getChunkSource().getGenerator().getSeaLevel(), LevelHeight.bottom(level), LevelHeight.top(level) - 1));
    }
}
