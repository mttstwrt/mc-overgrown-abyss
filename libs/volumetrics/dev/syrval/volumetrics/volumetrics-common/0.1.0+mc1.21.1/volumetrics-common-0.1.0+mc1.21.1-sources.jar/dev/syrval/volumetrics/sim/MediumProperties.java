package dev.syrval.volumetrics.sim;

/**
 * What a medium is like, whichever engine moves it: the engine turns these into its own numbers. Density and
 * buoyancy are the air's business and come with the level, so they are not here.
 *
 * @param params       dispersion, decay, maximum density, and the gas's own gravity and drift; a gravity is not used
 *                     when the medium floats
 * @param windResponse how much of the wind pushes the gas, 0 to 1
 * @param draft        the turning sideways push it has of its own, or null for none
 */
public record MediumProperties(MediumParams params, float windResponse, Draft.Settings draft) {
    public MediumProperties {
        if (params == null) {
            throw new IllegalArgumentException("A medium needs parameters");
        }
        if (!(windResponse >= 0 && windResponse <= 1)) {
            throw new IllegalArgumentException("Wind response must be between 0 and 1, got " + windResponse);
        }
    }

    /** A medium that follows the wind fully and has no draft. */
    public MediumProperties(MediumParams params) {
        this(params, 1f, null);
    }
}
