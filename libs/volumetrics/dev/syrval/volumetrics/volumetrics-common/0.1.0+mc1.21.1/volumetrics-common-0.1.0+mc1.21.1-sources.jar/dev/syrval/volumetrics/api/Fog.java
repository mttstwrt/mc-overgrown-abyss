package dev.syrval.volumetrics.api;

import java.util.Objects;
import net.minecraft.world.phys.Vec3;

/**
 * Gas that is not simulated: one look of gas filling a shape, its density given by a formula. It follows no floor and
 * no draught, and blocks do not stop it, but it costs the simulation nothing, so it can be as large as a valley and is
 * drawn at any distance. It is lit as simulated gas is, by the game's light where it is, as far as the windows of
 * simulated gas reach, and beyond them by the light at their edge. What it is for is the air of a place: haze in a
 * chasm, a pall over a swamp, the murk of a cave, with the simulated gas moving through it.
 *
 * <p>The density is that of simulated gas: light through {@code n} blocks of fog at density {@code d} is dimmed to
 * {@code exp(-appearance.opacity() * d * n)}. It goes from {@code bottomDensity} at the bottom of the shape to
 * {@code topDensity} at its top, by the same share every block up when both are above zero, which is how air thins,
 * and evenly when either is zero. Over its outermost {@code edge} blocks, sides, top and bottom, it thins to nothing.
 * The appearance's noise gives it wisps, which drift sideways at the noise's speed.
 *
 * @param appearance    how it looks: a medium's appearance, or one made for the fog
 * @param shape         the room it fills
 * @param anchor        the middle of the shape's base, in blocks
 * @param bottomDensity its density at the bottom of the shape
 * @param topDensity    its density at the top
 * @param edge          blocks over which it thins from its surface in to its full density; 0 for a hard edge
 */
public record Fog(Appearance appearance, FogShape shape, Vec3 anchor, float bottomDensity, float topDensity, float edge) {
    public Fog {
        Objects.requireNonNull(appearance, "appearance");
        Objects.requireNonNull(shape, "shape");
        Objects.requireNonNull(anchor, "anchor");
        requireNotNegative(bottomDensity, "bottom density");
        requireNotNegative(topDensity, "top density");
        requireNotNegative(edge, "edge");
    }

    /** As thick throughout. */
    public Fog(Appearance appearance, FogShape shape, Vec3 anchor, float density, float edge) {
        this(appearance, shape, anchor, density, density, edge);
    }

    private static void requireNotNegative(float value, String name) {
        if (!(value >= 0) || !Float.isFinite(value)) {
            throw new IllegalArgumentException("A fog's " + name + " must be a number of 0 or more, got " + value);
        }
    }
}
