package dev.syrval.volumetrics.ambient;

import dev.syrval.volumetrics.api.wind.Wind;
import dev.syrval.volumetrics.api.wind.WindArea;
import net.minecraft.resources.ResourceLocation;
import org.jspecify.annotations.Nullable;

/**
 * The client's side of the wind: what the server last sent. Holds an immutable value behind a volatile reference.
 * Without a word from the server the wind is zero. Nothing in here touches client classes.
 */
public final class ClientWind {
    private static volatile @Nullable WindPayload received;

    private ClientWind() {}

    /** What the loaders' receivers call with a payload from the server. */
    public static void receive(WindPayload payload) {
        received = payload;
    }

    /** Forgets what a server sent, when the player is out of any level. */
    public static void clear() {
        received = null;
    }

    public static @Nullable WindPayload received() {
        return received;
    }

    /**
     * The wind the server last sent for this dimension, or null if it sent none for it or said there is no wind.
     */
    public static @Nullable Wind windOf(ResourceLocation dimension) {
        WindPayload payload = received;
        return payload != null && payload.dimension().equals(dimension) ? payload.wind() : null;
    }

    /** The wind at a block as {x, z} in blocks per second: the first area that contains it, else the level's; zero if null. */
    public static float[] at(@Nullable Wind wind, int blockX, int blockY, int blockZ) {
        if (wind == null) {
            return new float[] {0f, 0f};
        }
        for (WindArea area : wind.areas()) {
            if (area.contains(blockX, blockY, blockZ)) {
                return new float[] {area.x(), area.z()};
            }
        }
        return new float[] {wind.x(), wind.z()};
    }
}
