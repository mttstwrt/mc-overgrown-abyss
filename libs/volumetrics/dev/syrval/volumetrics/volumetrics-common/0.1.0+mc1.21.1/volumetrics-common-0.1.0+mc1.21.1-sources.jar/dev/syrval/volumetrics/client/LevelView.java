package dev.syrval.volumetrics.client;

import net.minecraft.client.Camera;
import org.joml.Matrix4f;

/**
 * What the level was drawn with this frame. The game keeps none of it where it could be read afterwards: the
 * projection, with view bobbing and the nausea warp multiplied into it, exists only as an argument of the call
 * that draws the level. The matrices are the game's own objects, good for as long as the listener runs.
 *
 * @param viewRotation turns a direction from world space into view space
 * @param projection   the projection the level's depth was written with
 * @param partialTick  how far the frame is into the current tick, 0 to 1
 */
public record LevelView(Camera camera, Matrix4f viewRotation, Matrix4f projection, float partialTick) {}
