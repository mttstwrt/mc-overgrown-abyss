package dev.syrval.volumetrics.sim;

import java.util.Arrays;

/**
 * Counts blocks by the cell they are in, and remembers where in the world they were on average. A cell is the
 * finest thing the simulation knows, so all the blocks of a kind in one cell can be treated as one thing at their
 * middle, counted that many times.
 */
public final class CellTally {
    private final int[] count;
    private final long[] sumX;
    private final long[] sumY;
    private final long[] sumZ;
    private boolean empty = true;

    public CellTally(int cells) {
        this.count = new int[cells];
        this.sumX = new long[cells];
        this.sumY = new long[cells];
        this.sumZ = new long[cells];
    }

    public int cells() {
        return count.length;
    }

    /** Counts one block, at the given block coordinates, towards a cell. */
    public void add(int cell, int blockX, int blockY, int blockZ) {
        count[cell]++;
        sumX[cell] += blockX;
        sumY[cell] += blockY;
        sumZ[cell] += blockZ;
        empty = false;
    }

    public boolean isEmpty() {
        return empty;
    }

    public int count(int cell) {
        return count[cell];
    }

    /** Mean block coordinate of the blocks counted towards a cell. Only for a cell with a count. */
    public double meanX(int cell) {
        return (double) sumX[cell] / count[cell];
    }

    public double meanY(int cell) {
        return (double) sumY[cell] / count[cell];
    }

    public double meanZ(int cell) {
        return (double) sumZ[cell] / count[cell];
    }

    public void clear() {
        if (empty) {
            return;
        }
        Arrays.fill(count, 0);
        Arrays.fill(sumX, 0);
        Arrays.fill(sumY, 0);
        Arrays.fill(sumZ, 0);
        empty = true;
    }
}
