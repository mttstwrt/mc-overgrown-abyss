package dev.syrval.volumetrics.sim;

/**
 * Moves the gas of one window. One engine is made for each window and keeps whatever it needs between steps; the
 * world around it (what blocks the gas, where the sources are, the stores the gas is kept in, the moves of the
 * window) stays with the caller, which hands over what a step works on as an {@link EngineWindow}.
 */
public interface SimEngine {
    /** Makes the engine of one window. */
    @FunctionalInterface
    interface Factory {
        /**
         * @param size     the size of the window in cells
         * @param cellSize the edge of its cells, in blocks
         * @param coarser  the engine of the next coarser window, or null if this is the coarsest
         */
        SimEngine create(GridSize size, int cellSize, SimEngine coarser);
    }

    /** The name it is chosen by, see {@link SimEngines}. */
    String name();

    /** Steps every kind of gas in the window by {@code stepSeconds}, and leaves each in the store of its {@link EngineWindow.Kind}. */
    void step(EngineWindow window, WindowInputs inputs, float stepSeconds);

    /** The window has moved by these cells (the gas stores have been moved already); for state the engine keeps of its own. */
    default void shift(int dx, int dy, int dz) {}
}
