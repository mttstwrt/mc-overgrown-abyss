package dev.syrval.volumetrics.api;

import com.mojang.serialization.Codec;
import dev.syrval.volumetrics.Volumetrics;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;

/**
 * The mod's datapack registries. Both are loaded with the world and sent to clients, so a server's datapacks
 * decide what gases its players see.
 */
public final class VolumetricsRegistries {
    public static final ResourceKey<Registry<Medium>> MEDIUM = ResourceKey.createRegistryKey(Volumetrics.id("medium"));
    public static final ResourceKey<Registry<EmitterDefinition>> EMITTER = ResourceKey.createRegistryKey(Volumetrics.id("emitter"));

    private VolumetricsRegistries() {}

    /** Each loader registers datapack registries its own way; this hands it what to register, media first. */
    public static void forEach(Sink sink) {
        sink.accept(MEDIUM, Medium.CODEC);
        sink.accept(EMITTER, EmitterDefinition.CODEC);
    }

    @FunctionalInterface
    public interface Sink {
        <T> void accept(ResourceKey<Registry<T>> key, Codec<T> codec);
    }
}
