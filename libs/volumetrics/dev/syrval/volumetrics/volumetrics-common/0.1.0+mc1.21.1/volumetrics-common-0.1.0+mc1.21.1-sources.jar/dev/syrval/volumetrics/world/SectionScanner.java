package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.sim.CellTally;
import dev.syrval.volumetrics.sim.Occupancy;
import dev.syrval.volumetrics.sim.Source;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.PalettedContainer;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * Works out, from a copy of one 16-block chunk section ({@link SectionCopy}), which of its cells gas cannot enter, how
 * brightly each is lit, and which of its blocks give off gas. It reads only the copy and the {@link BlockFlags}
 * table, never the game, so it runs on the scan thread ({@link ScanWorker}); one instance on one thread at a time,
 * since it keeps scratch for a section.
 */
final class SectionScanner {
    private static final int SECTION_BLOCKS = 16;
    private static final int FULL_SKY_LIGHT = 15;
    private static final int LIGHT_BYTES_PER_CELL = 2;
    /** For each axis, X then Y then Z, the side of a cell at its low end and the side at its high end. */
    private static final int[][] SIDES = {{Occupancy.WEST, Occupancy.EAST}, {Occupancy.DOWN, Occupancy.UP}, {Occupancy.NORTH, Occupancy.SOUTH}};
    /**
     * The most cells of one section a rule makes emitters in: half of the cells of a section of the fine window.
     * A rule that matches the surface of something stays far under it; one that matches the inside of the ground
     * would otherwise make an emitter of every cell there is.
     */
    private static final int MAX_CELLS_PER_RULE = 256;

    private final int cellSize;
    private final List<BlockEmitterRule> rules;
    private final BlockFlags blockFlags;
    private final int cellsPerSection;
    private final int cells;
    /**
     * Scratch for one section: how many of each cell's blocks are solid, in all and, for each axis, in each of the
     * one-block layers the cell is made of across that axis.
     */
    private final int[] solidBlocks;
    private final int[][] solidInLayer = new int[SIDES.length][];
    /** Scratch for one section: for each rule, the blocks that match it, counted by cell. */
    private final CellTally[] matched;
    private final boolean[] limitReported;
    private final List<Emitter> found = new ArrayList<>();
    /** The state last looked up in the table, and its index there: neighbouring blocks are mostly the same. */
    private @Nullable BlockState lastState;
    private int lastIndex = -1;

    /** @param blockFlags what is known of each block state, the {@code rules} included */
    SectionScanner(int cellSize, List<BlockEmitterRule> rules, BlockFlags blockFlags) {
        if (SECTION_BLOCKS % cellSize != 0) {
            throw new IllegalArgumentException("Cell size must divide a chunk section, got " + cellSize);
        }
        this.cellSize = cellSize;
        this.rules = rules;
        this.blockFlags = blockFlags;
        this.cellsPerSection = SECTION_BLOCKS / cellSize;
        this.cells = cellsPerSection * cellsPerSection * cellsPerSection;
        this.solidBlocks = new int[cells];
        for (int axis = 0; axis < SIDES.length; axis++) {
            solidInLayer[axis] = new int[cells * cellSize];
        }
        this.matched = new CellTally[rules.size()];
        for (int rule = 0; rule < matched.length; rule++) {
            matched[rule] = new CellTally(cells);
        }
        this.limitReported = new boolean[rules.size()];
    }

    /** What the section's blocks and light come to, cell by cell. */
    SectionResult scan(SectionCopy copy) {
        byte[] light = new byte[cells * LIGHT_BYTES_PER_CELL];
        return switch (copy.kind()) {
            // Below the world nothing moves; above it is open sky.
            case BELOW_WORLD -> fill(copy, SectionResult.CLOSED_CELL, 0, light);
            case ABOVE_WORLD -> fill(copy, (byte) 0, FULL_SKY_LIGHT, light);
            case LIGHT_ONLY -> {
                readLight(copy, light);
                yield new SectionResult(copy.window(), copy.epoch(), copy.sectionX(), copy.sectionY(), copy.sectionZ(), null, light, null);
            }
            case FULL -> scanBlocks(copy, light);
        };
    }

    private SectionResult scanBlocks(SectionCopy copy, byte[] light) {
        List<Emitter> emitters = readBlocks(copy.states(), copy.sectionX(), copy.sectionY(), copy.sectionZ());
        readLight(copy, light);

        byte[] occupancy = new byte[cells];
        int blocksPerCell = cellSize * cellSize * cellSize;
        // A layer with a quarter of it missing still stops gas: a floor with the odd hole, or a stair, is a floor.
        int blocksPerSolidLayer = (3 * cellSize * cellSize + 3) / 4;
        for (int y = 0; y < cellsPerSection; y++) {
            for (int z = 0; z < cellsPerSection; z++) {
                for (int x = 0; x < cellsPerSection; x++) {
                    int cell = cellIndex(x, y, z);
                    boolean closed = solidBlocks[cell] == blocksPerCell;
                    int sides = 0;
                    for (int axis = 0; axis < SIDES.length; axis++) {
                        // A solid layer anywhere in a half of the cell closes the side that half is on: in a cell
                        // several blocks deep a floor need not lie at the very bottom to hold gas up.
                        if (hasSolidLayer(axis, cell, 0, cellSize / 2, blocksPerSolidLayer)) {
                            sides |= SIDES[axis][0];
                        }
                        if (hasSolidLayer(axis, cell, cellSize / 2, cellSize, blocksPerSolidLayer)) {
                            sides |= SIDES[axis][1];
                        }
                    }
                    occupancy[cell] = closed ? SectionResult.CLOSED_CELL : (byte) sides;
                }
            }
        }
        return new SectionResult(copy.window(), copy.epoch(), copy.sectionX(), copy.sectionY(), copy.sectionZ(), occupancy, light,
                emitters);
    }

    private void readLight(SectionCopy copy, byte[] light) {
        // A quarter of the way in from the corners: the corners themselves in a cell of two blocks.
        int low = cellSize / 4;
        int high = cellSize - 1 - low;
        for (int y = 0; y < cellsPerSection; y++) {
            for (int z = 0; z < cellsPerSection; z++) {
                for (int x = 0; x < cellsPerSection; x++) {
                    // The brighter of two blocks towards opposite corners of a cell. Light inside a full block is 0,
                    // so one sample could land in the only solid block of an otherwise open cell.
                    int lowX = cellSize * x + low;
                    int highY = cellSize * y + high;
                    int lowZ = cellSize * z + low;
                    int highX = cellSize * x + high;
                    int lowY = cellSize * y + low;
                    int highZ = cellSize * z + high;
                    int at = cellIndex(x, y, z) * LIGHT_BYTES_PER_CELL;
                    light[at] = (byte) Math.max(copy.skyLightAt(lowX, highY, lowZ), copy.skyLightAt(highX, lowY, highZ));
                    light[at + 1] = (byte) Math.max(copy.blockLightAt(lowX, highY, lowZ), copy.blockLightAt(highX, lowY, highZ));
                }
            }
        }
    }

    /** Counts the section's solid blocks into the scratch and returns the emitters at its blocks. */
    private List<Emitter> readBlocks(@Nullable PalettedContainer<BlockState> states, int sectionX, int sectionY, int sectionZ) {
        Arrays.fill(solidBlocks, 0);
        for (int[] layer : solidInLayer) {
            Arrays.fill(layer, 0);
        }
        for (CellTally tally : matched) {
            tally.clear();
        }
        if (states == null) {
            return List.of();
        }
        for (int y = 0; y < SECTION_BLOCKS; y++) {
            for (int z = 0; z < SECTION_BLOCKS; z++) {
                for (int x = 0; x < SECTION_BLOCKS; x++) {
                    BlockState state = states.get(x, y, z);
                    if (state != lastState) {
                        lastState = state;
                        lastIndex = blockFlags.index(state);
                    }
                    int index = lastIndex;
                    if (blockFlags.isAir(index)) {
                        continue;
                    }
                    int cell = cellIndex(x / cellSize, y / cellSize, z / cellSize);
                    if (blockFlags.keepsGasOut(index)) {
                        solidBlocks[cell]++;
                        solidInLayer[0][cell * cellSize + x % cellSize]++;
                        solidInLayer[1][cell * cellSize + y % cellSize]++;
                        solidInLayer[2][cell * cellSize + z % cellSize]++;
                    }
                    for (int rule : blockFlags.rules(index)) {
                        matched[rule].add(cell, SectionPos.sectionToBlockCoord(sectionX, x), SectionPos.sectionToBlockCoord(sectionY, y),
                                SectionPos.sectionToBlockCoord(sectionZ, z));
                    }
                }
            }
        }
        found.clear();
        addEmitters(found);
        return found.isEmpty() ? List.of() : List.copyOf(found);
    }

    /**
     * One emitter for each cell that holds blocks of a rule, in the middle of those blocks and counted as that
     * many. The simulation cannot tell blocks in one cell apart, so nothing is lost, and a floor of such blocks
     * comes to an emitter a cell however many blocks it is made of.
     */
    private void addEmitters(List<Emitter> emitters) {
        for (int index = 0; index < matched.length; index++) {
            CellTally tally = matched[index];
            if (tally.isEmpty()) {
                continue;
            }
            BlockEmitterRule rule = rules.get(index);
            int made = 0;
            for (int cell = 0; cell < tally.cells(); cell++) {
                int blocks = tally.count(cell);
                if (blocks == 0) {
                    continue;
                }
                if (made == MAX_CELLS_PER_RULE) {
                    reportLimit(index);
                    break;
                }
                // A block's anchor is the middle of its floor.
                Vec3 anchor = new Vec3(tally.meanX(cell) + 0.5, tally.meanY(cell), tally.meanZ(cell) + 0.5).add(rule.offset());
                emitters.add(new Emitter(rule.medium(), new Source(rule.shape().at(anchor), rule.rate(), blocks)));
                made++;
            }
        }
    }

    private void reportLimit(int rule) {
        if (limitReported[rule]) {
            return;
        }
        limitReported[rule] = true;
        Volumetrics.LOGGER.warn("Emitter {} matches blocks in more than {} cells of one chunk section; the rest of such a section gives off nothing",
                rules.get(rule).id(), MAX_CELLS_PER_RULE);
    }

    private boolean hasSolidLayer(int axis, int cell, int fromLayer, int toLayer, int blocksPerSolidLayer) {
        for (int layer = fromLayer; layer < toLayer; layer++) {
            if (solidInLayer[axis][cell * cellSize + layer] >= blocksPerSolidLayer) {
                return true;
            }
        }
        return false;
    }

    private SectionResult fill(SectionCopy copy, byte occupancy, int skyLight, byte[] light) {
        byte[] filled = new byte[cells];
        Arrays.fill(filled, occupancy);
        for (int cell = 0; cell < cells; cell++) {
            light[cell * LIGHT_BYTES_PER_CELL] = (byte) skyLight;
        }
        return new SectionResult(copy.window(), copy.epoch(), copy.sectionX(), copy.sectionY(), copy.sectionZ(), filled, light,
                List.of());
    }

    private int cellIndex(int x, int y, int z) {
        return x + cellsPerSection * (z + cellsPerSection * y);
    }
}
