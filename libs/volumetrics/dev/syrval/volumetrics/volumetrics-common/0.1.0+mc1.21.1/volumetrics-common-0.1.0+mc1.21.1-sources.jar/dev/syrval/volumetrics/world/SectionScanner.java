package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.sim.CellTally;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.sim.Occupancy;
import dev.syrval.volumetrics.sim.Source;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.DataLayer;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.level.lighting.LayerLightEventListener;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * Reads one 16-block chunk section of the client's world into the window: which cells gas cannot enter, how
 * brightly each is lit, and which of its blocks give off gas. Client thread only.
 */
final class SectionScanner {
    private static final int SECTION_BLOCKS = 16;
    private static final int FULL_SKY_LIGHT = 15;
    /** For each axis, X then Y then Z, the side of a cell at its low end and the side at its high end. */
    private static final int[][] SIDES = {{Occupancy.WEST, Occupancy.EAST}, {Occupancy.DOWN, Occupancy.UP}, {Occupancy.NORTH, Occupancy.SOUTH}};
    /**
     * The most cells of one section a rule makes emitters in: half of the cells of a section of the fine window.
     * A rule that matches the surface of something stays far under it; one that matches the inside of the ground
     * would otherwise make an emitter of every cell there is.
     */
    private static final int MAX_CELLS_PER_RULE = 256;

    private final GridSize size;
    private final int cellSize;
    private final List<BlockEmitterRule> rules;
    private final int cellsPerSection;
    /**
     * Scratch for one section: how many of each cell's blocks are solid, in all and, for each axis, in each of the
     * one-block layers the cell is made of across that axis.
     */
    private final int[] solidBlocks;
    private final int[][] solidInLayer = new int[SIDES.length][];
    /** Scratch for one section: for each rule, the blocks that match it, counted by cell. */
    private final CellTally[] matched;
    private final boolean[] limitReported;
    private final BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

    SectionScanner(GridSize size, int cellSize, List<BlockEmitterRule> rules) {
        if (SECTION_BLOCKS % cellSize != 0) {
            throw new IllegalArgumentException("Cell size must divide a chunk section, got " + cellSize);
        }
        this.size = size;
        this.cellSize = cellSize;
        this.rules = rules;
        this.cellsPerSection = SECTION_BLOCKS / cellSize;
        int cells = cellsPerSection * cellsPerSection * cellsPerSection;
        this.solidBlocks = new int[cells];
        for (int axis = 0; axis < SIDES.length; axis++) {
            solidInLayer[axis] = new int[cells * cellSize];
        }
        this.matched = new CellTally[rules.size()];
        for (int rule = 0; rule < matched.length; rule++) {
            matched[rule] = new CellTally(cells);
        }
        this.limitReported = new boolean[rules.size()];
    }

    enum Result {
        /** The section is outside the window or its chunk is not loaded; its cells keep what they had. */
        SKIPPED,
        UNCHANGED,
        /** At least one cell became blocked or open, so the simulation needs a fresh copy of the occupancy. */
        OCCUPANCY_CHANGED
    }

    /** Emitters found at the section's blocks are added to {@code emitters}; the caller empties it beforehand. */
    Result scan(ClientLevel level, GridPlacement placement, int sectionX, int sectionY, int sectionZ,
                Occupancy occupancy, LightGrid light, List<Emitter> emitters) {
        int cellX = sectionX * cellsPerSection - placement.originX();
        int cellY = sectionY * cellsPerSection - placement.originY();
        int cellZ = sectionZ * cellsPerSection - placement.originZ();
        if (!size.contains(cellX, cellY, cellZ)
                || !size.contains(cellX + cellsPerSection - 1, cellY + cellsPerSection - 1, cellZ + cellsPerSection - 1)) {
            return Result.SKIPPED;
        }
        // Below the world nothing moves; above it is open sky.
        if (sectionY < level.getMinSection()) {
            return fill(occupancy, light, cellX, cellY, cellZ, true, 0);
        }
        if (sectionY >= level.getMaxSection()) {
            return fill(occupancy, light, cellX, cellY, cellZ, false, FULL_SKY_LIGHT);
        }
        LevelChunk chunk = level.getChunkSource().getChunk(sectionX, sectionZ, ChunkStatus.FULL, false);
        if (chunk == null) {
            return Result.SKIPPED;
        }

        readBlocks(level, chunk.getSection(chunk.getSectionIndexFromSectionY(sectionY)), sectionX, sectionY, sectionZ, emitters);
        writeLight(level, SectionPos.of(sectionX, sectionY, sectionZ), cellX, cellY, cellZ, light);

        boolean changed = false;
        int blocksPerCell = cellSize * cellSize * cellSize;
        // A layer with a quarter of it missing still stops gas: a floor with the odd hole, or a stair, is a floor.
        int blocksPerSolidLayer = (3 * cellSize * cellSize + 3) / 4;
        for (int y = 0; y < cellsPerSection; y++) {
            for (int z = 0; z < cellsPerSection; z++) {
                for (int x = 0; x < cellsPerSection; x++) {
                    int cell = cellIndex(x, y, z);
                    boolean closed = solidBlocks[cell] == blocksPerCell;
                    int sides = 0;
                    for (int axis = 0; axis < SIDES.length; axis++) {
                        // A solid layer anywhere in a half of the cell closes the side that half is on: in a cell
                        // several blocks deep a floor need not lie at the very bottom to hold gas up.
                        if (hasSolidLayer(axis, cell, 0, cellSize / 2, blocksPerSolidLayer)) {
                            sides |= SIDES[axis][0];
                        }
                        if (hasSolidLayer(axis, cell, cellSize / 2, cellSize, blocksPerSolidLayer)) {
                            sides |= SIDES[axis][1];
                        }
                    }
                    changed |= write(occupancy, cellX + x, cellY + y, cellZ + z, closed, sides);
                }
            }
        }
        return changed ? Result.OCCUPANCY_CHANGED : Result.UNCHANGED;
    }

    /**
     * Reads only how the cells of a section are lit, which is a small part of the work of {@link #scan}: for a
     * section whose blocks are known not to have changed. Does nothing for a section outside the window or the
     * world, or whose chunk is not loaded.
     */
    void readLight(ClientLevel level, GridPlacement placement, int sectionX, int sectionY, int sectionZ, LightGrid light) {
        int cellX = sectionX * cellsPerSection - placement.originX();
        int cellY = sectionY * cellsPerSection - placement.originY();
        int cellZ = sectionZ * cellsPerSection - placement.originZ();
        if (!size.contains(cellX, cellY, cellZ)
                || !size.contains(cellX + cellsPerSection - 1, cellY + cellsPerSection - 1, cellZ + cellsPerSection - 1)
                || sectionY < level.getMinSection() || sectionY >= level.getMaxSection()
                || level.getChunkSource().getChunk(sectionX, sectionZ, ChunkStatus.FULL, false) == null) {
            return;
        }
        writeLight(level, SectionPos.of(sectionX, sectionY, sectionZ), cellX, cellY, cellZ, light);
    }

    private void writeLight(ClientLevel level, SectionPos sectionPos, int cellX, int cellY, int cellZ, LightGrid light) {
        LayerLightEventListener skyLight = level.getLightEngine().getLayerListener(LightLayer.SKY);
        LayerLightEventListener blockLight = level.getLightEngine().getLayerListener(LightLayer.BLOCK);
        DataLayer skyData = skyLight.getDataLayerData(sectionPos);
        DataLayer blockData = blockLight.getDataLayerData(sectionPos);
        for (int y = 0; y < cellsPerSection; y++) {
            for (int z = 0; z < cellsPerSection; z++) {
                for (int x = 0; x < cellsPerSection; x++) {
                    light.set(cellX + x, cellY + y, cellZ + z,
                            cellLight(skyLight, skyData, sectionPos, x, y, z),
                            cellLight(blockLight, blockData, sectionPos, x, y, z));
                }
            }
        }
    }

    private void readBlocks(ClientLevel level, LevelChunkSection section, int sectionX, int sectionY, int sectionZ, List<Emitter> emitters) {
        Arrays.fill(solidBlocks, 0);
        for (int[] layer : solidInLayer) {
            Arrays.fill(layer, 0);
        }
        for (CellTally tally : matched) {
            tally.clear();
        }
        if (section.hasOnlyAir()) {
            return;
        }
        for (int y = 0; y < SECTION_BLOCKS; y++) {
            for (int z = 0; z < SECTION_BLOCKS; z++) {
                for (int x = 0; x < SECTION_BLOCKS; x++) {
                    BlockState state = section.getBlockState(x, y, z);
                    if (state.isAir()) {
                        continue;
                    }
                    pos.set(SectionPos.sectionToBlockCoord(sectionX, x), SectionPos.sectionToBlockCoord(sectionY, y),
                            SectionPos.sectionToBlockCoord(sectionZ, z));
                    // Gas is kept out of water and lava, and out of anything that is a full block either to walk
                    // into (glass) or to look at (mud, which is a little short of full to walk on). It drifts
                    // through everything else: slabs, fences, plants.
                    if (!state.getFluidState().isEmpty() || state.isSolidRender(level, pos) || state.isCollisionShapeFullBlock(level, pos)) {
                        int cell = cellIndex(x / cellSize, y / cellSize, z / cellSize);
                        solidBlocks[cell]++;
                        solidInLayer[0][cell * cellSize + x % cellSize]++;
                        solidInLayer[1][cell * cellSize + y % cellSize]++;
                        solidInLayer[2][cell * cellSize + z % cellSize]++;
                    }
                    for (int rule = 0; rule < matched.length; rule++) {
                        if (rules.get(rule).matches(state)) {
                            matched[rule].add(cellIndex(x / cellSize, y / cellSize, z / cellSize), pos.getX(), pos.getY(), pos.getZ());
                        }
                    }
                }
            }
        }
        addEmitters(emitters);
    }

    /**
     * One emitter for each cell that holds blocks of a rule, in the middle of those blocks and counted as that
     * many. The simulation cannot tell blocks in one cell apart, so nothing is lost, and a floor of such blocks
     * comes to an emitter a cell however many blocks it is made of.
     */
    private void addEmitters(List<Emitter> emitters) {
        for (int index = 0; index < matched.length; index++) {
            CellTally tally = matched[index];
            if (tally.isEmpty()) {
                continue;
            }
            BlockEmitterRule rule = rules.get(index);
            int made = 0;
            for (int cell = 0; cell < tally.cells(); cell++) {
                int blocks = tally.count(cell);
                if (blocks == 0) {
                    continue;
                }
                if (made == MAX_CELLS_PER_RULE) {
                    reportLimit(index);
                    break;
                }
                // A block's anchor is the middle of its floor.
                Vec3 anchor = new Vec3(tally.meanX(cell) + 0.5, tally.meanY(cell), tally.meanZ(cell) + 0.5).add(rule.offset());
                emitters.add(new Emitter(rule.medium(), new Source(rule.shape().at(anchor), rule.rate(), blocks)));
                made++;
            }
        }
    }

    private void reportLimit(int rule) {
        if (limitReported[rule]) {
            return;
        }
        limitReported[rule] = true;
        Volumetrics.LOGGER.warn("Emitter {} matches blocks in more than {} cells of one chunk section; the rest of such a section gives off nothing",
                rules.get(rule).id(), MAX_CELLS_PER_RULE);
    }

    /**
     * The brighter of two blocks towards opposite corners of a cell. Light inside a full block is 0, so one
     * sample could land in the only solid block of an otherwise open cell.
     */
    private int cellLight(LayerLightEventListener listener, @Nullable DataLayer data, SectionPos sectionPos, int x, int y, int z) {
        // A quarter of the way in from the corners: the corners themselves in a cell of two blocks.
        int low = cellSize / 4;
        int high = cellSize - 1 - low;
        return Math.max(
                blockLight(listener, data, sectionPos, cellSize * x + low, cellSize * y + high, cellSize * z + low),
                blockLight(listener, data, sectionPos, cellSize * x + high, cellSize * y + low, cellSize * z + high));
    }

    private int blockLight(LayerLightEventListener listener, @Nullable DataLayer data, SectionPos sectionPos, int x, int y, int z) {
        if (data != null) {
            return data.get(x, y, z);
        }
        // A section with no light data of its own takes its values from elsewhere (open sky, say); ask the engine.
        pos.set(sectionPos.minBlockX() + x, sectionPos.minBlockY() + y, sectionPos.minBlockZ() + z);
        return listener.getLightValue(pos);
    }

    private boolean hasSolidLayer(int axis, int cell, int fromLayer, int toLayer, int blocksPerSolidLayer) {
        for (int layer = fromLayer; layer < toLayer; layer++) {
            if (solidInLayer[axis][cell * cellSize + layer] >= blocksPerSolidLayer) {
                return true;
            }
        }
        return false;
    }

    /** Sets a cell's occupancy and reports whether that changed anything. */
    private static boolean write(Occupancy occupancy, int x, int y, int z, boolean closed, int solidSides) {
        if (occupancy.isBlocked(x, y, z) == closed && (closed || occupancy.solidSides(x, y, z) == solidSides)) {
            return false;
        }
        if (closed) {
            occupancy.setBlocked(x, y, z, true);
        } else {
            occupancy.setSolidSides(x, y, z, solidSides);
        }
        return true;
    }

    private Result fill(Occupancy occupancy, LightGrid light, int cellX, int cellY, int cellZ, boolean blocked, int skyLight) {
        boolean changed = false;
        for (int y = cellY; y < cellY + cellsPerSection; y++) {
            for (int z = cellZ; z < cellZ + cellsPerSection; z++) {
                for (int x = cellX; x < cellX + cellsPerSection; x++) {
                    changed |= write(occupancy, x, y, z, blocked, 0);
                    light.set(x, y, z, skyLight, 0);
                }
            }
        }
        return changed ? Result.OCCUPANCY_CHANGED : Result.UNCHANGED;
    }

    private int cellIndex(int x, int y, int z) {
        return x + cellsPerSection * (z + cellsPerSection * y);
    }
}
