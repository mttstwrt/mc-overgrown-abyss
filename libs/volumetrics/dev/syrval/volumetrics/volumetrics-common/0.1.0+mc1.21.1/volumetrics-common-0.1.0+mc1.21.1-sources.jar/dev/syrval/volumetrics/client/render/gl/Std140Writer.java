package dev.syrval.volumetrics.client.render.gl;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import org.joml.Matrix4f;
import org.joml.Vector4f;

/**
 * Writes the fields of a GLSL uniform block into a buffer by the std140 rules, one call a field in the block's
 * order. Newer versions of the game ship a builder with these same calls; this version has no uniform blocks
 * of its own.
 *
 * <p>The rules, for the types here: a float or an int is 4 bytes and starts on a multiple of 4; a vec2 is 8 and
 * starts on a multiple of 8; a vec3 is 12 and a vec4 16, and both start on a multiple of 16, as does a mat4 of
 * 64. So a float straight after a vec3 fills the gap the vec3 leaves.
 */
public final class Std140Writer {
    private final ByteBuffer out;

    /** Writes from the start of the buffer, whatever its position was. */
    public Std140Writer(ByteBuffer out) {
        this.out = out.order(ByteOrder.nativeOrder());
        out.clear();
    }

    public Std140Writer putFloat(float value) {
        align(4);
        out.putFloat(value);
        return this;
    }

    public Std140Writer putInt(int value) {
        align(4);
        out.putInt(value);
        return this;
    }

    public Std140Writer putVec2(float x, float y) {
        align(8);
        out.putFloat(x).putFloat(y);
        return this;
    }

    public Std140Writer putVec3(float x, float y, float z) {
        align(16);
        out.putFloat(x).putFloat(y).putFloat(z);
        return this;
    }

    public Std140Writer putVec4(float x, float y, float z, float w) {
        align(16);
        out.putFloat(x).putFloat(y).putFloat(z).putFloat(w);
        return this;
    }

    public Std140Writer putVec4(Vector4f value) {
        return putVec4(value.x, value.y, value.z, value.w);
    }

    public Std140Writer putIVec4(int x, int y, int z, int w) {
        align(16);
        out.putInt(x).putInt(y).putInt(z).putInt(w);
        return this;
    }

    /** Column by column, as GLSL keeps a matrix. */
    public Std140Writer putMat4f(Matrix4f value) {
        align(16);
        // One float at a time: the matrix's own way of writing itself takes any buffer for one outside the heap.
        out.putFloat(value.m00()).putFloat(value.m01()).putFloat(value.m02()).putFloat(value.m03());
        out.putFloat(value.m10()).putFloat(value.m11()).putFloat(value.m12()).putFloat(value.m13());
        out.putFloat(value.m20()).putFloat(value.m21()).putFloat(value.m22()).putFloat(value.m23());
        out.putFloat(value.m30()).putFloat(value.m31()).putFloat(value.m32()).putFloat(value.m33());
        return this;
    }

    /** Bytes the block takes with what has been written: a block's size is a multiple of 16. */
    public int blockBytes() {
        return (out.position() + 15) & ~15;
    }

    private void align(int bytes) {
        out.position((out.position() + bytes - 1) & -bytes);
    }
}
