package dev.syrval.volumetrics.api;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.phys.Vec3;

/**
 * Something that gives off gas, and the rule for where it is found. Datapacks define them in
 * {@code data/<namespace>/volumetrics/emitter/<name>.json}.
 *
 * @param medium    the gas, by its id in the medium registry
 * @param shape     the region filled, relative to the anchor the placement gives
 * @param offset    moves the shape from the anchor, in blocks
 * @param rate      density each cell in the shape gains per second, up to the medium's max density
 * @param placement where the emitters are
 */
public record EmitterDefinition(ResourceKey<Medium> medium, EmitterShape shape, Vec3 offset, float rate, Placement placement) {
    public static final Codec<EmitterDefinition> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            ResourceKey.codec(VolumetricsRegistries.MEDIUM).fieldOf("medium").forGetter(EmitterDefinition::medium),
            EmitterShape.CODEC.fieldOf("shape").forGetter(EmitterDefinition::shape),
            Vec3.CODEC.optionalFieldOf("offset", Vec3.ZERO).forGetter(EmitterDefinition::offset),
            Codec.floatRange(0f, 64f).fieldOf("rate").forGetter(EmitterDefinition::rate),
            Placement.CODEC.fieldOf("placement").forGetter(EmitterDefinition::placement)
    ).apply(instance, EmitterDefinition::new));
}
