package dev.syrval.volumetrics.client.render.gl;

import com.mojang.blaze3d.platform.GlStateManager;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import net.minecraft.server.packs.resources.ResourceProvider;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL42;
import org.lwjgl.opengl.GL43;

/**
 * A compute shader that writes one RGBA8 texture as a storage image, read from {@code assets/volumetrics/shaders}.
 * Only for a context {@link GlCompute#detect} found able. Like {@link GlProgram} it goes through the game's
 * {@code GlStateManager} for the program, which a shader mod caches.
 */
public final class GlComputeProgram implements AutoCloseable {
    private static final String VERSION = "#version 430\n";
    /** The image the shader writes is bound to the highest image unit, away from the low ones a shader pack binds from 0. */
    private final int imageUnit = GL11.glGetInteger(GL42.GL_MAX_IMAGE_UNITS) - 1;
    private final int id;

    /**
     * @param shader  path of the compute shader under {@code assets/volumetrics/shaders}, without a version line
     * @param defines each becomes a {@code #define} at the top of the shader
     */
    public GlComputeProgram(ResourceProvider resources, String shader, Map<String, String> defines) {
        String header = VERSION + defines.entrySet().stream()
                .map(define -> "#define " + define.getKey() + " " + define.getValue() + "\n")
                .collect(Collectors.joining());
        int compute = GlProgram.compile(GL43.GL_COMPUTE_SHADER, shader, header + GlProgram.source(resources, shader, 0));
        this.id = GlStateManager.glCreateProgram();
        GlStateManager.glAttachShader(id, compute);
        GlStateManager.glLinkProgram(id);
        GlStateManager.glDeleteShader(compute);
        if (GlStateManager.glGetProgrami(id, GL20.GL_LINK_STATUS) == GL11.GL_FALSE) {
            String log = GlStateManager.glGetProgramInfoLog(id, 32768);
            GlStateManager.glDeleteProgram(id);
            throw new IllegalStateException("Could not link " + shader + ": " + log);
        }
    }

    /**
     * Runs the shader with a texture bound as its {@code Density} image, and makes what it wrote visible to the texture
     * fetches that come after. The program that was current is put back.
     *
     * @param uniforms sets the shader's uniforms with {@link #setInt4} and {@link #setFloat}, while it is current
     */
    public void dispatch(int texture, int groupsX, int groupsY, int groupsZ, Consumer<GlComputeProgram> uniforms) {
        int before = GlStateManager._getInteger(GL20.GL_CURRENT_PROGRAM);
        GlStateManager._glUseProgram(id);
        GL42.glBindImageTexture(imageUnit, texture, 0, false, 0, GL15.GL_WRITE_ONLY, GL11.GL_RGBA8);
        GL20.glUniform1i(GlStateManager._glGetUniformLocation(id, "Density"), imageUnit);
        uniforms.accept(this);
        GL43.glDispatchCompute(groupsX, groupsY, groupsZ);
        GL42.glMemoryBarrier(GL42.GL_SHADER_IMAGE_ACCESS_BARRIER_BIT | GL42.GL_TEXTURE_FETCH_BARRIER_BIT);
        GL42.glBindImageTexture(imageUnit, 0, 0, false, 0, GL15.GL_READ_ONLY, GL11.GL_RGBA8);
        GlStateManager._glUseProgram(before);
    }

    public void setInt4(String uniform, int x, int y, int z, int w) {
        GL20.glUniform4i(GlStateManager._glGetUniformLocation(id, uniform), x, y, z, w);
    }

    public void setFloat(String uniform, float value) {
        GL20.glUniform1f(GlStateManager._glGetUniformLocation(id, uniform), value);
    }

    @Override
    public void close() {
        GlStateManager.glDeleteProgram(id);
    }
}
