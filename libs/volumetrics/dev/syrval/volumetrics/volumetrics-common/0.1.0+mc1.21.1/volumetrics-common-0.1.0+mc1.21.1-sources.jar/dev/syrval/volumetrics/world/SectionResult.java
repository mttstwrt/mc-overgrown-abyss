package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.sim.Occupancy;
import java.util.List;
import org.jspecify.annotations.Nullable;

/**
 * What the scan made of one chunk section, for the simulation thread to write into its window. Cells are the section's
 * own, numbered X fastest, then Z, then Y. Handed over once; nobody changes it after.
 *
 * @param epoch     how many times the window had moved when the section was copied
 * @param cells     each cell as {@link Occupancy} keeps it: its solid sides, or {@link #CLOSED_CELL} if no gas can be
 *                  in it at all; null when only the section's light was read
 * @param light     each cell's sky light and then block light, 0 to 15, two bytes a cell
 * @param emitters  the emitters at the section's blocks, never changed; null when only the light was read
 */
record SectionResult(int window, int epoch, int sectionX, int sectionY, int sectionZ, byte @Nullable [] cells, byte[] light,
                     @Nullable List<Emitter> emitters) {
    static final int CLOSED = 1 << 6;
    static final byte CLOSED_CELL = (byte) (CLOSED | Occupancy.WEST | Occupancy.EAST | Occupancy.DOWN | Occupancy.UP
            | Occupancy.NORTH | Occupancy.SOUTH);
}
