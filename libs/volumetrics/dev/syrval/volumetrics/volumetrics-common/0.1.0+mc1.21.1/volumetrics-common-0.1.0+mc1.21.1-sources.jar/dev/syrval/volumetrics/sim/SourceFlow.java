package dev.syrval.volumetrics.sim;

/**
 * How a source pushes the gas around it sideways: along a heading, or towards a point, at a speed, within a reach of
 * its shape. Where the reaches of several sources overlap, their pushes are averaged by weight.
 *
 * @param toward whether {@code x, z} is a point in the world, in blocks, that gas is pushed towards; else a heading,
 *               a vector of length 1 east and south
 * @param speed  blocks per second, above 0 and at most {@link Push#MAX}
 * @param reach  how far beyond the box around the source's shape it pushes, in blocks, not negative; at 0 only inside it
 */
public record SourceFlow(boolean toward, double x, double z, float speed, float reach) {
    public SourceFlow {
        if (!Double.isFinite(x) || !Double.isFinite(z)) {
            throw new IllegalArgumentException("Flow target must be finite, got " + x + ", " + z);
        }
        if (!toward && Math.abs(x * x + z * z - 1) > 1e-4) {
            throw new IllegalArgumentException("Flow heading must have length 1, got " + x + ", " + z);
        }
        if (!(speed > 0 && speed <= Push.MAX)) {
            throw new IllegalArgumentException("Flow speed must be above 0 and at most " + Push.MAX + ", got " + speed);
        }
        if (!(reach >= 0) || !Float.isFinite(reach)) {
            throw new IllegalArgumentException("Flow reach must be finite and not negative, got " + reach);
        }
    }

    /** Along a heading, which is made length 1. */
    public static SourceFlow heading(double x, double z, float speed, float reach) {
        double length = Math.sqrt(x * x + z * z);
        if (!(length > 0) || !Double.isFinite(length)) {
            throw new IllegalArgumentException("Flow heading must be finite and not zero, got " + x + ", " + z);
        }
        return new SourceFlow(false, x / length, z / length, speed, reach);
    }

    /** Towards the vertical line through a point, in blocks. */
    public static SourceFlow toward(double x, double z, float speed, float reach) {
        return new SourceFlow(true, x, z, speed, reach);
    }
}
