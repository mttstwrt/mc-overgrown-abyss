package dev.syrval.volumetrics.sim;

/**
 * How a gas that has a density, rather than a fixed gravity, moves up and down: towards the height where the
 * {@link AmbientProfile} is as dense as it is, faster the further its density is from the air's around it. So it
 * rises from below that height, sinks from above it, and spreads out sideways into a layer there.
 *
 * @param density relative to the air at sea level
 * @param speed   blocks per second the gas sinks where it is twice as dense as the air around it; the speed is in
 *                proportion to the gap between the two densities, relative to the air's, and rising where the gas
 *                is the lighter
 */
public record Buoyancy(float density, float speed) {
    public Buoyancy {
        if (!Float.isFinite(density) || density <= 0) {
            throw new IllegalArgumentException("Density must be finite and positive, got " + density);
        }
        if (!Float.isFinite(speed) || speed < 0) {
            throw new IllegalArgumentException("Speed must be finite and not negative, got " + speed);
        }
    }

    /** A gas as dense as the air {@code blocksAboveSea} blocks above sea level, which therefore settles there. */
    public static Buoyancy settlingAt(AmbientProfile profile, double blocksAboveSea, float speed) {
        return new Buoyancy(profile.density(profile.seaLevel() + blocksAboveSea), speed);
    }

    /** Blocks per second at height {@code y}; positive sinks, negative rises, as {@link MediumParams#gravity()}. */
    public float gravityAt(AmbientProfile profile, double y) {
        float air = profile.density(y);
        return speed * (density - air) / air;
    }

    /**
     * The gravity at the middle of each layer of a window, for {@link GasStepper#step(GasField, Occupancy,
     * MediumParams, GridPlacement, java.util.List, float, float[])}. Where it is faster than a step with the rest of
     * {@code medium} can carry, it is slowed until the step is stable.
     */
    public float[] layerGravity(AmbientProfile profile, GridPlacement placement, int layers, MediumParams medium, float dt) {
        int cellSize = placement.cellSize();
        float otherOutflow = medium.outflowFraction(cellSize, dt) - medium.gravityFraction(cellSize, dt);
        float fastest = Math.max(0f, 0.999f - otherOutflow) * cellSize / dt;
        float[] gravity = new float[layers];
        for (int y = 0; y < layers; y++) {
            float g = gravityAt(profile, placement.centreY(y));
            gravity[y] = Math.max(-fastest, Math.min(fastest, g));
        }
        return gravity;
    }
}
