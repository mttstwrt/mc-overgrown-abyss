package dev.syrval.volumetrics.sim;

/**
 * A slow, turning sideways push for a medium, made from nothing but the medium's id, the game time and its two
 * settings, so every machine that knows those gets the same push. Smooth value noise on the direction, with a gentle
 * wobble of the speed.
 */
public final class Draft {
    /** Ticks in a second of game time. */
    private static final double TICKS_PER_SECOND = 20.0;
    /** The wobble of the speed runs this much faster than the turning of the direction. */
    private static final double WOBBLE_RATE = 1.7;
    /** The speed never falls below this share of the setting. */
    private static final double WOBBLE_FLOOR = 0.6;
    private static final Vector NONE = new Vector(0f, 0f);

    private Draft() {}

    /**
     * @param speed  blocks per second at most, 0 to 16
     * @param period seconds the direction takes to go from one random heading to the next, above 0
     */
    public record Settings(float speed, float period) {
        public Settings {
            if (!(speed >= 0 && speed <= 16)) {
                throw new IllegalArgumentException("Draft speed must be between 0 and 16, got " + speed);
            }
            if (!(period > 0) || !Float.isFinite(period)) {
                throw new IllegalArgumentException("Draft period must be finite and above 0, got " + period);
            }
        }
    }

    /** A push along X (east) and Z (south), in blocks per second. */
    public record Vector(float x, float z) {}

    /**
     * @param mediumHash a number that is the same on every machine for the same medium, such as the hash of its id
     * @param gameTicks  the game time, in ticks
     */
    public static Vector at(int mediumHash, long gameTicks, Settings settings) {
        return at(mediumHash, gameTicks, settings.speed(), settings.period());
    }

    public static Vector at(int mediumHash, long gameTicks, float speed, float periodSeconds) {
        if (speed == 0f) {
            return NONE;
        }
        double t = gameTicks / TICKS_PER_SECOND / periodSeconds;
        double angle = noise(mediumHash, 0x1234, t) * (2 * Math.PI);
        double wobble = WOBBLE_FLOOR + (1 - WOBBLE_FLOOR) * noise(mediumHash, 0x5678, t * WOBBLE_RATE);
        double length = speed * wobble;
        return new Vector((float) (length * StrictMath.cos(angle)), (float) (length * StrictMath.sin(angle)));
    }

    /** Value noise in 0 to 1: random values at whole numbers of {@code t}, eased between them. */
    private static double noise(int seed, int salt, double t) {
        double floor = Math.floor(t);
        double fraction = t - floor;
        long index = (long) floor;
        double eased = fraction * fraction * (3 - 2 * fraction);
        double from = value(seed, salt, index);
        double to = value(seed, salt, index + 1);
        return from + (to - from) * eased;
    }

    /** A number in 0 (inclusive) to 1 (exclusive) for the lattice point, the same every time. */
    private static double value(int seed, int salt, long index) {
        long h = (seed * 0x9E3779B97F4A7C15L) ^ (salt * 0xC2B2AE3D27D4EB4FL) ^ (index * 0x165667B19E3779F9L);
        h ^= h >>> 33;
        h *= 0xFF51AFD7ED558CCDL;
        h ^= h >>> 33;
        h *= 0xC4CEB9FE1A85EC53L;
        h ^= h >>> 33;
        return (h >>> 11) * 0x1.0p-53;
    }
}
