package dev.syrval.volumetrics.client.render;

import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.client.render.gl.GlTexture;
import dev.syrval.volumetrics.sim.AtlasLayout;
import dev.syrval.volumetrics.sim.BrickMask;
import dev.syrval.volumetrics.sim.CellRect;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.world.GasSnapshot;
import dev.syrval.volumetrics.world.GasWorld;
import dev.syrval.volumetrics.world.LightUpdate;
import dev.syrval.volumetrics.world.MainThreadTime;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.List;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;
import org.lwjgl.opengl.GL11;

/**
 * The gas as the simulation made it: each step the simulation takes is quantized and laid out on its own thread, and
 * sent from here to the density textures, with the light and the bricks. The renderer's own upload code, moved here.
 */
final class CpuFields implements GasFields {
    /** Light slices the world scan has changed that are sent to the GPU in one frame, at most. */
    private static final int LIGHT_SLICES_PER_FRAME = 8;
    /** Slices of a whole light update sent each frame, to the texture that is not being read yet. */
    private static final int WHOLE_LIGHT_SLICES_PER_FRAME = 16;

    /** Whether it has been logged that the device has no room for every level, or for every page of one. */
    private static boolean levelsLogged;
    private static boolean pagesLogged;
    /** Where each drawn level lies in the textures below; a level the device has no room for is not drawn. */
    private final LevelAtlas atlas;
    /** The levels of the cascade that are drawn, the finest first. */
    private final DrawnLevel[] levels;
    /**
     * The two density textures. Each level has its newest snapshot in one of them and the one before in the other,
     * which one is which changing each time the level steps.
     */
    private final GlTexture[] density = new GlTexture[2];
    /** How many pages the density textures have room for, as many as the slots in use take up. */
    private int pages = 1;
    /** Each level's light, twice: the shader reads its front copy, and a whole update is built in the other. */
    private final GlTexture lightTexture;
    /** For each level, the bricks either of its two snapshots holds gas in: the march blends the two, so it reads both. */
    private final GlTexture brickTexture;
    /** The kind of gas in each slot at the newest step taken, null for a free slot. */
    private final @Nullable Medium[] slotMedia = new Medium[GasWorld.MAX_KINDS];
    /** A light update partly sent, and how many of its slices have been; null if none is. */
    private @Nullable LightUpdate lightUpdate;
    private int lightUpdateSent;
    /** Time spent sending the whole update in progress, over the frames it has taken so far. */
    private long lightWholeNanos;
    /** Zeros, as many as the largest slice has texels: wipes what a texture held. */
    private final ByteBuffer zeroTexels;
    private final ByteBuffer brickTexels;
    private boolean skipEmptySpace;
    private boolean hasGas;
    private float stepSeconds;
    /** When level 0's newest snapshot was taken: what blending from its previous one is timed from. */
    private long newestNanos;
    private long uploadNanos;
    private long lightMoveNanos;

    /** @param sizes the size of each of the gas world's levels, the finest first */
    CpuFields(List<GridSize> sizes, boolean skipEmptySpace) {
        this.skipEmptySpace = skipEmptySpace;
        int maxTextureSize = GL11.glGetInteger(GL11.GL_MAX_TEXTURE_SIZE);
        this.atlas = LevelAtlas.fit(sizes, maxTextureSize, Long.MAX_VALUE);
        if (atlas.levels() < atlas.wanted() && !levelsLogged) {
            levelsLogged = true;
            Volumetrics.LOGGER.warn("Drawing {} of the {} levels of the gas: the device's textures are at most {} texels across",
                    atlas.levels(), atlas.wanted(), maxTextureSize);
        }
        int sliceCells = 0;
        int bricks = 0;
        for (int level = 0; level < atlas.levels(); level++) {
            GridSize size = atlas.size(level);
            sliceCells = Math.max(sliceCells, size.x() * size.z());
            bricks = Math.max(bricks, size.brickCount());
        }
        this.zeroTexels = ByteBuffer.allocateDirect(sliceCells * GasSnapshot.KINDS_PER_PAGE);
        this.brickTexels = ByteBuffer.allocateDirect(bricks);
        for (int index = 0; index < density.length; index++) {
            density[index] = new GlTexture(GlTexture.Format.RGBA8, atlas.width(), atlas.densityHeight(pages), true, false);
        }
        this.lightTexture = new GlTexture(GlTexture.Format.RG8, atlas.width(), atlas.lightHeight(), true, false);
        this.brickTexture = new GlTexture(GlTexture.Format.R8, atlas.brickWidth(), atlas.brickHeight(), false, false);
        this.levels = new DrawnLevel[atlas.levels()];
        for (int level = 0; level < levels.length; level++) {
            levels[level] = new DrawnLevel(level);
            // A fog may be drawn before any gas is: until then no brick holds any.
            putBricks(levels[level]);
        }
    }

    @Override
    public boolean prepare(GasWorld world, Vec3 camera) {
        stepSeconds = world.stepSeconds();
        long takeStart = System.nanoTime();
        takeNewestStep(world);
        MainThreadTime.add(MainThreadTime.Category.TAKE, System.nanoTime() - takeStart);
        long lightStart = System.nanoTime();
        uploadLight(world);
        MainThreadTime.add(MainThreadTime.Category.LIGHT, System.nanoTime() - lightStart);
        hasGas = false;
        for (DrawnLevel drawn : levels) {
            // Nothing can be drawn before there is light to draw it by.
            if (drawn.lightPlacement == null) {
                return false;
            }
            GridPlacement placement = drawn.buffers[drawn.newest].placement;
            hasGas |= placement != null && (drawn.buffers[0].hasGas || drawn.buffers[1].hasGas);
            // A level that has moved between its two snapshots, or has only one, shows its newest.
            drawn.blends = placement != null && placement.equals(drawn.buffers[1 - drawn.newest].placement);
        }
        return true;
    }

    @Override
    public boolean hasGas() {
        return hasGas;
    }

    @Override
    public FieldLevel[] levels() {
        // The moment shown, in base steps: between level 0's two snapshots, as far on as the time since its newest.
        // Every level is shown at that moment, between its own two snapshots.
        float sinceStep = (System.nanoTime() - newestNanos) / 1e9f;
        double shown = (double) levels[0].fromStep + Math.min(1f, sinceStep / stepSeconds);
        FieldLevel[] fields = new FieldLevel[levels.length];
        for (int index = 0; index < fields.length; index++) {
            DrawnLevel drawn = levels[index];
            fields[index] = new FieldLevel(drawn.box(), drawn.lightPlacement, drawn.size, drawn.pages, drawn.atlas, drawn.column,
                    drawn.brickColumn, atlas.lightSlotHeight() * drawn.lightFront, drawn.blend(shown), drawn.newest,
                    drawn.buffers[drawn.newest].placement, drawn.bricks.bounds().orElse(null));
        }
        return fields;
    }

    @Override
    public @Nullable Medium[] slotMedia() {
        return slotMedia;
    }

    @Override
    public GlTexture density(int index) {
        return density[index];
    }

    @Override
    public GlTexture light() {
        return lightTexture;
    }

    @Override
    public GlTexture bricks() {
        return brickTexture;
    }

    @Override
    public String pages() {
        StringBuilder pages = new StringBuilder();
        for (DrawnLevel level : levels) {
            pages.append(pages.isEmpty() ? "" : ", ").append(level.pages);
        }
        return pages.toString();
    }

    @Override
    public long uploadNanos() {
        return uploadNanos;
    }

    @Override
    public long lightMoveNanos() {
        return lightMoveNanos;
    }

    @Override
    public void setSkipEmptySpace(boolean skipEmptySpace) {
        this.skipEmptySpace = skipEmptySpace;
    }

    @Override
    public FieldSource source() {
        return FieldSource.CPU;
    }

    @Override
    public void close() {
        for (GlTexture texture : density) {
            texture.close();
        }
        lightTexture.close();
        brickTexture.close();
    }

    /**
     * Sends each drawn level's snapshot, if it has stepped since, to the density texture that holds its older one. Each
     * level has snapshots of its own, as often as it steps. Those of a level that is not drawn are given back as they are.
     */
    private void takeNewestStep(GasWorld world) {
        long start = System.nanoTime();
        boolean taken = false;
        for (int level = 0; level < world.levels(); level++) {
            GasSnapshot snapshot = world.takeSnapshot(level);
            if (snapshot == null) {
                continue;
            }
            if (level < levels.length) {
                DrawnLevel drawn = levels[level];
                take(drawn, snapshot, 1 - drawn.newest);
                drawn.newest = 1 - drawn.newest;
                drawn.fromStep = snapshot.fromStep();
                drawn.toStep = snapshot.toStep();
                if (level == 0) {
                    for (int slot = 0; slot < slotMedia.length; slot++) {
                        slotMedia[slot] = snapshot.medium(slot);
                    }
                    newestNanos = System.nanoTime();
                }
                taken = true;
            }
            world.recycle(level, snapshot);
        }
        if (taken) {
            uploadNanos = System.nanoTime() - start;
        }
    }

    /**
     * Sends the light the simulation has changed, in the order it was changed. After a level has moved all of its
     * light goes, a few slices each frame, to the level's back copy of its light while the shader keeps reading the
     * front one by the old place; when the last slice is up the two swap and the level's light is for the new place.
     * Partial updates go to the front copy, a few slices each frame, and what is left of an update waits for the next
     * frame. The light of a level that is not drawn is given back as it comes.
     */
    private void uploadLight(GasWorld world) {
        int partialSent = 0;
        while (true) {
            LightUpdate update = lightUpdate;
            if (update == null) {
                update = world.takeLightUpdate();
                if (update == null) {
                    return;
                }
                if (update.window() >= levels.length) {
                    // A level that is not drawn.
                    for (ByteBuffer slice : update.buffers()) {
                        world.recycleLightSlice(slice);
                    }
                    continue;
                }
                lightUpdate = update;
                lightUpdateSent = 0;
                lightWholeNanos = 0;
            }
            DrawnLevel drawn = levels[update.window()];
            boolean whole = update.whole();
            int row = atlas.lightSlotHeight() * (whole ? 1 - drawn.lightFront : drawn.lightFront);
            int limit = whole ? Math.min(update.slices().length, lightUpdateSent + WHOLE_LIGHT_SLICES_PER_FRAME) : update.slices().length;
            long start = System.nanoTime();
            while (lightUpdateSent < limit && (whole || partialSent < LIGHT_SLICES_PER_FRAME)) {
                int y = update.slices()[lightUpdateSent];
                ByteBuffer slice = update.buffers()[lightUpdateSent];
                lightTexture.upload(slice, drawn.column + drawn.atlas.tileX(y), row + drawn.atlas.tileY(y), drawn.size.x(), drawn.size.z());
                world.recycleLightSlice(slice);
                lightUpdateSent++;
                partialSent += whole ? 0 : 1;
            }
            lightWholeNanos += System.nanoTime() - start;
            if (lightUpdateSent < update.slices().length) {
                return;
            }
            if (whole) {
                drawn.lightFront = 1 - drawn.lightFront;
                drawn.lightPlacement = update.placement();
                lightMoveNanos = lightWholeNanos;
            }
            lightUpdate = null;
        }
    }

    private static boolean inside(CellRect inner, CellRect outer) {
        return inner.x() >= outer.x() && inner.z() >= outer.z()
                && inner.x() + inner.width() <= outer.x() + outer.width() && inner.z() + inner.depth() <= outer.z() + outer.depth();
    }

    /**
     * Sends one simulation step of a level to its part of one of the two density textures, and the bricks of both of
     * its snapshots to its part of the brick texture.
     */
    private void take(DrawnLevel level, GasSnapshot snapshot, int index) {
        if (snapshot.pages() > pages) {
            grow(snapshot.pages());
        }
        LevelBuffer target = level.buffers[index];
        GlTexture texture = density[index];
        AtlasLayout layout = level.atlas;
        for (int page = 0; page < level.pages; page++) {
            for (int y = 0; y < level.size.y(); y++) {
                // Only the part of a slice that holds gas is sent, together with the part that held gas when this
                // texture was last written, which may need wiping.
                CellRect now = snapshot.sliceBounds(page, y);
                CellRect before = target.written[page][y];
                int tileX = level.column + layout.tileX(y);
                int tileY = page * layout.height() + layout.tileY(y);
                if (before != null && (now == null || !inside(before, now))) {
                    texture.upload(zeroTexels, 0, tileX + before.x(), tileY + before.z(), before.width(), before.depth());
                }
                if (now != null) {
                    texture.upload(snapshot.uploadBuffer(), snapshot.uploadOffset(page, y), tileX + now.x(), tileY + now.z(),
                            now.width(), now.depth());
                }
                if (before != null || now != null) {
                    target.written[page][y] = now;
                }
            }
        }
        target.placement = snapshot.placement();
        target.hasGas = snapshot.hasGas();
        target.bricks.set(snapshot.bricks());

        if (skipEmptySpace) {
            level.bricks.set(level.buffers[0].bricks);
            level.bricks.include(level.buffers[1].bricks);
        } else {
            level.bricks.markAll();
        }
        putBricks(level);
    }

    private void putBricks(DrawnLevel level) {
        level.bricks.put(brickTexels);
        brickTexture.upload(brickTexels, level.brickColumn, 0, level.bricks.width(), level.bricks.height());
    }

    /**
     * Makes both density textures again with room for more pages. What they held is lost, for every level: each level's
     * two snapshots are written whole the next times, until then it shows no gas but what it takes next, and until
     * both have been written its newest is not blended with the other.
     */
    private void grow(int wanted) {
        pages = wanted;
        for (int index = 0; index < density.length; index++) {
            density[index].close();
            density[index] = new GlTexture(GlTexture.Format.RGBA8, atlas.width(), atlas.densityHeight(pages), true, false);
        }
        for (DrawnLevel level : levels) {
            level.pages = atlas.pages(level.index, pages);
            if (level.pages < pages && !pagesLogged) {
                pagesLogged = true;
                Volumetrics.LOGGER.warn("Level {} of the gas holds {} of its {} pages: the device's textures are not tall enough",
                        level.index, level.pages, pages);
            }
            level.buffers[0] = new LevelBuffer(level);
            level.buffers[1] = new LevelBuffer(level);
            level.bricks.clear();
            putBricks(level);
        }
    }

    /** What the renderer keeps of one drawn level of the cascade: where it lies in the shared textures, and its state. */
    private final class DrawnLevel {
        final int index;
        final GridSize size;
        final AtlasLayout atlas;
        /** The texel column the level starts at in the density and the light textures, and in the brick texture. */
        final int column;
        final int brickColumn;
        /** How many pages of the density textures the level holds. */
        int pages;
        /** What each of the two density textures holds of the level. */
        final LevelBuffer[] buffers = new LevelBuffer[2];
        /** Which of the two copies of its light the shader reads; a whole update is built in the other. */
        int lightFront;
        /** Where the level was when its light was last sent whole, or null if it never has been. */
        @Nullable GridPlacement lightPlacement;
        /** The bricks either of its two snapshots holds gas in. */
        final BrickMask bricks;
        /** Which of the two density textures holds the level's newest snapshot. */
        int newest;
        /** The base steps the newest snapshot's step began and ended at ({@link GasSnapshot#fromStep}); -1 before the first. */
        long fromStep = -1;
        long toStep = -1;
        /** Whether this frame blends the level's two snapshots; see where it is set. */
        boolean blends;

        DrawnLevel(int index) {
            this.index = index;
            this.size = CpuFields.this.atlas.size(index);
            this.atlas = CpuFields.this.atlas.atlas(index);
            this.column = CpuFields.this.atlas.column(index);
            this.brickColumn = CpuFields.this.atlas.brickColumn(index);
            this.pages = CpuFields.this.atlas.pages(index, CpuFields.this.pages);
            this.buffers[0] = new LevelBuffer(this);
            this.buffers[1] = new LevelBuffer(this);
            this.bricks = new BrickMask(size);
        }

        /** Where the gas of the newest step is, or the light's place before there is any gas. */
        GridPlacement box() {
            GridPlacement placement = buffers[newest].placement;
            return placement != null ? placement : lightPlacement;
        }

        /**
         * How far between its two snapshots the level is shown, 0 at the one before to 1 at the newest, at a moment in
         * base steps; 1 if it is not blended.
         */
        float blend(double shown) {
            if (!blends || toStep <= fromStep) {
                return 1f;
            }
            return (float) Math.clamp((shown - fromStep) / (toStep - fromStep), 0.0, 1.0);
        }
    }

    /** What one of the two density textures holds of a level, and what was last written to it there. */
    private static final class LevelBuffer {
        /** For each page and slice, the part of it that the texture holds gas in, or null if it holds none there. */
        final @Nullable CellRect[][] written;
        final BrickMask bricks;
        @Nullable GridPlacement placement;
        boolean hasGas;

        LevelBuffer(DrawnLevel level) {
            this.written = new CellRect[level.pages][level.size.y()];
            this.bricks = new BrickMask(level.size);
            // A new texture holds whatever was in its memory: the first step written to it must cover every slice.
            for (CellRect[] page : written) {
                Arrays.fill(page, CellRect.of(level.size));
            }
        }
    }
}
