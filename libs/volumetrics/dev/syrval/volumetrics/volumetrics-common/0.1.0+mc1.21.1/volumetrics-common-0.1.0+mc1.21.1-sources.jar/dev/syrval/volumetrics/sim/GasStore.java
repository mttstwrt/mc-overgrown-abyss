package dev.syrval.volumetrics.sim;

import java.util.ArrayDeque;
import java.util.Arrays;

/**
 * The gas of one kind in a window between steps, kept a brick at a time: a brick with no gas in it takes no memory.
 * The stepper works on a {@link GasField}, which holds every cell of the window. A window steps each of its kinds of
 * gas in one such field, loading the kind into it, stepping it and storing it back here, so what a window costs in
 * memory grows with the gas there is and not with how many kinds of it there are.
 *
 * <p>Within a brick the cells lie as they do in the grid: X fastest, then Z, then Y.
 */
public final class GasStore implements GasDensities {
    private static final int BRICK = GridSize.BRICK;
    /** Cells in a brick. */
    public static final int BRICK_CELLS = BRICK * BRICK * BRICK;
    /** Emptied bricks kept for reuse, at most: a cloud that has thinned away leaves no more than this behind. */
    private static final int SPARE_BRICKS = 256;

    private final GridSize size;
    /** By brick index, as {@link GridSize#brickIndex} gives it; null where the brick holds no gas. */
    private float[][] bricks;
    private float[][] shifted;
    private final ArrayDeque<float[]> spare = new ArrayDeque<>();
    private int held;

    public GasStore(GridSize size) {
        this.size = size;
        this.bricks = new float[size.brickCount()][];
        this.shifted = new float[size.brickCount()][];
    }

    /** Where cell {@code (x, y, z)} of a brick, counted from the brick's low corner, lies in its array. */
    public static int inBrick(int x, int y, int z) {
        return x + BRICK * (z + BRICK * y);
    }

    @Override
    public GridSize size() {
        return size;
    }

    public boolean isEmpty() {
        return held == 0;
    }

    /** How many bricks hold gas. */
    public int bricksHeld() {
        return held;
    }

    @Override
    public boolean brickHasGas(int brickX, int brickY, int brickZ) {
        return bricks[size.brickIndex(brickX, brickY, brickZ)] != null;
    }

    @Override
    public float density(int cellX, int cellY, int cellZ) {
        float[] brick = bricks[size.brickOfCell(cellX, cellY, cellZ)];
        return brick == null ? 0f : brick[inBrick(cellX % BRICK, cellY % BRICK, cellZ % BRICK)];
    }

    /** Sum of all densities, as a double so that a million small cells do not round away. */
    public double total() {
        double sum = 0;
        for (float[] brick : bricks) {
            if (brick != null) {
                for (float density : brick) {
                    sum += density;
                }
            }
        }
        return sum;
    }

    /**
     * Puts this gas into a field, which must hold none. Afterwards the field is this gas, and {@link #takeFrom}
     * gives it back.
     */
    public void loadInto(GasField field) {
        requireSameSize(field);
        if (held == 0) {
            return;
        }
        float[] cells = field.current();
        boolean[] hasGas = field.currentHasGas();
        for (int by = 0; by < size.bricksY(); by++) {
            for (int bz = 0; bz < size.bricksZ(); bz++) {
                for (int bx = 0; bx < size.bricksX(); bx++) {
                    int index = size.brickIndex(bx, by, bz);
                    float[] brick = bricks[index];
                    if (brick != null) {
                        copy(brick, cells, bx, by, bz, true);
                        hasGas[index] = true;
                    }
                }
            }
        }
    }

    /**
     * Keeps the gas a field holds now, in place of what this held, and leaves the field empty: every cell of its
     * current buffer zero, ready for the next kind of gas to be loaded into it.
     */
    public void takeFrom(GasField field) {
        requireSameSize(field);
        float[] cells = field.current();
        boolean[] hasGas = field.currentHasGas();
        for (int by = 0; by < size.bricksY(); by++) {
            for (int bz = 0; bz < size.bricksZ(); bz++) {
                for (int bx = 0; bx < size.bricksX(); bx++) {
                    int index = size.brickIndex(bx, by, bz);
                    if (hasGas[index]) {
                        float[] brick = bricks[index];
                        if (brick == null) {
                            brick = fresh();
                            bricks[index] = brick;
                            held++;
                        }
                        copy(brick, cells, bx, by, bz, false);
                        clear(cells, bx, by, bz);
                        hasGas[index] = false;
                    } else if (bricks[index] != null) {
                        release(index);
                    }
                }
            }
        }
    }

    /**
     * Follows the window as its origin moves: the gas that was at local cell {@code (x + dx, y + dy, z + dz)} is at
     * {@code (x, y, z)} afterwards, and what leaves the window is gone. A move by whole bricks only moves the bricks.
     */
    public void shift(int dx, int dy, int dz) {
        if (held == 0 || dx == 0 && dy == 0 && dz == 0) {
            return;
        }
        Arrays.fill(shifted, null);
        int kept = 0;
        if (dx % BRICK == 0 && dy % BRICK == 0 && dz % BRICK == 0) {
            for (int by = 0; by < size.bricksY(); by++) {
                for (int bz = 0; bz < size.bricksZ(); bz++) {
                    for (int bx = 0; bx < size.bricksX(); bx++) {
                        float[] brick = bricks[size.brickIndex(bx, by, bz)];
                        if (brick == null) {
                            continue;
                        }
                        int toX = bx - dx / BRICK;
                        int toY = by - dy / BRICK;
                        int toZ = bz - dz / BRICK;
                        if (toX >= 0 && toX < size.bricksX() && toY >= 0 && toY < size.bricksY() && toZ >= 0 && toZ < size.bricksZ()) {
                            shifted[size.brickIndex(toX, toY, toZ)] = brick;
                            kept++;
                        } else {
                            recycle(brick);
                        }
                    }
                }
            }
        } else {
            kept = shiftCells(dx, dy, dz);
        }
        float[][] old = bricks;
        bricks = shifted;
        shifted = old;
        held = kept;
    }

    /** Removes all the gas. */
    public void clear() {
        for (int index = 0; index < bricks.length; index++) {
            if (bricks[index] != null) {
                release(index);
            }
        }
    }

    /**
     * Writes the cells of one brick as bytes: 0 for no gas up to 255 for {@code full} density, the byte of cell
     * {@code i} of the brick (as {@link #inBrick} counts them) at {@code offset + i * stride}. Writes nothing for a
     * brick with no gas.
     */
    public void quantizeBrick(int brickX, int brickY, int brickZ, float full, byte[] out, int offset, int stride) {
        float[] brick = bricks[size.brickIndex(brickX, brickY, brickZ)];
        if (brick == null) {
            return;
        }
        float scale = 255f / full;
        for (int i = 0; i < BRICK_CELLS; i++) {
            out[offset + i * stride] = (byte) Math.min(255, Math.round(brick[i] * scale));
        }
    }

    // Moved by part of a brick: cell by cell, into bricks of the new place.
    private int shiftCells(int dx, int dy, int dz) {
        int kept = 0;
        for (int by = 0; by < size.bricksY(); by++) {
            for (int bz = 0; bz < size.bricksZ(); bz++) {
                for (int bx = 0; bx < size.bricksX(); bx++) {
                    float[] brick = bricks[size.brickIndex(bx, by, bz)];
                    if (brick == null) {
                        continue;
                    }
                    for (int i = 0; i < BRICK_CELLS; i++) {
                        if (brick[i] == 0f) {
                            continue;
                        }
                        int x = bx * BRICK + i % BRICK - dx;
                        int y = by * BRICK + i / (BRICK * BRICK) - dy;
                        int z = bz * BRICK + i / BRICK % BRICK - dz;
                        if (!size.contains(x, y, z)) {
                            continue;
                        }
                        int index = size.brickOfCell(x, y, z);
                        if (shifted[index] == null) {
                            shifted[index] = fresh();
                            kept++;
                        }
                        shifted[index][inBrick(x % BRICK, y % BRICK, z % BRICK)] = brick[i];
                    }
                    recycle(brick);
                }
            }
        }
        return kept;
    }

    /** Copies one brick between its own array and a whole grid's, a row of cells at a time. */
    private void copy(float[] brick, float[] cells, int bx, int by, int bz, boolean intoGrid) {
        for (int y = 0; y < BRICK; y++) {
            for (int z = 0; z < BRICK; z++) {
                int row = size.index(bx * BRICK, by * BRICK + y, bz * BRICK + z);
                int inBrick = inBrick(0, y, z);
                if (intoGrid) {
                    System.arraycopy(brick, inBrick, cells, row, BRICK);
                } else {
                    System.arraycopy(cells, row, brick, inBrick, BRICK);
                }
            }
        }
    }

    private void clear(float[] cells, int bx, int by, int bz) {
        for (int y = 0; y < BRICK; y++) {
            for (int z = 0; z < BRICK; z++) {
                int row = size.index(bx * BRICK, by * BRICK + y, bz * BRICK + z);
                Arrays.fill(cells, row, row + BRICK, 0f);
            }
        }
    }

    private float[] fresh() {
        float[] brick = spare.poll();
        if (brick == null) {
            return new float[BRICK_CELLS];
        }
        Arrays.fill(brick, 0f);
        return brick;
    }

    private void release(int index) {
        recycle(bricks[index]);
        bricks[index] = null;
        held--;
    }

    private void recycle(float[] brick) {
        if (spare.size() < SPARE_BRICKS) {
            spare.add(brick);
        }
    }

    private void requireSameSize(GasField field) {
        if (!size.equals(field.size())) {
            throw new IllegalArgumentException("Store and field cover different grids");
        }
    }
}
