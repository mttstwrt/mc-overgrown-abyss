package dev.syrval.volumetrics.ambient;

import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.api.wind.Wind;
import dev.syrval.volumetrics.api.wind.WindArea;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import org.jspecify.annotations.Nullable;

/**
 * Server to client, {@code volumetrics:wind}: the wind of one level, sent when it changes and when a player joins,
 * respawns or changes dimension. The channel is optional on both sides.
 *
 * @param dimension the id of the level the wind is for
 * @param wind the wind, or null for none
 */
public record WindPayload(ResourceLocation dimension, @Nullable Wind wind) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<WindPayload> TYPE = new CustomPacketPayload.Type<>(Volumetrics.id("wind"));
    public static final StreamCodec<RegistryFriendlyByteBuf, WindPayload> CODEC = CustomPacketPayload.codec(WindPayload::write, WindPayload::read);

    @Override
    public CustomPacketPayload.Type<WindPayload> type() {
        return TYPE;
    }

    void write(FriendlyByteBuf buffer) {
        buffer.writeUtf(dimension.toString());
        buffer.writeBoolean(wind != null);
        if (wind == null) {
            return;
        }
        buffer.writeFloat(wind.x());
        buffer.writeFloat(wind.z());
        buffer.writeVarInt(wind.areas().size());
        for (WindArea area : wind.areas()) {
            buffer.writeInt(area.minX());
            buffer.writeInt(area.minY());
            buffer.writeInt(area.minZ());
            buffer.writeInt(area.maxX());
            buffer.writeInt(area.maxY());
            buffer.writeInt(area.maxZ());
            buffer.writeFloat(area.x());
            buffer.writeFloat(area.z());
        }
    }

    static WindPayload read(FriendlyByteBuf buffer) {
        ResourceLocation dimension = ResourceLocation.parse(buffer.readUtf());
        if (!buffer.readBoolean()) {
            return new WindPayload(dimension, null);
        }
        float x = buffer.readFloat();
        float z = buffer.readFloat();
        int count = buffer.readVarInt();
        if (count < 0 || count > Wind.MAX_AREAS) {
            throw new IllegalArgumentException("Wind with " + count + " areas");
        }
        List<WindArea> areas = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            areas.add(new WindArea(buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt(),
                    buffer.readFloat(), buffer.readFloat()));
        }
        return new WindPayload(dimension, new Wind(x, z, areas));
    }
}
