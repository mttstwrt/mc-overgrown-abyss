package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.api.Fog;
import dev.syrval.volumetrics.api.FogShape;
import dev.syrval.volumetrics.api.client.GasFogs;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import net.minecraft.world.phys.Vec3;

/** The fogs made from code in one level; {@link GasFogs} is what other mods see of it. Client thread only. */
public final class LevelFogs implements GasFogs {
    private final Set<Placed> placed = new LinkedHashSet<>();

    @Override
    public Handle add(Fog fog) {
        Placed made = new Placed(Objects.requireNonNull(fog, "fog"));
        placed.add(made);
        return made;
    }

    public boolean isEmpty() {
        return placed.isEmpty();
    }

    /**
     * The fogs worth drawing from a camera: those whose shapes come within {@code reach} blocks of it, nearest
     * first, and no more than {@code most} of them.
     */
    public List<Fog> nearest(Vec3 camera, double reach, int most) {
        List<Near> near = new ArrayList<>();
        for (Placed fog : placed) {
            double distance = distance(fog.fog, camera);
            if (distance <= reach) {
                near.add(new Near(fog.fog, distance));
            }
        }
        near.sort(Comparator.comparingDouble(Near::distance));
        List<Fog> drawn = new ArrayList<>(Math.min(most, near.size()));
        for (int i = 0; i < near.size() && i < most; i++) {
            drawn.add(near.get(i).fog());
        }
        return drawn;
    }

    /** From a camera to the nearest point of the upright box round a fog's shape, in blocks; 0 inside it. */
    static double distance(Fog fog, Vec3 camera) {
        FogShape shape = fog.shape();
        double sideways = Math.max(0, Math.hypot(camera.x - fog.anchor().x, camera.z - fog.anchor().z) - shape.reach());
        double below = fog.anchor().y - camera.y;
        double above = camera.y - (fog.anchor().y + shape.height());
        return Math.hypot(sideways, Math.max(0, Math.max(below, above)));
    }

    private record Near(Fog fog, double distance) {}

    private final class Placed implements Handle {
        private Fog fog;

        Placed(Fog fog) {
            this.fog = fog;
        }

        @Override
        public void set(Fog fog) {
            this.fog = Objects.requireNonNull(fog, "fog");
        }

        @Override
        public void remove() {
            placed.remove(this);
        }
    }
}
