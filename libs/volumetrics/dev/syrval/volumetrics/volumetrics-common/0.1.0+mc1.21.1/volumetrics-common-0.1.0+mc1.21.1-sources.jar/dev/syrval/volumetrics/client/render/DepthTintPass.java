package dev.syrval.volumetrics.client.render;

import com.mojang.blaze3d.pipeline.RenderTarget;
import dev.syrval.volumetrics.client.LevelView;
import dev.syrval.volumetrics.client.render.gl.GlFramebuffer;
import dev.syrval.volumetrics.client.render.gl.GlProgram;
import dev.syrval.volumetrics.client.render.gl.GlUniformBuffer;
import dev.syrval.volumetrics.client.render.gl.ScreenPass;
import java.util.Map;
import net.minecraft.server.packs.resources.ResourceProvider;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.jspecify.annotations.Nullable;

/**
 * A fullscreen pass that reads the level's depth, works out where in the world each pixel is, and tints by it.
 * It exists to prove the pieces the gas renderer stands on: the hook point, sampling scene depth, a program and
 * a uniform block of our own.
 */
public final class DepthTintPass implements AutoCloseable {
    private final GlProgram program;
    private final GlUniformBuffer cameraUbo;
    private final ScreenPass pass = new ScreenPass();
    private final Matrix4f inverseViewRotation = new Matrix4f();
    private @Nullable GlFramebuffer mainColor;

    public DepthTintPass(ResourceProvider resources) {
        this.program = new GlProgram(resources, "core/depth_tint.fsh", Map.of());
        this.cameraUbo = new GlUniformBuffer(program.blockBytes("VolumetricsCamera"));
    }

    /** @param depth the texture holding the depth of the level in the target, which is not always the target's own */
    public void render(RenderTarget target, int depth, LevelView view) {
        view.viewRotation().invert(inverseViewRotation);
        Vec3 camera = view.camera().getPosition();
        int blockX = Mth.floor(camera.x);
        int blockY = Mth.floor(camera.y);
        int blockZ = Mth.floor(camera.z);
        // Must write exactly the fields of the VolumetricsCamera block in depth_tint.fsh, in its order.
        cameraUbo.write(uniforms -> uniforms
                .putMat4f(view.projection())
                .putMat4f(inverseViewRotation)
                .putIVec4(blockX, blockY, blockZ, 0)
                .putVec4((float) (blockX - camera.x), (float) (blockY - camera.y), (float) (blockZ - camera.z), 0f));

        mainColor = GlFramebuffer.colorOnly(mainColor, target);
        pass.begin();
        program.setBlock("VolumetricsCamera", cameraUbo);
        program.setTexture("DepthSampler", depth);
        pass.draw(mainColor, program, ScreenPass.Blend.ALPHA);
        pass.end(target);
    }

    @Override
    public void close() {
        program.close();
        cameraUbo.close();
        pass.close();
        if (mainColor != null) {
            mainColor.close();
        }
    }
}
