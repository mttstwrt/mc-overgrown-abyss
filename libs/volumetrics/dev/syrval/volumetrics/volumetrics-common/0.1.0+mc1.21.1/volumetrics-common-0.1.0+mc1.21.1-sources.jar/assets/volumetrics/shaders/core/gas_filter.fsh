#include <volumetrics:gas_depth.glsl>

// The marched gas, grainy: each pixel's ray started at a different offset.
uniform sampler2D GasSampler;
// The level's depth, which is what each of those rays was marched against.
uniform sampler2D DepthSampler;

in vec2 texCoord;

out vec4 fragColor;

// Two rays that stopped at depths this far apart, as a share of the nearer, count half for each other.
const float DEPTH_TOLERANCE = 0.125;

void main() {
    vec2 size = vec2(textureSize(GasSampler, 0));
    // Four blended reads that between them touch all nine texels: most of the screen has no gas and ends here.
    vec4 around = textureLod(GasSampler, texCoord + vec2(-0.5, -0.5) / size, 0.0)
        + textureLod(GasSampler, texCoord + vec2(0.5, -0.5) / size, 0.0)
        + textureLod(GasSampler, texCoord + vec2(-0.5, 0.5) / size, 0.0)
        + textureLod(GasSampler, texCoord + vec2(0.5, 0.5) / size, 0.0);
    if (around.a <= 0.0) {
        fragColor = vec4(0.0);
        return;
    }

    // The average of a pixel and its eight neighbours, whose rays between them sampled each step in nine places.
    // A neighbour whose ray stopped at a very different depth saw a different amount of gas, and counts for
    // less: without that, gas behind a block would bleed over the block's outline.
    ivec2 centre = ivec2(gl_FragCoord.xy);
    float here = gasViewDistance(textureLod(DepthSampler, (texCoord) * ContentScale, 0.0).r);
    vec4 total = vec4(0.0);
    float weights = 0.0;
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            ivec2 texel = clamp(centre + ivec2(x, y), ivec2(0), ivec2(size) - 1);
            float there = gasViewDistance(textureLod(DepthSampler, ((vec2(texel) + 0.5) / size) * ContentScale, 0.0).r);
            float gap = gasDepthGap(there, here) / DEPTH_TOLERANCE;
            float weight = 1.0 / (1.0 + gap * gap);
            total += texelFetch(GasSampler, texel, 0) * weight;
            weights += weight;
        }
    }
    fragColor = total / weights;
}
