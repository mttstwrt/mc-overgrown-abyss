package dev.syrval.volumetrics.client;

import dev.syrval.volumetrics.world.WorldChangeListener;
import org.jspecify.annotations.Nullable;

/**
 * What the game's {@code ClientLevel} is once this mod's mixin has been applied to it: something that tells
 * of changes to the client's world. The listener is kept on the level itself, so there is nothing static
 * between the mixins and the mod.
 */
public interface WorldChangeSource {
    /** Sets who is told, in place of anyone told before; null for nobody. */
    void volumetrics$listen(@Nullable WorldChangeListener listener);

    /** For the mixin on the game's packet listener, which is where a chunk's arrival is known: tells the listener. */
    void volumetrics$chunkArrived(int chunkX, int chunkZ);

    /** For the mixin on the game's chunk cache, which is where the light engine reports a section relit: tells the listener. */
    void volumetrics$sectionTouched(int sectionX, int sectionY, int sectionZ);
}
