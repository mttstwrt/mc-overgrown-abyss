#ifndef VOLUMETRICS_GAS_FIELD_GLSL
#define VOLUMETRICS_GAS_FIELD_GLSL

// Raised whenever something below changes what a shader that includes this file has to do: a field of the block,
// a texture, the meaning of a function.
#define GAS_FIELD_VERSION 3

// The gas around the camera, as Volumetrics hands it to a shader. This file needs nothing of the game's own
// shaders: the block and the eight textures below are all there is to bind.
//
// To draw the gas, walk a ray from the camera: gasRay makes one ready, gasSkipEmpty steps over what holds no gas,
// gasPointAlong finds where a distance along it lies in the boxes, gasReadPages finds which pages of gas there are to
// read there and gasPages says which, gasPageDensity reads one, and gasLightAt gives the game's sky and block light. How the gas
// is lit and how the steps are added up is the shader's own business; core/gas_march.fsh is this mod's way of
// doing it.
//
// Kinds of gas. Each kind near the camera has a slot, 0 to GAS_MAX_KINDS - 1, and four slots make a page: page p
// holds slots 4p to 4p + 3, one to each channel. GasMedium*[slot] say how the kind in a slot looks.
//
// The simulation works in two boxes of cells that follow the camera: a fine one for what is near and, around it,
// a coarse one of larger cells for what is far. In the functions below a box is GAS_NEAR or GAS_FAR.
//
// The game's GPU API has no 3D textures, so a box is stored as an atlas: each horizontal slice of cells is one
// tile, cell X along the tile's width and cell Z along its height, tiles left to right and then row by row going
// up. A density atlas holds its box's pages one above the other, each as many rows of tiles as the box needs; a
// texel's channels are the densities of the page's four kinds, 0 for none to 1 for as dense as that kind gets. A
// light atlas has one page: the sky light in red and the block light in green.
//
// Most of a box is usually empty. Its brick texture says, for each brick of 8x8x8 cells, which pages hold gas that
// can be read anywhere in the brick, edge to edge: one texel a brick, column brick X + brick Y * bricks along X, row
// brick Z, its value times 255 a bit for each page, bit p for page p. Zero is a brick that can be skipped.
//
// Fogs are gas that is not simulated: a kind fills a shape with a density given by a formula, whatever the blocks,
// and is drawn at any distance. There are GasFogCount of them; gasFogRange says which a ray meets and where, and
// gasFogDensity gives the density of one at a place.
//
// Positions are in cells measured from the corner of a box. gasCell turns an offset from the camera, in blocks
// and world axes, into one.

const int GAS_NEAR = 0;
const int GAS_FAR = 1;
const int GAS_MAX_KINDS = 32;
const int GAS_MAX_PAGES = 8;
const int GAS_MAX_FOGS = 16;
// Edge of a brick, in cells.
const float GAS_BRICK_CELLS = 8.0;
// A ray standing on the face between two bricks is looked up this far on, in blocks, safely inside the brick it
// is entering.
const float GAS_PAST_THE_FACE = 0.02;

layout(std140) uniform GasField {
    // Rotates a direction from view space into world space.
    mat4 GasInverseViewRotation;
    // The camera. xyz of the first: the block it is in. xyz of the second: from the camera to that block's low
    // corner, each between -1 and 0. Kept apart so that positions stay exact far from the world's origin.
    ivec4 GasCameraBlock;
    vec4 GasCameraOffset;
    // For each box. xyz: block coordinates of its corner. w: edge of one of its cells, in blocks.
    ivec4 GasBox[2];
    // The same for each box's light atlas. A box that has just moved has its light at the new place at once and
    // its gas only with the next simulation step, so for a moment the two differ.
    ivec4 GasLightBox[2];
    // Block coordinates of the low and the high corner of the smallest box that holds all the gas there is, in
    // either box. A ray that misses it has no simulated gas to draw.
    ivec4 GasBoundsLow;
    ivec4 GasBoundsHigh;
    // For each box. xyz: its size in cells. w: how many pages its density atlases hold.
    vec4 GasGridCells[2];
    // For each box: tiles in a row of an atlas, and rows of tiles in one page of it. zw: unused.
    vec4 GasAtlasTiles[2];
    // The simulation steps ten times a second; this runs from 0 at the previous step to 1 at the newest.
    float GasBlend;
    // Seconds of game time, wrapped every hour.
    float GasTime;
    // How many of the fogs below are in use.
    int GasFogCount;
    float GasUnused;
    // xyz: unit vector towards the sun, or the moon when that is the one in the sky. w: how bright it is, 0 to 1.
    vec4 GasSunDirection;
    // For each slot. rgb: its colour. a: how much light one block's depth of it stops at full density.
    vec4 GasMediumColor[GAS_MAX_KINDS];
    // x: response to sky light. y: response to block light. z: light of its own. w: glow towards the sun.
    vec4 GasMediumLight[GAS_MAX_KINDS];
    // x: wisps per block. y: their drift, blocks per second. z: their strength. w: 1 if the gas sinks, -1 if it rises.
    vec4 GasMediumNoise[GAS_MAX_KINDS];
    // x: blocks the gas's pattern has been carried east by its drift, the wind and its draft. y: the same, south.
    vec4 GasMediumDrift[GAS_MAX_KINDS];
    // For each fog. xyz: from the camera to the middle of its base, in blocks. w: its height.
    vec4 GasFogPlace[GAS_MAX_FOGS];
    // x: its radius at the base, or for a box half its width (x). y: its radius at the top, or half a box's depth (z).
    // z: how many blocks in from its surface it takes to reach its full density. w: 0 for a round fog, 1 for a box.
    vec4 GasFogShape[GAS_MAX_FOGS];
    // x: its density at the base. y: its density at the top. Between, it changes by the same share each block up
    // when both are above zero, and evenly when either is zero. zw: unused.
    vec4 GasFogDensity[GAS_MAX_FOGS];
    // How the fog looks, as GasMediumColor, GasMediumLight and GasMediumNoise do for a kind (w of the last unused).
    vec4 GasFogColor[GAS_MAX_FOGS];
    vec4 GasFogLight[GAS_MAX_FOGS];
    vec4 GasFogNoise[GAS_MAX_FOGS];
};

uniform sampler2D GasDensitySampler;
uniform sampler2D GasPreviousDensitySampler;
uniform sampler2D GasLightSampler;
uniform sampler2D GasBrickSampler;
uniform sampler2D GasFarDensitySampler;
uniform sampler2D GasFarPreviousDensitySampler;
uniform sampler2D GasFarLightSampler;
uniform sampler2D GasFarBrickSampler;

vec3 gasCell(int box, vec3 blocksFromCamera) {
    // The camera is a whole block plus an offset, so the subtraction is done on integers and stays exact.
    return (vec3(GasCameraBlock.xyz - GasBox[box].xyz) - GasCameraOffset.xyz + blocksFromCamera) / float(GasBox[box].w);
}

// One atlas read with the same result a 3D texture would give: two tiles of one page, blended by height. A
// position outside the box reads what is at the box's nearest edge.
vec4 gasAtlas(sampler2D atlas, int box, float page, float pages, vec3 cell) {
    vec3 grid = GasGridCells[box].xyz;
    vec2 tiles = GasAtlasTiles[box].xy;
    // Half a texel in from the tile's edge, so the filter never reaches into the tile next door.
    vec2 inTile = clamp(cell.xz, vec2(0.5), grid.xz - 0.5) / grid.xz;
    float height = clamp(cell.y - 0.5, 0.0, grid.y - 1.0);
    float lower = floor(height);
    float upper = min(lower + 1.0, grid.y - 1.0);
    vec2 lowerTile = vec2(mod(lower, tiles.x), floor(lower / tiles.x) + page * tiles.y);
    vec2 upperTile = vec2(mod(upper, tiles.x), floor(upper / tiles.x) + page * tiles.y);
    vec2 atlasTiles = vec2(tiles.x, tiles.y * pages);
    return mix(
        textureLod(atlas, (lowerTile + inTile) / atlasTiles, 0.0),
        textureLod(atlas, (upperTile + inTile) / atlasTiles, 0.0),
        height - lower);
}

vec4 gasBlended(sampler2D previous, sampler2D newest, int box, float page, vec3 cell) {
    float pages = GasGridCells[box].w;
    vec4 now = gasAtlas(newest, box, page, pages, cell);
    if (GasBlend >= 1.0) {
        return now;
    }
    return mix(gasAtlas(previous, box, page, pages, cell), now, GasBlend);
}

// Density of each of the four kinds of a page at a cell position in a box, 0 to 1.
vec4 gasDensity(int box, int page, vec3 cell) {
    if (box == GAS_NEAR) {
        return gasBlended(GasPreviousDensitySampler, GasDensitySampler, box, float(page), cell);
    }
    return gasBlended(GasFarPreviousDensitySampler, GasFarDensitySampler, box, float(page), cell);
}

// x: sky light, y: block light, each 0 to 1, at a cell position in a box, or at the box's nearest edge.
vec2 gasLight(int box, vec3 cell) {
    vec3 lightCell = cell + vec3(GasBox[box].xyz - GasLightBox[box].xyz) / float(GasBox[box].w);
    if (box == GAS_NEAR) {
        return gasAtlas(GasLightSampler, box, 0.0, 1.0, lightCell).rg;
    }
    return gasAtlas(GasFarLightSampler, box, 0.0, 1.0, lightCell).rg;
}

// The brick of a box a cell position lies in. A position on the far faces of the box counts as in the last brick.
vec3 gasBrick(int box, vec3 cell) {
    return clamp(floor(cell / GAS_BRICK_CELLS), vec3(0.0), GasGridCells[box].xyz / GAS_BRICK_CELLS - 1.0);
}

// The pages that hold gas that can be read in a brick of a box, a bit each.
int gasBrickPages(int box, vec3 brick) {
    ivec3 at = ivec3(brick);
    ivec2 texel = ivec2(at.x + at.y * int(GasGridCells[box].x / GAS_BRICK_CELLS), at.z);
    float bits = box == GAS_NEAR ? texelFetch(GasBrickSampler, texel, 0).r : texelFetch(GasFarBrickSampler, texel, 0).r;
    return int(bits * 255.0 + 0.5);
}

// Whether a brick of a box holds nothing to draw. gasDensity is zero everywhere in such a brick.
bool gasBrickIsEmpty(int box, vec3 brick) {
    return gasBrickPages(box, brick) == 0;
}

// Whether a cell position lies inside a box at all.
bool gasInBox(int box, vec3 cell) {
    return all(greaterThanEqual(cell, vec3(0.0))) && all(lessThan(cell, GasGridCells[box].xyz));
}

// How far inside a box a cell position is, in cells from the nearest face; negative outside.
float gasDepthInBox(int box, vec3 cell) {
    vec3 toFace = min(cell, GasGridCells[box].xyz - cell);
    return min(toFace.x, min(toFace.y, toFace.z));
}

// How much of the gas at a position in the near box is the near box's to give: all of it well inside, and less
// and less through its outermost bricks, where the far box takes over. Those bricks are not simulated: they hold
// what the far box holds there, so the two blend without a seam.
float gasNearShare(vec3 nearCell) {
    return clamp(gasDepthInBox(GAS_NEAR, nearCell) / GAS_BRICK_CELLS, 0.0, 1.0);
}

// The far box ends somewhere too; gas thins out over its last few cells so that the end is not a wall.
float gasFarFade(vec3 farCell) {
    return clamp(gasDepthInBox(GAS_FAR, farCell) / 6.0, 0.0, 1.0);
}

// A ray from the camera, made ready for walking through the gas. Distances along it are in blocks from the camera.
struct GasRay {
    // Unit vector in world axes.
    vec3 direction;
    // For each box: where in it the camera is, in cells, and the cells the ray crosses for each block it travels.
    vec3 nearStart;
    vec3 nearStep;
    vec3 farStart;
    vec3 farStep;
    // Where the ray comes into the near box. The camera is inside it but for a moment after a teleport.
    float nearFrom;
    // The stretch of the ray that can hold simulated gas: inside the box all the gas lies in, and no further than
    // asked. Most rays miss that box and have to no greater than from: there is then nothing to walk.
    float from;
    float to;
};

// direction: a unit vector in world axes. maxBlocks: how far the ray goes, to whatever it is that it hits.
GasRay gasRay(vec3 direction, float maxBlocks) {
    GasRay ray;
    ray.direction = direction;
    // With no component at zero, for dividing by.
    vec3 safe = mix(direction, vec3(1.0e-6), lessThan(abs(direction), vec3(1.0e-6)));
    ray.nearStart = gasCell(GAS_NEAR, vec3(0.0));
    ray.nearStep = safe / float(GasBox[GAS_NEAR].w);
    ray.farStart = gasCell(GAS_FAR, vec3(0.0));
    ray.farStep = safe / float(GasBox[GAS_FAR].w);

    vec3 toLow = (vec3(GasBoundsLow.xyz - GasCameraBlock.xyz) + GasCameraOffset.xyz) / safe;
    vec3 toHigh = (vec3(GasBoundsHigh.xyz - GasCameraBlock.xyz) + GasCameraOffset.xyz) / safe;
    vec3 enter = min(toLow, toHigh);
    vec3 leave = max(toLow, toHigh);
    ray.from = max(max(enter.x, enter.y), max(enter.z, 0.0));
    ray.to = min(min(leave.x, leave.y), min(leave.z, maxBlocks));

    vec3 nearEnter = min(-ray.nearStart / ray.nearStep, (GasGridCells[GAS_NEAR].xyz - ray.nearStart) / ray.nearStep);
    ray.nearFrom = max(nearEnter.x, max(nearEnter.y, nearEnter.z));
    return ray;
}

// How far along a ray it leaves a brick of a box, given where in that box the camera is and the cells the ray
// crosses for each block it travels.
float gasLeavesBrick(vec3 brick, vec3 start, vec3 cellsPerBlock, vec3 direction) {
    vec3 faces = ((brick + step(vec3(0.0), direction)) * GAS_BRICK_CELLS - start) / cellsPerBlock;
    return min(faces.x, min(faces.y, faces.z));
}

// Where to go on from, for a ray that has got to t: t itself if there may be gas there, and otherwise the far
// side of the empty space in front of it. Empty space is stepped over a brick at a time: a brick of the near box
// where the near box alone decides, a brick of the far box beyond it, and where the two overlap, as far as both
// are empty.
float gasSkipEmpty(GasRay ray, float t) {
    float look = t + GAS_PAST_THE_FACE;
    vec3 nearCell = ray.nearStart + ray.nearStep * look;
    float clear = 0.0;
    bool farDecides = true;
    if (gasInBox(GAS_NEAR, nearCell)) {
        vec3 brick = gasBrick(GAS_NEAR, nearCell);
        if (gasBrickIsEmpty(GAS_NEAR, brick)) {
            clear = gasLeavesBrick(brick, ray.nearStart, ray.nearStep, ray.direction);
            // Only in the outermost bricks of the near box does the far box show through.
            vec3 lastBrick = GasGridCells[GAS_NEAR].xyz / GAS_BRICK_CELLS - 1.0;
            farDecides = any(equal(brick, vec3(0.0))) || any(equal(brick, lastBrick));
        } else {
            farDecides = false;
        }
    } else if (look < ray.nearFrom) {
        clear = ray.nearFrom;
    } else {
        clear = ray.to;
    }
    if (farDecides) {
        vec3 brick = gasBrick(GAS_FAR, ray.farStart + ray.farStep * look);
        clear = gasBrickIsEmpty(GAS_FAR, brick) ? min(clear, gasLeavesBrick(brick, ray.farStart, ray.farStep, ray.direction)) : 0.0;
    }
    return clear > t ? max(clear, look) : t;
}

// A distance along a ray, as the boxes see it: the near box's answer where there is one, the far box's beyond it,
// and a blend of the two across the near box's outermost bricks.
struct GasPoint {
    vec3 nearCell;
    vec3 farCell;
    // How much of the answer is each box's: 0 where a box has no say.
    float nearWeight;
    float farWeight;
    // The pages each box has gas of here, a bit each; 0 where a box has no say, or until gasReadPages has read them.
    int nearPages;
    int farPages;
};

GasPoint gasPointAlong(GasRay ray, float t) {
    GasPoint point;
    point.nearCell = ray.nearStart + ray.nearStep * t;
    point.farCell = ray.farStart + ray.farStep * t;
    float nearShare = gasNearShare(point.nearCell);
    point.nearWeight = nearShare;
    point.farWeight = (1.0 - nearShare) * gasFarFade(point.farCell);
    point.nearPages = 0;
    point.farPages = 0;
    return point;
}

// Reads which pages each box has gas of at a point: what gasPages and gasPageDensity go by. A point used only for its
// light need not.
void gasReadPages(inout GasPoint point) {
    point.nearPages = point.nearWeight > 0.0 ? gasBrickPages(GAS_NEAR, gasBrick(GAS_NEAR, point.nearCell)) : 0;
    point.farPages = point.farWeight > 0.0 ? gasBrickPages(GAS_FAR, gasBrick(GAS_FAR, point.farCell)) : 0;
}

// The pages there is gas of at a point, a bit each.
int gasPages(GasPoint point) {
    return point.nearPages | point.farPages;
}

// The density of each of the four kinds of a page at a point, 0 to 1.
vec4 gasPageDensity(GasPoint point, int page) {
    vec4 density = vec4(0.0);
    if (((point.nearPages >> page) & 1) != 0) {
        density = gasDensity(GAS_NEAR, page, point.nearCell) * point.nearWeight;
    }
    if (((point.farPages >> page) & 1) != 0) {
        density += gasDensity(GAS_FAR, page, point.farCell) * point.farWeight;
    }
    return density;
}

// x: the sky light, y: the block light there, each 0 to 1. Beyond the far box, the light at its nearest edge.
vec2 gasLightAt(GasPoint point) {
    float nearShare = gasNearShare(point.nearCell);
    vec2 light = vec2(0.0);
    if (nearShare > 0.0) {
        light = gasLight(GAS_NEAR, point.nearCell) * nearShare;
    }
    if (nearShare < 1.0) {
        light += gasLight(GAS_FAR, point.farCell) * (1.0 - nearShare);
    }
    return light;
}

// The density of a fog at an offset from the camera, in blocks and world axes, before its noise.
float gasFogDensity(int fog, vec3 fromCamera) {
    vec4 place = GasFogPlace[fog];
    vec4 shape = GasFogShape[fog];
    vec3 p = fromCamera - place.xyz;
    float up = p.y / place.w;
    float inside;
    if (shape.w < 0.5) {
        inside = mix(shape.x, shape.y, clamp(up, 0.0, 1.0)) - length(p.xz);
    } else {
        inside = min(shape.x - abs(p.x), shape.y - abs(p.z));
    }
    inside = min(inside, min(p.y, place.w - p.y));
    if (inside <= 0.0) {
        return 0.0;
    }
    vec2 ends = GasFogDensity[fog].xy;
    float density = ends.x > 0.0 && ends.y > 0.0 ? ends.x * pow(ends.y / ends.x, up) : mix(ends.x, ends.y, up);
    return density * smoothstep(0.0, max(shape.z, 0.001), inside);
}

// The fogs a ray meets before maxBlocks, a bit each, and the stretch of it they lie in, from the first to the last.
int gasFogRange(vec3 direction, float maxBlocks, out float from, out float to) {
    vec3 safe = mix(direction, vec3(1.0e-6), lessThan(abs(direction), vec3(1.0e-6)));
    int met = 0;
    from = maxBlocks;
    to = 0.0;
    for (int fog = 0; fog < GasFogCount; fog++) {
        vec4 place = GasFogPlace[fog];
        vec4 shape = GasFogShape[fog];
        vec2 extent = shape.w < 0.5 ? vec2(max(shape.x, shape.y)) : shape.xy;
        vec3 low = place.xyz - vec3(extent.x, 0.0, extent.y);
        vec3 high = place.xyz + vec3(extent.x, place.w, extent.y);
        vec3 toLow = low / safe;
        vec3 toHigh = high / safe;
        vec3 enter = min(toLow, toHigh);
        vec3 leave = max(toLow, toHigh);
        float near = max(max(enter.x, enter.y), max(enter.z, 0.0));
        float far = min(min(leave.x, leave.y), min(leave.z, maxBlocks));
        if (far > near) {
            met |= 1 << fog;
            from = min(from, near);
            to = max(to, far);
        }
    }
    return met;
}

#endif
