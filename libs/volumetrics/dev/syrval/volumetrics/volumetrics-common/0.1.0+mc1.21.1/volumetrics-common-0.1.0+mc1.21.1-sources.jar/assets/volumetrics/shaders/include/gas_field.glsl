#ifndef VOLUMETRICS_GAS_FIELD_GLSL
#define VOLUMETRICS_GAS_FIELD_GLSL

// Raised whenever something below changes what a shader that includes this file has to do: a field of the block,
// a texture, the meaning of a function.
#define GAS_FIELD_VERSION 2

// The gas around the camera, as Volumetrics hands it to a shader. This file needs nothing of the game's own
// shaders: the block and the eight textures below are all there is to bind.
//
// To draw the gas, walk a ray from the camera: gasRay makes one ready, gasSkipEmpty steps over what holds no gas,
// and gasAlong gives the density of each kind of gas, and the game's sky and block light, at a distance along it.
// How the gas is lit and how the steps are added up is the shader's own business; core/gas_march.fsh is this
// mod's way of doing it.
//
// The simulation works in two boxes of cells that follow the camera: a fine one for what is near and, around it,
// a coarse one of as many cells, each twice the size, for what is far. In the functions below a box is GAS_NEAR
// or GAS_FAR.
//
// The game's GPU API has no 3D textures, so a box is stored as an atlas: each horizontal slice of cells is one
// tile, cell X along the tile's width and cell Z along its height, tiles left to right and then row by row going
// up. A density atlas has one channel for each of up to four kinds of gas, 0 for none to 1 for as dense as that
// gas gets. A light atlas has the sky light in red and the block light in green.
//
// Most of a box is usually empty. Its brick texture says which bricks of 8x8x8 cells can be skipped: one texel
// a brick, column brick X + brick Y * bricks along X, row brick Z, zero where no gas can be read anywhere in the
// brick, edge to edge.
//
// Positions are in cells measured from the corner of a box. gasCell turns an offset from the camera, in blocks
// and world axes, into one. To read the gas at a place without a ray, take gasNearShare of its position in the
// near box: that much of the answer is the near box's, and the rest the far box's. The two agree where they meet.

const int GAS_NEAR = 0;
const int GAS_FAR = 1;
// Edge of a brick, in cells.
const float GAS_BRICK_CELLS = 8.0;
// A ray standing on the face between two bricks is looked up this far on, in blocks, safely inside the brick it
// is entering.
const float GAS_PAST_THE_FACE = 0.02;

layout(std140) uniform GasField {
    // Rotates a direction from view space into world space.
    mat4 GasInverseViewRotation;
    // The camera. xyz of the first: the block it is in. xyz of the second: from the camera to that block's low
    // corner, each between -1 and 0. Kept apart so that positions stay exact far from the world's origin.
    ivec4 GasCameraBlock;
    vec4 GasCameraOffset;
    // For each box. xyz: block coordinates of its corner. w: edge of one of its cells, in blocks.
    ivec4 GasBox[2];
    // The same for each box's light atlas. A box that has just moved has its light at the new place at once and
    // its gas only with the next simulation step, so for a moment the two differ.
    ivec4 GasLightBox[2];
    // Block coordinates of the low and the high corner of the smallest box that holds all the gas there is, in
    // either box. A ray that misses it has nothing to draw.
    ivec4 GasBoundsLow;
    ivec4 GasBoundsHigh;
    // Size of each box, in cells.
    vec3 GasGridCells;
    // The simulation steps ten times a second; this runs from 0 at the previous step to 1 at the newest.
    float GasBlend;
    // Tiles in a row of an atlas, and rows of tiles.
    vec2 GasAtlasTiles;
    // Seconds of game time, wrapped every hour.
    float GasTime;
    float GasUnused;
    // xyz: unit vector towards the sun, or the moon when that is the one in the sky. w: how bright it is, 0 to 1.
    vec4 GasSunDirection;
    // For each kind of gas. rgb: its colour. a: how much light one block's depth of it stops at full density.
    vec4 GasMediumColor[4];
    // x: response to sky light. y: response to block light. z: light of its own. w: glow towards the sun.
    vec4 GasMediumLight[4];
    // x: wisps per block. y: their drift, blocks per second. z: their strength. w: 1 if the gas sinks, -1 if it rises.
    vec4 GasMediumNoise[4];
    // x: blocks per second the gas is carried east. y: the same, south. Its wisps travel with it.
    vec4 GasMediumDrift[4];
};

uniform sampler2D GasDensitySampler;
uniform sampler2D GasPreviousDensitySampler;
uniform sampler2D GasLightSampler;
uniform sampler2D GasBrickSampler;
uniform sampler2D GasFarDensitySampler;
uniform sampler2D GasFarPreviousDensitySampler;
uniform sampler2D GasFarLightSampler;
uniform sampler2D GasFarBrickSampler;

vec3 gasCell(int box, vec3 blocksFromCamera) {
    // The camera is a whole block plus an offset, so the subtraction is done on integers and stays exact.
    return (vec3(GasCameraBlock.xyz - GasBox[box].xyz) - GasCameraOffset.xyz + blocksFromCamera) / float(GasBox[box].w);
}

// One atlas read with the same result a 3D texture would give: two tiles, blended by height.
vec4 gasAtlas(sampler2D atlas, vec3 cell) {
    // Half a texel in from the tile's edge, so the filter never reaches into the tile next door.
    vec2 inTile = clamp(cell.xz, vec2(0.5), GasGridCells.xz - 0.5) / GasGridCells.xz;
    float height = clamp(cell.y - 0.5, 0.0, GasGridCells.y - 1.0);
    float lower = floor(height);
    float upper = min(lower + 1.0, GasGridCells.y - 1.0);
    vec2 lowerTile = vec2(mod(lower, GasAtlasTiles.x), floor(lower / GasAtlasTiles.x));
    vec2 upperTile = vec2(mod(upper, GasAtlasTiles.x), floor(upper / GasAtlasTiles.x));
    return mix(
        textureLod(atlas, (lowerTile + inTile) / GasAtlasTiles, 0.0),
        textureLod(atlas, (upperTile + inTile) / GasAtlasTiles, 0.0),
        height - lower);
}

vec4 gasBlended(sampler2D previous, sampler2D newest, vec3 cell) {
    vec4 now = gasAtlas(newest, cell);
    if (GasBlend >= 1.0) {
        return now;
    }
    return mix(gasAtlas(previous, cell), now, GasBlend);
}

// Density of each kind of gas at a cell position in a box, 0 to 1.
vec4 gasDensity(int box, vec3 cell) {
    if (box == GAS_NEAR) {
        return gasBlended(GasPreviousDensitySampler, GasDensitySampler, cell);
    }
    return gasBlended(GasFarPreviousDensitySampler, GasFarDensitySampler, cell);
}

// x: sky light, y: block light, each 0 to 1, at a cell position in a box.
vec2 gasLight(int box, vec3 cell) {
    vec3 lightCell = cell + vec3(GasBox[box].xyz - GasLightBox[box].xyz) / float(GasBox[box].w);
    if (box == GAS_NEAR) {
        return gasAtlas(GasLightSampler, lightCell).rg;
    }
    return gasAtlas(GasFarLightSampler, lightCell).rg;
}

// The brick a cell position lies in. A position on the far faces of the box counts as in the last brick.
vec3 gasBrick(vec3 cell) {
    return clamp(floor(cell / GAS_BRICK_CELLS), vec3(0.0), GasGridCells / GAS_BRICK_CELLS - 1.0);
}

// Whether a brick of a box holds nothing to draw. gasDensity is zero everywhere in such a brick.
bool gasBrickIsEmpty(int box, vec3 brick) {
    ivec3 at = ivec3(brick);
    ivec2 texel = ivec2(at.x + at.y * int(GasGridCells.x / GAS_BRICK_CELLS), at.z);
    if (box == GAS_NEAR) {
        return texelFetch(GasBrickSampler, texel, 0).r == 0.0;
    }
    return texelFetch(GasFarBrickSampler, texel, 0).r == 0.0;
}

// Whether a cell position lies inside a box at all.
bool gasInBox(vec3 cell) {
    return all(greaterThanEqual(cell, vec3(0.0))) && all(lessThan(cell, GasGridCells));
}

// How far inside a box a cell position is, in cells from the nearest face; negative outside.
float gasDepthInBox(vec3 cell) {
    vec3 toFace = min(cell, GasGridCells - cell);
    return min(toFace.x, min(toFace.y, toFace.z));
}

// How much of the gas at a position in the near box is the near box's to give: all of it well inside, and less
// and less through its outermost bricks, where the far box takes over. Those bricks are not simulated: they hold
// what the far box holds there, so the two blend without a seam.
float gasNearShare(vec3 nearCell) {
    return clamp(gasDepthInBox(nearCell) / GAS_BRICK_CELLS, 0.0, 1.0);
}

// The far box ends somewhere too; gas thins out over its last few cells so that the end is not a wall.
float gasFarFade(vec3 farCell) {
    return clamp(gasDepthInBox(farCell) / 6.0, 0.0, 1.0);
}

// A ray from the camera, made ready for walking through the gas. Distances along it are in blocks from the camera.
struct GasRay {
    // Unit vector in world axes.
    vec3 direction;
    // For each box: where in it the camera is, in cells, and the cells the ray crosses for each block it travels.
    vec3 nearStart;
    vec3 nearStep;
    vec3 farStart;
    vec3 farStep;
    // Where the ray comes into the near box. The camera is inside it but for a moment after a teleport.
    float nearFrom;
    // The stretch of the ray that can hold gas: inside the box all the gas lies in, and no further than asked.
    // Most rays miss that box and have to no greater than from: there is then nothing to walk.
    float from;
    float to;
};

// direction: a unit vector in world axes. maxBlocks: how far the ray goes, to whatever it is that it hits.
GasRay gasRay(vec3 direction, float maxBlocks) {
    GasRay ray;
    ray.direction = direction;
    // With no component at zero, for dividing by.
    vec3 safe = mix(direction, vec3(1.0e-6), lessThan(abs(direction), vec3(1.0e-6)));
    ray.nearStart = gasCell(GAS_NEAR, vec3(0.0));
    ray.nearStep = safe / float(GasBox[GAS_NEAR].w);
    ray.farStart = gasCell(GAS_FAR, vec3(0.0));
    ray.farStep = safe / float(GasBox[GAS_FAR].w);

    vec3 toLow = (vec3(GasBoundsLow.xyz - GasCameraBlock.xyz) + GasCameraOffset.xyz) / safe;
    vec3 toHigh = (vec3(GasBoundsHigh.xyz - GasCameraBlock.xyz) + GasCameraOffset.xyz) / safe;
    vec3 enter = min(toLow, toHigh);
    vec3 leave = max(toLow, toHigh);
    ray.from = max(max(enter.x, enter.y), max(enter.z, 0.0));
    ray.to = min(min(leave.x, leave.y), min(leave.z, maxBlocks));

    vec3 nearEnter = min(-ray.nearStart / ray.nearStep, (GasGridCells - ray.nearStart) / ray.nearStep);
    ray.nearFrom = max(nearEnter.x, max(nearEnter.y, nearEnter.z));
    return ray;
}

// How far along a ray it leaves a brick of a box, given where in that box the camera is and the cells the ray
// crosses for each block it travels.
float gasLeavesBrick(vec3 brick, vec3 start, vec3 cellsPerBlock, vec3 direction) {
    vec3 faces = ((brick + step(vec3(0.0), direction)) * GAS_BRICK_CELLS - start) / cellsPerBlock;
    return min(faces.x, min(faces.y, faces.z));
}

// Where to go on from, for a ray that has got to t: t itself if there may be gas there, and otherwise the far
// side of the empty space in front of it. Empty space is stepped over a brick at a time: a brick of the near box
// where the near box alone decides, a brick of the far box beyond it, and where the two overlap, as far as both
// are empty.
float gasSkipEmpty(GasRay ray, float t) {
    float look = t + GAS_PAST_THE_FACE;
    vec3 nearCell = ray.nearStart + ray.nearStep * look;
    float clear = 0.0;
    bool farDecides = true;
    if (gasInBox(nearCell)) {
        vec3 brick = gasBrick(nearCell);
        if (gasBrickIsEmpty(GAS_NEAR, brick)) {
            clear = gasLeavesBrick(brick, ray.nearStart, ray.nearStep, ray.direction);
            // Only in the outermost bricks of the near box does the far box show through.
            vec3 lastBrick = GasGridCells / GAS_BRICK_CELLS - 1.0;
            farDecides = any(equal(brick, vec3(0.0))) || any(equal(brick, lastBrick));
        } else {
            farDecides = false;
        }
    } else if (look < ray.nearFrom) {
        clear = ray.nearFrom;
    } else {
        clear = ray.to;
    }
    if (farDecides) {
        vec3 brick = gasBrick(ray.farStart + ray.farStep * look);
        clear = gasBrickIsEmpty(GAS_FAR, brick) ? min(clear, gasLeavesBrick(brick, ray.farStart, ray.farStep, ray.direction)) : 0.0;
    }
    return clear > t ? max(clear, look) : t;
}

// The gas at a distance along a ray: the density of each kind, 0 to 1, and in light the sky light (x) and the
// block light (y) there, each 0 to 1. The near box's answer where there is one, the far box's beyond it, and a
// blend of the two across the near box's outermost bricks.
vec4 gasAlong(GasRay ray, float t, out vec2 light) {
    vec3 nearCell = ray.nearStart + ray.nearStep * t;
    float nearShare = gasNearShare(nearCell);
    vec4 density = vec4(0.0);
    light = vec2(0.0);
    if (nearShare > 0.0) {
        density = gasDensity(GAS_NEAR, nearCell) * nearShare;
        light = gasLight(GAS_NEAR, nearCell) * nearShare;
    }
    if (nearShare < 1.0) {
        vec3 farCell = ray.farStart + ray.farStep * t;
        density += gasDensity(GAS_FAR, farCell) * ((1.0 - nearShare) * gasFarFade(farCell));
        light += gasLight(GAS_FAR, farCell) * (1.0 - nearShare);
    }
    return density;
}

#endif
