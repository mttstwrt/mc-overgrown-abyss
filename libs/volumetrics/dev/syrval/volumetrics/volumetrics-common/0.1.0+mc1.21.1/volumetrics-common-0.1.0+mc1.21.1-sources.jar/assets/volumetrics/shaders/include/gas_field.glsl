#ifndef VOLUMETRICS_GAS_FIELD_GLSL
#define VOLUMETRICS_GAS_FIELD_GLSL

// Raised whenever something below changes what a shader that includes this file has to do: a field of the block,
// a texture, the meaning of a function.
#define GAS_FIELD_VERSION 4

// The gas around the camera, as Volumetrics hands it to a shader. This file needs nothing of the game's own
// shaders: the block and the four textures below are all there is to bind.
//
// To draw the gas, walk a ray from the camera: gasRay makes one ready, gasSkipEmpty steps over what holds no gas,
// gasPointAlong finds where a distance along it lies in the levels, gasReadPages finds which pages of gas there are to
// read there and gasPages says which, gasPageDensity reads one, and gasLightAt gives the game's sky and block light. How the gas
// is lit and how the steps are added up is the shader's own business; core/gas_march.fsh is this mod's way of
// doing it.
//
// Kinds of gas. Each kind near the camera has a slot, 0 to GAS_MAX_KINDS - 1, and four slots make a page: page p
// holds slots 4p to 4p + 3, one to each channel. GasMedium*[slot] say how the kind in a slot looks.
//
// The simulation works in a cascade of boxes of cells that follow the camera, GasLevelCount of them: level 0 has the
// finest cells and is nearest, and each level after it has cells twice as large and reaches twice as far. In the
// functions below a level is its index, 0 to GasLevelCount - 1.
//
// The game's GPU API has no 3D textures, so a level is stored as an atlas: each horizontal slice of cells is one
// tile, cell X along the tile's width and cell Z along its height, tiles left to right and then row by row going
// up. All levels share each texture, side by side: a level's atlas starts at its own texel column (GasAtlasTiles.z).
// A density atlas holds its level's pages one above the other from row 0, each as many rows of tiles as the level
// needs; a texel's channels are the densities of the page's four kinds, 0 for none to 1 for as dense as that kind
// gets. There are two density textures: each level has its newest step in one of them and the step before in the
// other (GasLevel.y says which). The light texture holds each level's light atlas, one page, from row GasAtlasTiles.w
// on: the sky light in red and the block light in green.
//
// Most of a level is usually empty. Its bricks, in the brick texture from column GasLevel.z on, say for each brick
// of 8x8x8 cells which pages hold gas that can be read anywhere in the brick, edge to edge: one texel a brick, column
// brick X + brick Y * bricks along X, row brick Z, its value times 255 a bit for each page, bit p for page p. Zero is
// a brick that can be skipped.
//
// Fogs are gas that is not simulated: a kind fills a shape with a density given by a formula, whatever the blocks,
// and is drawn at any distance. There are GasFogCount of them; gasFogRange says which a ray meets and where, and
// gasFogDensity gives the density of one at a place.
//
// Positions are in cells measured from the corner of a level's box. gasCell turns an offset from the camera, in
// blocks and world axes, into one.

const int GAS_MAX_LEVELS = 4;
const int GAS_MAX_KINDS = 32;
const int GAS_MAX_PAGES = 8;
const int GAS_MAX_FOGS = 16;
// Edge of a brick, in cells.
const float GAS_BRICK_CELLS = 8.0;
// The outermost level thins out to nothing over this many of its last cells, so that its end is not a wall.
const float GAS_FADE_CELLS = 6.0;
// A ray standing on the face between two bricks is looked up this far on, in blocks, safely inside the brick it
// is entering.
const float GAS_PAST_THE_FACE = 0.02;

layout(std140) uniform GasField {
    // Rotates a direction from view space into world space.
    mat4 GasInverseViewRotation;
    // The camera. xyz of the first: the block it is in. xyz of the second: from the camera to that block's low
    // corner, each between -1 and 0. Kept apart so that positions stay exact far from the world's origin.
    ivec4 GasCameraBlock;
    vec4 GasCameraOffset;
    // For each level. xyz: block coordinates of its corner. w: edge of one of its cells, in blocks.
    ivec4 GasBox[GAS_MAX_LEVELS];
    // The same for each level's light atlas. A level that has just moved has its light at the new place at once and
    // its gas only with its next simulation step, so for a moment the two differ.
    ivec4 GasLightBox[GAS_MAX_LEVELS];
    // Block coordinates of the low and the high corner of the smallest box that holds all the gas there is, in
    // any level. A ray that misses it has no simulated gas to draw.
    ivec4 GasBoundsLow;
    ivec4 GasBoundsHigh;
    // For each level. xyz: its size in cells. w: how many pages of the density textures it holds.
    vec4 GasGridCells[GAS_MAX_LEVELS];
    // For each level: x, tiles in a row of its atlases; y, rows of tiles in one page of them; z, the texel column its
    // atlases start at, in the density and the light textures; w, the texel row its light starts at.
    vec4 GasAtlasTiles[GAS_MAX_LEVELS];
    // For each level. x: from 0 at its step before to 1 at its newest. Each level steps on a schedule of its own, the
    // coarser ones less often, and each is shown at the same moment between its steps. y: 0 if GasDensity0Sampler
    // holds its newest step and GasDensity1Sampler the one before, 1 for the other way round. z: the texel column its
    // bricks start at in the brick texture. w: unused.
    vec4 GasLevel[GAS_MAX_LEVELS];
    // Seconds of game time, wrapped every hour.
    float GasTime;
    // How many of the fogs below are in use.
    int GasFogCount;
    // How many levels there are, 1 to GAS_MAX_LEVELS.
    int GasLevelCount;
    float GasUnused;
    // xyz: unit vector towards the sun, or the moon when that is the one in the sky. w: how bright it is, 0 to 1.
    vec4 GasSunDirection;
    // For each slot. rgb: its colour. a: how much light one block's depth of it stops at full density.
    vec4 GasMediumColor[GAS_MAX_KINDS];
    // x: response to sky light. y: response to block light. z: light of its own. w: glow towards the sun.
    vec4 GasMediumLight[GAS_MAX_KINDS];
    // x: wisps per block. y: their drift, blocks per second. z: their strength. w: 1 if the gas sinks, -1 if it rises.
    vec4 GasMediumNoise[GAS_MAX_KINDS];
    // x: blocks the gas's pattern has been carried east by its drift, the wind and its draft. y: the same, south.
    vec4 GasMediumDrift[GAS_MAX_KINDS];
    // For each fog. xyz: from the camera to the middle of its base, in blocks. w: its height.
    vec4 GasFogPlace[GAS_MAX_FOGS];
    // x: its radius at the base, or for a box half its width (x). y: its radius at the top, or half a box's depth (z).
    // z: how many blocks in from its surface it takes to reach its full density. w: 0 for a round fog, 1 for a box.
    vec4 GasFogShape[GAS_MAX_FOGS];
    // x: its density at the base. y: its density at the top. Between, it changes by the same share each block up
    // when both are above zero, and evenly when either is zero. zw: unused.
    vec4 GasFogDensity[GAS_MAX_FOGS];
    // How the fog looks, as GasMediumColor, GasMediumLight and GasMediumNoise do for a kind (w of the last unused).
    vec4 GasFogColor[GAS_MAX_FOGS];
    vec4 GasFogLight[GAS_MAX_FOGS];
    vec4 GasFogNoise[GAS_MAX_FOGS];
};

uniform sampler2D GasDensity0Sampler;
uniform sampler2D GasDensity1Sampler;
uniform sampler2D GasLightSampler;
uniform sampler2D GasBrickSampler;

vec3 gasCell(int level, vec3 blocksFromCamera) {
    // The camera is a whole block plus an offset, so the subtraction is done on integers and stays exact.
    return (vec3(GasCameraBlock.xyz - GasBox[level].xyz) - GasCameraOffset.xyz + blocksFromCamera) / float(GasBox[level].w);
}

// One atlas read with the same result a 3D texture would give: two tiles of one page, blended by height. corner: the
// texel the level's atlas starts at in the texture. A position outside the level's box reads what is at its nearest
// edge.
vec4 gasAtlas(sampler2D atlas, int level, vec2 corner, float page, vec3 cell) {
    vec3 grid = GasGridCells[level].xyz;
    vec2 tiles = GasAtlasTiles[level].xy;
    // Half a texel in from the tile's edge, so the filter never reaches into the tile next door.
    vec2 inTile = clamp(cell.xz, vec2(0.5), grid.xz - 0.5);
    float height = clamp(cell.y - 0.5, 0.0, grid.y - 1.0);
    float lower = floor(height);
    float upper = min(lower + 1.0, grid.y - 1.0);
    vec2 lowerTile = vec2(mod(lower, tiles.x), floor(lower / tiles.x) + page * tiles.y);
    vec2 upperTile = vec2(mod(upper, tiles.x), floor(upper / tiles.x) + page * tiles.y);
    vec2 texels = vec2(textureSize(atlas, 0));
    return mix(
        textureLod(atlas, (corner + lowerTile * grid.xz + inTile) / texels, 0.0),
        textureLod(atlas, (corner + upperTile * grid.xz + inTile) / texels, 0.0),
        height - lower);
}

// Density of each of the four kinds of a page at a cell position in a level, 0 to 1: the level's step before and its
// newest, blended by where between them it is shown.
vec4 gasDensity(int level, int page, vec3 cell) {
    vec2 corner = vec2(GasAtlasTiles[level].z, 0.0);
    float blend = GasLevel[level].x;
    bool newestInFirst = GasLevel[level].y < 0.5;
    vec4 now;
    if (newestInFirst) {
        now = gasAtlas(GasDensity0Sampler, level, corner, float(page), cell);
    } else {
        now = gasAtlas(GasDensity1Sampler, level, corner, float(page), cell);
    }
    if (blend >= 1.0) {
        return now;
    }
    vec4 before;
    if (newestInFirst) {
        before = gasAtlas(GasDensity1Sampler, level, corner, float(page), cell);
    } else {
        before = gasAtlas(GasDensity0Sampler, level, corner, float(page), cell);
    }
    return mix(before, now, blend);
}

// x: sky light, y: block light, each 0 to 1, at a cell position in a level, or at its box's nearest edge.
vec2 gasLight(int level, vec3 cell) {
    vec3 lightCell = cell + vec3(GasBox[level].xyz - GasLightBox[level].xyz) / float(GasBox[level].w);
    return gasAtlas(GasLightSampler, level, GasAtlasTiles[level].zw, 0.0, lightCell).rg;
}

// The brick of a level a cell position lies in. A position on the far faces of the box counts as in the last brick.
vec3 gasBrick(int level, vec3 cell) {
    return clamp(floor(cell / GAS_BRICK_CELLS), vec3(0.0), GasGridCells[level].xyz / GAS_BRICK_CELLS - 1.0);
}

// The pages that hold gas that can be read in a brick of a level, a bit each.
int gasBrickPages(int level, vec3 brick) {
    ivec3 at = ivec3(brick);
    ivec2 texel = ivec2(int(GasLevel[level].z) + at.x + at.y * int(GasGridCells[level].x / GAS_BRICK_CELLS), at.z);
    int bits = int(texelFetch(GasBrickSampler, texel, 0).r * 255.0 + 0.5);
    // A level that holds fewer pages than there are has nothing to read of the others.
    return bits & ((1 << int(GasGridCells[level].w)) - 1);
}

// Whether a brick of a level holds nothing to draw. gasDensity is zero everywhere in such a brick.
bool gasBrickIsEmpty(int level, vec3 brick) {
    return gasBrickPages(level, brick) == 0;
}

// Whether a cell position lies inside a level's box at all.
bool gasInBox(int level, vec3 cell) {
    return all(greaterThanEqual(cell, vec3(0.0))) && all(lessThan(cell, GasGridCells[level].xyz));
}

// How far inside a level's box a cell position is, in cells from the nearest face; negative outside.
float gasDepthInBox(int level, vec3 cell) {
    vec3 toFace = min(cell, GasGridCells[level].xyz - cell);
    return min(toFace.x, min(toFace.y, toFace.z));
}

// How much of the gas at a position a level gives, of what the levels inside it have left to give: all of it well
// inside, and less and less through its outermost bricks, where the next level takes over. Those bricks are not
// simulated: they hold what the next level holds there, so the two blend without a seam. The outermost level has no
// level after it and instead thins out over its last few cells, so that its end is not a wall.
float gasLevelShare(int level, vec3 cell) {
    float over = level == GasLevelCount - 1 ? GAS_FADE_CELLS : GAS_BRICK_CELLS;
    return clamp(gasDepthInBox(level, cell) / over, 0.0, 1.0);
}

// A ray from the camera, made ready for walking through the gas. Distances along it are in blocks from the camera.
// Where it lies in each level is worked out from the uniforms when needed rather than kept for every level: what a
// ray keeps stays in registers for the whole walk.
struct GasRay {
    // Unit vector in world axes.
    vec3 direction;
    // The same with no component at zero, for dividing by.
    vec3 safe;
    // For each level: where the ray comes into its box, if it does. The camera is inside each but for a moment after
    // a teleport.
    float enter[GAS_MAX_LEVELS];
    // The stretch of the ray that can hold simulated gas: inside the box all the gas lies in, and no further than
    // asked. Most rays miss that box and have to no greater than from: there is then nothing to walk.
    float from;
    float to;
};

// The cells of a level a ray crosses for each block it travels.
vec3 gasCellsPerBlock(GasRay ray, int level) {
    return ray.safe / float(GasBox[level].w);
}

// direction: a unit vector in world axes. maxBlocks: how far the ray goes, to whatever it is that it hits.
GasRay gasRay(vec3 direction, float maxBlocks) {
    GasRay ray;
    ray.direction = direction;
    vec3 safe = mix(direction, vec3(1.0e-6), lessThan(abs(direction), vec3(1.0e-6)));
    ray.safe = safe;
    for (int level = 0; level < GAS_MAX_LEVELS; level++) {
        if (level >= GasLevelCount) {
            ray.enter[level] = 0.0;
            continue;
        }
        vec3 start = gasCell(level, vec3(0.0));
        vec3 cellsPerBlock = gasCellsPerBlock(ray, level);
        vec3 enter = min(-start / cellsPerBlock, (GasGridCells[level].xyz - start) / cellsPerBlock);
        ray.enter[level] = max(enter.x, max(enter.y, enter.z));
    }

    vec3 toLow = (vec3(GasBoundsLow.xyz - GasCameraBlock.xyz) + GasCameraOffset.xyz) / safe;
    vec3 toHigh = (vec3(GasBoundsHigh.xyz - GasCameraBlock.xyz) + GasCameraOffset.xyz) / safe;
    vec3 enter = min(toLow, toHigh);
    vec3 leave = max(toLow, toHigh);
    ray.from = max(max(enter.x, enter.y), max(enter.z, 0.0));
    ray.to = min(min(leave.x, leave.y), min(leave.z, maxBlocks));
    return ray;
}

// How far along a ray it leaves a brick of a level, given where in that level the camera is and the cells the ray
// crosses for each block it travels.
float gasLeavesBrick(vec3 brick, vec3 start, vec3 cellsPerBlock, vec3 direction) {
    vec3 faces = ((brick + step(vec3(0.0), direction)) * GAS_BRICK_CELLS - start) / cellsPerBlock;
    return min(faces.x, min(faces.y, faces.z));
}

// Where to go on from, for a ray that has got to t: t itself if there may be gas there, and otherwise the far
// side of the empty space in front of it. Empty space is stepped over a brick at a time: a brick of the finest level
// the ray is in where that level alone decides, and in its outermost bricks, where the next level shows through, as
// far as both are empty, and so on outwards.
float gasSkipEmpty(GasRay ray, float t) {
    float look = t + GAS_PAST_THE_FACE;
    float clear = 1.0e30;
    for (int level = 0; level < GAS_MAX_LEVELS; level++) {
        if (level >= GasLevelCount) {
            break;
        }
        vec3 start = gasCell(level, vec3(0.0));
        vec3 cellsPerBlock = gasCellsPerBlock(ray, level);
        vec3 cell = start + cellsPerBlock * look;
        if (gasInBox(level, cell)) {
            vec3 brick = gasBrick(level, cell);
            if (!gasBrickIsEmpty(level, brick)) {
                return t;
            }
            clear = min(clear, gasLeavesBrick(brick, start, cellsPerBlock, ray.direction));
            // Only in the outermost bricks of a level does the next level show through.
            vec3 lastBrick = GasGridCells[level].xyz / GAS_BRICK_CELLS - 1.0;
            if (!any(equal(brick, vec3(0.0))) && !any(equal(brick, lastBrick))) {
                break;
            }
        } else if (look < ray.enter[level]) {
            clear = min(clear, ray.enter[level]);
        } else {
            clear = min(clear, ray.to);
        }
    }
    return clear > t ? max(clear, look) : t;
}

// A distance along a ray, as the levels see it: the finest level whose box holds it, blended into the next level
// across its outermost bricks. Only those two levels can have a say at one place (the next level's own outermost
// bricks lie further out), so a point keeps two, not one for each level.
struct GasPoint {
    // The finest level whose box holds the point; the outermost level where none does. The other is the next one.
    int level;
    // Where the point is in each of the two, in cells.
    vec3 cell;
    vec3 outerCell;
    // How much of the answer is each one's: 0 where it has no say.
    float weight;
    float outerWeight;
    // How much of the light is the finer one's; the next gives the rest.
    float lightShare;
    // The pages each of the two has gas of here, a bit each; 0 where it has no say, or until gasReadPages has read them.
    int pages;
    int outerPages;
};

GasPoint gasPointAlong(GasRay ray, float t) {
    GasPoint point;
    vec3 offset = ray.safe * t;
    int last = GasLevelCount - 1;
    point.level = last;
    for (int level = 0; level < GAS_MAX_LEVELS; level++) {
        if (level >= last) {
            break;
        }
        if (gasInBox(level, gasCell(level, offset))) {
            point.level = level;
            break;
        }
    }
    point.cell = gasCell(point.level, offset);
    point.weight = gasLevelShare(point.level, point.cell);
    point.pages = 0;
    point.outerPages = 0;
    if (point.level == last) {
        point.outerCell = point.cell;
        point.outerWeight = 0.0;
        // Beyond its box, the light at its nearest edge.
        point.lightShare = 1.0;
    } else {
        point.outerCell = gasCell(point.level + 1, offset);
        point.outerWeight = (1.0 - point.weight) * gasLevelShare(point.level + 1, point.outerCell);
        point.lightShare = clamp(gasDepthInBox(point.level, point.cell) / GAS_BRICK_CELLS, 0.0, 1.0);
    }
    return point;
}

// Reads which pages each level has gas of at a point: what gasPages and gasPageDensity go by. A point used only for
// its light need not.
void gasReadPages(inout GasPoint point) {
    point.pages = point.weight > 0.0 ? gasBrickPages(point.level, gasBrick(point.level, point.cell)) : 0;
    point.outerPages = point.outerWeight > 0.0
            ? gasBrickPages(point.level + 1, gasBrick(point.level + 1, point.outerCell)) : 0;
}

// The pages there is gas of at a point, a bit each.
int gasPages(GasPoint point) {
    return point.pages | point.outerPages;
}

// The density of each of the four kinds of a page at a point, 0 to 1.
vec4 gasPageDensity(GasPoint point, int page) {
    vec4 density = vec4(0.0);
    if (((point.pages >> page) & 1) != 0) {
        density += gasDensity(point.level, page, point.cell) * point.weight;
    }
    if (((point.outerPages >> page) & 1) != 0) {
        density += gasDensity(point.level + 1, page, point.outerCell) * point.outerWeight;
    }
    return density;
}

// x: the sky light, y: the block light there, each 0 to 1. The finer level gives its share as for the gas, and the
// next all that is left; beyond the outermost level's box, the light at its nearest edge.
vec2 gasLightAt(GasPoint point) {
    vec2 light = vec2(0.0);
    if (point.lightShare > 0.0) {
        light += gasLight(point.level, point.cell) * point.lightShare;
    }
    if (point.lightShare < 1.0) {
        light += gasLight(point.level + 1, point.outerCell) * (1.0 - point.lightShare);
    }
    return light;
}

// The density of a fog at an offset from the camera, in blocks and world axes, before its noise.
float gasFogDensity(int fog, vec3 fromCamera) {
    vec4 place = GasFogPlace[fog];
    vec4 shape = GasFogShape[fog];
    vec3 p = fromCamera - place.xyz;
    float up = p.y / place.w;
    float inside;
    if (shape.w < 0.5) {
        inside = mix(shape.x, shape.y, clamp(up, 0.0, 1.0)) - length(p.xz);
    } else {
        inside = min(shape.x - abs(p.x), shape.y - abs(p.z));
    }
    inside = min(inside, min(p.y, place.w - p.y));
    if (inside <= 0.0) {
        return 0.0;
    }
    vec2 ends = GasFogDensity[fog].xy;
    float density = ends.x > 0.0 && ends.y > 0.0 ? ends.x * pow(ends.y / ends.x, up) : mix(ends.x, ends.y, up);
    return density * smoothstep(0.0, max(shape.z, 0.001), inside);
}

// The fogs a ray meets before maxBlocks, a bit each, and the stretch of it they lie in, from the first to the last.
int gasFogRange(vec3 direction, float maxBlocks, out float from, out float to) {
    vec3 safe = mix(direction, vec3(1.0e-6), lessThan(abs(direction), vec3(1.0e-6)));
    int met = 0;
    from = maxBlocks;
    to = 0.0;
    for (int fog = 0; fog < GasFogCount; fog++) {
        vec4 place = GasFogPlace[fog];
        vec4 shape = GasFogShape[fog];
        vec2 extent = shape.w < 0.5 ? vec2(max(shape.x, shape.y)) : shape.xy;
        vec3 low = place.xyz - vec3(extent.x, 0.0, extent.y);
        vec3 high = place.xyz + vec3(extent.x, place.w, extent.y);
        vec3 toLow = low / safe;
        vec3 toHigh = high / safe;
        vec3 enter = min(toLow, toHigh);
        vec3 leave = max(toLow, toHigh);
        float near = max(max(enter.x, enter.y), max(enter.z, 0.0));
        float far = min(min(leave.x, leave.y), min(leave.z, maxBlocks));
        if (far > near) {
            met |= 1 << fog;
            from = min(from, near);
            to = max(to, far);
        }
    }
    return met;
}

#endif
