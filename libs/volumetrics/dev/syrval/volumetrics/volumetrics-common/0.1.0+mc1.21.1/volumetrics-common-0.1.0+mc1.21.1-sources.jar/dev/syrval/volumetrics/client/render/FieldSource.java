package dev.syrval.volumetrics.client.render;

import java.util.Arrays;
import java.util.List;
import org.jspecify.annotations.Nullable;

/** Where the gas the renderer draws comes from; the values of the {@code field_source} experiment. */
public enum FieldSource {
    /** The simulation's steps, quantized on its thread and uploaded from the CPU. */
    CPU("cpu"),
    /** A compute shader writes a moving pattern into the density atlas: the check that the compute layer works. */
    COMPUTE_TEST("compute_test");

    private final String text;

    FieldSource(String text) {
        this.text = text;
    }

    /** The name the experiment and the log use. */
    public String text() {
        return text;
    }

    public static List<String> names() {
        return Arrays.stream(values()).map(FieldSource::text).toList();
    }

    /** The source with a name, or null if there is none. */
    public static @Nullable FieldSource byName(String text) {
        for (FieldSource source : values()) {
            if (source.text.equals(text)) {
                return source;
            }
        }
        return null;
    }
}
