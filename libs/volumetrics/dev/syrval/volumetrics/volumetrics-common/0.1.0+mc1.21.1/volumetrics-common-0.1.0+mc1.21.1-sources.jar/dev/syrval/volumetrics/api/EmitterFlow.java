package dev.syrval.volumetrics.api;

import dev.syrval.volumetrics.sim.Push;
import java.util.Objects;

/**
 * How an emitter pushes the gas near it sideways: along a heading, or towards a point, as from a draught that pulls
 * gas down a hole or out through a gap. The push is strongest inside the box around the emitter's shape and fades to
 * nothing at {@code reach} blocks beyond it. Where the reaches of several emitters of one medium overlap, their pushes
 * are averaged by how strongly each pushes there: emitters around one point do not together push faster than one,
 * and opposite pushes cancel. Gas moved by it keeps its medium's own drift, wind and draft as well.
 *
 * <p>The push only moves gas; it does not move the pattern the gas is drawn with, which follows the medium's own push.
 *
 * @param target what the gas is pushed along or towards
 * @param speed  blocks per second, above 0 and at most {@value Push#MAX}. A fine grid may carry less in a step, and
 *               slows it to what it can
 * @param reach  how far beyond the box around the emitter's shape the push reaches, in blocks, not negative; at 0 it
 *               pushes inside the box only
 */
public record EmitterFlow(Target target, float speed, float reach) {
    public EmitterFlow {
        Objects.requireNonNull(target, "target");
        if (!(speed > 0 && speed <= Push.MAX)) {
            throw new IllegalArgumentException("Flow speed must be above 0 and at most " + Push.MAX + ", got " + speed);
        }
        if (!(reach >= 0) || !Float.isFinite(reach)) {
            throw new IllegalArgumentException("Flow reach must be finite and not negative, got " + reach);
        }
    }

    /** Pushes along a heading, east ({@code x}) and south ({@code z}); see {@link Heading}. */
    public static EmitterFlow heading(float x, float z, float speed, float reach) {
        return new EmitterFlow(new Heading(x, z), speed, reach);
    }

    /** Pushes towards the point {@code x, z}, in blocks; see {@link Toward}. */
    public static EmitterFlow toward(double x, double z, float speed, float reach) {
        return new EmitterFlow(new Toward(x, z), speed, reach);
    }

    /** What the gas is pushed along or towards. */
    public sealed interface Target {}

    /**
     * A direction, east ({@code x}) and south ({@code z}); made length 1, so only the direction counts.
     *
     * @throws IllegalArgumentException if it is zero or not finite
     */
    public record Heading(float x, float z) implements Target {
        public Heading {
            double length = Math.sqrt((double) x * x + (double) z * z);
            if (!(length > 0) || !Double.isFinite(length)) {
                throw new IllegalArgumentException("Flow heading must be finite and not zero, got " + x + ", " + z);
            }
            x = (float) (x / length);
            z = (float) (z / length);
        }
    }

    /**
     * A point in the world, in blocks. Pushes are sideways only, so gas is pushed towards the vertical line through it,
     * and comes to rest there: the push slows over the last few blocks. The point stays where it is when the emitter
     * moves.
     *
     * @throws IllegalArgumentException if it is not finite
     */
    public record Toward(double x, double z) implements Target {
        public Toward {
            if (!Double.isFinite(x) || !Double.isFinite(z)) {
                throw new IllegalArgumentException("Flow point must be finite, got " + x + ", " + z);
            }
        }
    }
}
