package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.sim.Source;

/** A place in the world that gives off one kind of gas. */
public record Emitter(Medium medium, Source source) {}
