package dev.syrval.volumetrics.world;

/**
 * Told of what changes in the client's world, as the game comes to know of it. Three things, because they cost
 * differently to follow up: a chunk or a block means reading blocks again, anything else only light.
 */
public interface WorldChangeListener {
    /** A chunk has arrived from the server, with its light: every section of it is new. */
    void chunkArrived(int chunkX, int chunkZ);

    /**
     * A block has been set.
     *
     * @param byPlayer whether the game marks the change as the player's own doing
     */
    void blockChanged(int blockX, int blockY, int blockZ, boolean byPlayer);

    /**
     * The game is going to draw a chunk section again. It says so for the section a change is in and for those
     * around it, and for changes of light alone; of what this mod reads, nothing but the light need have changed.
     */
    void sectionTouched(int sectionX, int sectionY, int sectionZ);
}
