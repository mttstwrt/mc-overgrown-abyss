package dev.syrval.volumetrics.api;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
//? if >=26.1 {
/*import net.minecraft.advancements.predicates.StatePropertiesPredicate;
import net.minecraft.core.registries.codec.RegistryCodecs;
*///?} else {
import net.minecraft.advancements.critereon.StatePropertiesPredicate;
import net.minecraft.core.RegistryCodecs;
//?}
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.Registries;

/** Where in the world an emitter definition puts its emitters. */
public sealed interface Placement {
    Codec<Placement> CODEC = Codec.STRING.dispatch("type", Placement::type, Placement::codecFor);

    String type();

    /**
     * An emitter at every block that is one of these and in a matching state, anchored to the middle of the
     * block's floor. Clients find them as they read the world around the camera, so this needs nothing from the
     * server but the definition.
     *
     * @param state properties the block's state must have, as advancements and loot tables write them
     *              ({@code "lit": "true"}); with none, every state of the block matches
     */
    record Block(HolderSet<net.minecraft.world.level.block.Block> blocks, StatePropertiesPredicate state) implements Placement {
        private static final StatePropertiesPredicate ANY_STATE = new StatePropertiesPredicate(List.of());

        static final MapCodec<Block> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                //? if >=26.1 {
                /*RegistryCodecs.holderSet(Registries.BLOCK).fieldOf("blocks").forGetter(Block::blocks),
                *///?} else {
                RegistryCodecs.homogeneousList(Registries.BLOCK).fieldOf("blocks").forGetter(Block::blocks),
                //?}
                StatePropertiesPredicate.CODEC.optionalFieldOf("state", ANY_STATE).forGetter(Block::state)
        ).apply(instance, Block::new));

        @Override
        public String type() {
            return "volumetrics:block";
        }
    }

    private static MapCodec<? extends Placement> codecFor(String type) {
        return switch (type) {
            case "volumetrics:block" -> Block.CODEC;
            default -> MapCodec.unit(() -> {
                throw new IllegalArgumentException("Unknown emitter placement " + type);
            });
        };
    }
}
