package dev.syrval.volumetrics.sim;

import java.nio.ByteBuffer;
import java.util.Arrays;

/**
 * The density of one gas in every cell of the window. Double-buffered: a step reads one array and writes the
 * other, so its result does not depend on the order cells are visited in.
 *
 * <p>Each buffer remembers which bricks hold any gas. The stepper uses that to skip empty space, and to know
 * which stale bricks of the buffer it is about to write must be wiped first.
 *
 * <p>Every cell of the window is here, so a window keeps one of these as the place its gases are stepped in, each in
 * turn, and keeps each gas between steps in a {@link GasStore}, which holds only the bricks with gas in them.
 */
public final class GasField implements GasDensities {
    private final GridSize size;
    private float[] current;
    private float[] next;
    private boolean[] currentHasGas;
    private boolean[] nextHasGas;

    public GasField(GridSize size) {
        this.size = size;
        this.current = new float[size.cells()];
        this.next = new float[size.cells()];
        this.currentHasGas = new boolean[size.brickCount()];
        this.nextHasGas = new boolean[size.brickCount()];
    }

    @Override
    public GridSize size() {
        return size;
    }

    @Override
    public float density(int cellX, int cellY, int cellZ) {
        return current[size.index(cellX, cellY, cellZ)];
    }

    public void setDensity(int cellX, int cellY, int cellZ, float density) {
        if (!(density >= 0)) {
            throw new IllegalArgumentException("Density must not be negative, got " + density);
        }
        current[size.index(cellX, cellY, cellZ)] = density;
        if (density > 0) {
            currentHasGas[size.brickOfCell(cellX, cellY, cellZ)] = true;
        }
    }

    /** Sum of all densities, as a double so that a million small cells do not round away. */
    public double total() {
        double sum = 0;
        for (float density : current) {
            sum += density;
        }
        return sum;
    }

    public boolean isEmpty() {
        for (boolean hasGas : currentHasGas) {
            if (hasGas) {
                return false;
            }
        }
        return true;
    }

    /** Follows the window as its origin moves; cells that enter are empty. */
    public void shift(int cellsX, int cellsY, int cellsZ) {
        GridShift.shift(current, size, cellsX, cellsY, cellsZ, 0f);
        markBricks();
        Arrays.fill(next, 0f);
        Arrays.fill(nextHasGas, false);
    }

    @Override
    public boolean brickHasGas(int brickX, int brickY, int brickZ) {
        return currentHasGas[size.brickIndex(brickX, brickY, brickZ)];
    }

    /**
     * Writes the cells of one brick as bytes into a buffer laid out like the grid: 0 for no gas up to 255 for
     * {@code full} density. The byte of the cell at grid index {@code i} goes to {@code offset + i * stride},
     * so several gases can share a buffer as the channels of a texel.
     */
    public void quantizeBrick(int brickX, int brickY, int brickZ, float full, ByteBuffer out, int offset, int stride) {
        float scale = 255f / full;
        for (int y = brickY * GridSize.BRICK; y < (brickY + 1) * GridSize.BRICK; y++) {
            for (int z = brickZ * GridSize.BRICK; z < (brickZ + 1) * GridSize.BRICK; z++) {
                int row = size.index(brickX * GridSize.BRICK, y, z);
                for (int i = row; i < row + GridSize.BRICK; i++) {
                    out.put(offset + i * stride, (byte) Math.min(255, Math.round(current[i] * scale)));
                }
            }
        }
    }

    /** A copy of the densities, indexed by {@link GridSize#index}. */
    public float[] snapshot() {
        return current.clone();
    }

    float[] current() {
        return current;
    }

    float[] next() {
        return next;
    }

    boolean[] currentHasGas() {
        return currentHasGas;
    }

    boolean[] nextHasGas() {
        return nextHasGas;
    }

    void swap() {
        float[] cells = current;
        current = next;
        next = cells;
        boolean[] bricks = currentHasGas;
        currentHasGas = nextHasGas;
        nextHasGas = bricks;
    }

    private void markBricks() {
        Arrays.fill(currentHasGas, false);
        for (int y = 0; y < size.y(); y++) {
            for (int z = 0; z < size.z(); z++) {
                int row = size.index(0, y, z);
                for (int x = 0; x < size.x(); x++) {
                    if (current[row + x] > 0) {
                        currentHasGas[size.brickOfCell(x, y, z)] = true;
                    }
                }
            }
        }
    }
}
