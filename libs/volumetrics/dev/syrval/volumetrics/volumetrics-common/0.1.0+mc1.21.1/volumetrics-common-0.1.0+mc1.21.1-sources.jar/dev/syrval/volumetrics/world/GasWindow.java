package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import it.unimi.dsi.fastutil.longs.LongLinkedOpenHashSet;
import java.util.Arrays;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.SectionPos;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * One box of cells that follows the camera, and which of the chunk sections inside it are to be read, and when: the
 * client thread's side of a window. The sections are copied out of the world here and handed to the scan thread;
 * what they come to is kept by the simulation thread ({@link SimWindow}). Client thread only.
 */
final class GasWindow {
    private static final int SECTION_BLOCKS = 16;
    private static final int BRICK = GridSize.BRICK;

    private final GridSize size;
    private final int cellSize;
    /** Which of the world's windows this is, 0 for the fine one. */
    private final int windowIndex;
    private final int cellsPerSection;
    private final int sectionsX;
    private final int sectionsY;
    private final int sectionsZ;
    /**
     * Sections waiting to be read, in the order they are to be: those that have come into the window, nearest
     * first, and those in which a chunk has arrived or a block been set, as the game told of them. A set, so that
     * a section told of twice before it is read is read once.
     */
    private final LongLinkedOpenHashSet unread = new LongLinkedOpenHashSet();
    /**
     * Sections in which the player has set a block, read whole before any other and whatever the time: a block broken
     * under one's feet should not wait behind a row of chunks that has just come into view. None of them is also in
     * {@link #unread}.
     */
    private final LongLinkedOpenHashSet changedByPlayer = new LongLinkedOpenHashSet();
    /** Sections of which only the light need be read again. None of them is also in the two sets above. */
    private final LongLinkedOpenHashSet relit = new LongLinkedOpenHashSet();
    /** Scratch for sorting the sections that enter when the window moves. */
    private final long[] entered;

    private @Nullable GridPlacement placement;
    /** How many times the window has moved: the copies of sections, and the steps, say where it was for them. */
    private int epoch;
    private int sweepCursor;

    GasWindow(GridSize size, int cellSize, int windowIndex) {
        this.size = size;
        this.cellSize = cellSize;
        this.windowIndex = windowIndex;
        this.cellsPerSection = SECTION_BLOCKS / cellSize;
        if (BRICK % cellsPerSection != 0) {
            throw new IllegalArgumentException("A brick of cells of " + cellSize + " blocks is not a whole number of chunk sections");
        }
        this.sectionsX = size.x() / cellsPerSection;
        this.sectionsY = size.y() / cellsPerSection;
        this.sectionsZ = size.z() / cellsPerSection;
        this.entered = new long[sectionsX * sectionsY * sectionsZ];
    }

    int cellSize() {
        return cellSize;
    }

    /** Where the window is now, or null before it has first followed the camera. */
    @Nullable GridPlacement placement() {
        return placement;
    }

    int epoch() {
        return epoch;
    }

    int waitingSections() {
        return unread.size() + changedByPlayer.size();
    }

    int waitingForLight() {
        return relit.size();
    }

    /** Every section of a chunk that has just arrived is to be read. */
    void chunkArrived(int chunkX, int chunkZ) {
        GridPlacement window = placement;
        if (window == null) {
            return;
        }
        for (int y = 0; y < sectionsY; y++) {
            readLater(window, chunkX, window.originY() / cellsPerSection + y, chunkZ, false);
        }
    }

    /**
     * The section a block has been set in is to be read; ahead of all others if the player set it: a block broken
     * under one's feet should not wait behind a row of chunks that has just come into view.
     */
    void blockChanged(int blockX, int blockY, int blockZ, boolean byPlayer) {
        GridPlacement window = placement;
        if (window != null) {
            readLater(window, SectionPos.blockToSectionCoord(blockX), SectionPos.blockToSectionCoord(blockY),
                    SectionPos.blockToSectionCoord(blockZ), byPlayer);
        }
    }

    /** A section the game is going to draw again has its light read again, unless all of it is to be read anyway. */
    void sectionTouched(int sectionX, int sectionY, int sectionZ) {
        GridPlacement window = placement;
        if (window == null || !holdsSection(window, sectionX, sectionY, sectionZ)) {
            return;
        }
        long section = SectionPos.asLong(sectionX, sectionY, sectionZ);
        if (!unread.contains(section) && !changedByPlayer.contains(section)) {
            relit.add(section);
        }
    }

    private void readLater(GridPlacement window, int sectionX, int sectionY, int sectionZ, boolean first) {
        if (!holdsSection(window, sectionX, sectionY, sectionZ)) {
            return;
        }
        long section = SectionPos.asLong(sectionX, sectionY, sectionZ);
        relit.remove(section);
        if (first) {
            unread.remove(section);
            changedByPlayer.add(section);
        } else if (!changedByPlayer.contains(section)) {
            unread.add(section);
        }
    }

    /**
     * Keeps the camera near the middle of the window, moving the window a whole brick at a time, which is a whole
     * number of chunk sections too: the gas then moves with it a brick at a time, which costs next to nothing. Up and
     * down the window keeps inside the world's height, {@code bottomBlock} to {@code topBlock}, as far as it fits: a
     * cell beyond the world would hold nothing.
     */
    void follow(Vec3 camera, int bottomBlock, int topBlock) {
        GridPlacement wanted = new GridPlacement(originFor(camera.x, size.x()), verticalOriginFor(camera.y, bottomBlock, topBlock),
                originFor(camera.z, size.z()), cellSize);
        GridPlacement previous = placement;
        if (wanted.equals(previous)) {
            return;
        }
        placement = wanted;
        epoch++;
        MainThreadTime.countWindowMove();
        queueUnreadSections(wanted, previous, camera);
    }

    /** Hands every section in which the player has set a block to the scan, whatever the time or the scan's backlog. */
    void captureChangedByPlayer(ClientLevel level, ScanWorker scans) {
        GridPlacement window = placement;
        if (window == null) {
            return;
        }
        while (!changedByPlayer.isEmpty()) {
            long section = changedByPlayer.removeFirstLong();
            capture(level, window, scans, SectionPos.x(section), SectionPos.y(section), SectionPos.z(section), false);
        }
    }

    /**
     * Hands the sections that are waiting to the scan, until none is left, the deadline has passed or the scan has as
     * many in hand as it may: those to be read whole, and then those of which only the light is.
     */
    void captureWaiting(ClientLevel level, long deadlineNanos, ScanWorker scans) {
        GridPlacement window = placement;
        if (window == null) {
            return;
        }
        while (!(unread.isEmpty() && relit.isEmpty()) && scans.hasRoom() && System.nanoTime() < deadlineNanos) {
            boolean lightOnly = unread.isEmpty();
            long section = lightOnly ? relit.removeFirstLong() : unread.removeFirstLong();
            capture(level, window, scans, SectionPos.x(section), SectionPos.y(section), SectionPos.z(section), lightOnly);
        }
    }

    /**
     * Goes on round the window handing its sections to the scan again, until the deadline or until the scan has as
     * many in hand as it may. The game tells of every change it knows of, so this only catches what it did not: it
     * may take a long while to come by.
     */
    void sweep(ClientLevel level, long deadlineNanos, ScanWorker scans) {
        GridPlacement window = placement;
        if (window == null) {
            return;
        }
        while (scans.hasRoom() && System.nanoTime() < deadlineNanos) {
            int index = sweepCursor;
            sweepCursor = (sweepCursor + 1) % (sectionsX * sectionsY * sectionsZ);
            capture(level, window, scans, window.originX() / cellsPerSection + index % sectionsX,
                    window.originY() / cellsPerSection + index / (sectionsX * sectionsZ),
                    window.originZ() / cellsPerSection + index / sectionsX % sectionsZ, false);
        }
    }

    /**
     * Copies a section out of the world for the scan, unless it is outside the window or its chunk is not loaded:
     * then it is left as it is, and read when it comes into the window or its chunk arrives.
     */
    private void capture(ClientLevel level, GridPlacement window, ScanWorker scans, int sectionX, int sectionY, int sectionZ,
                         boolean lightOnly) {
        if (holdsWholeSection(window, sectionX, sectionY, sectionZ)) {
            SectionCopy copy = SectionCopy.capture(level, windowIndex, epoch, sectionX, sectionY, sectionZ, lightOnly);
            if (copy != null) {
                scans.submit(copy);
            }
        }
    }

    /** The window's first cell along an axis: the camera's cell less half the window, to the nearest whole brick. */
    private int originFor(double cameraBlock, int cells) {
        int cameraCell = Math.floorDiv(Mth.floor(cameraBlock), cellSize);
        return Math.floorDiv(cameraCell - cells / 2 + BRICK / 2, BRICK) * BRICK;
    }

    /**
     * The same up and down, moved inside the world's height if the window fits in it, or, if it does not, so that the
     * whole of the world's height is inside the window.
     */
    private int verticalOriginFor(double cameraBlock, int bottomBlock, int topBlock) {
        int brickBlocks = BRICK * cellSize;
        // The window's first cell at the brick at or below the world's lowest block, and so that its last brick ends
        // at or above the world's top.
        int lowest = Math.floorDiv(bottomBlock, brickBlocks) * BRICK;
        int highest = Math.floorDiv(topBlock + brickBlocks - 1, brickBlocks) * BRICK - size.y();
        return Math.clamp(originFor(cameraBlock, size.y()), Math.min(lowest, highest), Math.max(lowest, highest));
    }

    private boolean holdsSection(GridPlacement window, int sectionX, int sectionY, int sectionZ) {
        return size.contains(sectionX * cellsPerSection - window.originX(), sectionY * cellsPerSection - window.originY(),
                sectionZ * cellsPerSection - window.originZ());
    }

    /** Whether every cell of the section is inside the window, its first one and its last. */
    private boolean holdsWholeSection(GridPlacement window, int sectionX, int sectionY, int sectionZ) {
        int cellX = sectionX * cellsPerSection - window.originX();
        int cellY = sectionY * cellsPerSection - window.originY();
        int cellZ = sectionZ * cellsPerSection - window.originZ();
        return size.contains(cellX, cellY, cellZ)
                && size.contains(cellX + cellsPerSection - 1, cellY + cellsPerSection - 1, cellZ + cellsPerSection - 1);
    }

    private void queueUnreadSections(GridPlacement now, @Nullable GridPlacement before, Vec3 camera) {
        int cameraX = SectionPos.blockToSectionCoord(camera.x);
        int cameraY = SectionPos.blockToSectionCoord(camera.y);
        int cameraZ = SectionPos.blockToSectionCoord(camera.z);
        // Each entry is the section's squared distance from the camera above its place in the window, so that
        // sorting the numbers sorts the sections nearest first.
        int count = 0;
        for (int y = 0; y < sectionsY; y++) {
            for (int z = 0; z < sectionsZ; z++) {
                for (int x = 0; x < sectionsX; x++) {
                    int sectionX = now.originX() / cellsPerSection + x;
                    int sectionY = now.originY() / cellsPerSection + y;
                    int sectionZ = now.originZ() / cellsPerSection + z;
                    if (before == null || !holdsSection(before, sectionX, sectionY, sectionZ)) {
                        long distance = (long) (sectionX - cameraX) * (sectionX - cameraX)
                                + (long) (sectionY - cameraY) * (sectionY - cameraY)
                                + (long) (sectionZ - cameraZ) * (sectionZ - cameraZ);
                        entered[count++] = distance << Integer.SIZE | x + sectionsX * (z + (long) sectionsZ * y);
                    }
                }
            }
        }
        Arrays.sort(entered, 0, count);
        for (int i = 0; i < count; i++) {
            int index = (int) entered[i];
            unread.add(SectionPos.asLong(
                    now.originX() / cellsPerSection + index % sectionsX,
                    now.originY() / cellsPerSection + index / (sectionsX * sectionsZ),
                    now.originZ() / cellsPerSection + index / sectionsX % sectionsZ));
        }
    }
}
