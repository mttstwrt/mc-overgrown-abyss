package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.sim.Occupancy;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongLinkedOpenHashSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.SectionPos;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * One box of cells that follows the camera, and what the world looks like inside it: what stands in the way of
 * gas, how each cell is lit, and which blocks give gas off. Client thread only.
 */
final class GasWindow {
    private static final int SECTION_BLOCKS = 16;
    private static final int BRICK = GridSize.BRICK;

    private final GridSize size;
    private final int cellSize;
    private final int cellsPerSection;
    private final int sectionsX;
    private final int sectionsY;
    private final int sectionsZ;
    private final Occupancy occupancy;
    private final LightGrid light;
    private final SectionScanner scanner;
    /** Emitters at blocks a datapack rule names, by the chunk section the blocks are in. */
    private final Long2ObjectOpenHashMap<List<Emitter>> blockEmitters = new Long2ObjectOpenHashMap<>();
    private final List<Emitter> found = new ArrayList<>();
    /**
     * Sections waiting to be read, in the order they are to be: those that have come into the window, nearest
     * first, and those in which a chunk has arrived or a block been set, as the game told of them. A set, so that
     * a section told of twice before it is read is read once.
     */
    private final LongLinkedOpenHashSet unread = new LongLinkedOpenHashSet();
    /** Sections of which only the light need be read again. None of them is also in {@link #unread}. */
    private final LongLinkedOpenHashSet relit = new LongLinkedOpenHashSet();
    /** Scratch for sorting the sections that enter when the window moves. */
    private final long[] entered;

    private @Nullable GridPlacement placement;
    private @Nullable Occupancy submittedOccupancy;
    private boolean occupancyChanged = true;
    private int sweepCursor;

    GasWindow(GridSize size, int cellSize, List<BlockEmitterRule> rules) {
        this.size = size;
        this.cellSize = cellSize;
        this.cellsPerSection = SECTION_BLOCKS / cellSize;
        if (BRICK % cellsPerSection != 0) {
            throw new IllegalArgumentException("A brick of cells of " + cellSize + " blocks is not a whole number of chunk sections");
        }
        this.sectionsX = size.x() / cellsPerSection;
        this.sectionsY = size.y() / cellsPerSection;
        this.sectionsZ = size.z() / cellsPerSection;
        this.occupancy = new Occupancy(size);
        this.light = new LightGrid(size);
        this.scanner = new SectionScanner(size, cellSize, rules);
        this.entered = new long[sectionsX * sectionsY * sectionsZ];
    }

    int cellSize() {
        return cellSize;
    }

    /** Where the window is now, or null before it has first followed the camera. */
    @Nullable GridPlacement placement() {
        return placement;
    }

    LightGrid light() {
        return light;
    }

    int waitingSections() {
        return unread.size();
    }

    int waitingForLight() {
        return relit.size();
    }

    /** Every section of a chunk that has just arrived is to be read. */
    void chunkArrived(int chunkX, int chunkZ) {
        GridPlacement window = placement;
        if (window == null) {
            return;
        }
        for (int y = 0; y < sectionsY; y++) {
            readLater(window, chunkX, window.originY() / cellsPerSection + y, chunkZ, false);
        }
    }

    /**
     * The section a block has been set in is to be read; ahead of all others if the player set it: a block broken
     * under one's feet should not wait behind a row of chunks that has just come into view.
     */
    void blockChanged(int blockX, int blockY, int blockZ, boolean byPlayer) {
        GridPlacement window = placement;
        if (window != null) {
            readLater(window, SectionPos.blockToSectionCoord(blockX), SectionPos.blockToSectionCoord(blockY),
                    SectionPos.blockToSectionCoord(blockZ), byPlayer);
        }
    }

    /** A section the game is going to draw again has its light read again, unless all of it is to be read anyway. */
    void sectionTouched(int sectionX, int sectionY, int sectionZ) {
        GridPlacement window = placement;
        if (window == null || !holdsSection(window, sectionX, sectionY, sectionZ)) {
            return;
        }
        long section = SectionPos.asLong(sectionX, sectionY, sectionZ);
        if (!unread.contains(section)) {
            relit.add(section);
        }
    }

    private void readLater(GridPlacement window, int sectionX, int sectionY, int sectionZ, boolean first) {
        if (!holdsSection(window, sectionX, sectionY, sectionZ)) {
            return;
        }
        long section = SectionPos.asLong(sectionX, sectionY, sectionZ);
        relit.remove(section);
        if (first) {
            unread.addAndMoveToFirst(section);
        } else {
            unread.add(section);
        }
    }

    int emitterCount() {
        int count = 0;
        for (List<Emitter> section : blockEmitters.values()) {
            count += section.size();
        }
        return count;
    }

    void addEmittersTo(List<Emitter> emitters) {
        blockEmitters.values().forEach(emitters::addAll);
    }

    /**
     * The occupancy for the simulation to work from: a copy, since the simulation thread reads it while this
     * thread goes on scanning, and a new one only when something has changed since the last.
     */
    Occupancy occupancyForStep() {
        if (occupancyChanged || submittedOccupancy == null) {
            submittedOccupancy = occupancy.copy();
            occupancyChanged = false;
        }
        return submittedOccupancy;
    }

    /**
     * Keeps the camera near the middle of the window, moving the window a whole brick at a time, which is a whole
     * number of chunk sections too: the gas then moves with it a brick at a time, which costs next to nothing. Up and
     * down the window keeps inside the world's height, {@code bottomBlock} to {@code topBlock}, as far as it fits: a
     * cell beyond the world would hold nothing.
     */
    void follow(Vec3 camera, int bottomBlock, int topBlock) {
        GridPlacement wanted = new GridPlacement(originFor(camera.x, size.x()), verticalOriginFor(camera.y, bottomBlock, topBlock),
                originFor(camera.z, size.z()), cellSize);
        GridPlacement previous = placement;
        if (wanted.equals(previous)) {
            return;
        }
        placement = wanted;
        if (previous != null) {
            int dx = wanted.originX() - previous.originX();
            int dy = wanted.originY() - previous.originY();
            int dz = wanted.originZ() - previous.originZ();
            occupancy.shift(dx, dy, dz);
            light.shift(dx, dy, dz);
            occupancyChanged = true;
            blockEmitters.keySet().removeIf(section -> !holdsSection(wanted, SectionPos.x(section), SectionPos.y(section), SectionPos.z(section)));
        }
        queueUnreadSections(wanted, previous, camera);
    }

    /**
     * Reads the sections that are waiting, until none is left or the deadline has passed: those to be read
     * whole, and then those of which only the light is.
     */
    void readWaiting(ClientLevel level, long deadlineNanos) {
        GridPlacement window = placement;
        if (window == null) {
            return;
        }
        while (!(unread.isEmpty() && relit.isEmpty()) && System.nanoTime() < deadlineNanos) {
            if (unread.isEmpty()) {
                long section = relit.removeFirstLong();
                scanner.readLight(level, window, SectionPos.x(section), SectionPos.y(section), SectionPos.z(section), light);
            } else {
                long section = unread.removeFirstLong();
                readSection(level, window, SectionPos.x(section), SectionPos.y(section), SectionPos.z(section));
            }
        }
    }

    /**
     * Goes on round the window reading its sections again, until the deadline. The game tells of every change it
     * knows of, so this only catches what it did not: it may take a long while to come by.
     */
    void sweep(ClientLevel level, long deadlineNanos) {
        GridPlacement window = placement;
        if (window == null) {
            return;
        }
        while (System.nanoTime() < deadlineNanos) {
            int index = sweepCursor;
            sweepCursor = (sweepCursor + 1) % (sectionsX * sectionsY * sectionsZ);
            readSection(level, window, window.originX() / cellsPerSection + index % sectionsX,
                    window.originY() / cellsPerSection + index / (sectionsX * sectionsZ),
                    window.originZ() / cellsPerSection + index / sectionsX % sectionsZ);
        }
    }

    private void readSection(ClientLevel level, GridPlacement window, int sectionX, int sectionY, int sectionZ) {
        found.clear();
        SectionScanner.Result result = scanner.scan(level, window, sectionX, sectionY, sectionZ, occupancy, light, found);
        if (result == SectionScanner.Result.OCCUPANCY_CHANGED) {
            occupancyChanged = true;
        }
        if (result != SectionScanner.Result.SKIPPED) {
            long section = SectionPos.asLong(sectionX, sectionY, sectionZ);
            if (found.isEmpty()) {
                blockEmitters.remove(section);
            } else {
                blockEmitters.put(section, List.copyOf(found));
            }
        }
    }

    /** The window's first cell along an axis: the camera's cell less half the window, to the nearest whole brick. */
    private int originFor(double cameraBlock, int cells) {
        int cameraCell = Math.floorDiv(Mth.floor(cameraBlock), cellSize);
        return Math.floorDiv(cameraCell - cells / 2 + BRICK / 2, BRICK) * BRICK;
    }

    /**
     * The same up and down, moved inside the world's height if the window fits in it, or, if it does not, so that the
     * whole of the world's height is inside the window.
     */
    private int verticalOriginFor(double cameraBlock, int bottomBlock, int topBlock) {
        int brickBlocks = BRICK * cellSize;
        // The window's first cell at the brick at or below the world's lowest block, and so that its last brick ends
        // at or above the world's top.
        int lowest = Math.floorDiv(bottomBlock, brickBlocks) * BRICK;
        int highest = Math.floorDiv(topBlock + brickBlocks - 1, brickBlocks) * BRICK - size.y();
        return Math.clamp(originFor(cameraBlock, size.y()), Math.min(lowest, highest), Math.max(lowest, highest));
    }

    private boolean holdsSection(GridPlacement window, int sectionX, int sectionY, int sectionZ) {
        return size.contains(sectionX * cellsPerSection - window.originX(), sectionY * cellsPerSection - window.originY(),
                sectionZ * cellsPerSection - window.originZ());
    }

    private void queueUnreadSections(GridPlacement now, @Nullable GridPlacement before, Vec3 camera) {
        int cameraX = SectionPos.blockToSectionCoord(camera.x);
        int cameraY = SectionPos.blockToSectionCoord(camera.y);
        int cameraZ = SectionPos.blockToSectionCoord(camera.z);
        // Each entry is the section's squared distance from the camera above its place in the window, so that
        // sorting the numbers sorts the sections nearest first.
        int count = 0;
        for (int y = 0; y < sectionsY; y++) {
            for (int z = 0; z < sectionsZ; z++) {
                for (int x = 0; x < sectionsX; x++) {
                    int sectionX = now.originX() / cellsPerSection + x;
                    int sectionY = now.originY() / cellsPerSection + y;
                    int sectionZ = now.originZ() / cellsPerSection + z;
                    if (before == null || !holdsSection(before, sectionX, sectionY, sectionZ)) {
                        long distance = (long) (sectionX - cameraX) * (sectionX - cameraX)
                                + (long) (sectionY - cameraY) * (sectionY - cameraY)
                                + (long) (sectionZ - cameraZ) * (sectionZ - cameraZ);
                        entered[count++] = distance << Integer.SIZE | x + sectionsX * (z + (long) sectionsZ * y);
                    }
                }
            }
        }
        Arrays.sort(entered, 0, count);
        for (int i = 0; i < count; i++) {
            int index = (int) entered[i];
            unread.add(SectionPos.asLong(
                    now.originX() / cellsPerSection + index % sectionsX,
                    now.originY() / cellsPerSection + index / (sectionsX * sectionsZ),
                    now.originZ() / cellsPerSection + index / sectionsX % sectionsZ));
        }
    }
}
