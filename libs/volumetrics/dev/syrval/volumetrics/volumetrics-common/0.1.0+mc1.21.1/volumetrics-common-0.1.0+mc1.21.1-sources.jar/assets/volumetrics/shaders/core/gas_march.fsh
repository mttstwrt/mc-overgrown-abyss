#include <volumetrics:gas_game.glsl>
#include <volumetrics:gas_field.glsl>

uniform sampler2D DepthSampler;
uniform sampler2D NoiseSampler;
// The game's lightmap: 16 texels each way, block light along x and sky light along y, a light level to a texel.
uniform sampler2D LightmapSampler;

in vec2 texCoord;

// rgb: light the gas sends to the eye, already weighted by how much of it there is. a: how much it hides.
out vec4 fragColor;

// The pipeline defines, differently for each quality setting:
//   MIN_STEP_BLOCKS  the length of a step near the camera
//   STEP_GROWTH      how much longer a step gets for each block of distance: far gas covers fewer pixels
//   MAX_SAMPLES      the most steps a ray takes through bricks that hold gas

// Stepping over an empty brick is not a sample but is a turn of the loop; a ray crosses a few dozen bricks at most.
const int MAX_TURNS = MAX_SAMPLES + 64;
// Under this a channel is treated as empty: it is below what a byte of the density texture can hold anyway.
const float NO_GAS = 0.004;

// Where in each of its steps a pixel's ray takes its sample: one of nine evenly spread places, in a pattern that
// repeats every three pixels each way. Any three by three pixels therefore hold all nine, and the filter pass,
// which averages just such a square, turns one sample a step into nine without a trace of the pattern.
const int OFFSET_ORDER[9] = int[9](0, 5, 7, 3, 8, 1, 6, 2, 4);

float rayOffset(vec2 pixel) {
    ivec2 place = ivec2(pixel) % 3;
    return (float(OFFSET_ORDER[place.x + 3 * place.y]) + 0.5) / 9.0;
}

// Smooth noise, 0 to 1, that changes about once for each whole number. The texture holds one layer of it in red
// and, in green, the layer above: the same layer moved along by LAYER_SHIFT. One blended read gives both.
const float NOISE_SIZE = 256.0;
const vec2 LAYER_SHIFT = vec2(37.0, 239.0);

float valueNoise(vec3 p) {
    vec3 whole = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    vec2 texel = mod(whole.xy + LAYER_SHIFT * whole.z, NOISE_SIZE) + f.xy;
    vec2 layers = textureLod(NoiseSampler, (texel + 0.5) / NOISE_SIZE, 0.0).rg;
    return mix(layers.r, layers.g, f.z);
}

// What the game makes of a sky and a block light level, each 0 to 1: the light that falls on a block there at
// this moment. The time of day, the dimension, the player's brightness setting and night vision are all in it,
// so gas lit by it is as bright as the blocks around it, whatever makes them so. Read between the centres of the
// texels, as the game's own shaders do, so that levels in between blend.
vec3 lightmapLight(float sky, float block) {
    return textureLod(LightmapSampler, (vec2(block, sky) * 15.0 + 0.5) / 16.0, 0.0).rgb;
}

// The colour one kind of gas shows, seen along a ray, where the game's light is: ambient, what falls on
// everything there; fromSky and fromLamps, what the sky and light sources add to that. A gas's two responses
// weigh those two; sky is the sky light level, 0 to 1, for the glow towards the sun.
vec3 litColor(int medium, vec3 ambient, vec3 fromSky, vec3 fromLamps, float sky, vec3 ray) {
    vec4 response = GasMediumLight[medium];
    vec3 light = min(ambient + fromSky * response.x + fromLamps * response.y, vec3(1.0));
    float towardsSun = max(dot(ray, GasSunDirection.xyz), 0.0);
    float glow = pow(towardsSun, 8.0) * GasSunDirection.w * sky * response.w;
    return GasMediumColor[medium].rgb * (light + response.z) + vec3(1.0, 0.95, 0.85) * glow;
}

void main() {
    float depth = textureLod(DepthSampler, texCoord, 0.0).r;
    // Depth is cleared to 1, so 1 is sky. Unproject it a hair in front of that for a direction.
    bool sky = depth >= 1.0;
    depth = min(depth, 0.99999);
    vec4 unprojected = inverse(ProjMat) * vec4(texCoord * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec3 fromCamera = (GasInverseViewRotation * vec4(unprojected.xyz / unprojected.w, 0.0)).xyz;
    float sceneBlocks = sky ? 1.0e6 : length(fromCamera);

    vec3 ray = normalize(fromCamera);
    // Most rays miss the box all the gas lies in, or reach the scene before it, and end here.
    GasRay gas = gasRay(ray, sceneBlocks);
    if (gas.to <= gas.from) {
        fragColor = vec4(0.0);
        return;
    }
    float t = gas.from;
    float end = gas.to;

    float offset = rayOffset(gl_FragCoord.xy);
    // Wrapped, so the wisps keep their detail far from the world's origin.
    vec3 noiseOrigin = vec3(GasCameraBlock.xyz & 1023) - GasCameraOffset.xyz;

    vec3 ambient = lightmapLight(0.0, 0.0);

    vec3 scattered = vec3(0.0);
    float through = 1.0;
    float distanceSum = 0.0;
    int samples = 0;

    // The ray is cut into steps that lie end to end, and the gas of each is judged by one sample somewhere in it.
    for (int turn = 0; turn < MAX_TURNS && samples < MAX_SAMPLES && t < end && through > 0.02; turn++) {
        float onward = gasSkipEmpty(gas, t);
        if (onward > t) {
            t = onward;
            continue;
        }

        // The last step ends at the scene, however short that makes it.
        float stepEnd = min(t + max(MIN_STEP_BLOCKS, t * STEP_GROWTH), end);
        float stepBlocks = stepEnd - t;
        float at = t + stepBlocks * offset;
        t = stepEnd;
        samples++;

        vec2 lit;
        vec4 density = gasAlong(gas, at, lit);
        if (max(max(density.r, density.g), max(density.b, density.a)) < NO_GAS) {
            continue;
        }

        vec3 fromSky = lightmapLight(lit.x, 0.0) - ambient;
        vec3 fromLamps = lightmapLight(0.0, lit.y) - ambient;
        vec3 block = noiseOrigin + ray * at;
        float stopped = 0.0;
        vec3 color = vec3(0.0);
        for (int medium = 0; medium < 4; medium++) {
            float amount = density[medium];
            if (amount < NO_GAS) {
                continue;
            }
            vec4 wisps = GasMediumNoise[medium];
            // Wisps need a few steps each to show; with fewer they are only noise, so they fade out with distance.
            float detail = wisps.z * clamp(2.0 - 4.0 * stepBlocks * wisps.x, 0.0, 1.0);
            if (detail > 0.0) {
                // The pattern goes the way the gas moves: along with one that is carried, and down for one that sinks.
                vec3 carried = vec3(GasMediumDrift[medium].x, 0.0, GasMediumDrift[medium].y) * GasTime;
                float wisp = valueNoise((block - carried) * wisps.x + vec3(0.0, GasTime * wisps.y * wisps.w, 0.0));
                amount *= mix(1.0, wisp * 2.0, detail);
            }
            float stops = amount * GasMediumColor[medium].a;
            stopped += stops;
            color += stops * litColor(medium, ambient, fromSky, fromLamps, lit.x, ray);
        }
        if (stopped <= 0.0) {
            continue;
        }

        float hidden = 1.0 - exp(-stopped * stepBlocks);
        scattered += through * hidden * color / stopped;
        distanceSum += through * hidden * at;
        through *= 1.0 - hidden;
    }

    float alpha = 1.0 - through;
    if (alpha > 0.0) {
        // The game's own distance fog takes the gas as it takes the terrain behind it.
        float fogged = gasFog(ray * (distanceSum / alpha));
        scattered = mix(scattered, FogColor.rgb * alpha, fogged * FogColor.a);
    }
    fragColor = vec4(scattered, alpha);
}
