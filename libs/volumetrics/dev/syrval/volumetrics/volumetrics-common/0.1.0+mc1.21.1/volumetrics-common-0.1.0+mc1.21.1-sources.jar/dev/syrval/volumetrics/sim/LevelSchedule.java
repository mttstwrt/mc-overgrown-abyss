package dev.syrval.volumetrics.sim;

/**
 * When each level of the cascade steps, counted in base steps. Level k has cells 2^k times as large as level 0's and
 * steps every 2^k base steps, by 2^k base steps at a time, so that the gas moves as far in a step for each level's
 * cells. Level 0 steps at every base step; the others are staggered so that a base step runs level 0 and at most one
 * other: level k >= 1 steps at the base steps s with s mod 2^k == 2^(k-1).
 *
 * <p>A level stepped at base step s goes forward from s to the end of its interval, s + 2^k. Within a base step the
 * coarser levels step first, so a finer level steps to a time inside the interval its next coarser level has just
 * stepped across, or is still in, and takes what is at its edge from between the coarser level's two last states by
 * {@link #fraction}.
 */
public final class LevelSchedule {
    /** The most levels there may be: their cells, 2 * 2^k blocks, must divide a chunk section's 16. */
    public static final int MAX_LEVELS = 4;

    private LevelSchedule() {}

    /** How many base steps a step of the level spans. */
    public static int interval(int level) {
        return 1 << level;
    }

    /** The seconds a step of the level spans, for base steps of {@code baseSeconds}. */
    public static float stepSeconds(int level, float baseSeconds) {
        return baseSeconds * interval(level);
    }

    /** Whether the level steps at base step {@code step}. */
    public static boolean steps(int level, long step) {
        return level == 0 || Math.floorMod(step, interval(level)) == interval(level) / 2;
    }

    /** The last base step at or before {@code step} at which the level steps; before its first, a negative one. */
    public static long lastStep(int level, long step) {
        if (level == 0) {
            return step;
        }
        int interval = interval(level);
        return step - Math.floorMod(step - interval / 2, interval);
    }

    /**
     * Where the end of the step of {@code level} at base step {@code step} falls within the step of the next coarser
     * level at base step {@code outerStep}: 0 at the state before that step, 1 at the state after it.
     *
     * <p>The stagger lets a level's every other step end past the end of the coarser level's newest interval (by a
     * quarter of it, for level 1 and up): it then takes the newest state, 1, as it would without interpolating.
     */
    public static float fraction(int level, long step, long outerStep) {
        double fraction = (double) (step + interval(level) - outerStep) / interval(level + 1);
        return (float) Math.clamp(fraction, 0.0, 1.0);
    }
}
