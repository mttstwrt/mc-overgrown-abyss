package dev.syrval.volumetrics.sim;

import java.util.Arrays;

/**
 * What stands in the way of gas in the window. A cell is coarser than a block, so a floor or a wall one block
 * thick does not fill one. Each cell therefore records, for each of its six sides, whether the layer of blocks
 * along that side is solid: gas crosses from one cell to the next only if neither cell has a solid layer at the
 * face between them. A floor through the middle of a cell holds gas up, and the gas still lies in the cell's
 * open half, down on the floor where it belongs.
 *
 * <p>A cell that is solid through and through is closed: no gas is ever in it. A cell nobody has looked at yet
 * counts as closed, so gas never flows into terrain that has not been scanned and then vanishes when it is.
 */
public final class Occupancy {
    public static final int WEST = 1;
    public static final int EAST = 1 << 1;
    public static final int DOWN = 1 << 2;
    public static final int UP = 1 << 3;
    public static final int NORTH = 1 << 4;
    public static final int SOUTH = 1 << 5;
    /** No gas can be in the cell at all. Always set together with every side. */
    static final int CLOSED = 1 << 6;
    private static final int ALL_SIDES = WEST | EAST | DOWN | UP | NORTH | SOUTH;
    private static final byte OPEN_CELL = 0;
    private static final byte CLOSED_CELL = (byte) (ALL_SIDES | CLOSED);

    private final GridSize size;
    private final byte[] cells;

    public Occupancy(GridSize size) {
        this.size = size;
        this.cells = new byte[size.cells()];
        Arrays.fill(cells, CLOSED_CELL);
    }

    private Occupancy(GridSize size, byte[] cells) {
        this.size = size;
        this.cells = cells;
    }

    public GridSize size() {
        return size;
    }

    /** Whether the cell is closed: solid throughout, or not yet scanned. */
    public boolean isBlocked(int cellX, int cellY, int cellZ) {
        return (cells[size.index(cellX, cellY, cellZ)] & CLOSED) != 0;
    }

    /** Closes a cell entirely, or opens it on every side. */
    public void setBlocked(int cellX, int cellY, int cellZ, boolean blocked) {
        cells[size.index(cellX, cellY, cellZ)] = blocked ? CLOSED_CELL : OPEN_CELL;
    }

    /**
     * Makes a cell open to gas but with solid layers along some of its sides.
     *
     * @param solidSides any of {@link #WEST}, {@link #EAST}, {@link #DOWN}, {@link #UP}, {@link #NORTH},
     *                   {@link #SOUTH} added together
     */
    public void setSolidSides(int cellX, int cellY, int cellZ, int solidSides) {
        if ((solidSides & ~ALL_SIDES) != 0) {
            throw new IllegalArgumentException("Not a set of sides: " + solidSides);
        }
        cells[size.index(cellX, cellY, cellZ)] = (byte) solidSides;
    }

    /** The cell's solid sides, or every side if it is closed. */
    public int solidSides(int cellX, int cellY, int cellZ) {
        return cells[size.index(cellX, cellY, cellZ)] & ALL_SIDES;
    }

    public void setAll(boolean blocked) {
        Arrays.fill(cells, blocked ? CLOSED_CELL : OPEN_CELL);
    }

    /** Follows the window as its origin moves; cells that enter are closed until scanned. */
    public void shift(int cellsX, int cellsY, int cellsZ) {
        GridShift.shift(cells, size, cellsX, cellsY, cellsZ, CLOSED_CELL);
    }

    public Occupancy copy() {
        return new Occupancy(size, cells.clone());
    }

    /** The raw flags, indexed by {@link GridSize#index}. For the stepper's inner loop. */
    byte[] cells() {
        return cells;
    }
}
