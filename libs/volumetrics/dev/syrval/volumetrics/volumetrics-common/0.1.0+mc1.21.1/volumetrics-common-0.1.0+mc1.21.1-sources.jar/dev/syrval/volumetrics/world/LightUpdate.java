package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.sim.GridPlacement;
import java.nio.ByteBuffer;

/**
 * Light of one window that the simulation thread has changed, for the renderer to send: each slice in a buffer of its
 * own, two bytes a cell from the start, sky then block light. Handed over once; each buffer goes back with
 * {@link GasWorld#recycleLightSlice} once it has been sent.
 *
 * @param placement where the window is that the light is for
 * @param whole     whether this is every slice, after the window has moved or the first time: then it is to be sent at
 *                  once, and the window's light is for {@code placement} from then on
 * @param slices    the slices sent, by their height in the window
 * @param buffers   for each of {@code slices}, its texels
 */
public record LightUpdate(int window, GridPlacement placement, boolean whole, int[] slices, ByteBuffer[] buffers) {}
