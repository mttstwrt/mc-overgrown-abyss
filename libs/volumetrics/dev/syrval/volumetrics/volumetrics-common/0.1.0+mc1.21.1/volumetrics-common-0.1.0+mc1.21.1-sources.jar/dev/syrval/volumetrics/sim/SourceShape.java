package dev.syrval.volumetrics.sim;

/** The region of the world, in block coordinates, that a source feeds gas into. */
public sealed interface SourceShape {
    boolean contains(double x, double y, double z);

    double minX();

    double minY();

    double minZ();

    double maxX();

    double maxY();

    double maxZ();

    default double centreX() {
        return (minX() + maxX()) / 2;
    }

    default double centreY() {
        return (minY() + maxY()) / 2;
    }

    default double centreZ() {
        return (minZ() + maxZ()) / 2;
    }

    record Box(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) implements SourceShape {
        public Box {
            if (!(minX <= maxX && minY <= maxY && minZ <= maxZ)) {
                throw new IllegalArgumentException("Box corners are out of order");
            }
        }

        @Override
        public boolean contains(double x, double y, double z) {
            return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
        }
    }

    /** An upright cylinder standing on {@code baseY}. A disc is a cylinder of small height. */
    record Cylinder(double x, double baseY, double z, double radius, double height) implements SourceShape {
        public Cylinder {
            if (!(radius > 0) || !(height > 0)) {
                throw new IllegalArgumentException("Cylinder radius and height must be positive");
            }
        }

        @Override
        public boolean contains(double px, double py, double pz) {
            double dx = px - x;
            double dz = pz - z;
            return py >= baseY && py <= baseY + height && dx * dx + dz * dz <= radius * radius;
        }

        @Override
        public double minX() {
            return x - radius;
        }

        @Override
        public double minY() {
            return baseY;
        }

        @Override
        public double minZ() {
            return z - radius;
        }

        @Override
        public double maxX() {
            return x + radius;
        }

        @Override
        public double maxY() {
            return baseY + height;
        }

        @Override
        public double maxZ() {
            return z + radius;
        }
    }

    record Sphere(double x, double y, double z, double radius) implements SourceShape {
        public Sphere {
            if (!(radius > 0)) {
                throw new IllegalArgumentException("Sphere radius must be positive");
            }
        }

        @Override
        public boolean contains(double px, double py, double pz) {
            double dx = px - x;
            double dy = py - y;
            double dz = pz - z;
            return dx * dx + dy * dy + dz * dz <= radius * radius;
        }

        @Override
        public double minX() {
            return x - radius;
        }

        @Override
        public double minY() {
            return y - radius;
        }

        @Override
        public double minZ() {
            return z - radius;
        }

        @Override
        public double maxX() {
            return x + radius;
        }

        @Override
        public double maxY() {
            return y + radius;
        }

        @Override
        public double maxZ() {
            return z + radius;
        }
    }
}
