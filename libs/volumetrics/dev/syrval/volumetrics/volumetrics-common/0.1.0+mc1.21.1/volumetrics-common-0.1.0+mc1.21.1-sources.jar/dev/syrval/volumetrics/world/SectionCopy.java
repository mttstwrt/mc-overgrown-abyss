package dev.syrval.volumetrics.world;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.DataLayer;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.PalettedContainer;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.level.lighting.LayerLightEventListener;
import net.minecraft.world.level.lighting.LevelLightEngine;
import org.jspecify.annotations.Nullable;

/**
 * Everything the scan needs of one chunk section, copied out of the client's world on the client thread so that
 * {@link SectionScanner} can read it without the game. The copies belong to whoever holds this; they are handed over
 * once and nobody else touches them.
 *
 * @param window       the window the section is read for
 * @param epoch        how many times that window had moved when the section was copied
 * @param states       the section's blocks; null if they are all air, and for a section only lit or not in the world
 * @param blockLayer   the section's block light; null where it has none, which the game counts as dark
 * @param skyLayer     the section's sky light, or, where it has none, that of the nearest section above that has;
 *                     null if no section above has any either
 * @param skyFromAbove whether {@code skyLayer} is a section above's: then its lowest layer of blocks lights the
 *                     whole of this section, as the game has it
 * @param skyElsewhere the sky light of every block of the section when {@code skyLayer} is null
 */
record SectionCopy(int window, int epoch, int sectionX, int sectionY, int sectionZ, Kind kind,
                   @Nullable PalettedContainer<BlockState> states, @Nullable DataLayer blockLayer,
                   @Nullable DataLayer skyLayer, boolean skyFromAbove, int skyElsewhere) {
    private static final int FULL_SKY_LIGHT = 15;

    enum Kind {
        /** The section's blocks and its light. */
        FULL,
        /** Only its light: its blocks are known not to have changed. */
        LIGHT_ONLY,
        /** Below the world, where nothing moves. */
        BELOW_WORLD,
        /** Above the world: open sky. */
        ABOVE_WORLD
    }

    /**
     * Copies a section out of the world, or returns null if its chunk is not loaded or, when only its light is
     * wanted, if it is outside the world: then there is nothing to read. Client thread only.
     */
    static @Nullable SectionCopy capture(ClientLevel level, int window, int epoch, int sectionX, int sectionY, int sectionZ,
                                         boolean lightOnly) {
        if (sectionY < level./*? if >=26.1 {*//*getMinSectionY*//*?} else {*/getMinSection/*?}*/()) {
            return lightOnly ? null : new SectionCopy(window, epoch, sectionX, sectionY, sectionZ, Kind.BELOW_WORLD, null, null, null, false, 0);
        }
        if (sectionY /*? if >=26.1 {*//*> level.getMaxSectionY()*//*?} else {*/>= level.getMaxSection()/*?}*/) {
            return lightOnly ? null
                    : new SectionCopy(window, epoch, sectionX, sectionY, sectionZ, Kind.ABOVE_WORLD, null, null, null, false, FULL_SKY_LIGHT);
        }
        LevelChunk chunk = level.getChunkSource().getChunk(sectionX, sectionZ, ChunkStatus.FULL, false);
        if (chunk == null) {
            return null;
        }
        PalettedContainer<BlockState> states = null;
        if (!lightOnly) {
            LevelChunkSection section = chunk.getSection(chunk.getSectionIndexFromSectionY(sectionY));
            states = section.hasOnlyAir() ? null : section.getStates().copy();
        }

        LevelLightEngine engine = level.getLightEngine();
        SectionPos pos = SectionPos.of(sectionX, sectionY, sectionZ);
        // A section with no block light of its own is dark: the game answers 0 for every block of it.
        DataLayer blockLayer = engine.getLayerListener(LightLayer.BLOCK).getDataLayerData(pos);
        LayerLightEventListener skyListener = engine.getLayerListener(LightLayer.SKY);
        DataLayer skyLayer = skyListener.getDataLayerData(pos);
        boolean skyFromAbove = false;
        int skyElsewhere = FULL_SKY_LIGHT;
        if (skyLayer == null) {
            if (skyListener == LayerLightEventListener.DummyLightLayerEventListener.INSTANCE) {
                // A level without sky light, which the game answers 0 for everywhere.
                skyElsewhere = 0;
            } else {
                // The game lights a section without sky light of its own from the lowest blocks of the nearest
                // section above that has some, or fully if there is none.
                for (int y = sectionY + 1; y < engine.getMaxLightSection() && skyLayer == null; y++) {
                    skyLayer = skyListener.getDataLayerData(SectionPos.of(sectionX, y, sectionZ));
                }
                skyFromAbove = skyLayer != null;
            }
        }
        return new SectionCopy(window, epoch, sectionX, sectionY, sectionZ, lightOnly ? Kind.LIGHT_ONLY : Kind.FULL, states,
                blockLayer == null ? null : blockLayer.copy(), skyLayer == null ? null : skyLayer.copy(), skyFromAbove, skyElsewhere);
    }

    /** The sky light of a block of the section, 0 to 15, from the section's own coordinates. */
    int skyLightAt(int x, int y, int z) {
        DataLayer layer = skyLayer;
        return layer == null ? skyElsewhere : layer.get(x, skyFromAbove ? 0 : y, z);
    }

    /** The block light of a block of the section, 0 to 15, from the section's own coordinates. */
    int blockLightAt(int x, int y, int z) {
        DataLayer layer = blockLayer;
        return layer == null ? 0 : layer.get(x, y, z);
    }
}
