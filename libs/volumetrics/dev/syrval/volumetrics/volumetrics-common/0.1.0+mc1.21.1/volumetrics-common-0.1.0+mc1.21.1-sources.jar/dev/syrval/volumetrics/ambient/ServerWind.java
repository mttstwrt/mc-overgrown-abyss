package dev.syrval.volumetrics.ambient;

import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.api.wind.Wind;
import dev.syrval.volumetrics.api.wind.WindArea;
import dev.syrval.volumetrics.api.wind.WindProvider;
import dev.syrval.volumetrics.api.wind.Winds;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import org.jspecify.annotations.Nullable;

/**
 * The server's side of the wind: polls the registered provider (or the dev command's value, which wins while it is
 * set) once a second for each level and sends the wind to the level's players when it changed. The loaders call
 * {@link #tick} after each level's tick and {@link #payloadFor} when a player joins, respawns or changes dimension.
 * Server thread only. No loader API in here.
 */
public final class ServerWind {
    /** Ticks between asking the provider. */
    static final int POLL_TICKS = 20;
    /** Components closer than this, in blocks per second, count as the same wind. */
    static final float EPSILON = 0.01f;

    /** How the loader sends: whether the player's client has the channel, and the send itself. */
    public interface Sink {
        boolean canSend(ServerPlayer player);

        void send(ServerPlayer player, WindPayload payload);
    }

    private static final Map<ServerLevel, WindPayload> SENT = new WeakHashMap<>();
    private static volatile @Nullable Wind devWind;
    private static boolean providerFailureLogged;

    private ServerWind() {}

    /** The dev command's wind, everywhere; null hands it back to the provider. */
    public static void setDevWind(@Nullable Wind wind) {
        devWind = wind == null ? null : clamp(wind);
    }

    public static @Nullable Wind devWind() {
        return devWind;
    }

    /** Called after each tick of a level. */
    public static void tick(ServerLevel level, Sink sink) {
        if (level.getGameTime() % POLL_TICKS != 0) {
            return;
        }
        WindPayload now = current(level);
        WindPayload before = SENT.get(level);
        if (before != null && same(before.wind(), now.wind())) {
            return;
        }
        SENT.put(level, now);
        for (ServerPlayer player : level.players()) {
            if (sink.canSend(player)) {
                sink.send(player, now);
            }
        }
    }

    /** The wind of the player's level, for a player who has just arrived in it. */
    public static WindPayload payloadFor(ServerPlayer player) {
        return current((ServerLevel) player.level());
    }

    private static WindPayload current(ServerLevel level) {
        ResourceLocation dimension = level.dimension()./*? if >=26.1 {*//*identifier*//*?} else {*/location/*?}*/();
        Wind wind = devWind;
        if (wind == null) {
            WindProvider provider = Winds.provider();
            if (provider != null) {
                try {
                    Wind asked = provider.windFor(level, level.getGameTime());
                    wind = asked == null ? null : clamp(asked);
                } catch (RuntimeException e) {
                    if (!providerFailureLogged) {
                        providerFailureLogged = true;
                        Volumetrics.LOGGER.warn("The wind provider {} threw; treating it as no wind (further failures not logged)",
                                provider.getClass().getName(), e);
                    }
                }
            }
        }
        return new WindPayload(dimension, wind);
    }

    static Wind clamp(Wind wind) {
        List<WindArea> areas = wind.areas().size() > Wind.MAX_AREAS ? wind.areas().subList(0, Wind.MAX_AREAS) : wind.areas();
        return new Wind(speed(wind.x()), speed(wind.z()), areas.stream()
                .map(a -> new WindArea(a.minX(), a.minY(), a.minZ(), a.maxX(), a.maxY(), a.maxZ(), speed(a.x()), speed(a.z()))).toList());
    }

    private static float speed(float value) {
        return Float.isNaN(value) ? 0f : Math.clamp(value, -Wind.MAX_SPEED, Wind.MAX_SPEED);
    }

    static boolean same(@Nullable Wind a, @Nullable Wind b) {
        if (a == null || b == null) {
            return a == b;
        }
        if (Math.abs(a.x() - b.x()) > EPSILON || Math.abs(a.z() - b.z()) > EPSILON || a.areas().size() != b.areas().size()) {
            return false;
        }
        for (int i = 0; i < a.areas().size(); i++) {
            WindArea p = a.areas().get(i);
            WindArea q = b.areas().get(i);
            if (p.minX() != q.minX() || p.minY() != q.minY() || p.minZ() != q.minZ() || p.maxX() != q.maxX() || p.maxY() != q.maxY()
                    || p.maxZ() != q.maxZ() || Math.abs(p.x() - q.x()) > EPSILON || Math.abs(p.z() - q.z()) > EPSILON) {
                return false;
            }
        }
        return true;
    }
}
