package dev.syrval.volumetrics.mixin;

import dev.syrval.volumetrics.client.WorldChangeSource;
import dev.syrval.volumetrics.world.WorldChangeListener;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Tells the mod of changes to the client's world. These three methods are where the world tells the game's
 * renderer to draw chunk sections again: a block set or broken, and light that has arrived from the server.
 * Neither loader has an event for any of it, and without it a change is only found when the mod next happens to
 * read the section again, seconds later.
 *
 * <p>They are hooked here and not in {@code LevelRenderer}, where they all end up: Sodium replaces the bodies of
 * the renderer's own marking methods and sends each straight to its own renderer, so there is no one place left
 * in it that everything passes through. Nothing replaces these.
 */
@Mixin(ClientLevel.class)
abstract class ClientLevelMixin implements WorldChangeSource {
    @Unique
    private @Nullable WorldChangeListener volumetrics$listener;

    @Override
    public void volumetrics$listen(@Nullable WorldChangeListener listener) {
        this.volumetrics$listener = listener;
    }

    @Override
    public void volumetrics$chunkArrived(int chunkX, int chunkZ) {
        if (volumetrics$listener != null) {
            volumetrics$listener.chunkArrived(chunkX, chunkZ);
        }
    }

    @Override
    public void volumetrics$sectionTouched(int sectionX, int sectionY, int sectionZ) {
        if (volumetrics$listener != null) {
            volumetrics$listener.sectionTouched(sectionX, sectionY, sectionZ);
        }
    }

    @Inject(method = "sendBlockUpdated(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;I)V",
            at = @At("HEAD"))
    private void volumetrics$blockChanged(BlockPos pos, BlockState oldState, BlockState newState, int updateFlags, CallbackInfo callback) {
        if (volumetrics$listener != null) {
            // The flag the game itself takes to mean the player did it, and rebuilds the mesh at once for.
            volumetrics$listener.blockChanged(pos.getX(), pos.getY(), pos.getZ(), (updateFlags & Block.UPDATE_IMMEDIATE) != 0);
        }
    }

    @Inject(method = "setBlocksDirty(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;)V",
            at = @At("HEAD"))
    private void volumetrics$blockChanged(BlockPos pos, BlockState oldState, BlockState newState, CallbackInfo callback) {
        if (volumetrics$listener != null) {
            volumetrics$listener.blockChanged(pos.getX(), pos.getY(), pos.getZ(), false);
        }
    }

    @Inject(method = "setSectionDirtyWithNeighbors(III)V", at = @At("HEAD"))
    private void volumetrics$sectionsTouched(int sectionX, int sectionY, int sectionZ, CallbackInfo callback) {
        if (volumetrics$listener == null) {
            return;
        }
        // The section and the 26 around it, as the game marks them.
        for (int z = sectionZ - 1; z <= sectionZ + 1; z++) {
            for (int y = sectionY - 1; y <= sectionY + 1; y++) {
                for (int x = sectionX - 1; x <= sectionX + 1; x++) {
                    volumetrics$listener.sectionTouched(x, y, z);
                }
            }
        }
    }
}
