package dev.syrval.volumetrics.sim;

import java.util.Arrays;
import java.util.List;

/**
 * Advances a gas by one time step. Each cell trades gas with its six neighbours:
 *
 * <ul>
 *   <li>gravity moves a share of it to the cell below (or above, for a gas that rises), as far as that cell
 *       has room. What cannot move that way, because the way is shut or that cell is full, is pushed sideways towards
 *       thinner neighbours instead. Together these make gas pool on a floor, run along it and pour off its edge;
 *   <li>dispersion moves gas from the denser of two neighbours to the thinner;
 *   <li>drift, for a gas that has any, moves a share of it to the next cell downwind, as far as that cell has
 *       room. Gas pushed against a solid layer rises instead, as far as the cell above has room: so a bank that
 *       meets a wall or a hillside climbs it and goes on over the top. Gas held back only because the cell ahead
 *       is full waits its turn;
 *   <li>decay removes a share outright.
 * </ul>
 *
 * Gas only crosses a face that neither cell has a solid layer along; see {@link Occupancy}. Beyond the window is
 * open and empty, so gas that reaches the edge leaves.
 * Every exchange is computed once from the old state and applied to both cells, so nothing is created or lost
 * except by decay, the window edge, and traces: a density under {@code minDensity} is dropped unless the cell or
 * one it trades with held at least that much. A thin haze thus does not keep the whole window busy, while a flow
 * too slow to fill a cell in one step still builds up there and moves on.
 */
public final class GasStepper {
    /** How far apart the points are at which a source's shape is tested: one a cell on a 2-block grid, more on a coarser one. */
    private static final int POINT_SPACING_BLOCKS = 2;

    private final float minDensity;
    // Scratch for emission: for each cell the sources reach in this step, how much of it they cover, taken
    // together, and how much gas they would add. Zero everywhere between steps.
    private float[] share = new float[0];
    private float[] gain = new float[0];
    private int[] fed = new int[256];
    private int fedCount;

    public GasStepper(float minDensity) {
        if (!(minDensity >= 0)) {
            throw new IllegalArgumentException("Min density must not be negative, got " + minDensity);
        }
        this.minDensity = minDensity;
    }

    public void step(GasField field, Occupancy occupancy, MediumParams medium, GridPlacement placement,
                     List<Source> sources, float dt) {
        if (!field.size().equals(occupancy.size())) {
            throw new IllegalArgumentException("Field and occupancy cover different grids");
        }
        if (!(dt > 0) || !medium.isStable(placement.cellSize(), dt)) {
            throw new IllegalArgumentException("Unstable step: dt " + dt + ", cell " + placement.cellSize() + ", " + medium);
        }
        emit(field, occupancy, medium, placement, sources, dt);
        transport(field, occupancy, medium, placement.cellSize(), dt);
        field.swap();
    }

    /**
     * Feeds the cells the sources reach. A cell gains a source's rate in proportion to how much of the cell lies
     * inside the source's shape, and is filled no further than that same share of the medium's full density: a
     * coarse grid is thus fed what the finest grid would be, averaged over each of its cells.
     */
    private void emit(GasField field, Occupancy occupancy, MediumParams medium, GridPlacement placement,
                      List<Source> sources, float dt) {
        if (sources.isEmpty()) {
            return;
        }
        if (share.length != field.size().cells()) {
            share = new float[field.size().cells()];
            gain = new float[field.size().cells()];
        }
        fedCount = 0;
        for (Source source : sources) {
            measure(occupancy, placement, source, dt);
        }
        float[] cells = field.current();
        boolean[] hasGas = field.currentHasGas();
        for (int k = 0; k < fedCount; k++) {
            int cell = fed[k];
            float full = Math.min(1f, share[cell]) * medium.maxDensity();
            if (cells[cell] < full) {
                cells[cell] = Math.min(full, cells[cell] + gain[cell]);
                hasGas[field.size().brickOfIndex(cell)] = true;
            }
            share[cell] = 0f;
            gain[cell] = 0f;
        }
    }

    /** Adds to {@link #share} and {@link #gain} what one source contributes to each cell it reaches. */
    private void measure(Occupancy occupancy, GridPlacement placement, Source source, float dt) {
        GridSize size = occupancy.size();
        SourceShape shape = source.shape();
        int cellSize = placement.cellSize();
        int points = Math.max(1, cellSize / POINT_SPACING_BLOCKS);
        double spacing = (double) cellSize / points;
        float pointShare = source.weight() / (points * points * points);
        float pointGain = source.rate() * dt * pointShare;
        int minX = Math.max(0, placement.localX(shape.minX()));
        int minY = Math.max(0, placement.localY(shape.minY()));
        int minZ = Math.max(0, placement.localZ(shape.minZ()));
        int maxX = Math.min(size.x() - 1, placement.localX(shape.maxX()));
        int maxY = Math.min(size.y() - 1, placement.localY(shape.maxY()));
        int maxZ = Math.min(size.z() - 1, placement.localZ(shape.maxZ()));

        boolean any = false;
        for (int y = minY; y <= maxY; y++) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int x = minX; x <= maxX; x++) {
                    for (int py = 0; py < points; py++) {
                        double blockY = (placement.originY() + y) * (double) cellSize + (py + 0.5) * spacing;
                        for (int pz = 0; pz < points; pz++) {
                            double blockZ = (placement.originZ() + z) * (double) cellSize + (pz + 0.5) * spacing;
                            for (int px = 0; px < points; px++) {
                                double blockX = (placement.originX() + x) * (double) cellSize + (px + 0.5) * spacing;
                                if (shape.contains(blockX, blockY, blockZ)) {
                                    feed(occupancy, x, cellOnTheFloor(occupancy, x, y, z, py, points), z, pointShare, pointGain);
                                    any = true;
                                }
                            }
                        }
                    }
                }
            }
        }
        // A shape small enough to miss every point still feeds the cell it sits in, as if it had caught one.
        if (!any) {
            feed(occupancy, placement.localX(shape.centreX()), placement.localY(shape.centreY()), placement.localZ(shape.centreZ()),
                    pointShare, pointGain);
        }
    }

    /**
     * The cell a point in the upper or lower part of a cell feeds. A cell with a floor through its upper half
     * holds its gas under that floor, so what a source gives off in the upper half, which is most likely to be
     * standing on the floor, belongs to the cell above. A grid whose cells take a single point never does this.
     */
    private static int cellOnTheFloor(Occupancy occupancy, int x, int y, int z, int pointY, int points) {
        boolean upperHalf = 2 * pointY + 1 > points;
        return upperHalf && (occupancy.solidSides(x, y, z) & Occupancy.UP) != 0 && !occupancy.isBlocked(x, y, z) ? y + 1 : y;
    }

    private void feed(Occupancy occupancy, int x, int y, int z, float pointShare, float pointGain) {
        GridSize size = occupancy.size();
        if (!size.contains(x, y, z) || occupancy.isBlocked(x, y, z)) {
            return;
        }
        int cell = size.index(x, y, z);
        if (share[cell] == 0f) {
            if (fedCount == fed.length) {
                fed = Arrays.copyOf(fed, fed.length * 2);
            }
            fed[fedCount++] = cell;
        }
        share[cell] += pointShare;
        gain[cell] += pointGain;
    }

    private void transport(GasField field, Occupancy occupancy, MediumParams medium, int cellSize, float dt) {
        GridSize size = field.size();
        boolean[] hasGas = field.currentHasGas();
        boolean[] nextHasGas = field.nextHasGas();
        Rates rates = new Rates(
                medium.gravityFraction(cellSize, dt),
                medium.diffusionFraction(cellSize, dt),
                Math.max(0f, 1f - medium.decay() * dt),
                medium.maxDensity(),
                // Offset in the cell array from a cell to the one gravity pulls its gas into.
                medium.gravity() >= 0 ? -size.x() * size.z() : size.x() * size.z(),
                Carry.along(medium.driftFractionX(cellSize, dt), medium.driftX() >= 0, 1, Occupancy.WEST, Occupancy.EAST),
                Carry.along(medium.driftFractionZ(cellSize, dt), medium.driftZ() >= 0, size.x(), Occupancy.NORTH, Occupancy.SOUTH));

        for (int by = 0; by < size.bricksY(); by++) {
            for (int bz = 0; bz < size.bricksZ(); bz++) {
                for (int bx = 0; bx < size.bricksX(); bx++) {
                    int brick = size.brickIndex(bx, by, bz);
                    if (gasCanReach(size, hasGas, bx, by, bz)) {
                        nextHasGas[brick] = stepBrick(field, occupancy.cells(), rates, bx, by, bz);
                    } else if (nextHasGas[brick]) {
                        // The buffer being written still holds this brick's gas from two steps ago.
                        clearBrick(size, field.next(), bx, by, bz);
                        nextHasGas[brick] = false;
                    }
                }
            }
        }
    }

    /** Gas moves one cell a step, so a brick can only change if it or a brick sharing a face with it holds gas. */
    private static boolean gasCanReach(GridSize size, boolean[] hasGas, int bx, int by, int bz) {
        return hasGas[size.brickIndex(bx, by, bz)]
                || bx > 0 && hasGas[size.brickIndex(bx - 1, by, bz)]
                || bx < size.bricksX() - 1 && hasGas[size.brickIndex(bx + 1, by, bz)]
                || by > 0 && hasGas[size.brickIndex(bx, by - 1, bz)]
                || by < size.bricksY() - 1 && hasGas[size.brickIndex(bx, by + 1, bz)]
                || bz > 0 && hasGas[size.brickIndex(bx, by, bz - 1)]
                || bz < size.bricksZ() - 1 && hasGas[size.brickIndex(bx, by, bz + 1)];
    }

    /** Writes one brick of the next buffer and reports whether any gas ended up in it. */
    private boolean stepBrick(GasField field, byte[] solid, Rates rates, int bx, int by, int bz) {
        GridSize size = field.size();
        float[] src = field.current();
        float[] dst = field.next();
        int sizeX = size.x();
        int sizeY = size.y();
        int sizeZ = size.z();
        int strideY = sizeX * sizeZ;
        int fall = rates.fallOffset();
        // The side of a cell its gas leaves by under gravity, and the side of the cell beyond that it enters by.
        int fallSide = fall < 0 ? Occupancy.DOWN : Occupancy.UP;
        int feedSide = fall < 0 ? Occupancy.UP : Occupancy.DOWN;
        float gravity = rates.gravity();
        float diffusion = rates.diffusion();
        float room = rates.maxDensity();
        float keep = rates.keep();
        Carry carryX = rates.carryX();
        Carry carryZ = rates.carryZ();
        boolean drifts = carryX.share() > 0f || carryZ.share() > 0f;
        boolean driftsEast = carryX.offset() > 0;
        boolean driftsSouth = carryZ.offset() > 0;
        boolean any = false;

        for (int y = by * GridSize.BRICK; y < (by + 1) * GridSize.BRICK; y++) {
            boolean below = y > 0;
            boolean above = y < sizeY - 1;
            // Whether the cell this one drops gas into, and the cell that drops gas into this one, are in the window.
            boolean hasTarget = fall < 0 ? below : above;
            boolean hasFeeder = fall < 0 ? above : below;
            for (int z = bz * GridSize.BRICK; z < (bz + 1) * GridSize.BRICK; z++) {
                boolean north = z > 0;
                boolean south = z < sizeZ - 1;
                // Whether the cells downwind and upwind of this row, along Z, are in the window.
                boolean downwindZ = driftsSouth ? south : north;
                boolean upwindZ = driftsSouth ? north : south;
                int row = sizeX * (z + sizeZ * y);
                for (int x = bx * GridSize.BRICK; x < (bx + 1) * GridSize.BRICK; x++) {
                    int i = row + x;
                    int sides = solid[i];
                    if ((sides & Occupancy.CLOSED) != 0) {
                        dst[i] = 0f;
                        continue;
                    }
                    float d = src[i];
                    // Most cells a step visits are empty with nothing next to them: bricks are visited whole,
                    // and so are the empty bricks around one that holds gas. Nothing can change in such a cell.
                    if (d == 0f
                            && (x == 0 || src[i - 1] == 0f) && (x == sizeX - 1 || src[i + 1] == 0f)
                            && (!north || src[i - sizeX] == 0f) && (!south || src[i + sizeX] == 0f)
                            && (!below || src[i - strideY] == 0f) && (!above || src[i + strideY] == 0f)) {
                        dst[i] = 0f;
                        continue;
                    }
                    // Which of the six faces gas can cross. Beyond the window counts as open.
                    boolean west = x == 0 ? (sides & Occupancy.WEST) == 0 : ((sides & Occupancy.WEST) | (solid[i - 1] & Occupancy.EAST)) == 0;
                    boolean east = x == sizeX - 1 ? (sides & Occupancy.EAST) == 0 : ((sides & Occupancy.EAST) | (solid[i + 1] & Occupancy.WEST)) == 0;
                    boolean toNorth = !north ? (sides & Occupancy.NORTH) == 0 : ((sides & Occupancy.NORTH) | (solid[i - sizeX] & Occupancy.SOUTH)) == 0;
                    boolean toSouth = !south ? (sides & Occupancy.SOUTH) == 0 : ((sides & Occupancy.SOUTH) | (solid[i + sizeX] & Occupancy.NORTH)) == 0;
                    boolean down = !below ? (sides & Occupancy.DOWN) == 0 : ((sides & Occupancy.DOWN) | (solid[i - strideY] & Occupancy.UP)) == 0;
                    boolean up = !above ? (sides & Occupancy.UP) == 0 : ((sides & Occupancy.UP) | (solid[i + strideY] & Occupancy.DOWN)) == 0;

                    float out;
                    if (!(fall < 0 ? down : up)) {
                        out = 0f;
                    } else if (!hasTarget) {
                        out = d * gravity;
                    } else {
                        out = Math.min(d * gravity, Math.max(0f, room - src[i + fall]));
                    }
                    float in = 0f;
                    if (hasFeeder && (fall < 0 ? up : down)) {
                        in = Math.min(src[i - fall] * gravity, Math.max(0f, room - d));
                    }
                    if (gravity > 0f) {
                        // Gas held up here runs off sideways, and gas held up next door runs in.
                        float held = d * gravity - out;
                        if (west) {
                            in += x == 0 ? -slump(held, d, 0f)
                                    : slump(src, solid, rates, i - 1, hasTarget, fallSide, feedSide, d) - slump(held, d, src[i - 1]);
                        }
                        if (east) {
                            in += x == sizeX - 1 ? -slump(held, d, 0f)
                                    : slump(src, solid, rates, i + 1, hasTarget, fallSide, feedSide, d) - slump(held, d, src[i + 1]);
                        }
                        if (toNorth) {
                            in += !north ? -slump(held, d, 0f)
                                    : slump(src, solid, rates, i - sizeX, hasTarget, fallSide, feedSide, d) - slump(held, d, src[i - sizeX]);
                        }
                        if (toSouth) {
                            in += !south ? -slump(held, d, 0f)
                                    : slump(src, solid, rates, i + sizeX, hasTarget, fallSide, feedSide, d) - slump(held, d, src[i + sizeX]);
                        }
                    }

                    float carried = 0f;
                    if (drifts) {
                        // The faces drift leaves this cell by and enters it by, and whether the cells beyond them
                        // are in the window.
                        boolean leavesX = driftsEast ? east : west;
                        boolean entersX = driftsEast ? west : east;
                        boolean leavesZ = driftsSouth ? toSouth : toNorth;
                        boolean entersZ = driftsSouth ? toNorth : toSouth;
                        boolean downwindX = driftsEast ? x < sizeX - 1 : x > 0;
                        boolean upwindX = driftsEast ? x > 0 : x < sizeX - 1;
                        float pushedX = d * carryX.share();
                        float pushedZ = d * carryZ.share();
                        float movedX = !leavesX ? 0f : downwindX ? Math.min(pushedX, spare(rates, src[i + carryX.offset()])) : pushedX;
                        float movedZ = !leavesZ ? 0f : downwindZ ? Math.min(pushedZ, spare(rates, src[i + carryZ.offset()])) : pushedZ;
                        // What a solid layer stops goes up instead, as far as the cell above has room.
                        float stopped = (leavesX ? 0f : pushedX) + (leavesZ ? 0f : pushedZ);
                        float risen = !up ? 0f : above ? Math.min(stopped, spare(rates, src[i + strideY])) : stopped;
                        float lost = movedX + movedZ + risen;
                        // What the cells upwind send on to this one, and what the cell below sends up.
                        float takes = spare(rates, d);
                        float gained = (upwindX && entersX ? Math.min(src[i - carryX.offset()] * carryX.share(), takes) : 0f)
                                + (upwindZ && entersZ ? Math.min(src[i - carryZ.offset()] * carryZ.share(), takes) : 0f);
                        if (below && down && src[i - strideY] > 0f) {
                            int under = i - strideY;
                            gained += Math.min(stoppedByWall(src, solid, under, carryX, downwindX)
                                    + stoppedByWall(src, solid, under, carryZ, downwindZ), takes);
                        }
                        carried = gained - lost;
                    }

                    float spread = 0f;
                    // The most gas in this cell or in any it trades with.
                    float nearby = d;
                    if (west) {
                        float there = x > 0 ? src[i - 1] : 0f;
                        spread += there - d;
                        nearby = Math.max(nearby, there);
                    }
                    if (east) {
                        float there = x < sizeX - 1 ? src[i + 1] : 0f;
                        spread += there - d;
                        nearby = Math.max(nearby, there);
                    }
                    if (toNorth) {
                        float there = north ? src[i - sizeX] : 0f;
                        spread += there - d;
                        nearby = Math.max(nearby, there);
                    }
                    if (toSouth) {
                        float there = south ? src[i + sizeX] : 0f;
                        spread += there - d;
                        nearby = Math.max(nearby, there);
                    }
                    if (down) {
                        float there = below ? src[i - strideY] : 0f;
                        spread += there - d;
                        nearby = Math.max(nearby, there);
                    }
                    if (up) {
                        float there = above ? src[i + strideY] : 0f;
                        spread += there - d;
                        nearby = Math.max(nearby, there);
                    }

                    float value = (d - out + in + carried + diffusion * spread) * keep;
                    if (value <= 0f || value < minDensity && nearby < minDensity) {
                        value = 0f;
                    } else {
                        any = true;
                    }
                    dst[i] = value;
                }
            }
        }
        return any;
    }

    /**
     * How much of the gas a cell could not drop goes to one of its four side neighbours: a quarter of it, scaled
     * by how much thinner that neighbour is. Nothing flows towards a neighbour that is as dense or denser.
     */
    private static float slump(float held, float density, float neighbourDensity) {
        if (held <= 0f || neighbourDensity >= density) {
            return 0f;
        }
        return 0.25f * held * (density - neighbourDensity) / density;
    }

    /** The same, for the gas a neighbouring cell in the same slice could not drop, flowing into a cell of {@code density}. */
    private static float slump(float[] src, byte[] solid, Rates rates, int neighbour, boolean hasTarget,
                               int fallSide, int feedSide, float density) {
        float there = src[neighbour];
        if (there <= density) {
            return 0f;
        }
        float out;
        if ((solid[neighbour] & fallSide) != 0) {
            out = 0f;
        } else if (!hasTarget) {
            out = there * rates.gravity();
        } else if ((solid[neighbour + rates.fallOffset()] & feedSide) != 0) {
            out = 0f;
        } else {
            out = Math.min(there * rates.gravity(), Math.max(0f, rates.maxDensity() - src[neighbour + rates.fallOffset()]));
        }
        return slump(there * rates.gravity() - out, there, density);
    }

    /** Whether a solid layer stands between a cell and the one downwind of it. */
    private static boolean shut(byte[] solid, int cell, Carry carry, boolean hasDownwind) {
        return (solid[cell] & carry.leaveSide()) != 0
                || hasDownwind && (solid[cell + carry.offset()] & carry.enterSide()) != 0;
    }

    /**
     * How much gas drift may bring into a cell that holds {@code there}: what it has room for once it has passed
     * its own share on. Counting only the room it has beforehand, a full bank would move in fits, every other
     * cell at a time. A cell that cannot pass its share on thus ends up a little over full.
     */
    private static float spare(Rates rates, float there) {
        return Math.max(0f, rates.maxDensity() - there * rates.stays());
    }

    /** How much of a cell's gas drift pushes against a solid layer, for a cell other than the one being stepped. */
    private static float stoppedByWall(float[] src, byte[] solid, int cell, Carry carry, boolean hasDownwind) {
        return shut(solid, cell, carry, hasDownwind) ? src[cell] * carry.share() : 0f;
    }

    private static void clearBrick(GridSize size, float[] cells, int bx, int by, int bz) {
        for (int y = by * GridSize.BRICK; y < (by + 1) * GridSize.BRICK; y++) {
            for (int z = bz * GridSize.BRICK; z < (bz + 1) * GridSize.BRICK; z++) {
                int from = size.index(bx * GridSize.BRICK, y, z);
                Arrays.fill(cells, from, from + GridSize.BRICK, 0f);
            }
        }
    }

    /** One step's worth of each effect, as shares of a cell's gas. */
    private record Rates(float gravity, float diffusion, float keep, float maxDensity, int fallOffset, Carry carryX, Carry carryZ) {
        /** The share of a cell's gas that drift leaves where it is. */
        float stays() {
            return 1f - (carryX.share() + carryZ.share());
        }
    }

    /**
     * Drift along one axis.
     *
     * @param share     the share of a cell's gas pushed downwind in a step; 0 for no drift along this axis
     * @param offset    offset in the cell array from a cell to the one downwind of it
     * @param leaveSide the side of a cell its gas leaves by
     * @param enterSide the side of the cell downwind that it enters by
     */
    private record Carry(float share, int offset, int leaveSide, int enterSide) {
        /**
         * @param forwards whether the drift goes towards higher coordinates
         * @param stride   offset in the cell array from a cell to the next one up the axis
         */
        static Carry along(float share, boolean forwards, int stride, int lowSide, int highSide) {
            return forwards ? new Carry(share, stride, highSide, lowSide) : new Carry(share, -stride, lowSide, highSide);
        }
    }
}
