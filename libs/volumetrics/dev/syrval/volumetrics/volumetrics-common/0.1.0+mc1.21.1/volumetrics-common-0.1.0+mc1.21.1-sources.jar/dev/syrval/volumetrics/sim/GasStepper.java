package dev.syrval.volumetrics.sim;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * Advances a gas by one time step. Each cell trades gas with its six neighbours:
 *
 * <ul>
 *   <li>gravity moves a share of it to the cell below (or above, for a gas that rises), as far as that cell
 *       has room. Gravity may differ from layer to layer, and rise in some and sink in others: a gas with a
 *       {@link Buoyancy} sinks above the height it settles at and rises below it. What cannot move that way, because the way is shut or that cell is full, is pushed sideways towards
 *       thinner neighbours instead. Together these make gas pool on a floor, run along it and pour off its edge;
 *   <li>dispersion moves gas from the denser of two neighbours to the thinner;
 *   <li>drift, for a gas that has any, moves a share of it to the next cell downwind, as far as that cell has
 *       room. Gas pushed against a solid layer rises instead, as far as the cell above has room: so a bank that
 *       meets a wall or a hillside climbs it and goes on over the top. Gas held back only because the cell ahead
 *       is full waits its turn;
 *   <li>decay removes a share outright.
 * </ul>
 *
 * Gas only crosses a face that neither cell has a solid layer along; see {@link Occupancy}. Beyond the window is
 * open and empty, so gas that reaches the edge leaves.
 * Every exchange is computed once from the old state and applied to both cells, so nothing is created or lost
 * except by decay, the window edge, and traces: a density under {@code minDensity} is dropped unless the cell or
 * one it trades with held at least that much. A thin haze thus does not keep the whole window busy, while a flow
 * too slow to fill a cell in one step still builds up there and moves on.
 */
public final class GasStepper {
    /** How far apart the points are at which a source's shape is tested: one a cell on a 2-block grid, more on a coarser one. */
    private static final int POINT_SPACING_BLOCKS = 2;

    /**
     * The settled threshold, as a fraction of the medium's maximum density: a brick whose every cell moved by no more
     * than this in a step counts as settled (see {@link #settledBricks()}). Counted only; bricks sleep at a 16th of it
     * (see {@link BrickSleep}).
     */
    public static final float SETTLED_FRACTION = 1f / 2048f;

    private final float minDensity;
    // Per-brick counts of the steps since the last resetCounts(), summed over the steps (and so kinds) made.
    private int visitedBricks;
    private int changedBricks;
    private int settledBricks;
    private int asleepBricks;
    private int skippedBricks;
    /** Largest |new - old| in the brick {@link #stepBrick} stepped last. */
    private float brickDelta;
    /** Largest |new - old * keep| there: how far a cell moved other than by decay. */
    private float transportDelta;
    // Scratch for emission: for each cell the sources reach in this step, how much of it they cover, taken
    // together, and how much gas they would add. Zero everywhere between steps.
    private float[] share = new float[0];
    private float[] gain = new float[0];
    private int[] fed = new int[256];
    private int fedCount;
    // Scratch for the flow: what each cell of the bricks with a push sends east and south in this step.
    private float[] flowX = new float[0];
    private float[] flowZ = new float[0];

    public GasStepper(float minDensity) {
        if (!(minDensity >= 0)) {
            throw new IllegalArgumentException("Min density must not be negative, got " + minDensity);
        }
        this.minDensity = minDensity;
    }

    /** Zeroes the brick counts. */
    public void resetCounts() {
        visitedBricks = 0;
        changedBricks = 0;
        settledBricks = 0;
        asleepBricks = 0;
        skippedBricks = 0;
    }

    /** Bricks stepped since {@link #resetCounts()}: those holding gas or next to a brick that does. */
    public int visitedBricks() {
        return visitedBricks;
    }

    /** Visited bricks where some cell differs from before the step by more than {@link #SETTLED_FRACTION} of the medium's maximum density. */
    public int changedBricks() {
        return changedBricks;
    }

    /** Visited bricks where every cell is within that threshold of before the step. */
    public int settledBricks() {
        return settledBricks;
    }

    /** Bricks not stepped because they were asleep (see {@link BrickSleep}). */
    public int asleepBricks() {
        return asleepBricks;
    }

    /** Bricks not stepped, because neither they nor a neighbour held gas. */
    public int skippedBricks() {
        return skippedBricks;
    }

    public void step(GasField field, Occupancy occupancy, MediumParams medium, GridPlacement placement,
                     List<Source> sources, float dt) {
        step(field, occupancy, medium, placement, sources, dt, null, null, false);
    }

    /**
     * The same, with a gravity for each layer of the window, from the bottom up, in place of the medium's own; see
     * {@link Buoyancy#layerGravity}.
     */
    public void step(GasField field, Occupancy occupancy, MediumParams medium, GridPlacement placement,
                     List<Source> sources, float dt, float[] layerGravity) {
        step(field, occupancy, medium, placement, sources, dt, Objects.requireNonNull(layerGravity), null, false);
    }

    /**
     * Either of the above, with the medium's gravity if {@code layerGravity} is null, and if {@code sleep} is not null
     * letting settled bricks sleep: a brick asleep in it is not stepped, only decayed, and it is kept up to date.
     *
     * @param edgeFromCoarser whether {@link Nesting} fills the outermost ring of bricks after the step, so that
     *                        stepping them would be wasted: they are left as they are, for it to write. Needs a {@code sleep}
     */
    void step(GasField field, Occupancy occupancy, MediumParams medium, GridPlacement placement, List<Source> sources,
              float dt, float[] layerGravity, BrickSleep sleep, boolean edgeFromCoarser) {
        step(field, occupancy, medium, placement, sources, dt, layerGravity, sleep, edgeFromCoarser, null);
    }

    /**
     * The same, then, if {@code flow} is not null, moving the gas by the sources' pushes (see {@link #flow}). The flow
     * must have been made for this window and step.
     */
    void step(GasField field, Occupancy occupancy, MediumParams medium, GridPlacement placement, List<Source> sources,
              float dt, float[] layerGravity, BrickSleep sleep, boolean edgeFromCoarser, FlowField flow) {
        if (!field.size().equals(occupancy.size())) {
            throw new IllegalArgumentException("Field and occupancy cover different grids");
        }
        float[] gravity;
        if (layerGravity == null) {
            if (!(dt > 0) || !medium.isStable(placement.cellSize(), dt)) {
                throw new IllegalArgumentException("Unstable step: dt " + dt + ", cell " + placement.cellSize() + ", " + medium);
            }
            gravity = new float[field.size().y()];
            Arrays.fill(gravity, medium.gravity());
        } else {
            if (layerGravity.length != field.size().y()) {
                throw new IllegalArgumentException("Gravity for " + layerGravity.length + " layers, window has " + field.size().y());
            }
            for (float layerGravityAt : layerGravity) {
                MediumParams layer = new MediumParams(layerGravityAt, medium.dispersion(), medium.decay(), medium.maxDensity(),
                        medium.driftX(), medium.driftZ());
                if (!(dt > 0) || !layer.isStable(placement.cellSize(), dt)) {
                    throw new IllegalArgumentException("Unstable step: dt " + dt + ", cell " + placement.cellSize() + ", " + layer);
                }
            }
            gravity = layerGravity;
        }
        if (sleep != null) {
            sleep.flow = flow;
        }
        emit(field, occupancy, medium, placement, sources, dt, sleep);
        transport(field, occupancy, medium, gravity, placement.cellSize(), dt, sleep, edgeFromCoarser);
        if (flow != null) {
            flow(field, occupancy, flow, medium.maxDensity(), sleep, edgeFromCoarser);
        }
        field.swap();
    }

    /**
     * Feeds the cells the sources reach. A cell gains a source's rate in proportion to how much of the cell lies
     * inside the source's shape, and is filled no further than that same share of the medium's full density: a
     * coarse grid is thus fed what the finest grid would be, averaged over each of its cells.
     */
    private void emit(GasField field, Occupancy occupancy, MediumParams medium, GridPlacement placement,
                      List<Source> sources, float dt, BrickSleep sleep) {
        if (sources.isEmpty()) {
            return;
        }
        // Grown to the largest window stepped, so that windows of different sizes can share one stepper.
        if (share.length < field.size().cells()) {
            share = new float[field.size().cells()];
            gain = new float[field.size().cells()];
        }
        fedCount = 0;
        for (Source source : sources) {
            measure(occupancy, placement, source, dt);
        }
        float[] cells = field.current();
        boolean[] hasGas = field.currentHasGas();
        for (int k = 0; k < fedCount; k++) {
            int cell = fed[k];
            if (sleep != null) {
                // A source keeps the brick it feeds awake.
                sleep.fed[field.size().brickOfIndex(cell)] = true;
            }
            float full = Math.min(1f, share[cell]) * medium.maxDensity();
            if (cells[cell] < full) {
                cells[cell] = Math.min(full, cells[cell] + gain[cell]);
                hasGas[field.size().brickOfIndex(cell)] = true;
            }
            share[cell] = 0f;
            gain[cell] = 0f;
        }
    }

    /** Adds to {@link #share} and {@link #gain} what one source contributes to each cell it reaches. */
    private void measure(Occupancy occupancy, GridPlacement placement, Source source, float dt) {
        GridSize size = occupancy.size();
        SourceShape shape = source.shape();
        int cellSize = placement.cellSize();
        int points = Math.max(1, cellSize / POINT_SPACING_BLOCKS);
        double spacing = (double) cellSize / points;
        float pointShare = source.weight() / (points * points * points);
        float pointGain = source.rate() * dt * pointShare;
        int minX = Math.max(0, placement.localX(shape.minX()));
        int minY = Math.max(0, placement.localY(shape.minY()));
        int minZ = Math.max(0, placement.localZ(shape.minZ()));
        int maxX = Math.min(size.x() - 1, placement.localX(shape.maxX()));
        int maxY = Math.min(size.y() - 1, placement.localY(shape.maxY()));
        int maxZ = Math.min(size.z() - 1, placement.localZ(shape.maxZ()));

        boolean any = false;
        for (int y = minY; y <= maxY; y++) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int x = minX; x <= maxX; x++) {
                    for (int py = 0; py < points; py++) {
                        double blockY = (placement.originY() + y) * (double) cellSize + (py + 0.5) * spacing;
                        for (int pz = 0; pz < points; pz++) {
                            double blockZ = (placement.originZ() + z) * (double) cellSize + (pz + 0.5) * spacing;
                            for (int px = 0; px < points; px++) {
                                double blockX = (placement.originX() + x) * (double) cellSize + (px + 0.5) * spacing;
                                if (shape.contains(blockX, blockY, blockZ)) {
                                    feed(occupancy, x, cellOnTheFloor(occupancy, x, y, z, py, points), z, pointShare, pointGain);
                                    any = true;
                                }
                            }
                        }
                    }
                }
            }
        }
        // A shape small enough to miss every point still feeds the cell it sits in, as if it had caught one.
        if (!any) {
            feed(occupancy, placement.localX(shape.centreX()), placement.localY(shape.centreY()), placement.localZ(shape.centreZ()),
                    pointShare, pointGain);
        }
    }

    /**
     * The cell a point in the upper or lower part of a cell feeds. A cell with a floor through its upper half
     * holds its gas under that floor, so what a source gives off in the upper half, which is most likely to be
     * standing on the floor, belongs to the cell above. A grid whose cells take a single point never does this.
     */
    private static int cellOnTheFloor(Occupancy occupancy, int x, int y, int z, int pointY, int points) {
        boolean upperHalf = 2 * pointY + 1 > points;
        return upperHalf && (occupancy.solidSides(x, y, z) & Occupancy.UP) != 0 && !occupancy.isBlocked(x, y, z) ? y + 1 : y;
    }

    private void feed(Occupancy occupancy, int x, int y, int z, float pointShare, float pointGain) {
        GridSize size = occupancy.size();
        if (!size.contains(x, y, z) || occupancy.isBlocked(x, y, z)) {
            return;
        }
        int cell = size.index(x, y, z);
        if (share[cell] == 0f) {
            if (fedCount == fed.length) {
                fed = Arrays.copyOf(fed, fed.length * 2);
            }
            fed[fedCount++] = cell;
        }
        share[cell] += pointShare;
        gain[cell] += pointGain;
    }

    private void transport(GasField field, Occupancy occupancy, MediumParams medium, float[] layerGravity, int cellSize, float dt,
                           BrickSleep sleep, boolean edgeFromCoarser) {
        GridSize size = field.size();
        boolean[] hasGas = field.currentHasGas();
        boolean[] nextHasGas = field.nextHasGas();
        float[] gravity = new float[size.y()];
        int[] fallOffset = new int[size.y()];
        for (int y = 0; y < size.y(); y++) {
            gravity[y] = Math.abs(layerGravity[y]) * dt / cellSize;
            // Offset in the cell array from a cell to the one gravity pulls its gas into.
            fallOffset[y] = layerGravity[y] >= 0 ? -size.x() * size.z() : size.x() * size.z();
        }
        Rates rates = new Rates(
                gravity,
                medium.diffusionFraction(cellSize, dt),
                Math.max(0f, 1f - medium.decay() * dt),
                medium.maxDensity(),
                fallOffset,
                Carry.along(medium.driftFractionX(cellSize, dt), medium.driftX() >= 0, 1, Occupancy.WEST, Occupancy.EAST),
                Carry.along(medium.driftFractionZ(cellSize, dt), medium.driftZ() >= 0, size.x(), Occupancy.NORTH, Occupancy.SOUTH));

        float threshold = medium.maxDensity() * SETTLED_FRACTION;
        for (int by = 0; by < size.bricksY(); by++) {
            for (int bz = 0; bz < size.bricksZ(); bz++) {
                for (int bx = 0; bx < size.bricksX(); bx++) {
                    int brick = size.brickIndex(bx, by, bz);
                    if (edgeFromCoarser && (bx == 0 || bx == size.bricksX() - 1 || by == 0 || by == size.bricksY() - 1
                            || bz == 0 || bz == size.bricksZ() - 1)) {
                        // Nesting writes the whole brick after the step, and every cell is worked out from the cells
                        // as they were before it, so what a step would write here reaches nothing.
                        sleep.quiet[brick] = 0;
                        continue;
                    }
                    if (gasCanReach(size, hasGas, bx, by, bz)) {
                        if (sleep != null && sleep.asleep(brick)) {
                            if (!sleep.mustWake(brick, bx, by, bz)) {
                                int slept = sleepBrick(field, rates.keep(), bx, by, bz);
                                if (slept >= 0) {
                                    nextHasGas[brick] = slept > 0;
                                    asleepBricks++;
                                    continue;
                                }
                            }
                            sleep.quiet[brick] = 0;
                        }
                        nextHasGas[brick] = stepBrick(field, occupancy.cells(), rates, bx, by, bz);
                        visitedBricks++;
                        if (brickDelta > threshold) {
                            changedBricks++;
                        } else {
                            settledBricks++;
                        }
                        if (sleep != null) {
                            if (transportDelta > sleep.threshold) {
                                faceDeltas(size, field.current(), field.next(), rates.keep(), bx, by, bz, sleep.faceNow, brick * BrickSleep.FACES);
                            } else {
                                sleep.movedEverywhere(brick, transportDelta);
                            }
                            sleep.stepped(brick, bx, by, bz, transportDelta);
                        }
                    } else {
                        if (sleep != null) {
                            sleep.quiet[brick] = 0;
                        }
                        skippedBricks++;
                        if (nextHasGas[brick]) {
                            // The buffer being written still holds this brick's gas from two steps ago.
                            clearBrick(size, field.next(), bx, by, bz);
                            nextHasGas[brick] = false;
                        }
                    }
                }
            }
        }
    }

    /**
     * Moves the gas the transport just wrote by the sources' pushes: each cell with a push sends that share of its gas
     * to the next cell east or west, and the next cell south or north, as far as that cell has room once it has sent its
     * own share on. What one cell sends the other gets, so nothing is made or lost. Gas is not pushed into a solid cell,
     * across a solid layer, or out of the window: it stays where it is. Every share is worked out from the gas as the
     * transport left it, before any is moved, so the result does not depend on the order of the cells. Bricks that
     * {@link Nesting} fills afterwards push nothing.
     */
    private void flow(GasField field, Occupancy occupancy, FlowField flow, float room, BrickSleep sleep, boolean edgeFromCoarser) {
        GridSize size = field.size();
        float[] cells = field.next();
        boolean[] hasGas = field.nextHasGas();
        byte[] solid = occupancy.cells();
        int sizeX = size.x();
        int sizeZ = size.z();
        int brickCells = GridSize.BRICK * GridSize.BRICK * GridSize.BRICK;
        int[] bricks = flow.bricks;
        if (flowX.length < bricks.length * brickCells) {
            flowX = new float[bricks.length * brickCells];
            flowZ = new float[bricks.length * brickCells];
        }
        boolean[] pushes = new boolean[bricks.length];
        for (int k = 0; k < bricks.length; k++) {
            int brick = bricks[k];
            int bx = brick % size.bricksX();
            int bz = brick / size.bricksX() % size.bricksZ();
            int by = brick / (size.bricksX() * size.bricksZ());
            if (!hasGas[brick] || edgeFromCoarser && (bx == 0 || bx == size.bricksX() - 1 || by == 0 || by == size.bricksY() - 1
                    || bz == 0 || bz == size.bricksZ() - 1)) {
                continue;
            }
            pushes[k] = true;
            float[] shareX = flow.shareX[brick];
            float[] shareZ = flow.shareZ[brick];
            int at = k * brickCells;
            for (int y = by * GridSize.BRICK; y < (by + 1) * GridSize.BRICK; y++) {
                for (int z = bz * GridSize.BRICK; z < (bz + 1) * GridSize.BRICK; z++) {
                    int row = sizeX * (z + sizeZ * y);
                    for (int x = bx * GridSize.BRICK; x < (bx + 1) * GridSize.BRICK; x++, at++) {
                        int i = row + x;
                        int cell = FlowField.inBrick(x, y, z);
                        float d = cells[i];
                        float sx = shareX[cell];
                        float sz = shareZ[cell];
                        float movedX = 0f;
                        float movedZ = 0f;
                        if (d > 0f && (solid[i] & Occupancy.CLOSED) == 0) {
                            if (sx > 0f && x < sizeX - 1 && ((solid[i] & Occupancy.EAST) | (solid[i + 1] & Occupancy.WEST)) == 0) {
                                movedX = Math.min(d * sx, flowRoom(flow, cells, room, i + 1, x + 1, y, z));
                            } else if (sx < 0f && x > 0 && ((solid[i] & Occupancy.WEST) | (solid[i - 1] & Occupancy.EAST)) == 0) {
                                movedX = -Math.min(-d * sx, flowRoom(flow, cells, room, i - 1, x - 1, y, z));
                            }
                            if (sz > 0f && z < sizeZ - 1 && ((solid[i] & Occupancy.SOUTH) | (solid[i + sizeX] & Occupancy.NORTH)) == 0) {
                                movedZ = Math.min(d * sz, flowRoom(flow, cells, room, i + sizeX, x, y, z + 1));
                            } else if (sz < 0f && z > 0 && ((solid[i] & Occupancy.NORTH) | (solid[i - sizeX] & Occupancy.SOUTH)) == 0) {
                                movedZ = -Math.min(-d * sz, flowRoom(flow, cells, room, i - sizeX, x, y, z - 1));
                            }
                        }
                        flowX[at] = movedX;
                        flowZ[at] = movedZ;
                    }
                }
            }
        }
        for (int k = 0; k < bricks.length; k++) {
            if (!pushes[k]) {
                continue;
            }
            int brick = bricks[k];
            int bx = brick % size.bricksX();
            int bz = brick / size.bricksX() % size.bricksZ();
            int by = brick / (size.bricksX() * size.bricksZ());
            float most = 0f;
            int at = k * brickCells;
            for (int y = by * GridSize.BRICK; y < (by + 1) * GridSize.BRICK; y++) {
                for (int z = bz * GridSize.BRICK; z < (bz + 1) * GridSize.BRICK; z++) {
                    int row = sizeX * (z + sizeZ * y);
                    for (int x = bx * GridSize.BRICK; x < (bx + 1) * GridSize.BRICK; x++, at++) {
                        float movedX = flowX[at];
                        float movedZ = flowZ[at];
                        if (movedX == 0f && movedZ == 0f) {
                            continue;
                        }
                        int i = row + x;
                        cells[i] -= Math.abs(movedX) + Math.abs(movedZ);
                        if (movedX != 0f) {
                            int to = movedX > 0f ? x + 1 : x - 1;
                            cells[movedX > 0f ? i + 1 : i - 1] += Math.abs(movedX);
                            hasGas[size.brickOfCell(to, y, z)] = true;
                        }
                        if (movedZ != 0f) {
                            int to = movedZ > 0f ? z + 1 : z - 1;
                            cells[movedZ > 0f ? i + sizeX : i - sizeX] += Math.abs(movedZ);
                            hasGas[size.brickOfCell(x, y, to)] = true;
                        }
                        most = Math.max(most, Math.abs(movedX) + Math.abs(movedZ));
                    }
                }
            }
            if (sleep != null) {
                sleep.flowed(brick, most);
            }
        }
    }

    /**
     * How much gas the flow may bring into a cell: what it has room for once it has sent its own share on, as drift
     * counts it (see {@link #spare}).
     */
    private static float flowRoom(FlowField flow, float[] cells, float room, int i, int x, int y, int z) {
        int brick = flow.size.brickOfCell(x, y, z);
        float sends = 0f;
        if (flow.has(brick)) {
            int cell = FlowField.inBrick(x, y, z);
            sends = Math.abs(flow.shareX[brick][cell]) + Math.abs(flow.shareZ[brick][cell]);
        }
        return Math.max(0f, room - cells[i] * (1f - sends));
    }

    /** Gas moves one cell a step, so a brick can only change if it or a brick sharing a face with it holds gas. */
    private static boolean gasCanReach(GridSize size, boolean[] hasGas, int bx, int by, int bz) {
        return hasGas[size.brickIndex(bx, by, bz)]
                || bx > 0 && hasGas[size.brickIndex(bx - 1, by, bz)]
                || bx < size.bricksX() - 1 && hasGas[size.brickIndex(bx + 1, by, bz)]
                || by > 0 && hasGas[size.brickIndex(bx, by - 1, bz)]
                || by < size.bricksY() - 1 && hasGas[size.brickIndex(bx, by + 1, bz)]
                || bz > 0 && hasGas[size.brickIndex(bx, by, bz - 1)]
                || bz < size.bricksZ() - 1 && hasGas[size.brickIndex(bx, by, bz + 1)];
    }

    /** Writes one brick of the next buffer and reports whether any gas ended up in it. */
    private boolean stepBrick(GasField field, byte[] solid, Rates rates, int bx, int by, int bz) {
        GridSize size = field.size();
        float[] src = field.current();
        float[] dst = field.next();
        int sizeX = size.x();
        int sizeY = size.y();
        int sizeZ = size.z();
        int strideY = sizeX * sizeZ;
        float diffusion = rates.diffusion();
        float room = rates.maxDensity();
        float keep = rates.keep();
        Carry carryX = rates.carryX();
        Carry carryZ = rates.carryZ();
        boolean drifts = carryX.share() > 0f || carryZ.share() > 0f;
        boolean driftsEast = carryX.offset() > 0;
        boolean driftsSouth = carryZ.offset() > 0;
        boolean any = false;
        float maxDelta = 0f;
        float maxMoved = 0f;

        for (int y = by * GridSize.BRICK; y < (by + 1) * GridSize.BRICK; y++) {
            boolean below = y > 0;
            boolean above = y < sizeY - 1;
            int fall = rates.fallOffset()[y];
            // The side of a cell its gas leaves by under gravity, and the side of the cell beyond that it enters by.
            int fallSide = fall < 0 ? Occupancy.DOWN : Occupancy.UP;
            int feedSide = fall < 0 ? Occupancy.UP : Occupancy.DOWN;
            float gravity = rates.gravity()[y];
            // Whether the cell this one drops gas into is in the window, and whether the cells above and below drop
            // gas into this one.
            boolean hasTarget = fall < 0 ? below : above;
            boolean fedFromAbove = above && rates.fallOffset()[y + 1] < 0;
            boolean fedFromBelow = below && rates.fallOffset()[y - 1] > 0;
            float gravityAbove = above ? rates.gravity()[y + 1] : 0f;
            float gravityBelow = below ? rates.gravity()[y - 1] : 0f;
            for (int z = bz * GridSize.BRICK; z < (bz + 1) * GridSize.BRICK; z++) {
                boolean north = z > 0;
                boolean south = z < sizeZ - 1;
                // Whether the cells downwind and upwind of this row, along Z, are in the window.
                boolean downwindZ = driftsSouth ? south : north;
                boolean upwindZ = driftsSouth ? north : south;
                int row = sizeX * (z + sizeZ * y);
                for (int x = bx * GridSize.BRICK; x < (bx + 1) * GridSize.BRICK; x++) {
                    int i = row + x;
                    int sides = solid[i];
                    if ((sides & Occupancy.CLOSED) != 0) {
                        dst[i] = 0f;
                        maxDelta = Math.max(maxDelta, Math.abs(src[i]));
                        maxMoved = Math.max(maxMoved, Math.abs(src[i] * keep));
                        continue;
                    }
                    float d = src[i];
                    // Most cells a step visits are empty with nothing next to them: bricks are visited whole,
                    // and so are the empty bricks around one that holds gas. Nothing can change in such a cell.
                    if (d == 0f
                            && (x == 0 || src[i - 1] == 0f) && (x == sizeX - 1 || src[i + 1] == 0f)
                            && (!north || src[i - sizeX] == 0f) && (!south || src[i + sizeX] == 0f)
                            && (!below || src[i - strideY] == 0f) && (!above || src[i + strideY] == 0f)) {
                        dst[i] = 0f;
                        continue;
                    }
                    // Which of the six faces gas can cross. Beyond the window counts as open.
                    boolean west = x == 0 ? (sides & Occupancy.WEST) == 0 : ((sides & Occupancy.WEST) | (solid[i - 1] & Occupancy.EAST)) == 0;
                    boolean east = x == sizeX - 1 ? (sides & Occupancy.EAST) == 0 : ((sides & Occupancy.EAST) | (solid[i + 1] & Occupancy.WEST)) == 0;
                    boolean toNorth = !north ? (sides & Occupancy.NORTH) == 0 : ((sides & Occupancy.NORTH) | (solid[i - sizeX] & Occupancy.SOUTH)) == 0;
                    boolean toSouth = !south ? (sides & Occupancy.SOUTH) == 0 : ((sides & Occupancy.SOUTH) | (solid[i + sizeX] & Occupancy.NORTH)) == 0;
                    boolean down = !below ? (sides & Occupancy.DOWN) == 0 : ((sides & Occupancy.DOWN) | (solid[i - strideY] & Occupancy.UP)) == 0;
                    boolean up = !above ? (sides & Occupancy.UP) == 0 : ((sides & Occupancy.UP) | (solid[i + strideY] & Occupancy.DOWN)) == 0;

                    float out;
                    if (!(fall < 0 ? down : up)) {
                        out = 0f;
                    } else if (!hasTarget) {
                        out = d * gravity;
                    } else {
                        out = Math.min(d * gravity, Math.max(0f, room - src[i + fall]));
                    }
                    float in = 0f;
                    if (fedFromAbove && up) {
                        in += Math.min(src[i + strideY] * gravityAbove, Math.max(0f, room - d));
                    }
                    if (fedFromBelow && down) {
                        in += Math.min(src[i - strideY] * gravityBelow, Math.max(0f, room - d));
                    }
                    if (gravity > 0f) {
                        // Gas held up here runs off sideways, and gas held up next door runs in.
                        float held = d * gravity - out;
                        if (west) {
                            in += x == 0 ? -slump(held, d, 0f)
                                    : slump(src, solid, gravity, fall, room, i - 1, hasTarget, fallSide, feedSide, d) - slump(held, d, src[i - 1]);
                        }
                        if (east) {
                            in += x == sizeX - 1 ? -slump(held, d, 0f)
                                    : slump(src, solid, gravity, fall, room, i + 1, hasTarget, fallSide, feedSide, d) - slump(held, d, src[i + 1]);
                        }
                        if (toNorth) {
                            in += !north ? -slump(held, d, 0f)
                                    : slump(src, solid, gravity, fall, room, i - sizeX, hasTarget, fallSide, feedSide, d) - slump(held, d, src[i - sizeX]);
                        }
                        if (toSouth) {
                            in += !south ? -slump(held, d, 0f)
                                    : slump(src, solid, gravity, fall, room, i + sizeX, hasTarget, fallSide, feedSide, d) - slump(held, d, src[i + sizeX]);
                        }
                    }

                    float carried = 0f;
                    if (drifts) {
                        // The faces drift leaves this cell by and enters it by, and whether the cells beyond them
                        // are in the window.
                        boolean leavesX = driftsEast ? east : west;
                        boolean entersX = driftsEast ? west : east;
                        boolean leavesZ = driftsSouth ? toSouth : toNorth;
                        boolean entersZ = driftsSouth ? toNorth : toSouth;
                        boolean downwindX = driftsEast ? x < sizeX - 1 : x > 0;
                        boolean upwindX = driftsEast ? x > 0 : x < sizeX - 1;
                        float pushedX = d * carryX.share();
                        float pushedZ = d * carryZ.share();
                        float movedX = !leavesX ? 0f : downwindX ? Math.min(pushedX, spare(rates, src[i + carryX.offset()])) : pushedX;
                        float movedZ = !leavesZ ? 0f : downwindZ ? Math.min(pushedZ, spare(rates, src[i + carryZ.offset()])) : pushedZ;
                        // What a solid layer stops goes up instead, as far as the cell above has room.
                        float stopped = (leavesX ? 0f : pushedX) + (leavesZ ? 0f : pushedZ);
                        float risen = !up ? 0f : above ? Math.min(stopped, spare(rates, src[i + strideY])) : stopped;
                        float lost = movedX + movedZ + risen;
                        // What the cells upwind send on to this one, and what the cell below sends up.
                        float takes = spare(rates, d);
                        float gained = (upwindX && entersX ? Math.min(src[i - carryX.offset()] * carryX.share(), takes) : 0f)
                                + (upwindZ && entersZ ? Math.min(src[i - carryZ.offset()] * carryZ.share(), takes) : 0f);
                        if (below && down && src[i - strideY] > 0f) {
                            int under = i - strideY;
                            gained += Math.min(stoppedByWall(src, solid, under, carryX, downwindX)
                                    + stoppedByWall(src, solid, under, carryZ, downwindZ), takes);
                        }
                        carried = gained - lost;
                    }

                    float spread = 0f;
                    // The most gas in this cell or in any it trades with.
                    float nearby = d;
                    if (west) {
                        float there = x > 0 ? src[i - 1] : 0f;
                        spread += there - d;
                        nearby = Math.max(nearby, there);
                    }
                    if (east) {
                        float there = x < sizeX - 1 ? src[i + 1] : 0f;
                        spread += there - d;
                        nearby = Math.max(nearby, there);
                    }
                    if (toNorth) {
                        float there = north ? src[i - sizeX] : 0f;
                        spread += there - d;
                        nearby = Math.max(nearby, there);
                    }
                    if (toSouth) {
                        float there = south ? src[i + sizeX] : 0f;
                        spread += there - d;
                        nearby = Math.max(nearby, there);
                    }
                    if (down) {
                        float there = below ? src[i - strideY] : 0f;
                        spread += there - d;
                        nearby = Math.max(nearby, there);
                    }
                    if (up) {
                        float there = above ? src[i + strideY] : 0f;
                        spread += there - d;
                        nearby = Math.max(nearby, there);
                    }

                    float value = (d - out + in + carried + diffusion * spread) * keep;
                    if (value <= 0f || value < minDensity && nearby < minDensity) {
                        value = 0f;
                    } else {
                        any = true;
                    }
                    dst[i] = value;
                    maxDelta = Math.max(maxDelta, Math.abs(value - d));
                    maxMoved = Math.max(maxMoved, Math.abs(value - d * keep));
                }
            }
        }
        brickDelta = maxDelta;
        transportDelta = maxMoved;
        return any;
    }

    /**
     * Writes a sleeping brick of the next buffer: its cells as they are, times what decay keeps. Returns whether any
     * gas is left in it (1) or not (0), or -1 if it must be stepped after all, because decay takes a cell below the
     * least density kept, or the whole brick is below it, which the step decides by its neighbours.
     */
    private int sleepBrick(GasField field, float keep, int bx, int by, int bz) {
        GridSize size = field.size();
        int brick = size.brickIndex(bx, by, bz);
        float[] src = field.current();
        float[] dst = field.next();
        if (!field.currentHasGas()[brick]) {
            if (field.nextHasGas()[brick]) {
                clearBrick(size, dst, bx, by, bz);
            }
            return 0;
        }
        float most = 0f;
        for (int y = by * GridSize.BRICK; y < (by + 1) * GridSize.BRICK; y++) {
            for (int z = bz * GridSize.BRICK; z < (bz + 1) * GridSize.BRICK; z++) {
                int row = size.index(bx * GridSize.BRICK, y, z);
                if (keep == 1f) {
                    System.arraycopy(src, row, dst, row, GridSize.BRICK);
                    continue;
                }
                for (int i = row; i < row + GridSize.BRICK; i++) {
                    float d = src[i];
                    float value = d * keep;
                    if (value < minDensity && d >= minDensity) {
                        return -1;
                    }
                    dst[i] = value;
                    most = Math.max(most, value);
                }
            }
        }
        if (keep == 1f) {
            return 1;
        }
        if (most < minDensity) {
            return most > 0f ? -1 : 0;
        }
        return 1;
    }

    /** For a brick just stepped, the most a cell along each face moved other than by decay, as {@link BrickSleep} keeps it. */
    private static void faceDeltas(GridSize size, float[] src, float[] dst, float keep, int bx, int by, int bz, float[] out, int at) {
        int x0 = bx * GridSize.BRICK;
        int x1 = x0 + GridSize.BRICK - 1;
        int y0 = by * GridSize.BRICK;
        int y1 = y0 + GridSize.BRICK - 1;
        int z0 = bz * GridSize.BRICK;
        int z1 = z0 + GridSize.BRICK - 1;
        float west = 0f;
        float east = 0f;
        float down = 0f;
        float up = 0f;
        float north = 0f;
        float south = 0f;
        for (int y = y0; y <= y1; y++) {
            for (int z = z0; z <= z1; z++) {
                int row = size.index(x0, y, z);
                west = Math.max(west, Math.abs(dst[row] - src[row] * keep));
                east = Math.max(east, Math.abs(dst[row + x1 - x0] - src[row + x1 - x0] * keep));
                if (y == y0 || y == y1 || z == z0 || z == z1) {
                    float most = 0f;
                    for (int i = row; i <= row + x1 - x0; i++) {
                        most = Math.max(most, Math.abs(dst[i] - src[i] * keep));
                    }
                    if (y == y0) {
                        down = Math.max(down, most);
                    }
                    if (y == y1) {
                        up = Math.max(up, most);
                    }
                    if (z == z0) {
                        north = Math.max(north, most);
                    }
                    if (z == z1) {
                        south = Math.max(south, most);
                    }
                }
            }
        }
        out[at + BrickSleep.WEST] = west;
        out[at + BrickSleep.EAST] = east;
        out[at + BrickSleep.DOWN] = down;
        out[at + BrickSleep.UP] = up;
        out[at + BrickSleep.NORTH] = north;
        out[at + BrickSleep.SOUTH] = south;
    }

    /**
     * How much of the gas a cell could not drop goes to one of its four side neighbours: a quarter of it, scaled
     * by how much thinner that neighbour is. Nothing flows towards a neighbour that is as dense or denser.
     */
    private static float slump(float held, float density, float neighbourDensity) {
        if (held <= 0f || neighbourDensity >= density) {
            return 0f;
        }
        return 0.25f * held * (density - neighbourDensity) / density;
    }

    /** The same, for the gas a neighbouring cell in the same slice could not drop, flowing into a cell of {@code density}. */
    private static float slump(float[] src, byte[] solid, float gravity, int fall, float room, int neighbour,
                               boolean hasTarget, int fallSide, int feedSide, float density) {
        float there = src[neighbour];
        if (there <= density) {
            return 0f;
        }
        float out;
        if ((solid[neighbour] & fallSide) != 0) {
            out = 0f;
        } else if (!hasTarget) {
            out = there * gravity;
        } else if ((solid[neighbour + fall] & feedSide) != 0) {
            out = 0f;
        } else {
            out = Math.min(there * gravity, Math.max(0f, room - src[neighbour + fall]));
        }
        return slump(there * gravity - out, there, density);
    }

    /** Whether a solid layer stands between a cell and the one downwind of it. */
    private static boolean shut(byte[] solid, int cell, Carry carry, boolean hasDownwind) {
        return (solid[cell] & carry.leaveSide()) != 0
                || hasDownwind && (solid[cell + carry.offset()] & carry.enterSide()) != 0;
    }

    /**
     * How much gas drift may bring into a cell that holds {@code there}: what it has room for once it has passed
     * its own share on. Counting only the room it has beforehand, a full bank would move in fits, every other
     * cell at a time. A cell that cannot pass its share on thus ends up a little over full.
     */
    private static float spare(Rates rates, float there) {
        return Math.max(0f, rates.maxDensity() - there * rates.stays());
    }

    /** How much of a cell's gas drift pushes against a solid layer, for a cell other than the one being stepped. */
    private static float stoppedByWall(float[] src, byte[] solid, int cell, Carry carry, boolean hasDownwind) {
        return shut(solid, cell, carry, hasDownwind) ? src[cell] * carry.share() : 0f;
    }

    private static void clearBrick(GridSize size, float[] cells, int bx, int by, int bz) {
        for (int y = by * GridSize.BRICK; y < (by + 1) * GridSize.BRICK; y++) {
            for (int z = bz * GridSize.BRICK; z < (bz + 1) * GridSize.BRICK; z++) {
                int from = size.index(bx * GridSize.BRICK, y, z);
                Arrays.fill(cells, from, from + GridSize.BRICK, 0f);
            }
        }
    }

    /**
     * One step's worth of each effect, as shares of a cell's gas. Gravity is per layer, from the bottom up, with
     * the offset in the cell array from a cell of that layer to the one gravity pulls its gas into.
     */
    private record Rates(float[] gravity, float diffusion, float keep, float maxDensity, int[] fallOffset, Carry carryX, Carry carryZ) {
        /** The share of a cell's gas that drift leaves where it is. */
        float stays() {
            return 1f - (carryX.share() + carryZ.share());
        }
    }

    /**
     * Drift along one axis.
     *
     * @param share     the share of a cell's gas pushed downwind in a step; 0 for no drift along this axis
     * @param offset    offset in the cell array from a cell to the one downwind of it
     * @param leaveSide the side of a cell its gas leaves by
     * @param enterSide the side of the cell downwind that it enters by
     */
    private record Carry(float share, int offset, int leaveSide, int enterSide) {
        /**
         * @param forwards whether the drift goes towards higher coordinates
         * @param stride   offset in the cell array from a cell to the next one up the axis
         */
        static Carry along(float share, boolean forwards, int stride, int lowSide, int highSide) {
            return forwards ? new Carry(share, stride, highSide, lowSide) : new Carry(share, -stride, lowSide, highSide);
        }
    }
}
