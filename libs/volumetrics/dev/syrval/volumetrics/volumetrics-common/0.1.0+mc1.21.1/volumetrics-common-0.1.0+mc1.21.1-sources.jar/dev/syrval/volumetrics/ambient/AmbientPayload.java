package dev.syrval.volumetrics.ambient;

import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.api.MediumBuoyancy;
import dev.syrval.volumetrics.sim.AmbientProfile;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Server to client, {@code volumetrics:ambient}: the air of the level the player is now in. Sent when a player joins,
 * respawns or changes dimension. The channel is optional on both sides.
 *
 * @param dimension the id of the level the state is for
 */
public record AmbientPayload(ResourceLocation dimension, AmbientState state) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<AmbientPayload> TYPE = new CustomPacketPayload.Type<>(Volumetrics.id("ambient"));
    public static final StreamCodec<RegistryFriendlyByteBuf, AmbientPayload> CODEC = CustomPacketPayload.codec(AmbientPayload::write, AmbientPayload::read);
    // Far past any real level: a limit so that a bad packet cannot ask for gigabytes.
    private static final int MAX_BLOCKS = 1 << 16;
    private static final int MAX_MEDIA = 1 << 12;
    private static final int HAS_DENSITY = 1;
    private static final int HAS_SETTLES_AT = 2;
    private static final int HAS_SPEED = 4;

    @Override
    public CustomPacketPayload.Type<AmbientPayload> type() {
        return TYPE;
    }

    private void write(RegistryFriendlyByteBuf buffer) {
        buffer.writeUtf(dimension.toString());
        AmbientProfile profile = state.profile();
        buffer.writeInt(profile.seaLevel());
        buffer.writeInt(profile.minY());
        float[] densities = profile.densities();
        buffer.writeVarInt(densities.length);
        for (float density : densities) {
            buffer.writeFloat(density);
        }
        buffer.writeFloat(state.buoyancySpeed());
        buffer.writeVarInt(state.media().size());
        state.media().forEach((id, buoyancy) -> {
            buffer.writeUtf(id.toString());
            buffer.writeByte((buoyancy.density().isPresent() ? HAS_DENSITY : 0) | (buoyancy.settlesAt().isPresent() ? HAS_SETTLES_AT : 0)
                    | (buoyancy.speed().isPresent() ? HAS_SPEED : 0));
            buoyancy.density().ifPresent(buffer::writeFloat);
            buoyancy.settlesAt().ifPresent(buffer::writeFloat);
            buoyancy.speed().ifPresent(buffer::writeFloat);
        });
    }

    private static AmbientPayload read(RegistryFriendlyByteBuf buffer) {
        ResourceLocation dimension = ResourceLocation.parse(buffer.readUtf());
        int seaLevel = buffer.readInt();
        int minY = buffer.readInt();
        int blocks = buffer.readVarInt();
        if (blocks < 1 || blocks > MAX_BLOCKS) {
            throw new IllegalArgumentException("Ambient profile of " + blocks + " blocks");
        }
        float[] densities = new float[blocks];
        for (int i = 0; i < blocks; i++) {
            densities[i] = buffer.readFloat();
        }
        float speed = buffer.readFloat();
        int count = buffer.readVarInt();
        if (count < 0 || count > MAX_MEDIA) {
            throw new IllegalArgumentException("Ambient state with " + count + " media");
        }
        Map<ResourceLocation, MediumBuoyancy> media = new HashMap<>();
        for (int i = 0; i < count; i++) {
            ResourceLocation id = ResourceLocation.parse(buffer.readUtf());
            int flags = buffer.readByte();
            Optional<Float> density = (flags & HAS_DENSITY) != 0 ? Optional.of(buffer.readFloat()) : Optional.empty();
            Optional<Float> settlesAt = (flags & HAS_SETTLES_AT) != 0 ? Optional.of(buffer.readFloat()) : Optional.empty();
            Optional<Float> own = (flags & HAS_SPEED) != 0 ? Optional.of(buffer.readFloat()) : Optional.empty();
            media.put(id, new MediumBuoyancy(density, settlesAt, own));
        }
        return new AmbientPayload(dimension, new AmbientState(AmbientProfile.of(seaLevel, minY, densities), speed, media));
    }
}
