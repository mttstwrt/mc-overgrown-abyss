package dev.syrval.volumetrics.client.render.gl;

import com.mojang.blaze3d.platform.GlStateManager;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryUtil;

/** A 2D texture of bytes, one to four a texel, or of half floats, four a texel, with no mip levels. */
public final class GlTexture implements AutoCloseable {
    public enum Format {
        R8(GL30.GL_R8, GL11.GL_RED),
        RG8(GL30.GL_RG8, GL30.GL_RG),
        RGBA8(GL11.GL_RGBA8, GL11.GL_RGBA),
        /** Half floats, for what is drawn into and read again over many frames: bytes would round it off each time. */
        RGBA16F(GL30.GL_RGBA16F, GL11.GL_RGBA),
        /** One full float, for a depth drawn as a colour. */
        R32F(GL30.GL_R32F, GL11.GL_RED);

        private final int internal;
        private final int external;

        Format(int internal, int external) {
            this.internal = internal;
            this.external = external;
        }
    }

    private final int id = GlStateManager._genTexture();
    private final Format format;
    private final int width;
    private final int height;

    /**
     * Its contents are whatever was in its memory until something is written or drawn to it.
     *
     * @param linear whether a read between texels blends them, or takes the nearest
     * @param repeat whether a read past the edge wraps round, or takes the edge
     */
    public GlTexture(Format format, int width, int height, boolean linear, boolean repeat) {
        this.format = format;
        this.width = width;
        this.height = height;
        int filter = linear ? GL11.GL_LINEAR : GL11.GL_NEAREST;
        int wrap = repeat ? GL11.GL_REPEAT : GL12.GL_CLAMP_TO_EDGE;
        GlStateManager._bindTexture(id);
        GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL12.GL_TEXTURE_MAX_LEVEL, 0);
        GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, filter);
        GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, filter);
        GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, wrap);
        GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, wrap);
        GlStateManager._texImage2D(GL11.GL_TEXTURE_2D, 0, format.internal, width, height, 0, format.external, GL11.GL_UNSIGNED_BYTE, (IntBuffer) null);
    }

    /**
     * Replaces a rectangle of the texture with bytes read from the buffer's position on, row by row. Not for a
     * texture of half floats, which is only ever drawn into.
     */
    public void upload(ByteBuffer texels, int x, int y, int width, int height) {
        upload(texels, 0, x, y, width, height);
    }

    /** As {@link #upload(ByteBuffer, int, int, int, int)}, reading from a byte offset in the buffer; the position is ignored. */
    public void upload(ByteBuffer texels, int offset, int x, int y, int width, int height) {
        GlStateManager._bindTexture(id);
        // Rows of any width follow each other without padding, and nothing left set by another upload applies.
        GlStateManager._pixelStore(GL11.GL_UNPACK_ALIGNMENT, 1);
        GlStateManager._pixelStore(GL11.GL_UNPACK_ROW_LENGTH, 0);
        GlStateManager._pixelStore(GL11.GL_UNPACK_SKIP_PIXELS, 0);
        GlStateManager._pixelStore(GL11.GL_UNPACK_SKIP_ROWS, 0);
        GlStateManager._texSubImage2D(GL11.GL_TEXTURE_2D, 0, x, y, width, height, format.external, GL11.GL_UNSIGNED_BYTE, MemoryUtil.memAddress(texels, offset));
    }

    public int id() {
        return id;
    }

    public int width() {
        return width;
    }

    public int height() {
        return height;
    }

    @Override
    public void close() {
        GlStateManager._deleteTexture(id);
    }
}
