package dev.syrval.volumetrics.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.client.render.Quality;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * What a player sets about how gas is drawn on their own machine, kept as JSON in the game's config folder.
 * What the gases themselves are and do is not here: that is the datapacks' business and the same for everyone.
 *
 * @param enabled whether there is gas at all: with false nothing is simulated, read from the world or drawn
 */
record ClientSettings(boolean enabled, Quality quality) {
    static final ClientSettings DEFAULT = new ClientSettings(true, Quality.MEDIUM);
    static final Codec<ClientSettings> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.BOOL.optionalFieldOf("enabled", DEFAULT.enabled).forGetter(ClientSettings::enabled),
            Quality.CODEC.optionalFieldOf("quality", DEFAULT.quality).forGetter(ClientSettings::quality)
    ).apply(instance, ClientSettings::new));
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** The settings in a file, or the defaults if it is not there or cannot be read. */
    static ClientSettings load(Path file) {
        if (!Files.exists(file)) {
            return DEFAULT;
        }
        try (Reader reader = Files.newBufferedReader(file)) {
            return CODEC.parse(JsonOps.INSTANCE, JsonParser.parseReader(reader))
                    .resultOrPartial(problem -> Volumetrics.LOGGER.warn("Ignoring {}: {}", file, problem))
                    .orElse(DEFAULT);
        } catch (IOException | JsonParseException e) {
            Volumetrics.LOGGER.warn("Ignoring {}, which could not be read", file, e);
            return DEFAULT;
        }
    }

    void save(Path file) {
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, GSON.toJson(CODEC.encodeStart(JsonOps.INSTANCE, this).getOrThrow()) + "\n");
        } catch (IOException e) {
            Volumetrics.LOGGER.warn("Could not save settings to {}", file, e);
        }
    }
}
