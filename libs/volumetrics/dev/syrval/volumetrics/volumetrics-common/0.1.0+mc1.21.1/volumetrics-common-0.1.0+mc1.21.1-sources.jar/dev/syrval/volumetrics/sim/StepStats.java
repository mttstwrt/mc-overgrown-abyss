package dev.syrval.volumetrics.sim;

/**
 * What one engine step of a window did, for the statistics. Brick counts are summed over the kinds of gas stepped;
 * the counting does not change what the step computes.
 *
 * @param nestNanos nanoseconds spent setting the window's edge from the coarser window (see {@link Nesting})
 * @param visited   bricks stepped
 * @param changed   visited bricks where some cell moved by more than {@link GasStepper#SETTLED_FRACTION} of the medium's maximum density
 * @param settled   visited bricks where every cell stayed within it
 * @param asleep    bricks not stepped because they were asleep (see {@code BrickSleep})
 * @param skipped   bricks not stepped: neither they nor a neighbour held gas
 * @param edge      bricks {@link Nesting} rewrote from the coarser window
 */
public record StepStats(long nestNanos, int visited, int changed, int settled, int asleep, int skipped, int edge) {
    public static final StepStats NONE = new StepStats(0, 0, 0, 0, 0, 0, 0);
}
