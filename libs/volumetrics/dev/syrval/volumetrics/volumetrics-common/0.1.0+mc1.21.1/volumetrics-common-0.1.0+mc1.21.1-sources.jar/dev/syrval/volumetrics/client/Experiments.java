package dev.syrval.volumetrics.client;

import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.client.render.FieldSource;
import dev.syrval.volumetrics.sim.SimEngines;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringJoiner;
import java.util.function.Function;
import org.jspecify.annotations.Nullable;

/**
 * The switches for experimental techniques and debug aids, by name: each one on or off, a choice or a number, set with
 * {@code /volumetrics experiment <name> <value>} while the game runs and kept in the client settings file. Each says
 * what a change of it needs before it shows (see {@link Rebuild}); the client does that much and no more, so that one
 * session can time a technique on and off. A {@code -D<property>} on the command line still sets one, for that session
 * only: it wins over the file and is not saved.
 */
public final class Experiments {
    /** What a change of an experiment needs before it shows, from least to most. */
    public enum Rebuild {
        /** It is read where it is used, from the next frame or step. */
        NOTHING("nothing"),
        /** The shaders it is a define of are compiled again, or picked from those compiled already. */
        SHADERS("a shader rebuild"),
        /** The renderer is made again, with its textures and buffers. */
        RENDERER("a renderer rebuild"),
        /** The gas world is made again, and the gas starts again from nothing. */
        GAS("a gas world rebuild");

        private final String text;

        Rebuild(String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    /** Whether a switch is a technique to try or an aid for looking into the gas, listed apart in the screen and the command. */
    public enum Category {
        /** A technique, or a choice between techniques, that a player might keep on. */
        EXPERIMENT,
        /** A view or a measurement for looking into the gas: debug colours, timings, logs. */
        DEBUG
    }

    /** How much a setting can change the frame rate, as shader packs rate their options. */
    public enum Impact {
        LOW("Low"),
        MEDIUM("Medium"),
        HIGH("High");

        private final String text;

        Impact(String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    /**
     * Another experiment's value that this one needs to do anything, and what to tell a player when it does not hold.
     *
     * @param reason why the row can do nothing as things are, and what to change, for the settings screen
     */
    public record Requirement(Experiment<?> experiment, Object value, String reason) {}

    /** The values an experiment takes, for the command to suggest and the settings screen to pick a widget by. */
    public sealed interface Values {
        /** On or off. */
        record Flag() implements Values {}

        /** One of a list of names. */
        record Choice(List<String> choices) implements Values {}

        /** A number from {@code min} to {@code max}; text outside is clamped. */
        record Range(float min, float max) implements Values {}
    }

    /** One switch: its name, what it does, its default, and how its values are read and written. */
    public static final class Experiment<T> {
        private final String name;
        private final String property;
        private final String description;
        private final String help;
        private final Rebuild rebuild;
        private final T fallback;
        private final Function<String, @Nullable T> parse;
        private final Values values;
        private final List<Requirement> requirements = new ArrayList<>();
        private Category category = Category.EXPERIMENT;
        private @Nullable Impact impact;
        private @Nullable String performance;

        private Experiment(String name, String property, String description, String help, Rebuild rebuild, T fallback,
                           Function<String, @Nullable T> parse, Values values) {
            this.name = name;
            this.property = property;
            this.description = description;
            this.help = help;
            this.rebuild = rebuild;
            this.fallback = fallback;
            this.parse = parse;
            this.values = values;
        }

        public String name() {
            return name;
        }

        public String description() {
            return description;
        }

        /** What it does for a player, in a sentence or two, and when to turn it on: the settings screen's tooltip. */
        public String help() {
            return help;
        }

        public Category category() {
            return category;
        }

        /** The other experiments' values it needs to do anything; empty if it always does something. */
        public List<Requirement> requirements() {
            return Collections.unmodifiableList(requirements);
        }

        /** How much it can change the frame rate, or null for a debug aid whose cost is too small to rate. */
        public @Nullable Impact impact() {
            return impact;
        }

        /** What it does to the frame rate, as an estimated range and why, or null with no impact. */
        public @Nullable String performance() {
            return performance;
        }

        private <V> Experiment<T> requires(Experiment<V> experiment, V value, String reason) {
            requirements.add(new Requirement(experiment, value, reason));
            return this;
        }

        private Experiment<T> debug() {
            category = Category.DEBUG;
            return this;
        }

        private Experiment<T> performance(Impact impact, String performance) {
            this.impact = impact;
            this.performance = performance;
            return this;
        }

        public Rebuild rebuild() {
            return rebuild;
        }

        public T fallback() {
            return fallback;
        }

        public Values values() {
            return values;
        }

        /** The values the command suggests for it. */
        public List<String> suggestions() {
            return switch (values) {
                case Values.Flag flag -> List.of("true", "false");
                case Values.Choice choice -> choice.choices();
                case Values.Range range -> List.of(Float.toString(range.min()), String.valueOf(fallback), Float.toString(range.max()));
            };
        }

        /** A value of it from text, or null if the text is not one. */
        public @Nullable T parse(String text) {
            return parse.apply(text.trim());
        }
    }

    private static final Map<String, Experiment<?>> ALL = new LinkedHashMap<>();

    /** Draws a depth tint and a world-space grid over the level: the check that depth and position are read right. */
    public static final Experiment<Boolean> DEPTH_TINT = flag("depth_tint", "volumetrics.debug.depth_tint", false, Rebuild.NOTHING,
            "a depth tint and a world grid over the level",
            "A debug view for checking that the gas lines up with the world. It tints everything by how far away it is and "
                    + "draws a grid that stays fixed to the blocks. If gas ever sits in the wrong place, this shows whether the mod "
                    + "is reading the world wrongly. Leave it off for normal play.")
            .debug()
            .performance(Impact.LOW, "Not measured. One extra tint over the screen; expected to cost under 1% of the frame rate.");
    /** Times the gas passes on the GPU, for {@code /volumetrics stats}. */
    public static final Experiment<Boolean> GPU_TIME = flag("gpu_time", "volumetrics.debug.gpu_time", false, Rebuild.RENDERER,
            "times the gas passes on the GPU, for /volumetrics stats",
            "Measures how many milliseconds the graphics card spends drawing the gas, and shows it in /volumetrics stats. "
                    + "Nothing changes on screen. Turn it on to find out what the gas costs on your machine, for example "
                    + "before choosing a Quality setting.")
            .debug()
            .performance(Impact.LOW, "Not measured. Timing the graphics card is very cheap; expected to cost under 1% of the frame rate.");
    /** Logs frames in which the library held the main thread for more than 2 ms, with the time by category. */
    public static final Experiment<Boolean> MAIN_THREAD = flag("main_thread", "volumetrics.debug.main_thread", false, Rebuild.NOTHING,
            "logs frames in which the gas held the main thread over 2 ms",
            "Writes a line to the game log each time the mod holds up Minecraft's own frame for more than 2 ms. The "
                    + "simulation itself runs on its own thread and is not counted; what is counted is the mod's work on "
                    + "the game's main thread: reading changed blocks, handing each step to the simulation, taking its "
                    + "results and uploading them to the graphics card, and issuing the draw commands. Each line says how "
                    + "long each of those took. Nothing changes on screen. Useful for tracking down stutters; leave it off "
                    + "otherwise, as the log can grow long.")
            .debug()
            .performance(Impact.LOW, "Not measured. It only reads the clock and writes the odd log line; expected to cost under 1%.");
    /** Makes the march walk through empty space too, to measure what skipping it saves. From the next step of gas. */
    public static final Experiment<Boolean> NO_SKIP = flag("no_skip", "volumetrics.debug.no_skip", false, Rebuild.NOTHING,
            "the march walks through empty bricks too, from the next step",
            "When drawing, the mod normally skips the empty space between clouds of gas. With this on it works through all "
                    + "of it: the picture looks exactly the same, only slower. It exists to measure how much the skipping "
                    + "saves; leave it off.")
            .debug()
            .performance(Impact.LOW, "Turning it on costs about 1 to 2% of the frame time (up to about 2.3% on high Quality): rays "
                    + "spend samples on empty space they would otherwise jump over.");
    /** Paints the pixels the composite marches again magenta, and those it searches wider for, cyan. */
    public static final Experiment<Boolean> SHOW_EDGES = flag("show_edges", "volumetrics.debug.show_edges", false, Rebuild.SHADERS,
            "paints the pixels the composite looks at again magenta (nearest depth) and cyan (wider search)",
            "A debug view. Where the edge of a block passes in front of gas, the mod redraws those pixels more carefully so "
                    + "the gas does not bleed around the block. This paints them: magenta where they were redrawn, cyan where "
                    + "it had to search further. For checking odd fringes around blocks; leave it off for play.")
            .debug()
            .performance(Impact.LOW, "Not measured. It only recolours pixels the mod redraws anyway; expected to cost under 1%.");
    /** Draws the gas with fewer samples each frame, blended into the frames before; see {@link #TEMPORAL_SCALE}. */
    public static final Experiment<Boolean> TEMPORAL = flag("temporal", "volumetrics.debug.temporal", false, Rebuild.NOTHING,
            "temporal accumulation: fewer samples each frame, blended into the frames before (/volumetrics temporal)",
            "Temporal accumulation spreads the work of drawing the gas over several frames: each frame draws it with fewer "
                    + "samples and blends the result into the frames before. That is cheaper, and the blending hides the "
                    + "grain, but gas that moves fast, or that you look at while turning quickly, can smear or leave a faint "
                    + "trail. Try it if the gas costs too much at the Quality you want. The two rows below tune it.")
            .performance(Impact.LOW, "This one makes things faster: it saves about 1 to 2% of the frame time, 20 to 40% of what the "
                    + "gas costs, because each frame takes only a share of the samples (temporal_scale). The more the gas "
                    + "costs, the more it saves.");
    /** With temporal accumulation, the samples a ray takes on each frame as a share of what the quality setting gives. */
    public static final Experiment<Float> TEMPORAL_SCALE = number("temporal_scale", "volumetrics.debug.temporal_scale", 0.5f, 0.05f, 1f,
            Rebuild.SHADERS, "with temporal accumulation, the samples a ray takes as a share of the quality's",
            "How much of the work each frame does while temporal accumulation is on, as a share of what the Quality setting "
                    + "asks for: 0.5 means each frame takes half the samples. Lower is faster but grainier and leans more on "
                    + "the blending; 1 saves nothing.")
            .performance(Impact.LOW, "Not measured. Lower values save more of the gas's drawing cost, but never more than "
                    + "temporal accumulation saves in all (about 1 to 2% of the frame time).")
            .requires(TEMPORAL, true, "Temporal accumulation is off, so this does nothing. Turn on the temporal row above to use it.");
    /** With temporal accumulation, how much of the frames before goes into each frame. */
    public static final Experiment<Float> TEMPORAL_HISTORY = number("temporal_history", "volumetrics.debug.temporal_history", 0.9f, 0f, 1f,
            Rebuild.NOTHING, "with temporal accumulation, how much of the frames before goes into each",
            "How strongly earlier frames are blended into each new one while temporal accumulation is on. Higher (towards 1) "
                    + "gives smoother, less grainy gas but more smearing when things move; lower reacts faster but shows "
                    + "more grain. It costs nothing either way.")
            .performance(Impact.LOW, "Effectively free: about 0.01 ms a frame, measured.")
            .requires(TEMPORAL, true, "Temporal accumulation is off, so this does nothing. Turn on the temporal row above to use it.");
    /** The engine that moves the gas, by name, see {@link SimEngines}. */
    public static final Experiment<String> ENGINE = choice("engine", "volumetrics.dev.engine", SimEngines.DEFAULT, SimEngines.names(),
            Rebuild.GAS, "the engine that moves the gas",
            "Which simulation moves the gas. cellular is the real one and the one to play with: gas flows, spreads, pours off "
                    + "edges and settles. decay is a stub that does nothing useful yet: gas appears where it is made and "
                    + "fades, but never moves. It is there for developers, to tell the simulation's cost from the rest. "
                    + "Changing the engine clears all gas, which then builds up again.")
            .performance(Impact.LOW, "Not measured. decay does less work than cellular, so it can only be cheaper; the "
                    + "simulation runs beside the game, so the frame rate barely changes either way.");
    /** Whether settled bricks of gas sleep and the fine window's edge is filled only where the coarse one moved; off is for comparison. */
    public static final Experiment<Boolean> SLEEP = flag("sleep", "volumetrics.dev.sleep", true, Rebuild.GAS,
            "settled bricks sleep and window edges are filled only where the outer level moved",
            "Lets gas that has settled and stopped moving be left alone until something disturbs it, such as a changed block "
                    + "or new gas. The picture stays the same and it saves processor time, the more so the more still gas "
                    + "there is. Turn it off only to measure what it saves.")
            .requires(ENGINE, SimEngines.DEFAULT, "Only the cellular engine lets gas sleep, and the engine row is set to another, so "
                    + "this does nothing. Set the engine to cellular to use it.")
            .performance(Impact.LOW, "Turning it off makes the simulation 10 to 20% slower for the processor (measured). The "
                    + "frame rate barely changes, because the simulation runs beside the game rather than in each frame.");

    /** Where the gas the renderer draws comes from, see {@link FieldSource}. */
    public static final Experiment<String> FIELD_SOURCE = choice("field_source", "volumetrics.dev.field_source", FieldSource.CPU.text(),
            FieldSource.names(), Rebuild.RENDERER, "where the drawn gas comes from",
            "cpu draws the simulation's gas. compute_test ignores the simulation and draws a moving test pattern that a compute "
                    + "shader on the graphics card writes, to check that compute works on this machine; it needs OpenGL 4.3 "
                    + "and falls back to cpu, with a line in the log, where that is not there. It is for developers.")
            .performance(Impact.LOW, "Not measured. The test pattern is one small level written by a short compute shader each frame.");

    private final Map<Experiment<?>, Object> values = new IdentityHashMap<>();
    private final Map<String, String> saved = new LinkedHashMap<>();
    private final Map<Experiment<?>, String> fromProperty = new IdentityHashMap<>();

    /**
     * The values to start a session with: each experiment's default, then what the settings file holds, then what a
     * {@code -D} property sets, which is for this session only.
     *
     * @param saved the experiments in the settings file, by name, as text
     */
    Experiments(Map<String, String> saved) {
        saved.forEach((name, text) -> {
            Experiment<?> experiment = ALL.get(name);
            if (experiment == null) {
                Volumetrics.LOGGER.warn("Ignoring the saved experiment {}, which there is none of", name);
            } else if (experiment.parse(text) == null) {
                Volumetrics.LOGGER.warn("Ignoring the saved experiment {}={}, which is not a value of it", name, text);
            } else {
                this.saved.put(name, text);
                values.put(experiment, experiment.parse(text));
            }
        });
        for (Experiment<?> experiment : ALL.values()) {
            String text = System.getProperty(experiment.property);
            if (text == null) {
                continue;
            }
            Object value = experiment.parse(text);
            if (value == null) {
                Volumetrics.LOGGER.warn("Ignoring -D{}={}, which is not a value of the experiment {}", experiment.property, text,
                        experiment.name);
            } else {
                values.put(experiment, value);
                fromProperty.put(experiment, text);
            }
        }
    }

    /** All experiments, in the order they are listed. */
    public static Collection<Experiment<?>> all() {
        return Collections.unmodifiableCollection(ALL.values());
    }

    public static @Nullable Experiment<?> byName(String name) {
        return ALL.get(name);
    }

    @SuppressWarnings("unchecked")
    public <T> T get(Experiment<T> experiment) {
        return (T) values.getOrDefault(experiment, experiment.fallback);
    }

    /**
     * Sets an experiment from text, {@code default} for its default, and remembers it for {@link #saved}. False, and
     * nothing changed, if the text is not a value of it.
     */
    boolean set(Experiment<?> experiment, String text) {
        if (text.equals("default")) {
            values.remove(experiment);
            saved.remove(experiment.name);
        } else {
            Object value = experiment.parse(text);
            if (value == null) {
                return false;
            }
            values.put(experiment, value);
            saved.put(experiment.name, String.valueOf(value));
        }
        fromProperty.remove(experiment);
        return true;
    }

    /** What the settings file is to hold: the experiments set with the command, by name, as text. */
    Map<String, String> saved() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(saved));
    }

    /** One line about an experiment: its value, its default, what a change needs, and what it does. */
    String describe(Experiment<?> experiment) {
        String source = fromProperty.containsKey(experiment) ? " (from -D" + experiment.property + ")" : "";
        return experiment.name + " = " + get(experiment) + source + " [default " + experiment.fallback + "; a change needs "
                + experiment.rebuild + "]: " + experiment.description;
    }

    /** The experiments not at their default, as {@code name=value}, or {@code none}. */
    String changed() {
        StringJoiner joiner = new StringJoiner(", ");
        for (Experiment<?> experiment : ALL.values()) {
            if (!get(experiment).equals(experiment.fallback)) {
                joiner.add(experiment.name + "=" + get(experiment));
            }
        }
        return joiner.length() == 0 ? "none" : joiner.toString();
    }

    private static <T> Experiment<T> add(Experiment<T> experiment) {
        ALL.put(experiment.name, experiment);
        return experiment;
    }

    private static Experiment<Boolean> flag(String name, String property, boolean fallback, Rebuild rebuild, String description,
                                            String help) {
        return add(new Experiment<>(name, property, description, help, rebuild, fallback, text -> switch (text.toLowerCase(Locale.ROOT)) {
            case "true", "on" -> true;
            case "false", "off" -> false;
            default -> null;
        }, new Values.Flag()));
    }

    private static Experiment<Float> number(String name, String property, float fallback, float min, float max, Rebuild rebuild,
                                            String description, String help) {
        return add(new Experiment<>(name, property, description + " (" + min + " to " + max + ")", help, rebuild, fallback, text -> {
            try {
                float number = Float.parseFloat(text);
                return Float.isNaN(number) ? null : Math.clamp(number, min, max);
            } catch (NumberFormatException e) {
                return null;
            }
        }, new Values.Range(min, max)));
    }

    private static Experiment<String> choice(String name, String property, String fallback, Collection<String> choices, Rebuild rebuild,
                                             String description, String help) {
        List<String> list = new ArrayList<>(choices);
        return add(new Experiment<>(name, property, description + " (" + String.join(", ", list) + ")", help, rebuild, fallback,
                text -> list.contains(text) ? text : null, new Values.Choice(List.copyOf(list))));
    }
}
