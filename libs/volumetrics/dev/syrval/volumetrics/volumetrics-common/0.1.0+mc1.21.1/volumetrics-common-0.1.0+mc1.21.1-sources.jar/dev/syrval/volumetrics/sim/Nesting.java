package dev.syrval.volumetrics.sim;

import java.util.Arrays;

/**
 * Ties a fine window to a coarse one around it. The fine simulation knows nothing of gas beyond its own window,
 * so its outermost bricks are not left to it: after each step they are set to what the coarse window holds at
 * the same places. Gas outside the fine window flows in through them, and ground that comes into the window as
 * the camera moves arrives with the gas it had, not empty.
 *
 * <p>The tie goes one way. Nothing the fine window does reaches the coarse one, which simulates the same sources
 * for itself.
 *
 * <p>In the cascade of levels the coarse window is the next coarser level, which steps less often and ahead of the
 * fine one; the fine one reads it between its last two states ({@link OuterLevel}).
 */
public final class Nesting {
    private Nesting() {}

    /**
     * @param minDensity densities under this are dropped, as the stepper drops them
     * @return how many bricks were rewritten (the empty edge bricks are skipped)
     */
    public static int edgeFromCoarse(GasField fine, GridPlacement finePlacement, Occupancy fineOccupancy,
                                      GasDensities coarse, GridPlacement coarsePlacement, float minDensity) {
        GridSize size = fine.size();
        if (!size.equals(fineOccupancy.size())) {
            throw new IllegalArgumentException("Field and occupancy cover different grids");
        }
        Sampler sampler = new Sampler(finePlacement, coarse, coarsePlacement);
        int written = 0;
        for (int by = 0; by < size.bricksY(); by++) {
            for (int bz = 0; bz < size.bricksZ(); bz++) {
                for (int bx = 0; bx < size.bricksX(); bx++) {
                    boolean outermost = bx == 0 || bx == size.bricksX() - 1 || by == 0 || by == size.bricksY() - 1
                            || bz == 0 || bz == size.bricksZ() - 1;
                    if (outermost) {
                        if (fillBrick(fine, fineOccupancy, sampler, bx, by, bz, minDensity)) {
                            written++;
                        }
                    }
                }
            }
        }
        return written;
    }

    /**
     * The same for a window whose bricks may sleep, stepped with the ring left to this (see {@link GasStepper}): the
     * current buffer's ring holds nothing to keep, and the other buffer the ring as it was before the step. A brick of
     * the ring is filled from the coarse window again only when a source fed it, its occupancy changed, or the coarse
     * cells it reads from may have moved, other than by decay, by more than {@link BrickSleep#ringThreshold} since it was
     * last filled; otherwise it keeps what it had, decayed as the step decays. What each brick moved goes to
     * {@code sleep}, so that sleeping bricks next to it wake.
     *
     * @param keep       the share of the gas the step keeps against decay
     * @param coarseKeep the share the coarse window's own step keeps, which its change sums are taken against
     * @return how many bricks were filled from the coarse window
     */
    static int edgeFromCoarse(GasField fine, GridPlacement finePlacement, Occupancy fineOccupancy, OuterLevel coarse,
                              GridPlacement coarsePlacement, float minDensity, float keep, float coarseKeep, BrickSleep sleep) {
        GridSize size = fine.size();
        if (!size.equals(fineOccupancy.size())) {
            throw new IllegalArgumentException("Field and occupancy cover different grids");
        }
        Sampler sampler = new Sampler(finePlacement, coarse, coarsePlacement);
        // The coarse store's sums say how far it moved other than by decay, if its last step kept what it was meant to.
        boolean tracked = coarse.tracksChanges() && coarse.trackedKeep() == coarseKeep;
        float[] cells = fine.current();
        float[] before = fine.next();
        boolean[] hasGas = fine.currentHasGas();
        boolean[] hadGas = fine.nextHasGas();
        int written = 0;
        for (int by = 0; by < size.bricksY(); by++) {
            for (int bz = 0; bz < size.bricksZ(); bz++) {
                for (int bx = 0; bx < size.bricksX(); bx++) {
                    if (!(bx == 0 || bx == size.bricksX() - 1 || by == 0 || by == size.bricksY() - 1
                            || bz == 0 || bz == size.bricksZ() - 1)) {
                        continue;
                    }
                    int brick = size.brickIndex(bx, by, bz);
                    int x0 = bx * GridSize.BRICK;
                    int y0 = by * GridSize.BRICK;
                    int z0 = bz * GridSize.BRICK;
                    float moved;
                    if (!sampler.anyGasAround(x0, y0, z0)) {
                        // Nothing to fill from: the brick is empty, as filling it would leave it.
                        moved = hadGas[brick] ? keep * max(size, before, bx, by, bz) : 0f;
                        if (hasGas[brick]) {
                            clear(size, cells, bx, by, bz);
                        }
                        hasGas[brick] = false;
                        sleep.ringSeen[brick] = Double.NaN;
                    } else {
                        double seen = tracked ? sampler.changeAround(x0, y0, z0, coarse) : Double.NaN;
                        if (sleep.fed[brick] || !(Math.abs(seen - sleep.ringSeen[brick]) <= sleep.ringThreshold)) {
                            fillBrick(fine, fineOccupancy, sampler, bx, by, bz, minDensity);
                            moved = hadGas[brick] ? movedFrom(size, cells, before, keep, bx, by, bz) : max(size, cells, bx, by, bz);
                            sleep.ringSeen[brick] = seen;
                            written++;
                        } else {
                            moved = 0f;
                            if (hadGas[brick]) {
                                hasGas[brick] = decayed(size, before, cells, keep, minDensity, bx, by, bz);
                            } else {
                                if (hasGas[brick]) {
                                    clear(size, cells, bx, by, bz);
                                }
                                hasGas[brick] = false;
                            }
                        }
                    }
                    sleep.movedEverywhere(brick, moved);
                }
            }
        }
        return written;
    }

    /**
     * Marks the bricks of a coarse window that {@link #edgeFromCoarse} reads from for a fine window's edge where the two
     * are now: what the coarse window must keep of its previous state for the fine one to read between that and its
     * newest ({@link OuterLevel}).
     */
    static void markSampled(GridSize fineSize, GridPlacement finePlacement, GridSize coarseSize, GridPlacement coarsePlacement,
                            boolean[] marks) {
        Sampler sampler = new Sampler(finePlacement, coarseSize, null, coarsePlacement);
        for (int by = 0; by < fineSize.bricksY(); by++) {
            for (int bz = 0; bz < fineSize.bricksZ(); bz++) {
                for (int bx = 0; bx < fineSize.bricksX(); bx++) {
                    if (bx == 0 || bx == fineSize.bricksX() - 1 || by == 0 || by == fineSize.bricksY() - 1
                            || bz == 0 || bz == fineSize.bricksZ() - 1) {
                        sampler.markAround(bx * GridSize.BRICK, by * GridSize.BRICK, bz * GridSize.BRICK, marks);
                    }
                }
            }
        }
    }

    /** Writes a brick's cells as they were, times {@code keep}, dropping what falls under the least density; whether any gas is left. */
    private static boolean decayed(GridSize size, float[] from, float[] to, float keep, float minDensity, int bx, int by, int bz) {
        boolean any = false;
        for (int y = by * GridSize.BRICK; y < (by + 1) * GridSize.BRICK; y++) {
            for (int z = bz * GridSize.BRICK; z < (bz + 1) * GridSize.BRICK; z++) {
                int row = size.index(bx * GridSize.BRICK, y, z);
                for (int i = row; i < row + GridSize.BRICK; i++) {
                    float value = from[i] * keep;
                    if (value < minDensity) {
                        value = 0f;
                    }
                    to[i] = value;
                    any |= value > 0f;
                }
            }
        }
        return any;
    }

    /** The most a cell of the brick differs from its old value times {@code keep}. */
    private static float movedFrom(GridSize size, float[] cells, float[] before, float keep, int bx, int by, int bz) {
        float most = 0f;
        for (int y = by * GridSize.BRICK; y < (by + 1) * GridSize.BRICK; y++) {
            for (int z = bz * GridSize.BRICK; z < (bz + 1) * GridSize.BRICK; z++) {
                int row = size.index(bx * GridSize.BRICK, y, z);
                for (int i = row; i < row + GridSize.BRICK; i++) {
                    most = Math.max(most, Math.abs(cells[i] - before[i] * keep));
                }
            }
        }
        return most;
    }

    private static float max(GridSize size, float[] cells, int bx, int by, int bz) {
        float most = 0f;
        for (int y = by * GridSize.BRICK; y < (by + 1) * GridSize.BRICK; y++) {
            for (int z = bz * GridSize.BRICK; z < (bz + 1) * GridSize.BRICK; z++) {
                int row = size.index(bx * GridSize.BRICK, y, z);
                for (int i = row; i < row + GridSize.BRICK; i++) {
                    most = Math.max(most, cells[i]);
                }
            }
        }
        return most;
    }

    private static void clear(GridSize size, float[] cells, int bx, int by, int bz) {
        for (int y = by * GridSize.BRICK; y < (by + 1) * GridSize.BRICK; y++) {
            for (int z = bz * GridSize.BRICK; z < (bz + 1) * GridSize.BRICK; z++) {
                int row = size.index(bx * GridSize.BRICK, y, z);
                Arrays.fill(cells, row, row + GridSize.BRICK, 0f);
            }
        }
    }

    private static boolean fillBrick(GasField fine, Occupancy occupancy, Sampler sampler, int bx, int by, int bz, float minDensity) {
        GridSize size = fine.size();
        float[] cells = fine.current();
        boolean[] hasGas = fine.currentHasGas();
        int brick = size.brickIndex(bx, by, bz);
        int x0 = bx * GridSize.BRICK;
        int y0 = by * GridSize.BRICK;
        int z0 = bz * GridSize.BRICK;
        // Most of the edge is empty in both windows, and then there is nothing to write.
        boolean coarseHasGas = sampler.anyGasAround(x0, y0, z0);
        if (!coarseHasGas && !hasGas[brick]) {
            return false;
        }
        boolean any = false;
        for (int y = y0; y < y0 + GridSize.BRICK; y++) {
            for (int z = z0; z < z0 + GridSize.BRICK; z++) {
                for (int x = x0; x < x0 + GridSize.BRICK; x++) {
                    float value = coarseHasGas && !occupancy.isBlocked(x, y, z) ? sampler.at(x, y, z) : 0f;
                    if (value < minDensity) {
                        value = 0f;
                    }
                    cells[size.index(x, y, z)] = value;
                    any |= value > 0f;
                }
            }
        }
        hasGas[brick] = any;
        return true;
    }

    /** Reads the coarse field at the centres of fine cells, blending the eight coarse cells around each. */
    private static final class Sampler {
        private final GridSize coarseSize;
        private final GasDensities coarse;
        /** Fine cells for each coarse cell, along an axis; the windows' cell sizes need not divide evenly. */
        private final double ratio;
        /** Position, in coarse cells from the coarse window's first cell centre, of the fine window's first cell centre. */
        private final double startX;
        private final double startY;
        private final double startZ;

        Sampler(GridPlacement finePlacement, GasDensities coarse, GridPlacement coarsePlacement) {
            this(finePlacement, coarse.size(), coarse, coarsePlacement);
        }

        /** @param coarse null for a sampler that only says which coarse bricks it reads from */
        Sampler(GridPlacement finePlacement, GridSize coarseSize, GasDensities coarse, GridPlacement coarsePlacement) {
            this.coarseSize = coarseSize;
            this.coarse = coarse;
            this.ratio = (double) coarsePlacement.cellSize() / finePlacement.cellSize();
            this.startX = start(finePlacement.originX(), finePlacement.cellSize(), coarsePlacement.originX(), coarsePlacement.cellSize());
            this.startY = start(finePlacement.originY(), finePlacement.cellSize(), coarsePlacement.originY(), coarsePlacement.cellSize());
            this.startZ = start(finePlacement.originZ(), finePlacement.cellSize(), coarsePlacement.originZ(), coarsePlacement.cellSize());
        }

        private static double start(int fineOrigin, int fineCell, int coarseOrigin, int coarseCell) {
            return (fineOrigin + 0.5) * fineCell / coarseCell - coarseOrigin - 0.5;
        }

        float at(int x, int y, int z) {
            double u = startX + x / ratio;
            double v = startY + y / ratio;
            double w = startZ + z / ratio;
            int x0 = (int) Math.floor(u);
            int y0 = (int) Math.floor(v);
            int z0 = (int) Math.floor(w);
            float fx = (float) (u - x0);
            float fy = (float) (v - y0);
            float fz = (float) (w - z0);
            float low = mix(mix(cell(x0, y0, z0), cell(x0 + 1, y0, z0), fx), mix(cell(x0, y0, z0 + 1), cell(x0 + 1, y0, z0 + 1), fx), fz);
            float high = mix(mix(cell(x0, y0 + 1, z0), cell(x0 + 1, y0 + 1, z0), fx), mix(cell(x0, y0 + 1, z0 + 1), cell(x0 + 1, y0 + 1, z0 + 1), fx), fz);
            return mix(low, high, fy);
        }

        /** Whether any coarse brick that {@link #at} reads from for a brick of fine cells may hold gas. */
        boolean anyGasAround(int fineX, int fineY, int fineZ) {
            int last = GridSize.BRICK - 1;
            int maxX = Math.floorDiv((int) Math.floor(startX + (fineX + last) / ratio) + 1, GridSize.BRICK);
            int maxY = Math.floorDiv((int) Math.floor(startY + (fineY + last) / ratio) + 1, GridSize.BRICK);
            int maxZ = Math.floorDiv((int) Math.floor(startZ + (fineZ + last) / ratio) + 1, GridSize.BRICK);
            for (int by = Math.floorDiv((int) Math.floor(startY + fineY / ratio), GridSize.BRICK); by <= maxY; by++) {
                for (int bz = Math.floorDiv((int) Math.floor(startZ + fineZ / ratio), GridSize.BRICK); bz <= maxZ; bz++) {
                    for (int bx = Math.floorDiv((int) Math.floor(startX + fineX / ratio), GridSize.BRICK); bx <= maxX; bx++) {
                        if (bx >= 0 && bx < coarseSize.bricksX() && by >= 0 && by < coarseSize.bricksY()
                                && bz >= 0 && bz < coarseSize.bricksZ() && coarse.brickHasGas(bx, by, bz)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        /**
         * The sum of {@link GasStore#changeSum} over the coarse bricks {@link #at} reads from for a brick of fine cells:
         * it grows by at least as much as any of those cells moves, other than by decay.
         */
        double changeAround(int fineX, int fineY, int fineZ, OuterLevel store) {
            int last = GridSize.BRICK - 1;
            int maxX = Math.floorDiv((int) Math.floor(startX + (fineX + last) / ratio) + 1, GridSize.BRICK);
            int maxY = Math.floorDiv((int) Math.floor(startY + (fineY + last) / ratio) + 1, GridSize.BRICK);
            int maxZ = Math.floorDiv((int) Math.floor(startZ + (fineZ + last) / ratio) + 1, GridSize.BRICK);
            double sum = 0;
            for (int by = Math.floorDiv((int) Math.floor(startY + fineY / ratio), GridSize.BRICK); by <= maxY; by++) {
                for (int bz = Math.floorDiv((int) Math.floor(startZ + fineZ / ratio), GridSize.BRICK); bz <= maxZ; bz++) {
                    for (int bx = Math.floorDiv((int) Math.floor(startX + fineX / ratio), GridSize.BRICK); bx <= maxX; bx++) {
                        if (bx >= 0 && bx < coarseSize.bricksX() && by >= 0 && by < coarseSize.bricksY()
                                && bz >= 0 && bz < coarseSize.bricksZ()) {
                            sum += store.changeSum(coarseSize.brickIndex(bx, by, bz));
                        }
                    }
                }
            }
            return sum;
        }

        /** Marks the coarse bricks that {@link #at} reads from for a brick of fine cells. */
        void markAround(int fineX, int fineY, int fineZ, boolean[] marks) {
            int last = GridSize.BRICK - 1;
            int maxX = Math.floorDiv((int) Math.floor(startX + (fineX + last) / ratio) + 1, GridSize.BRICK);
            int maxY = Math.floorDiv((int) Math.floor(startY + (fineY + last) / ratio) + 1, GridSize.BRICK);
            int maxZ = Math.floorDiv((int) Math.floor(startZ + (fineZ + last) / ratio) + 1, GridSize.BRICK);
            for (int by = Math.floorDiv((int) Math.floor(startY + fineY / ratio), GridSize.BRICK); by <= maxY; by++) {
                for (int bz = Math.floorDiv((int) Math.floor(startZ + fineZ / ratio), GridSize.BRICK); bz <= maxZ; bz++) {
                    for (int bx = Math.floorDiv((int) Math.floor(startX + fineX / ratio), GridSize.BRICK); bx <= maxX; bx++) {
                        if (bx >= 0 && bx < coarseSize.bricksX() && by >= 0 && by < coarseSize.bricksY()
                                && bz >= 0 && bz < coarseSize.bricksZ()) {
                            marks[coarseSize.brickIndex(bx, by, bz)] = true;
                        }
                    }
                }
            }
        }

        /** Beyond the coarse window there is no gas. */
        private float cell(int x, int y, int z) {
            return coarseSize.contains(x, y, z) ? coarse.density(x, y, z) : 0f;
        }

        private static float mix(float a, float b, float t) {
            return a + (b - a) * t;
        }
    }
}
