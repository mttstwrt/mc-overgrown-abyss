package dev.syrval.volumetrics.sim;

/**
 * Ties a fine window to a coarse one around it. The fine simulation knows nothing of gas beyond its own window,
 * so its outermost bricks are not left to it: after each step they are set to what the coarse window holds at
 * the same places. Gas outside the fine window flows in through them, and ground that comes into the window as
 * the camera moves arrives with the gas it had, not empty.
 *
 * <p>The tie goes one way. Nothing the fine window does reaches the coarse one, which simulates the same sources
 * for itself.
 */
public final class Nesting {
    private Nesting() {}

    /**
     * @param minDensity densities under this are dropped, as the stepper drops them
     */
    public static void edgeFromCoarse(GasField fine, GridPlacement finePlacement, Occupancy fineOccupancy,
                                      GasDensities coarse, GridPlacement coarsePlacement, float minDensity) {
        GridSize size = fine.size();
        if (!size.equals(fineOccupancy.size())) {
            throw new IllegalArgumentException("Field and occupancy cover different grids");
        }
        Sampler sampler = new Sampler(finePlacement, coarse, coarsePlacement);
        for (int by = 0; by < size.bricksY(); by++) {
            for (int bz = 0; bz < size.bricksZ(); bz++) {
                for (int bx = 0; bx < size.bricksX(); bx++) {
                    boolean outermost = bx == 0 || bx == size.bricksX() - 1 || by == 0 || by == size.bricksY() - 1
                            || bz == 0 || bz == size.bricksZ() - 1;
                    if (outermost) {
                        fillBrick(fine, fineOccupancy, sampler, bx, by, bz, minDensity);
                    }
                }
            }
        }
    }

    private static void fillBrick(GasField fine, Occupancy occupancy, Sampler sampler, int bx, int by, int bz, float minDensity) {
        GridSize size = fine.size();
        float[] cells = fine.current();
        boolean[] hasGas = fine.currentHasGas();
        int brick = size.brickIndex(bx, by, bz);
        int x0 = bx * GridSize.BRICK;
        int y0 = by * GridSize.BRICK;
        int z0 = bz * GridSize.BRICK;
        // Most of the edge is empty in both windows, and then there is nothing to write.
        boolean coarseHasGas = sampler.anyGasAround(x0, y0, z0);
        if (!coarseHasGas && !hasGas[brick]) {
            return;
        }
        boolean any = false;
        for (int y = y0; y < y0 + GridSize.BRICK; y++) {
            for (int z = z0; z < z0 + GridSize.BRICK; z++) {
                for (int x = x0; x < x0 + GridSize.BRICK; x++) {
                    float value = coarseHasGas && !occupancy.isBlocked(x, y, z) ? sampler.at(x, y, z) : 0f;
                    if (value < minDensity) {
                        value = 0f;
                    }
                    cells[size.index(x, y, z)] = value;
                    any |= value > 0f;
                }
            }
        }
        hasGas[brick] = any;
    }

    /** Reads the coarse field at the centres of fine cells, blending the eight coarse cells around each. */
    private static final class Sampler {
        private final GridSize coarseSize;
        private final GasDensities coarse;
        /** Fine cells for each coarse cell, along an axis; the windows' cell sizes need not divide evenly. */
        private final double ratio;
        /** Position, in coarse cells from the coarse window's first cell centre, of the fine window's first cell centre. */
        private final double startX;
        private final double startY;
        private final double startZ;

        Sampler(GridPlacement finePlacement, GasDensities coarse, GridPlacement coarsePlacement) {
            this.coarseSize = coarse.size();
            this.coarse = coarse;
            this.ratio = (double) coarsePlacement.cellSize() / finePlacement.cellSize();
            this.startX = start(finePlacement.originX(), finePlacement.cellSize(), coarsePlacement.originX(), coarsePlacement.cellSize());
            this.startY = start(finePlacement.originY(), finePlacement.cellSize(), coarsePlacement.originY(), coarsePlacement.cellSize());
            this.startZ = start(finePlacement.originZ(), finePlacement.cellSize(), coarsePlacement.originZ(), coarsePlacement.cellSize());
        }

        private static double start(int fineOrigin, int fineCell, int coarseOrigin, int coarseCell) {
            return (fineOrigin + 0.5) * fineCell / coarseCell - coarseOrigin - 0.5;
        }

        float at(int x, int y, int z) {
            double u = startX + x / ratio;
            double v = startY + y / ratio;
            double w = startZ + z / ratio;
            int x0 = (int) Math.floor(u);
            int y0 = (int) Math.floor(v);
            int z0 = (int) Math.floor(w);
            float fx = (float) (u - x0);
            float fy = (float) (v - y0);
            float fz = (float) (w - z0);
            float low = mix(mix(cell(x0, y0, z0), cell(x0 + 1, y0, z0), fx), mix(cell(x0, y0, z0 + 1), cell(x0 + 1, y0, z0 + 1), fx), fz);
            float high = mix(mix(cell(x0, y0 + 1, z0), cell(x0 + 1, y0 + 1, z0), fx), mix(cell(x0, y0 + 1, z0 + 1), cell(x0 + 1, y0 + 1, z0 + 1), fx), fz);
            return mix(low, high, fy);
        }

        /** Whether any coarse brick that {@link #at} reads from for a brick of fine cells may hold gas. */
        boolean anyGasAround(int fineX, int fineY, int fineZ) {
            int last = GridSize.BRICK - 1;
            int maxX = Math.floorDiv((int) Math.floor(startX + (fineX + last) / ratio) + 1, GridSize.BRICK);
            int maxY = Math.floorDiv((int) Math.floor(startY + (fineY + last) / ratio) + 1, GridSize.BRICK);
            int maxZ = Math.floorDiv((int) Math.floor(startZ + (fineZ + last) / ratio) + 1, GridSize.BRICK);
            for (int by = Math.floorDiv((int) Math.floor(startY + fineY / ratio), GridSize.BRICK); by <= maxY; by++) {
                for (int bz = Math.floorDiv((int) Math.floor(startZ + fineZ / ratio), GridSize.BRICK); bz <= maxZ; bz++) {
                    for (int bx = Math.floorDiv((int) Math.floor(startX + fineX / ratio), GridSize.BRICK); bx <= maxX; bx++) {
                        if (bx >= 0 && bx < coarseSize.bricksX() && by >= 0 && by < coarseSize.bricksY()
                                && bz >= 0 && bz < coarseSize.bricksZ() && coarse.brickHasGas(bx, by, bz)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        /** Beyond the coarse window there is no gas. */
        private float cell(int x, int y, int z) {
            return coarseSize.contains(x, y, z) ? coarse.density(x, y, z) : 0f;
        }

        private static float mix(float a, float b, float t) {
            return a + (b - a) * t;
        }
    }
}
