package dev.syrval.volumetrics.mixin;

import java.util.List;
import java.util.Set;
import org.objectweb.asm.tree.ClassNode;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

/**
 * Applies the mixins on Iris only when Iris is installed. They would do nothing without it either, but the loader
 * would warn at every start that it cannot find their targets.
 */
public final class VolumetricsMixinPlugin implements IMixinConfigPlugin {
    private static final String IRIS_MIXIN_PREFIX = "dev.syrval.volumetrics.mixin.Iris";
    private static final String IRIS_CLASS = "net/irisshaders/iris/Iris.class";

    private boolean iris;

    @Override
    public void onLoad(String mixinPackage) {
        ClassLoader loader = VolumetricsMixinPlugin.class.getClassLoader();
        iris = loader != null && loader.getResource(IRIS_CLASS) != null;
        if (iris) {
            LoggerFactory.getLogger("volumetrics").info("Iris is installed: gas will stop at Voxy's far terrain under a shader pack");
        }
    }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        return iris || !mixinClassName.startsWith(IRIS_MIXIN_PREFIX);
    }

    @Override
    public String getRefMapperConfig() {
        return null;
    }

    @Override
    public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {
    }

    @Override
    public List<String> getMixins() {
        return null;
    }

    @Override
    public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
    }

    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
    }
}
