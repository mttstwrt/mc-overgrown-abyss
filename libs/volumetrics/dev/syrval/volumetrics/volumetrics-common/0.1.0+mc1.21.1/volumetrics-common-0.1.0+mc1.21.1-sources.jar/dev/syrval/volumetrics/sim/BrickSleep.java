package dev.syrval.volumetrics.sim;

import java.util.Arrays;
import java.util.Objects;

/**
 * Which bricks of one kind of gas in one window are asleep: they have settled, so the {@link GasStepper} does not step
 * them, and their cells keep their values, apart from decay, while their neighbours read them as usual.
 *
 * <p>A brick falls asleep after {@link #QUIET_STEPS} steps in a row in which none of its cells moved, other than by
 * decay, by more than {@link #SLEEP_FRACTION} of the medium's maximum density (eps), no source fed it, and
 * no face neighbour's cells along the shared face moved by more than eps. It wakes, and is stepped again in the same
 * step, when a face neighbour's cells along the shared face moved by more than eps in the step before, a source feeds
 * it, a cell of it or of a face neighbour changes in the {@link Occupancy}, or the medium's push differs from the push
 * it fell asleep under by more than moves eps of a full cell in a step. The whole kind wakes when the medium's other
 * numbers or its gravity by layer change. A move of the window keeps the bricks that stay in it as they were; those
 * that come in are awake.
 *
 * <p>For a window filled at its edge from a coarser one ({@link Nesting}), this also keeps what each brick of the edge
 * was last filled from, so the edge is only filled again when that has moved.
 */
final class BrickSleep {
    /** Quiet steps in a row after which a brick sleeps. */
    static final int QUIET_STEPS = 3;
    /**
     * eps, as a fraction of the medium's maximum density: a 16th of {@link GasStepper#SETTLED_FRACTION}. A brick that
     * moves by a little less than that every step still moves a long way in a minute, and sleeping freezes it: at that
     * fraction itself, the gas of SimBench's scenes ended up to 0.12 of the maximum density per cell, and 2.6% of it
     * all, away from where it got to with no sleeping (SleepTest); at this, 0.008 and 0.13%.
     */
    static final float SLEEP_FRACTION = GasStepper.SETTLED_FRACTION / 16f;
    static final int WEST = 0;
    static final int EAST = 1;
    static final int DOWN = 2;
    static final int UP = 3;
    static final int NORTH = 4;
    static final int SOUTH = 5;
    static final int FACES = 6;

    final GridSize size;
    /** By brick: the quiet steps in a row, up to {@link #QUIET_STEPS}, at which it sleeps. */
    final byte[] quiet;
    /** By brick: the push (blocks per second) when it fell asleep. */
    final float[] pushX;
    final float[] pushZ;
    /**
     * By brick and face: the most a cell along the face moved, other than by decay, in this step, and in the step
     * before. A brick that is not stepped moved nothing.
     */
    float[] faceNow;
    float[] facePrevious;
    /** By brick: whether a source fed it in this step. */
    final boolean[] fed;
    /**
     * By brick of the outermost ring: what {@link Nesting} last filled it from, as a sum of the coarse store's
     * {@link GasStore#changeSum}; NaN when it must be filled from the coarse window again.
     */
    final double[] ringSeen;

    /** The pushes of the sources in this step, or null; a brick with one never sleeps. */
    FlowField flow;
    /** eps for this step. */
    float threshold;
    /**
     * How far, at most, the coarse cells an edge brick is filled from may have moved since it was filled, before it is
     * filled again: {@link GasStepper#SETTLED_FRACTION} of the maximum density. The edge then never lags the coarse
     * window by more than that, where a sleeping brick, which is not stepped, can fall behind by a little every step.
     */
    float ringThreshold;
    /** The push of this step, blocks per second. */
    float driftX;
    float driftZ;
    /** How far the push may move, in blocks per second, before a sleeping brick wakes. */
    private float pushTolerance;

    private Occupancy occupancy;
    private long occupancySeen;
    private MediumParams params;
    private float[] layerGravity;
    private GasStore coarser;
    private GridPlacement coarserPlacement;

    BrickSleep(GridSize size) {
        this.size = size;
        int bricks = size.brickCount();
        quiet = new byte[bricks];
        pushX = new float[bricks];
        pushZ = new float[bricks];
        faceNow = new float[bricks * FACES];
        facePrevious = new float[bricks * FACES];
        fed = new boolean[bricks];
        ringSeen = new double[bricks];
        Arrays.fill(ringSeen, Double.NaN);
    }

    /**
     * Before the kind is stepped: wakes what the occupancy, the medium and the coarser window say must wake.
     *
     * @param medium       the medium's numbers as the stepper gets them, with the push of this step
     * @param layerGravity the gravity by layer the stepper gets, or null; not changed afterwards
     * @param coarser      the coarser window's store of the kind, or null
     */
    void begin(Occupancy occupancy, MediumParams medium, float[] layerGravity, int cellSize, float dt,
               GasStore coarser, GridPlacement coarserPlacement) {
        float[] swap = facePrevious;
        facePrevious = faceNow;
        faceNow = swap;
        Arrays.fill(faceNow, 0f);
        threshold = medium.maxDensity() * SLEEP_FRACTION;
        ringThreshold = medium.maxDensity() * GasStepper.SETTLED_FRACTION;
        driftX = medium.driftX();
        driftZ = medium.driftZ();
        pushTolerance = SLEEP_FRACTION * cellSize / dt;

        if (occupancy != this.occupancy || !Arrays.equals(layerGravity, this.layerGravity) || !sameButPush(medium, params)) {
            wakeAll();
        } else if (occupancy.changeCount() != occupancySeen) {
            for (int by = 0; by < size.bricksY(); by++) {
                for (int bz = 0; bz < size.bricksZ(); bz++) {
                    for (int bx = 0; bx < size.bricksX(); bx++) {
                        int brick = size.brickIndex(bx, by, bz);
                        if (occupancy.brickChangedAt(brick) > occupancySeen) {
                            wakeAround(bx, by, bz);
                        }
                    }
                }
            }
        }
        if (coarser != this.coarser || !Objects.equals(coarserPlacement, this.coarserPlacement)) {
            Arrays.fill(ringSeen, Double.NaN);
        }
        this.occupancy = occupancy;
        this.occupancySeen = occupancy.changeCount();
        this.layerGravity = layerGravity;
        this.params = medium;
        this.coarser = coarser;
        this.coarserPlacement = coarserPlacement;
    }

    /** After the kind is stepped and its edge filled. */
    void end() {
        Arrays.fill(fed, false);
    }

    boolean asleep(int brick) {
        return quiet[brick] >= QUIET_STEPS;
    }

    /** Whether a sleeping brick must wake before this step: fed, a neighbour moved along the shared face, or the push moved. */
    boolean mustWake(int brick, int bx, int by, int bz) {
        return fed[brick] || flow != null && flow.has(brick) || neighbourMoved(bx, by, bz)
                || Math.abs(driftX - pushX[brick]) > pushTolerance || Math.abs(driftZ - pushZ[brick]) > pushTolerance;
    }

    /** After the brick was stepped: whether it was quiet, given the most any of its cells moved other than by decay. */
    void stepped(int brick, int bx, int by, int bz, float moved) {
        if (moved > threshold || fed[brick] || neighbourMoved(bx, by, bz)) {
            quiet[brick] = 0;
        } else if (quiet[brick] < QUIET_STEPS) {
            quiet[brick]++;
            if (quiet[brick] == QUIET_STEPS) {
                pushX[brick] = driftX;
                pushZ[brick] = driftZ;
            }
        }
    }

    /** The same moved along every face of the brick, for the steppers and {@link Nesting}. */
    void movedEverywhere(int brick, float moved) {
        Arrays.fill(faceNow, brick * FACES, brick * FACES + FACES, moved);
    }

    /**
     * After the sources' pushes moved gas out of a brick, at most {@code moved} from a cell: it is not quiet, and if
     * that is more than eps, its face neighbours, which the gas may have gone into, wake in the next step.
     */
    void flowed(int brick, float moved) {
        if (moved > threshold) {
            quiet[brick] = 0;
            for (int face = brick * FACES; face < brick * FACES + FACES; face++) {
                faceNow[face] = Math.max(faceNow[face], moved);
            }
        }
    }

    /** Follows the window as its origin moves by these cells, as the stores do. */
    void shift(int dx, int dy, int dz) {
        Arrays.fill(ringSeen, Double.NaN);
        int brick = GridSize.BRICK;
        if (dx % brick != 0 || dy % brick != 0 || dz % brick != 0) {
            wakeAll();
            Arrays.fill(facePrevious, 0f);
            return;
        }
        byte[] quietBefore = quiet.clone();
        float[] pushXBefore = pushX.clone();
        float[] pushZBefore = pushZ.clone();
        float[] facesBefore = facePrevious.clone();
        for (int by = 0; by < size.bricksY(); by++) {
            for (int bz = 0; bz < size.bricksZ(); bz++) {
                for (int bx = 0; bx < size.bricksX(); bx++) {
                    int to = size.brickIndex(bx, by, bz);
                    int fromX = bx + dx / brick;
                    int fromY = by + dy / brick;
                    int fromZ = bz + dz / brick;
                    if (fromX >= 0 && fromX < size.bricksX() && fromY >= 0 && fromY < size.bricksY() && fromZ >= 0 && fromZ < size.bricksZ()) {
                        int from = size.brickIndex(fromX, fromY, fromZ);
                        quiet[to] = quietBefore[from];
                        pushX[to] = pushXBefore[from];
                        pushZ[to] = pushZBefore[from];
                        System.arraycopy(facesBefore, from * FACES, facePrevious, to * FACES, FACES);
                    } else {
                        quiet[to] = 0;
                        Arrays.fill(facePrevious, to * FACES, to * FACES + FACES, 0f);
                    }
                }
            }
        }
    }

    private void wakeAll() {
        Arrays.fill(quiet, (byte) 0);
        Arrays.fill(ringSeen, Double.NaN);
    }

    /** Wakes a brick whose occupancy changed and its face neighbours, and has its edge filled again if it has one. */
    private void wakeAround(int bx, int by, int bz) {
        int brick = size.brickIndex(bx, by, bz);
        quiet[brick] = 0;
        ringSeen[brick] = Double.NaN;
        if (bx > 0) {
            quiet[size.brickIndex(bx - 1, by, bz)] = 0;
        }
        if (bx < size.bricksX() - 1) {
            quiet[size.brickIndex(bx + 1, by, bz)] = 0;
        }
        if (by > 0) {
            quiet[size.brickIndex(bx, by - 1, bz)] = 0;
        }
        if (by < size.bricksY() - 1) {
            quiet[size.brickIndex(bx, by + 1, bz)] = 0;
        }
        if (bz > 0) {
            quiet[size.brickIndex(bx, by, bz - 1)] = 0;
        }
        if (bz < size.bricksZ() - 1) {
            quiet[size.brickIndex(bx, by, bz + 1)] = 0;
        }
    }

    /** Whether a face neighbour's cells along the face it shares with this brick moved by more than eps in the step before. */
    private boolean neighbourMoved(int bx, int by, int bz) {
        float[] faces = facePrevious;
        float eps = threshold;
        return bx > 0 && faces[size.brickIndex(bx - 1, by, bz) * FACES + EAST] > eps
                || bx < size.bricksX() - 1 && faces[size.brickIndex(bx + 1, by, bz) * FACES + WEST] > eps
                || by > 0 && faces[size.brickIndex(bx, by - 1, bz) * FACES + UP] > eps
                || by < size.bricksY() - 1 && faces[size.brickIndex(bx, by + 1, bz) * FACES + DOWN] > eps
                || bz > 0 && faces[size.brickIndex(bx, by, bz - 1) * FACES + SOUTH] > eps
                || bz < size.bricksZ() - 1 && faces[size.brickIndex(bx, by, bz + 1) * FACES + NORTH] > eps;
    }

    /** Whether two sets of a medium's numbers are the same but for the push. */
    private static boolean sameButPush(MediumParams a, MediumParams b) {
        return b != null && a.gravity() == b.gravity() && a.dispersion() == b.dispersion() && a.decay() == b.decay()
                && a.maxDensity() == b.maxDensity();
    }
}
