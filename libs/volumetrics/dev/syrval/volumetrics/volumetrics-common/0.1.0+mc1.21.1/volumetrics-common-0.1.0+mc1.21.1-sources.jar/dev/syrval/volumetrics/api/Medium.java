package dev.syrval.volumetrics.api;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.sim.Draft;
import dev.syrval.volumetrics.sim.MediumParams;
import dev.syrval.volumetrics.sim.MediumProperties;
import java.util.Optional;

/**
 * One kind of gas: how it moves and how it looks. Datapacks define them in
 * {@code data/<namespace>/volumetrics/medium/<name>.json}.
 *
 * @param simulation the fixed numbers of its movement; its gravity is not used when there is a {@code buoyancy}
 * @param buoyancy   what makes it rise or sink with the air around it, in place of a gravity of its own
 * @param windResponse how much of the server's wind pushes it, 0 (none) to 1 (all of it)
 * @param draft      a slowly turning sideways push of its own, on top of its drift and the wind
 */
public record Medium(MediumParams simulation, Appearance appearance, Optional<MediumBuoyancy> buoyancy,
                     float windResponse, Optional<Draft.Settings> draft) {
    // The ranges keep every value the simulation's own checks would refuse out of a datapack, with a message
    // that names the field, instead of an exception while the registry loads.
    private static final Codec<Draft.Settings> DRAFT_CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.floatRange(0f, 16f).fieldOf("speed").forGetter(Draft.Settings::speed),
            Codec.floatRange(1e-3f, 1e5f).fieldOf("period").forGetter(Draft.Settings::period)
    ).apply(instance, Draft.Settings::new));

    private static final Codec<Simulation> SIMULATION_CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.floatRange(-64f, 64f).optionalFieldOf("gravity", 0f).forGetter(sim -> sim.params().gravity()),
            Codec.floatRange(0f, 64f).fieldOf("dispersion").forGetter(sim -> sim.params().dispersion()),
            Codec.floatRange(0f, 20f).optionalFieldOf("decay", 0f).forGetter(sim -> sim.params().decay()),
            Codec.floatRange(0.01f, 16f).optionalFieldOf("max_density", 1f).forGetter(sim -> sim.params().maxDensity()),
            Drift.CODEC.optionalFieldOf("drift", Drift.NONE).forGetter(sim -> new Drift(sim.params().driftX(), sim.params().driftZ())),
            MediumBuoyancy.CODEC.optionalFieldOf("buoyancy").forGetter(Simulation::buoyancy),
            Codec.floatRange(0f, 1f).optionalFieldOf("wind_response", 1f).forGetter(Simulation::windResponse),
            DRAFT_CODEC.optionalFieldOf("draft").forGetter(Simulation::draft)
    ).apply(instance, (gravity, dispersion, decay, maxDensity, drift, buoyancy, windResponse, draft) -> new Simulation(
            new MediumParams(gravity, dispersion, decay, maxDensity, drift.x(), drift.z()), buoyancy, windResponse, draft)));

    public static final Codec<Medium> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            SIMULATION_CODEC.fieldOf("simulation").forGetter(medium -> new Simulation(medium.simulation(), medium.buoyancy(), medium.windResponse(), medium.draft())),
            Appearance.CODEC.fieldOf("appearance").forGetter(Medium::appearance)
    ).apply(instance, (simulation, appearance) -> new Medium(simulation.params(), appearance, simulation.buoyancy(), simulation.windResponse(), simulation.draft())));

    /** A medium without buoyancy: its gravity is the one in its simulation. */
    public Medium(MediumParams simulation, Appearance appearance) {
        this(simulation, appearance, Optional.empty());
    }

    /** A medium that follows the wind fully and has no draft. */
    public Medium(MediumParams simulation, Appearance appearance, Optional<MediumBuoyancy> buoyancy) {
        this(simulation, appearance, buoyancy, 1f, Optional.empty());
    }

    public Medium {
        if (simulation == null || appearance == null || buoyancy == null || draft == null) {
            throw new IllegalArgumentException("A medium needs both simulation and appearance");
        }
        if (!(windResponse >= 0 && windResponse <= 1)) {
            throw new IllegalArgumentException("Wind response must be between 0 and 1, got " + windResponse);
        }
    }

    /** What the simulation engines work from: the numbers of the medium without its buoyancy, which belongs to the air. */
    public MediumProperties properties() {
        return new MediumProperties(simulation, windResponse, draft.orElse(null));
    }

    /** The {@code simulation} object of a medium file. */
    private record Simulation(MediumParams params, Optional<MediumBuoyancy> buoyancy, float windResponse,
                              Optional<Draft.Settings> draft) {}

    /** How a medium file writes its drift: blocks per second towards east ({@code x}) and south ({@code z}). */
    private record Drift(float x, float z) {
        static final Drift NONE = new Drift(0f, 0f);

        static final Codec<Drift> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                Codec.floatRange(-16f, 16f).optionalFieldOf("x", 0f).forGetter(Drift::x),
                Codec.floatRange(-16f, 16f).optionalFieldOf("z", 0f).forGetter(Drift::z)
        ).apply(instance, Drift::new));
    }
}
