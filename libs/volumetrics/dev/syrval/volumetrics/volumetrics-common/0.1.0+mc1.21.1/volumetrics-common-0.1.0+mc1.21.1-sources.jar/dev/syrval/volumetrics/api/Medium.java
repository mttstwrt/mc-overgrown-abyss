package dev.syrval.volumetrics.api;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.sim.MediumParams;

/**
 * One kind of gas: how it moves and how it looks. Datapacks define them in
 * {@code data/<namespace>/volumetrics/medium/<name>.json}.
 */
public record Medium(MediumParams simulation, Appearance appearance) {
    // The ranges keep every value the simulation's own checks would refuse out of a datapack, with a message
    // that names the field, instead of an exception while the registry loads.
    private static final Codec<MediumParams> SIMULATION_CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.floatRange(-64f, 64f).fieldOf("gravity").forGetter(MediumParams::gravity),
            Codec.floatRange(0f, 64f).fieldOf("dispersion").forGetter(MediumParams::dispersion),
            Codec.floatRange(0f, 20f).optionalFieldOf("decay", 0f).forGetter(MediumParams::decay),
            Codec.floatRange(0.01f, 16f).optionalFieldOf("max_density", 1f).forGetter(MediumParams::maxDensity),
            Drift.CODEC.optionalFieldOf("drift", Drift.NONE).forGetter(params -> new Drift(params.driftX(), params.driftZ()))
    ).apply(instance, (gravity, dispersion, decay, maxDensity, drift) ->
            new MediumParams(gravity, dispersion, decay, maxDensity, drift.x(), drift.z())));

    public static final Codec<Medium> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            SIMULATION_CODEC.fieldOf("simulation").forGetter(Medium::simulation),
            Appearance.CODEC.fieldOf("appearance").forGetter(Medium::appearance)
    ).apply(instance, Medium::new));

    public Medium {
        if (simulation == null || appearance == null) {
            throw new IllegalArgumentException("A medium needs both simulation and appearance");
        }
    }

    /** How a medium file writes its drift: blocks per second towards east ({@code x}) and south ({@code z}). */
    private record Drift(float x, float z) {
        static final Drift NONE = new Drift(0f, 0f);

        static final Codec<Drift> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                Codec.floatRange(-16f, 16f).optionalFieldOf("x", 0f).forGetter(Drift::x),
                Codec.floatRange(-16f, 16f).optionalFieldOf("z", 0f).forGetter(Drift::z)
        ).apply(instance, Drift::new));
    }
}
