package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.api.EmitterShape;
import dev.syrval.volumetrics.api.Medium;
import net.minecraft.advancements.critereon.StatePropertiesPredicate;
import net.minecraft.core.HolderSet;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * An emitter definition placed by block, with its medium looked up: every such block, in a matching state, gives
 * off this gas.
 *
 * @param id the definition's id in the emitter registry, for messages
 */
public record BlockEmitterRule(ResourceLocation id, HolderSet<Block> blocks, StatePropertiesPredicate state, Medium medium,
                               EmitterShape shape, Vec3 offset, float rate) {
    boolean matches(BlockState blockState) {
        return blockState.is(blocks) && state.matches(blockState);
    }
}
