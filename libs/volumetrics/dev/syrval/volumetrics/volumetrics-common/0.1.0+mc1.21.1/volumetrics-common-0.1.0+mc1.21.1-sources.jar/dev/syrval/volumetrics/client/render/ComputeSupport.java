package dev.syrval.volumetrics.client.render;

/**
 * What the compute layer can do on this device: which backend runs the compute shaders, if any, said in one line for
 * the log and {@code /volumetrics stats}.
 *
 * @param backend     which implementation runs the compute shaders
 * @param description one line saying what runs them, or for {@link Backend#NONE} that nothing does
 * @param reason      for {@link Backend#NONE}, why not; empty otherwise
 */
public record ComputeSupport(Backend backend, String description, String reason) {
    /** The compute layer's implementations. */
    public enum Backend {
        /** OpenGL 4.3 compute shaders and storage images. */
        GL43,
        /** Vulkan compute pipelines, recorded into the game's own command buffer. */
        VULKAN,
        /** No compute on this device or backend. */
        NONE
    }

    public static ComputeSupport available(Backend backend, String description) {
        return new ComputeSupport(backend, description, "");
    }

    public static ComputeSupport none(String reason) {
        return new ComputeSupport(Backend.NONE, "not available", reason);
    }

    public boolean usable() {
        return backend != Backend.NONE;
    }

    /** The line the log and the stats show, such as {@code OpenGL 4.6 (Mesa llvmpipe)}. */
    public String line() {
        return usable() ? description : description + " (" + reason + ")";
    }
}
