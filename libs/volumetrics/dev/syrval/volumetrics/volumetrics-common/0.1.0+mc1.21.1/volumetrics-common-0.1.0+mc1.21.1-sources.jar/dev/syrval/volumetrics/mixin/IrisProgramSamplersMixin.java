package dev.syrval.volumetrics.mixin;

import dev.syrval.volumetrics.client.render.FarTerrainDepth;
import java.util.function.IntSupplier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Sees each texture Iris gives a shader pack's program, by the names the pack reads it by: every way a program is
 * given one ends here. Applied only when Iris is installed, and it names none of Iris's types, so the mod builds
 * and runs without Iris; an Iris this does not fit loses only the far terrain's depth. See {@link FarTerrainDepth}.
 */
@Pseudo
@Mixin(targets = "net.irisshaders.iris.gl.program.ProgramSamplers$Builder", remap = false)
abstract class IrisProgramSamplersMixin {
    @Inject(method = "addDynamicSampler(Lnet/irisshaders/iris/gl/texture/TextureType;Ljava/util/function/IntSupplier;Lnet/irisshaders/iris/gl/sampler/GlSampler;ZLnet/irisshaders/iris/gl/state/ValueUpdateNotifier;[Ljava/lang/String;)Z",
            at = @At("HEAD"), require = 0, remap = false)
    private void volumetrics$samplerAdded(@Coerce Object type, IntSupplier texture, @Coerce Object sampler, boolean used,
                                          @Coerce Object notifier, String[] names, CallbackInfoReturnable<Boolean> info) {
        FarTerrainDepth.samplerAdded(texture, names);
    }
}
