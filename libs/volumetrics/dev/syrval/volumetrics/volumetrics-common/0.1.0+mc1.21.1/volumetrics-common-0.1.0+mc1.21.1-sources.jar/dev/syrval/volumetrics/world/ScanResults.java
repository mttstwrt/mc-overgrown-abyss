package dev.syrval.volumetrics.world;

import org.jspecify.annotations.Nullable;

/** Where the simulation thread takes the scans of chunk sections from, in the order the sections were copied. */
interface ScanResults {
    /** The oldest scan not yet taken, or null. Each one taken is {@link #done} once written into its window or dropped. */
    @Nullable SectionResult poll();

    void done();
}
