package dev.syrval.volumetrics.sim;

/**
 * What a window is told from outside for one step, taken on the thread that owns it and so safe to hand to the
 * simulation thread.
 *
 * @param ambient  the air that floating gas floats in; null until it is known
 * @param windX    the wind the server sets for the window, in blocks per second towards east
 * @param windZ    the same towards south
 * @param gameTime the game time in ticks, which the draft is a function of
 */
public record WindowInputs(AmbientProfile ambient, float windX, float windZ, long gameTime) {
    /** Nothing known: no air, so gas that floats waits; no wind. */
    public static final WindowInputs NONE = new WindowInputs(null, 0f, 0f, 0L);

    public WindowInputs {
        if (!Float.isFinite(windX) || !Float.isFinite(windZ)) {
            throw new IllegalArgumentException("Wind must be finite, got " + windX + ", " + windZ);
        }
    }

    public WindowInputs withAmbient(AmbientProfile ambient) {
        return new WindowInputs(ambient, windX, windZ, gameTime);
    }

    public WindowInputs withGameTime(long gameTime) {
        return new WindowInputs(ambient, windX, windZ, gameTime);
    }
}
