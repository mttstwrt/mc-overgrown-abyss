package dev.syrval.volumetrics.client.render;

import dev.syrval.volumetrics.sim.AtlasLayout;
import dev.syrval.volumetrics.sim.BrickMask;
import dev.syrval.volumetrics.sim.GridSize;
import java.util.ArrayList;
import java.util.List;

/**
 * Where each level of the cascade lies in the textures the renderer shares between all of them, so that the shaders
 * bind the same few textures however many levels there are. The levels sit side by side along X, the finest first:
 * each has its own column of texels in every texture, starting at row 0. In a density texture a level's column holds
 * its pages one above the other ({@link AtlasLayout#height} rows each); in the light texture it holds two copies of
 * its light atlas one above the other, the one being read and the one a whole update is built in, each
 * {@link #lightSlotHeight} rows; in the brick texture it holds the level's {@link BrickMask}.
 *
 * <p>Made to fit the device: levels that would make a texture wider or taller than it allows are left out, the
 * outermost first (level 0 always stays), and a level whose pages would make the density textures too tall holds
 * fewer of them ({@link #pages}).
 */
public final class LevelAtlas {
    private static final int DENSITY_BYTES = 4;
    private static final int LIGHT_BYTES = 2;

    private final List<GridSize> sizes;
    private final List<AtlasLayout> atlases;
    private final int[] columns;
    private final int[] brickColumns;
    private final int width;
    private final int lightSlotHeight;
    private final int brickWidth;
    private final int brickHeight;
    /** The most rows a density texture this wide may have. */
    private final int maxDensityRows;
    private final int wanted;

    private LevelAtlas(List<GridSize> sizes, int wanted, int maxTextureSize, long maxTextureBytes) {
        this.sizes = List.copyOf(sizes);
        this.wanted = wanted;
        List<AtlasLayout> atlases = new ArrayList<>();
        this.columns = new int[sizes.size()];
        this.brickColumns = new int[sizes.size()];
        int width = 0;
        int lightSlotHeight = 0;
        int brickWidth = 0;
        int brickHeight = 0;
        for (int level = 0; level < sizes.size(); level++) {
            AtlasLayout atlas = AtlasLayout.of(sizes.get(level));
            BrickMask bricks = new BrickMask(sizes.get(level));
            atlases.add(atlas);
            columns[level] = width;
            brickColumns[level] = brickWidth;
            width += atlas.width();
            lightSlotHeight = Math.max(lightSlotHeight, atlas.height());
            brickWidth += bricks.width();
            brickHeight = Math.max(brickHeight, bricks.height());
        }
        this.atlases = List.copyOf(atlases);
        this.width = width;
        this.lightSlotHeight = lightSlotHeight;
        this.brickWidth = brickWidth;
        this.brickHeight = brickHeight;
        this.maxDensityRows = (int) Math.min(maxTextureSize, maxTextureBytes / ((long) width * DENSITY_BYTES));
    }

    /**
     * The levels that fit the device, as many of the given ones as can be drawn, the finest first.
     *
     * @param sizes           each level's size in cells, the finest first
     * @param maxTextureSize  the widest and tallest texture the device makes, in texels
     * @param maxTextureBytes the most memory one texture may take, in bytes; {@link Long#MAX_VALUE} if the device
     *                        does not say
     */
    public static LevelAtlas fit(List<GridSize> sizes, int maxTextureSize, long maxTextureBytes) {
        for (int levels = sizes.size(); levels > 1; levels--) {
            LevelAtlas atlas = new LevelAtlas(sizes.subList(0, levels), sizes.size(), maxTextureSize, maxTextureBytes);
            if (atlas.fits(maxTextureSize, maxTextureBytes)) {
                return atlas;
            }
        }
        return new LevelAtlas(sizes.subList(0, 1), sizes.size(), maxTextureSize, maxTextureBytes);
    }

    /** Whether every texture, with one page of density, is within the device's limits. */
    private boolean fits(int maxTextureSize, long maxTextureBytes) {
        int tallest = 0;
        for (AtlasLayout atlas : atlases) {
            tallest = Math.max(tallest, atlas.height());
        }
        return width <= maxTextureSize && brickWidth <= maxTextureSize && brickHeight <= maxTextureSize
                && lightHeight() <= maxTextureSize && (long) width * lightHeight() * LIGHT_BYTES <= maxTextureBytes
                && tallest <= maxDensityRows;
    }

    /** How many levels are drawn. */
    public int levels() {
        return sizes.size();
    }

    /** How many levels there were to draw, before those that did not fit were left out. */
    public int wanted() {
        return wanted;
    }

    public GridSize size(int level) {
        return sizes.get(level);
    }

    public AtlasLayout atlas(int level) {
        return atlases.get(level);
    }

    /** The texel column a level's density and light atlases start at. */
    public int column(int level) {
        return columns[level];
    }

    /** The texel column a level's bricks start at in the brick texture. */
    public int brickColumn(int level) {
        return brickColumns[level];
    }

    /** Width of the density and the light textures. */
    public int width() {
        return width;
    }

    /** Rows of one of the two copies of the light in the light texture: the tallest level's light atlas. */
    public int lightSlotHeight() {
        return lightSlotHeight;
    }

    /** Height of the light texture: two copies of each level's light, one above the other. */
    public int lightHeight() {
        return 2 * lightSlotHeight;
    }

    public int brickWidth() {
        return brickWidth;
    }

    public int brickHeight() {
        return brickHeight;
    }

    /** How many of the pages wanted a level holds: all of them, unless that would make the density textures too tall. */
    public int pages(int level, int wanted) {
        return Math.max(1, Math.min(wanted, maxDensityRows / atlases.get(level).height()));
    }

    /** Height of the density textures with room for the pages wanted, as {@link #pages} has each level hold them. */
    public int densityHeight(int wanted) {
        int height = 1;
        for (int level = 0; level < levels(); level++) {
            height = Math.max(height, pages(level, wanted) * atlases.get(level).height());
        }
        return height;
    }
}
