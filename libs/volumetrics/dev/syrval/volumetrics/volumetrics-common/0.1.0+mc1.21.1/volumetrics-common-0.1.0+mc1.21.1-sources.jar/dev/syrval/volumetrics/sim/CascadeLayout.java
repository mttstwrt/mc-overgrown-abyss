package dev.syrval.volumetrics.sim;

import java.util.ArrayList;
import java.util.List;

/**
 * The levels of the cascade of windows that follow the camera, finest first: level k has cells of 2 * 2^k blocks.
 * Each level is as many cells across as the reach scale gives (128 at 1, in whole bricks, at least 32), so it reaches
 * twice as far as the one inside it; level 0 is 64 cells high, the others as high as the world, up to 96 cells. There
 * are as many levels as it takes for the outermost to reach the render distance, at least two and at most
 * {@link LevelSchedule#MAX_LEVELS}.
 *
 * @param sizes     each level's size in cells
 * @param cellSizes the edge of each level's cells, in blocks
 */
public record CascadeLayout(List<GridSize> sizes, List<Integer> cellSizes) {
    public static final float MIN_REACH = 0.25f;
    public static final float MAX_REACH = 1f;
    /** The cells of level 0, in blocks. */
    public static final int FINEST_CELL = 2;
    private static final int FULL_CELLS = 128;
    private static final int MIN_CELLS = 32;
    private static final int FINEST_HEIGHT = 64;
    private static final int MAX_HEIGHT = 96;
    private static final int MIN_LEVELS = 2;

    public CascadeLayout {
        sizes = List.copyOf(sizes);
        cellSizes = List.copyOf(cellSizes);
        if (sizes.size() != cellSizes.size() || sizes.isEmpty()) {
            throw new IllegalArgumentException("A size and a cell size for each level, and at least one level");
        }
    }

    /**
     * @param renderDistance how far the world is drawn, in blocks
     * @param reach          the reach scale, {@link #MIN_REACH} to {@link #MAX_REACH}; clamped to that
     * @param worldHeight    how many blocks high the world is
     */
    public static CascadeLayout of(int renderDistance, float reach, int worldHeight) {
        float scale = Math.clamp(reach, MIN_REACH, MAX_REACH);
        int across = Math.max(MIN_CELLS, Math.round(FULL_CELLS * scale / GridSize.BRICK) * GridSize.BRICK);
        List<GridSize> sizes = new ArrayList<>();
        List<Integer> cellSizes = new ArrayList<>();
        for (int level = 0; level < LevelSchedule.MAX_LEVELS; level++) {
            int cell = FINEST_CELL << level;
            int high = level == 0 ? FINEST_HEIGHT : Math.min(MAX_HEIGHT, wholeBricks(Math.ceilDiv(worldHeight, cell)));
            sizes.add(new GridSize(across, high, across));
            cellSizes.add(cell);
            // Half the level's width, in blocks, reaches the render distance.
            if (sizes.size() >= MIN_LEVELS && across / 2 * cell >= renderDistance) {
                break;
            }
        }
        return new CascadeLayout(sizes, cellSizes);
    }

    private static int wholeBricks(int cells) {
        return Math.max(GridSize.BRICK, Math.ceilDiv(cells, GridSize.BRICK) * GridSize.BRICK);
    }

    public int levels() {
        return sizes.size();
    }

    public GridSize size(int level) {
        return sizes.get(level);
    }

    public int cellSize(int level) {
        return cellSizes.get(level);
    }
}
