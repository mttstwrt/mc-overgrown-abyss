package dev.syrval.volumetrics.sim;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The engine that moves gas cell by cell with a {@link GasStepper}: gravity, dispersion and drift, blocked by what
 * the {@link Occupancy} says, and fed at its edge from the coarser window's gas.
 */
public final class CellularEngine implements SimEngine {
    public static final String NAME = "cellular";
    /** Densities under this are dropped; a byte of the density texture cannot show them anyway. */
    private static final float MIN_DENSITY = 1f / 512f;

    private final GridSize size;
    private final int cellSize;
    private final GasStepper stepper = new GasStepper(MIN_DENSITY);
    /** Each medium's parameters, with the push of the moment, slowed to what this window's cells carry in a step. */
    private final Map<Object, Stable> stableParams = new HashMap<>();
    /** The same with no gravity, for the media that float: the air moves them instead. */
    private final Map<Object, Stable> stableParamsWithoutGravity = new HashMap<>();
    /** The gravity of each layer for each medium that floats, kept while nothing it came from changes. */
    private final Map<Object, LayerGravity> layerGravities = new HashMap<>();
    /** Whether settled bricks sleep, and the edge is filled from the coarser window only where that has moved. */
    private final boolean sleeps;
    /** Which bricks of each kind sleep; see {@link BrickSleep}. */
    private final Map<Object, BrickSleep> sleep = new HashMap<>();
    /** The pushes of each kind's sources that have a flow, kept while those sources and the window stay the same. */
    private final Map<Object, FlowField> flows = new HashMap<>();
    private StepStats lastStats = StepStats.NONE;

    public CellularEngine(GridSize size, int cellSize) {
        this(size, cellSize, true);
    }

    /** @param sleeps whether settled bricks sleep (see {@link BrickSleep}); off steps every brick, for comparison */
    public CellularEngine(GridSize size, int cellSize, boolean sleeps) {
        this.size = size;
        this.cellSize = cellSize;
        this.sleeps = sleeps;
    }

    public static SimEngine.Factory factory() {
        return factory(true);
    }

    /** @param sleeps whether settled bricks sleep; see {@link #CellularEngine(GridSize, int, boolean)} */
    public static SimEngine.Factory factory(boolean sleeps) {
        return (size, cellSize, coarser) -> new CellularEngine(size, cellSize, sleeps);
    }

    /** A medium's parameters as they were last slowed, and what they were slowed from. */
    private record Stable(MediumParams from, MediumParams slowed) {}

    private record LayerGravity(AmbientProfile ambient, Buoyancy buoyancy, MediumParams stable, int originY, float[] gravity) {}

    @Override
    public String name() {
        return NAME;
    }

    @Override
    public StepStats lastStats() {
        return lastStats;
    }

    @Override
    public void step(EngineWindow window, WindowInputs inputs, float stepSeconds) {
        stepper.resetCounts();
        long nestNanos = 0;
        int edge = 0;
        GridPlacement placement = window.placement();
        for (EngineWindow.Kind kind : window.kinds()) {
            GasStore store = kind.store();
            OuterLevel coarser = kind.coarser();
            // Nothing given off here, none left here and none to come in at the edge: nothing can change.
            if (kind.sources().isEmpty() && store.isEmpty() && (coarser == null || coarser.isEmpty())) {
                sleep.remove(kind.key());
                flows.remove(kind.key());
                continue;
            }
            MediumParams own = withEffectiveDrift(kind, inputs);
            MediumParams stable;
            float[] layerGravity = null;
            if (!kind.floats()) {
                stable = stable(stableParams, kind.key(), own, stepSeconds);
            } else {
                stable = stable(stableParamsWithoutGravity, kind.key(),
                        new MediumParams(0f, own.dispersion(), own.decay(), own.maxDensity(), own.driftX(), own.driftZ()), stepSeconds);
                if (kind.buoyancy() != null && inputs.ambient() != null) {
                    layerGravity = layerGravity(kind, inputs.ambient(), placement, stable, stepSeconds);
                }
            }
            // What the step keeps of the gas against decay, as the stepper works it out.
            float keep = Math.max(0f, 1f - stable.decay() * stepSeconds);
            BrickSleep asleep = null;
            if (sleeps) {
                asleep = sleep.computeIfAbsent(kind.key(), key -> new BrickSleep(size));
                asleep.begin(window.occupancy(), stable, layerGravity, cellSize, stepSeconds, coarser == null ? null : coarser.store(),
                        window.coarserPlacement());
                if (coarser != null) {
                    coarser.trackChanges();
                }
            }
            GasField field = window.workspace();
            store.loadInto(field);
            FlowField flow = flow(kind, placement, stepSeconds);
            if (asleep != null) {
                stepper.step(field, window.occupancy(), stable, placement, kind.sources(), stepSeconds, layerGravity, asleep, coarser != null,
                        flow);
            } else if (flow != null) {
                stepper.step(field, window.occupancy(), stable, placement, kind.sources(), stepSeconds, layerGravity, null, false, flow);
            } else if (layerGravity == null) {
                stepper.step(field, window.occupancy(), stable, placement, kind.sources(), stepSeconds);
            } else {
                stepper.step(field, window.occupancy(), stable, placement, kind.sources(), stepSeconds, layerGravity);
            }
            if (coarser != null) {
                long nestStart = System.nanoTime();
                if (asleep != null) {
                    // The coarser level's change sums are against what its own step keeps, which spans more time.
                    float coarserKeep = Float.isNaN(coarser.stepSeconds()) ? keep : Math.max(0f, 1f - stable.decay() * coarser.stepSeconds());
                    edge += Nesting.edgeFromCoarse(field, placement, window.occupancy(), coarser, window.coarserPlacement(), MIN_DENSITY,
                            keep, coarserKeep, asleep);
                } else {
                    edge += Nesting.edgeFromCoarse(field, placement, window.occupancy(), coarser, window.coarserPlacement(), MIN_DENSITY);
                }
                nestNanos += System.nanoTime() - nestStart;
            }
            store.takeFrom(field, keep);
            if (asleep != null) {
                asleep.end();
            }
        }
        // Forget the kinds that are gone.
        sleep.keySet().removeIf(key -> window.kinds().stream().noneMatch(kind -> kind.key().equals(key)));
        flows.keySet().removeIf(key -> window.kinds().stream().noneMatch(kind -> kind.key().equals(key)));
        lastStats = new StepStats(nestNanos, stepper.visitedBricks(), stepper.changedBricks(), stepper.settledBricks(),
                stepper.asleepBricks(), stepper.skippedBricks(), edge);
    }

    @Override
    public void shift(int dx, int dy, int dz) {
        for (BrickSleep kind : sleep.values()) {
            kind.shift(dx, dy, dz);
        }
    }

    /** Whether the brick of the kind will sleep in the next step, unless something wakes it. For tests. */
    boolean asleep(Object key, int brickX, int brickY, int brickZ) {
        BrickSleep kind = sleep.get(key);
        return kind != null && kind.asleep(size.brickIndex(brickX, brickY, brickZ));
    }

    /** The medium's parameters slowed to what the window's cells carry, worked out again only when they have changed. */
    private MediumParams stable(Map<Object, Stable> cache, Object key, MediumParams params, float dt) {
        Stable kept = cache.get(key);
        if (kept != null && kept.from().equals(params)) {
            return kept.slowed();
        }
        MediumParams slowed = params.slowedToStable(cellSize, dt);
        cache.put(key, new Stable(params, slowed));
        return slowed;
    }

    /**
     * The pushes of the kind's sources that have a flow, made again only when those sources or the window have changed;
     * null if none has a flow, or every push cancels.
     */
    private FlowField flow(EngineWindow.Kind kind, GridPlacement placement, float dt) {
        List<Source> flowing = null;
        for (Source source : kind.sources()) {
            if (source.flow() != null) {
                if (flowing == null) {
                    flowing = new ArrayList<>();
                }
                flowing.add(source);
            }
        }
        if (flowing == null) {
            flows.remove(kind.key());
            return null;
        }
        FlowField kept = flows.get(kind.key());
        if (kept == null || !kept.builtFrom(flowing, placement, dt)) {
            kept = FlowField.build(flowing, size, placement, dt);
            flows.put(kind.key(), kept);
        }
        return kept.isEmpty() ? null : kept;
    }

    /** The medium's numbers with its drift made what pushes it now (see {@link Push}). */
    private static MediumParams withEffectiveDrift(EngineWindow.Kind kind, WindowInputs inputs) {
        MediumParams own = kind.properties().params();
        Draft.Vector push = Push.of(kind.properties(), kind.idHash(), inputs.windX(), inputs.windZ(), inputs.gameTime());
        if (push.x() == own.driftX() && push.z() == own.driftZ()) {
            return own;
        }
        return new MediumParams(own.gravity(), own.dispersion(), own.decay(), own.maxDensity(), push.x(), push.z());
    }

    /** Worked out again only when the window has moved up or down, or the air or the medium's buoyancy has changed. */
    private float[] layerGravity(EngineWindow.Kind kind, AmbientProfile air, GridPlacement placement, MediumParams stable, float dt) {
        LayerGravity kept = layerGravities.get(kind.key());
        if (kept != null && kept.ambient() == air && kept.buoyancy().equals(kind.buoyancy()) && kept.stable().equals(stable)
                && kept.originY() == placement.originY()) {
            return kept.gravity();
        }
        float[] gravity = kind.buoyancy().layerGravity(air, placement, size.y(), stable, dt);
        layerGravities.put(kind.key(), new LayerGravity(air, kind.buoyancy(), stable, placement.originY(), gravity));
        return gravity;
    }
}
