package dev.syrval.volumetrics.sim;

import java.util.HashMap;
import java.util.Map;

/**
 * The engine that moves gas cell by cell with a {@link GasStepper}: gravity, dispersion and drift, blocked by what
 * the {@link Occupancy} says, and fed at its edge from the coarser window's gas.
 */
public final class CellularEngine implements SimEngine {
    public static final String NAME = "cellular";
    /** Densities under this are dropped; a byte of the density texture cannot show them anyway. */
    private static final float MIN_DENSITY = 1f / 512f;

    private final GridSize size;
    private final int cellSize;
    private final GasStepper stepper = new GasStepper(MIN_DENSITY);
    /** Each medium's parameters, with the push of the moment, slowed to what this window's cells carry in a step. */
    private final Map<Object, Stable> stableParams = new HashMap<>();
    /** The same with no gravity, for the media that float: the air moves them instead. */
    private final Map<Object, Stable> stableParamsWithoutGravity = new HashMap<>();
    /** The gravity of each layer for each medium that floats, kept while nothing it came from changes. */
    private final Map<Object, LayerGravity> layerGravities = new HashMap<>();

    public CellularEngine(GridSize size, int cellSize) {
        this.size = size;
        this.cellSize = cellSize;
    }

    public static SimEngine.Factory factory() {
        return (size, cellSize, coarser) -> new CellularEngine(size, cellSize);
    }

    /** A medium's parameters as they were last slowed, and what they were slowed from. */
    private record Stable(MediumParams from, MediumParams slowed) {}

    private record LayerGravity(AmbientProfile ambient, Buoyancy buoyancy, MediumParams stable, int originY, float[] gravity) {}

    @Override
    public String name() {
        return NAME;
    }

    @Override
    public void step(EngineWindow window, WindowInputs inputs, float stepSeconds) {
        GridPlacement placement = window.placement();
        for (EngineWindow.Kind kind : window.kinds()) {
            GasStore store = kind.store();
            GasStore coarser = kind.coarser();
            // Nothing given off here, none left here and none to come in at the edge: nothing can change.
            if (kind.sources().isEmpty() && store.isEmpty() && (coarser == null || coarser.isEmpty())) {
                continue;
            }
            MediumParams own = withEffectiveDrift(kind, inputs);
            MediumParams stable;
            float[] layerGravity = null;
            if (!kind.floats()) {
                stable = stable(stableParams, kind.key(), own, stepSeconds);
            } else {
                stable = stable(stableParamsWithoutGravity, kind.key(),
                        new MediumParams(0f, own.dispersion(), own.decay(), own.maxDensity(), own.driftX(), own.driftZ()), stepSeconds);
                if (kind.buoyancy() != null && inputs.ambient() != null) {
                    layerGravity = layerGravity(kind, inputs.ambient(), placement, stable, stepSeconds);
                }
            }
            GasField field = window.workspace();
            store.loadInto(field);
            if (layerGravity == null) {
                stepper.step(field, window.occupancy(), stable, placement, kind.sources(), stepSeconds);
            } else {
                stepper.step(field, window.occupancy(), stable, placement, kind.sources(), stepSeconds, layerGravity);
            }
            if (coarser != null) {
                Nesting.edgeFromCoarse(field, placement, window.occupancy(), coarser, window.coarserPlacement(), MIN_DENSITY);
            }
            store.takeFrom(field);
        }
    }

    /** The medium's parameters slowed to what the window's cells carry, worked out again only when they have changed. */
    private MediumParams stable(Map<Object, Stable> cache, Object key, MediumParams params, float dt) {
        Stable kept = cache.get(key);
        if (kept != null && kept.from().equals(params)) {
            return kept.slowed();
        }
        MediumParams slowed = params.slowedToStable(cellSize, dt);
        cache.put(key, new Stable(params, slowed));
        return slowed;
    }

    /** The medium's numbers with its drift made what pushes it now (see {@link Push}). */
    private static MediumParams withEffectiveDrift(EngineWindow.Kind kind, WindowInputs inputs) {
        MediumParams own = kind.properties().params();
        Draft.Vector push = Push.of(kind.properties(), kind.idHash(), inputs.windX(), inputs.windZ(), inputs.gameTime());
        if (push.x() == own.driftX() && push.z() == own.driftZ()) {
            return own;
        }
        return new MediumParams(own.gravity(), own.dispersion(), own.decay(), own.maxDensity(), push.x(), push.z());
    }

    /** Worked out again only when the window has moved up or down, or the air or the medium's buoyancy has changed. */
    private float[] layerGravity(EngineWindow.Kind kind, AmbientProfile air, GridPlacement placement, MediumParams stable, float dt) {
        LayerGravity kept = layerGravities.get(kind.key());
        if (kept != null && kept.ambient() == air && kept.buoyancy().equals(kind.buoyancy()) && kept.stable().equals(stable)
                && kept.originY() == placement.originY()) {
            return kept.gravity();
        }
        float[] gravity = kind.buoyancy().layerGravity(air, placement, size.y(), stable, dt);
        layerGravities.put(kind.key(), new LayerGravity(air, kind.buoyancy(), stable, placement.originY(), gravity));
        return gravity;
    }
}
