package dev.syrval.volumetrics.client.render;

import dev.syrval.volumetrics.sim.AtlasLayout;
import dev.syrval.volumetrics.sim.CellBox;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import org.jspecify.annotations.Nullable;

/**
 * What the march needs to know of one level of the cascade on one frame, besides the textures: where the level's
 * fields lie in the shared atlases and in the world. Exactly the inputs of the GasField block's per-level arrays.
 *
 * @param box         where the gas of the newest step is, or the light's place before there is any gas
 * @param lightBox    where the level was when its light was last sent whole
 * @param size        the level's size in cells
 * @param pages       how many pages of the density textures the level holds
 * @param atlas       how the level's Y slices sit as tiles
 * @param column      the texel column the level starts at in the density and the light textures
 * @param brickColumn the texel column the level starts at in the brick texture
 * @param lightRow    the texel row the front copy of the level's light starts at
 * @param blend       how far between its two snapshots the level is shown, 0 to 1; 1 if it is not blended
 * @param newest      which of the two density textures holds the level's newest snapshot
 * @param gasBox      where the gas of the newest step is, null before there is any; what {@code brickBounds} is relative to
 * @param brickBounds the smallest box of cells that holds every brick the march has to walk, null if there is none
 */
public record FieldLevel(GridPlacement box, GridPlacement lightBox, GridSize size, int pages, AtlasLayout atlas, int column,
                         int brickColumn, int lightRow, float blend, int newest, @Nullable GridPlacement gasBox,
                         @Nullable CellBox brickBounds) {}
