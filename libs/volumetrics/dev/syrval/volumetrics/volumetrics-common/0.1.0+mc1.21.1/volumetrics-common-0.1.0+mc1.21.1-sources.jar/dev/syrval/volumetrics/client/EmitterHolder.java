package dev.syrval.volumetrics.client;

import dev.syrval.volumetrics.world.LevelEmitters;
import dev.syrval.volumetrics.world.LevelFogs;

/**
 * What the game's {@code ClientLevel} is once this mod's mixin has been applied to it: something that keeps the
 * emitters and the fogs made from code in that level. They are kept on the level itself, so there is nothing static
 * between another mod and the gas, and they go when the level does.
 */
public interface EmitterHolder {
    LevelEmitters volumetrics$emitters();

    LevelFogs volumetrics$fogs();
}
