package dev.syrval.volumetrics.sim;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Optional;

/**
 * Which bricks of a grid a renderer has to march through, and in which pages of the density textures: it can step
 * straight over the rest, and read only those pages where it cannot. A page holds four kinds of gas, one to each
 * channel of its texels. A brick is marked for a page if a texel of that page in it, or in a cell right next to it, is
 * not zero: a renderer that blends each texel with its neighbours reads gas up to a cell away from where the gas is.
 *
 * <p>Like {@link AtlasLayout} this is also the shape the data takes as a 2D texture, one byte a brick with a bit for
 * each page: brick {@code (x, y, z)} is the texel in column {@code x + y * bricksX}, row {@code z}.
 */
public final class BrickMask {
    /** Pages a mask tells apart: one for each bit of its byte. */
    public static final int MAX_PAGES = 8;
    private static final int BRICK = GridSize.BRICK;
    private static final byte ALL_PAGES = (byte) 0xFF;

    private final GridSize size;
    private final byte[] marks;

    public BrickMask(GridSize size) {
        this.size = size;
        this.marks = new byte[size.brickCount()];
    }

    public int width() {
        return size.bricksX() * size.bricksY();
    }

    public int height() {
        return size.bricksZ();
    }

    public boolean isMarked(int brickX, int brickY, int brickZ) {
        return marks[texel(brickX, brickY, brickZ)] != 0;
    }

    /** The pages marked for a brick, a bit each: bit {@code p} for page {@code p}. */
    public int pages(int brickX, int brickY, int brickZ) {
        return marks[texel(brickX, brickY, brickZ)] & 0xFF;
    }

    /** The smallest box of cells that holds every marked brick, if any is marked. */
    public Optional<CellBox> bounds() {
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxX = -1;
        int maxY = -1;
        int maxZ = -1;
        for (int bz = 0; bz < size.bricksZ(); bz++) {
            for (int by = 0; by < size.bricksY(); by++) {
                for (int bx = 0; bx < size.bricksX(); bx++) {
                    if (marks[texel(bx, by, bz)] != 0) {
                        minX = Math.min(minX, bx);
                        minY = Math.min(minY, by);
                        minZ = Math.min(minZ, bz);
                        maxX = Math.max(maxX, bx);
                        maxY = Math.max(maxY, by);
                        maxZ = Math.max(maxZ, bz);
                    }
                }
            }
        }
        if (maxX < 0) {
            return Optional.empty();
        }
        return Optional.of(new CellBox(minX * BRICK, minY * BRICK, minZ * BRICK,
                (maxX + 1) * BRICK, (maxY + 1) * BRICK, (maxZ + 1) * BRICK));
    }

    public void clear() {
        Arrays.fill(marks, (byte) 0);
    }

    /** Marks every brick for every page. */
    public void markAll() {
        Arrays.fill(marks, ALL_PAGES);
    }

    /**
     * Marks, for one page, the bricks around every cell of one brick that holds gas.
     *
     * @param texels the brick's texels in that page, four bytes a cell, the cells as {@link GasStore#inBrick} counts them
     */
    public void markBrick(byte[] texels, int page, int brickX, int brickY, int brickZ) {
        if (page < 0 || page >= MAX_PAGES) {
            throw new IllegalArgumentException("Page must be 0 to " + (MAX_PAGES - 1) + ", got " + page);
        }
        byte bit = (byte) (1 << page);
        boolean any = false;
        for (int y = 0; y < BRICK; y++) {
            for (int z = 0; z < BRICK; z++) {
                for (int x = 0; x < BRICK; x++) {
                    int at = GasStore.inBrick(x, y, z) * 4;
                    if ((texels[at] | texels[at + 1] | texels[at + 2] | texels[at + 3]) == 0) {
                        continue;
                    }
                    any = true;
                    // A cell inside the brick is only ever read from the brick itself.
                    if (x == 0 || x == BRICK - 1 || y == 0 || y == BRICK - 1 || z == 0 || z == BRICK - 1) {
                        markAround(brickX * BRICK + x, brickY * BRICK + y, brickZ * BRICK + z, bit);
                    }
                }
            }
        }
        if (any) {
            marks[texel(brickX, brickY, brickZ)] |= bit;
        }
    }

    /** Makes this a copy of another mask of the same grid. */
    public void set(BrickMask other) {
        System.arraycopy(other.marks, 0, marks, 0, marks.length);
    }

    /** Marks every brick the other mask has marked as well, for the same pages. */
    public void include(BrickMask other) {
        for (int i = 0; i < marks.length; i++) {
            marks[i] |= other.marks[i];
        }
    }

    /** Writes the texture, row by row, to the start of a buffer. */
    public void put(ByteBuffer out) {
        out.put(0, marks);
    }

    private void markAround(int x, int y, int z, byte bit) {
        int highX = Math.min(x + 1, size.x() - 1) / BRICK;
        int highY = Math.min(y + 1, size.y() - 1) / BRICK;
        int highZ = Math.min(z + 1, size.z() - 1) / BRICK;
        for (int bz = Math.max(z - 1, 0) / BRICK; bz <= highZ; bz++) {
            for (int by = Math.max(y - 1, 0) / BRICK; by <= highY; by++) {
                for (int bx = Math.max(x - 1, 0) / BRICK; bx <= highX; bx++) {
                    marks[texel(bx, by, bz)] |= bit;
                }
            }
        }
    }

    private int texel(int brickX, int brickY, int brickZ) {
        return brickX + size.bricksX() * (brickY + size.bricksY() * brickZ);
    }
}
