package dev.syrval.volumetrics.sim;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Optional;

/**
 * Which bricks of a grid a renderer has to march through; it can step straight over the rest. A brick is marked
 * if a density texel in it, or in a cell right next to it, is not zero: a renderer that blends each texel with
 * its neighbours reads gas up to a cell away from where the gas is.
 *
 * <p>Like {@link AtlasLayout} this is also the shape the data takes as a 2D texture, one byte a brick: brick
 * {@code (x, y, z)} is the texel in column {@code x + y * bricksX}, row {@code z}.
 */
public final class BrickMask {
    private static final byte MARKED = (byte) 0xFF;

    private final GridSize size;
    private final byte[] marks;

    public BrickMask(GridSize size) {
        this.size = size;
        this.marks = new byte[size.brickCount()];
    }

    public int width() {
        return size.bricksX() * size.bricksY();
    }

    public int height() {
        return size.bricksZ();
    }

    public boolean isMarked(int brickX, int brickY, int brickZ) {
        return marks[texel(brickX, brickY, brickZ)] != 0;
    }

    /** The smallest box of cells that holds every marked brick, if any is marked. */
    public Optional<CellBox> bounds() {
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxX = -1;
        int maxY = -1;
        int maxZ = -1;
        for (int bz = 0; bz < size.bricksZ(); bz++) {
            for (int by = 0; by < size.bricksY(); by++) {
                for (int bx = 0; bx < size.bricksX(); bx++) {
                    if (marks[texel(bx, by, bz)] != 0) {
                        minX = Math.min(minX, bx);
                        minY = Math.min(minY, by);
                        minZ = Math.min(minZ, bz);
                        maxX = Math.max(maxX, bx);
                        maxY = Math.max(maxY, by);
                        maxZ = Math.max(maxZ, bz);
                    }
                }
            }
        }
        if (maxX < 0) {
            return Optional.empty();
        }
        return Optional.of(new CellBox(minX * GridSize.BRICK, minY * GridSize.BRICK, minZ * GridSize.BRICK,
                (maxX + 1) * GridSize.BRICK, (maxY + 1) * GridSize.BRICK, (maxZ + 1) * GridSize.BRICK));
    }

    public void clear() {
        Arrays.fill(marks, (byte) 0);
    }

    public void markAll() {
        Arrays.fill(marks, MARKED);
    }

    /**
     * Marks the bricks around every cell of one brick that holds gas.
     *
     * @param texels the whole grid as density texels, four bytes a cell in index order
     */
    public void markBrick(ByteBuffer texels, int brickX, int brickY, int brickZ) {
        for (int y = brickY * GridSize.BRICK; y < (brickY + 1) * GridSize.BRICK; y++) {
            for (int z = brickZ * GridSize.BRICK; z < (brickZ + 1) * GridSize.BRICK; z++) {
                for (int x = brickX * GridSize.BRICK; x < (brickX + 1) * GridSize.BRICK; x++) {
                    if (texels.getInt(size.index(x, y, z) * Integer.BYTES) != 0) {
                        markAround(x, y, z);
                    }
                }
            }
        }
    }

    /** Makes this a copy of another mask of the same grid. */
    public void set(BrickMask other) {
        System.arraycopy(other.marks, 0, marks, 0, marks.length);
    }

    /** Marks every brick the other mask has marked as well. */
    public void include(BrickMask other) {
        for (int i = 0; i < marks.length; i++) {
            marks[i] |= other.marks[i];
        }
    }

    /** Writes the texture, row by row, to the start of a buffer. */
    public void put(ByteBuffer out) {
        out.put(0, marks);
    }

    private void markAround(int x, int y, int z) {
        int highX = Math.min(x + 1, size.x() - 1) / GridSize.BRICK;
        int highY = Math.min(y + 1, size.y() - 1) / GridSize.BRICK;
        int highZ = Math.min(z + 1, size.z() - 1) / GridSize.BRICK;
        for (int bz = Math.max(z - 1, 0) / GridSize.BRICK; bz <= highZ; bz++) {
            for (int by = Math.max(y - 1, 0) / GridSize.BRICK; by <= highY; by++) {
                for (int bx = Math.max(x - 1, 0) / GridSize.BRICK; bx <= highX; bx++) {
                    marks[texel(bx, by, bz)] = MARKED;
                }
            }
        }
    }

    private int texel(int brickX, int brickY, int brickZ) {
        return brickX + size.bricksX() * (brickY + size.bricksY() * brickZ);
    }
}
