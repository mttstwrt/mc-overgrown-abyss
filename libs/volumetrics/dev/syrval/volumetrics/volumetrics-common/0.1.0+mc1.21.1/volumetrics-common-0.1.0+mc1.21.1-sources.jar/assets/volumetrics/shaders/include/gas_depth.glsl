#ifndef VOLUMETRICS_GAS_DEPTH_GLSL
#define VOLUMETRICS_GAS_DEPTH_GLSL

#include <volumetrics:gas_game.glsl>

// Distance along the view axis for a depth-buffer value. Depth here runs from 0 at the nearest to 1 at the
// furthest, which is also what the sky is cleared to, and stands for -1 to 1 in clip space.
float gasViewDistance(float depth) {
    return ProjMat[3][2] / min(depth * 2.0 - 1.0 + ProjMat[2][2], -1.0e-7);
}

// How far apart two view distances are, as a share of the nearer one.
float gasDepthGap(float a, float b) {
    return abs(a - b) / min(a, b);
}

#endif
