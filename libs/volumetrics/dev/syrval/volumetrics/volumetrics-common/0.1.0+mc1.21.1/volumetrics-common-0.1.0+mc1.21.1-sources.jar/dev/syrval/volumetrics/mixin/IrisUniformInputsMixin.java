package dev.syrval.volumetrics.mixin;

import dev.syrval.volumetrics.client.render.FarTerrainDepth;
import java.util.function.Supplier;
import org.joml.Matrix4fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Sees each matrix uniform a shader pack's pipeline is given, by name, with what sets it: Iris gathers the uniforms
 * every program shares here, once for each pipeline, the ones other mods add among them. Applied only when Iris is
 * installed, like {@link IrisProgramSamplersMixin}.
 */
@Pseudo
@Mixin(targets = "net.irisshaders.iris.uniforms.custom.CustomUniformFixedInputUniformsHolder$Builder", remap = false)
abstract class IrisUniformInputsMixin {
    @Inject(method = "uniformMatrix(Lnet/irisshaders/iris/gl/uniform/UniformUpdateFrequency;Ljava/lang/String;Ljava/util/function/Supplier;)Lnet/irisshaders/iris/gl/uniform/UniformHolder;",
            at = @At("HEAD"), require = 0, remap = false)
    private void volumetrics$matrixAdded(@Coerce Object frequency, String name, Supplier<Matrix4fc> value,
                                         CallbackInfoReturnable<Object> info) {
        FarTerrainDepth.matrixUniformAdded(name, value);
    }
}
