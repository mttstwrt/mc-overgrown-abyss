package dev.syrval.volumetrics.sim;

import java.util.List;

/**
 * Everything an engine steps in one window for one step. The caller builds it again each step; the stores and the
 * workspace are the same objects from step to step.
 *
 * @param placement        where the window is
 * @param occupancy        what blocks the gas in it
 * @param workspace        a field of the window's size to step in, which the engine may use for every kind in turn
 * @param coarserPlacement where the next coarser window is, null if there is none
 * @param kinds            the kinds of gas to step, each with the store it is kept in
 */
public record EngineWindow(GridPlacement placement, Occupancy occupancy, GasField workspace,
                           GridPlacement coarserPlacement, List<Kind> kinds) {
    /**
     * One kind of gas.
     *
     * @param key      what the kind is known by between steps, equal for the same medium
     * @param properties the medium's own numbers, not yet slowed to what the window's cells carry
     * @param idHash   a number that is the same on every machine for this medium, for its draft
     * @param floats   whether it floats in the air instead of having a gravity of its own
     * @param buoyancy how it floats, if it does and the air is known, else null
     * @param sources  what feeds it in this window
     * @param store    where its gas is kept between steps
     * @param coarser  the same kind's store in the next coarser window, or null
     */
    public record Kind(Object key, MediumProperties properties, int idHash, boolean floats, Buoyancy buoyancy, List<Source> sources,
                       GasStore store, GasStore coarser) {}
}
