package dev.syrval.volumetrics.world;

import java.util.Arrays;
import java.util.Locale;

/**
 * Instrumentation: how long the library holds the client main thread, per frame, by category. Main thread only.
 * Nanos add up during a frame, and {@link #endFrame} files them as microseconds and zeroes them.
 */
public final class MainThreadTime {
    public enum Category { WORLD, STEP, TAKE, LIGHT, DRAW }

    private static final int CATEGORIES = Category.values().length;
    private static final int TOTAL = CATEGORIES;
    private static final int FRAMES = 16384;
    private static final long[] LIMITS_MICROS = {500, 1000, 2000};

    private static final long[] frameNanos = new long[CATEGORIES];
    private static final int[][] ring = new int[CATEGORIES + 1][FRAMES];
    private static final int[] sortBuffer = new int[FRAMES];
    private static int recorded;
    private static int next;
    private static long framesSinceReset;
    private static final long[] sum = new long[CATEGORIES + 1];
    private static final int[] over = new int[LIMITS_MICROS.length];
    private static long scanSections;
    private static long scanNanos;
    private static int windowMoves;

    private MainThreadTime() {
    }

    public static void add(Category category, long nanos) {
        frameNanos[category.ordinal()] += nanos;
    }

    public static long get(Category category) {
        return frameNanos[category.ordinal()];
    }

    /** Chunk sections the scan thread has scanned, and its time for them, as the main thread last took them from it. */
    public static void addScan(long sections, long nanos) {
        scanSections += sections;
        scanNanos += nanos;
    }

    public static void countWindowMove() {
        windowMoves++;
    }

    /** Files the frame's values; returns its total in microseconds. */
    public static int endFrame() {
        int total = 0;
        for (int category = 0; category < CATEGORIES; category++) {
            int micros = (int) Math.min(Integer.MAX_VALUE, frameNanos[category] / 1000);
            ring[category][next] = micros;
            sum[category] += micros;
            total += micros;
            frameNanos[category] = 0;
        }
        ring[TOTAL][next] = total;
        sum[TOTAL] += total;
        next = (next + 1) % FRAMES;
        recorded = Math.min(recorded + 1, FRAMES);
        framesSinceReset++;
        for (int i = 0; i < LIMITS_MICROS.length; i++) {
            if (total > LIMITS_MICROS[i]) {
                over[i]++;
            }
        }
        return total;
    }

    /** The microseconds of the last filed frame, for one category. */
    public static int lastFrameMicros(Category category) {
        return ring[category.ordinal()][(next + FRAMES - 1) % FRAMES];
    }

    /** The lines for /volumetrics stats; resets the statistics. */
    public static String reportAndReset() {
        StringBuilder out = new StringBuilder();
        out.append(String.format(Locale.ROOT, "main thread per frame (us, %d frames): total mean/p50/p99/p99.9/max %s; >0.5ms %d, >1ms %d, >2ms %d",
                framesSinceReset, summary(TOTAL), over[0], over[1], over[2]));
        for (Category category : Category.values()) {
            out.append(String.format(Locale.ROOT, "\n%s %s", category.name().toLowerCase(Locale.ROOT), summary(category.ordinal())));
        }
        out.append(String.format(Locale.ROOT, "\nscan: %d sections, %.1f us each; window moves %d", scanSections,
                scanSections == 0 ? 0.0 : scanNanos / 1000.0 / scanSections, windowMoves));
        reset();
        return out.toString();
    }

    private static String summary(int index) {
        if (recorded == 0) {
            return "0/0/0/0/0";
        }
        System.arraycopy(ring[index], 0, sortBuffer, 0, recorded);
        Arrays.sort(sortBuffer, 0, recorded);
        long mean = framesSinceReset == 0 ? 0 : sum[index] / framesSinceReset;
        return mean + "/" + sortBuffer[percentile(0.5)] + "/" + sortBuffer[percentile(0.99)] + "/"
                + sortBuffer[percentile(0.999)] + "/" + sortBuffer[recorded - 1];
    }

    private static int percentile(double fraction) {
        return Math.min(recorded - 1, (int) Math.ceil(fraction * recorded) - 1 < 0 ? 0 : (int) Math.ceil(fraction * recorded) - 1);
    }

    private static void reset() {
        recorded = 0;
        next = 0;
        framesSinceReset = 0;
        Arrays.fill(sum, 0);
        Arrays.fill(over, 0);
        scanSections = 0;
        scanNanos = 0;
        windowMoves = 0;
    }
}
