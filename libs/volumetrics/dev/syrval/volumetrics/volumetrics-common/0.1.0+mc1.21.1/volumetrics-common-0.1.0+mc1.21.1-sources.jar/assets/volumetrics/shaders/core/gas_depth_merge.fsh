#include <volumetrics:gas_game.glsl>

// The level's depth as the game or a shader pack left it: 0 at the nearest, 1 where there is sky.
uniform sampler2D DepthSampler;
// The depth of the terrain Voxy draws past the render distance, in Voxy's own projection, which a shader pack keeps
// apart from the level's.
uniform sampler2D FarDepthSampler;

// GasRenderer fills this block each frame there is far terrain.
layout(std140) uniform GasFarDepth {
    // From the far terrain's depth, as normalized device coordinates, to view space.
    mat4 FarInverseProjection;
};

in vec2 texCoord;

out vec4 fragColor;

// The furthest the far terrain past the game's far plane can be put: just short of the game's sky.
const float SHORT_OF_SKY = 0.99998;

// The level's depth with the far terrain in it, in the game's own projection, so the gas passes read it as they read
// the game's. The far terrain shows only where the game drew sky, so only there does it count.
void main() {
    float depth = textureLod(DepthSampler, texCoord, 0.0).r;
    // The level fills ContentScale of the depth texture, and the far terrain all of its own.
    vec2 screen = texCoord / ContentScale;
    float far = depth < 1.0 || any(greaterThan(screen, vec2(1.0))) ? 1.0 : textureLod(FarDepthSampler, screen, 0.0).r;
    if (far >= 1.0) {
        fragColor = vec4(depth, 0.0, 0.0, 1.0);
        return;
    }
    vec4 view = FarInverseProjection * vec4(screen * 2.0 - 1.0, far * 2.0 - 1.0, 1.0);
    vec4 clip = ProjMat * vec4(view.xyz / view.w, 1.0);
    fragColor = vec4(min(clip.z / clip.w * 0.5 + 0.5, SHORT_OF_SKY), 0.0, 0.0, 1.0);
}
