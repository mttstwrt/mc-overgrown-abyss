package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.api.EmitterShape;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.api.client.GasEmitters;
import dev.syrval.volumetrics.sim.Source;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Queue;
import java.util.Set;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * The emitters made from code in one level; {@link GasEmitters} is what other mods see of it. Client thread only.
 * Every change is also put, in order, on the queue of the {@link GasWorld} attached, if there is one, for the
 * simulation thread to apply.
 */
public final class LevelEmitters implements GasEmitters {
    // A set, in the order they were made: a mod may remove thousands at once, and each removal finds its own.
    private final Set<Placed> placed = new LinkedHashSet<>();
    private long nextId;
    private @Nullable Queue<EmitterOp> listener;

    /** Starts sending changes to {@code ops}, after a put for each emitter there is now; replaces any other. */
    void attach(Queue<EmitterOp> ops) {
        for (Placed emitter : placed) {
            ops.add(new EmitterOp.Put(emitter.id, emitter.current));
        }
        listener = ops;
    }

    /** Stops sending changes to {@code ops}, if they are still going there. */
    void detach(Queue<EmitterOp> ops) {
        if (listener == ops) {
            listener = null;
        }
    }

    @Override
    public Handle add(Medium medium, EmitterShape shape, Vec3 anchor, float rate) {
        Placed emitter = new Placed(nextId++, Objects.requireNonNull(medium, "medium"),
                Objects.requireNonNull(shape, "shape"), Objects.requireNonNull(anchor, "anchor"), rate);
        placed.add(emitter);
        put(emitter);
        return emitter;
    }

    private void put(Placed emitter) {
        if (listener != null) {
            listener.add(new EmitterOp.Put(emitter.id, emitter.current));
        }
    }

    private final class Placed implements Handle {
        private final long id;
        private final Medium medium;
        private final EmitterShape shape;
        private Vec3 anchor;
        private float rate;
        /** What the simulation is handed: replaced, never changed, since the simulation reads it on its own thread. */
        private Emitter current;
        private boolean removed;

        Placed(long id, Medium medium, EmitterShape shape, Vec3 anchor, float rate) {
            this.id = id;
            this.medium = medium;
            this.shape = shape;
            this.anchor = anchor;
            this.rate = rate;
            this.current = emitter(anchor, rate);
        }

        @Override
        public void moveTo(Vec3 anchor) {
            this.current = emitter(Objects.requireNonNull(anchor, "anchor"), rate);
            this.anchor = anchor;
            if (!removed) {
                put(this);
            }
        }

        @Override
        public void setRate(float rate) {
            this.current = emitter(anchor, rate);
            this.rate = rate;
            if (!removed) {
                put(this);
            }
        }

        @Override
        public void remove() {
            if (removed) {
                return;
            }
            removed = true;
            placed.remove(this);
            if (listener != null) {
                listener.add(new EmitterOp.Remove(id));
            }
        }

        private Emitter emitter(Vec3 anchor, float rate) {
            return new Emitter(medium, new Source(shape.at(anchor), rate));
        }
    }
}
