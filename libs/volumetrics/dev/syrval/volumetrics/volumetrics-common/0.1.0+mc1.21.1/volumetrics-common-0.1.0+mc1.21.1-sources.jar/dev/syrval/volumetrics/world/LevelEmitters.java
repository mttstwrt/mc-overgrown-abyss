package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.api.EmitterShape;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.api.client.GasEmitters;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.sim.Source;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import net.minecraft.world.phys.Vec3;

/** The emitters made from code in one level; {@link GasEmitters} is what other mods see of it. Client thread only. */
public final class LevelEmitters implements GasEmitters {
    // A set, in the order they were made: a mod may remove thousands at once, and each removal finds its own.
    private final Set<Placed> placed = new LinkedHashSet<>();

    @Override
    public Handle add(Medium medium, EmitterShape shape, Vec3 anchor, float rate) {
        Placed emitter = new Placed(Objects.requireNonNull(medium, "medium"), Objects.requireNonNull(shape, "shape"),
                Objects.requireNonNull(anchor, "anchor"), rate);
        placed.add(emitter);
        return emitter;
    }

    /**
     * The emitters whose shapes a window of {@code size} cells at {@code placement} reaches, in a new list the
     * caller may add to. One beyond the window would feed nothing there, and would still keep its gas one of the
     * few kinds a window holds at once.
     */
    List<Emitter> reaching(GridPlacement placement, GridSize size) {
        List<Emitter> reaching = new ArrayList<>();
        for (Placed emitter : placed) {
            if (placement.reaches(size, emitter.current.source().shape())) {
                reaching.add(emitter.current);
            }
        }
        return reaching;
    }

    private final class Placed implements Handle {
        private final Medium medium;
        private final EmitterShape shape;
        private Vec3 anchor;
        private float rate;
        /** What the simulation is handed: replaced, never changed, since the simulation reads it on its own thread. */
        private Emitter current;

        Placed(Medium medium, EmitterShape shape, Vec3 anchor, float rate) {
            this.medium = medium;
            this.shape = shape;
            this.anchor = anchor;
            this.rate = rate;
            this.current = emitter(anchor, rate);
        }

        @Override
        public void moveTo(Vec3 anchor) {
            this.current = emitter(Objects.requireNonNull(anchor, "anchor"), rate);
            this.anchor = anchor;
        }

        @Override
        public void setRate(float rate) {
            this.current = emitter(anchor, rate);
            this.rate = rate;
        }

        @Override
        public void remove() {
            placed.remove(this);
        }

        private Emitter emitter(Vec3 anchor, float rate) {
            return new Emitter(medium, new Source(shape.at(anchor), rate));
        }
    }
}
