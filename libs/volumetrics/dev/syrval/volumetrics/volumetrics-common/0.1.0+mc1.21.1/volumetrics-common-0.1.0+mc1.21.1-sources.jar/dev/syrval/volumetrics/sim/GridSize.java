package dev.syrval.volumetrics.sim;

/** Size of the simulated window in cells. Each axis is a whole number of bricks. */
public record GridSize(int x, int y, int z) {
    /** Edge of a brick in cells. The stepper skips bricks that hold no gas, so a brick is its unit of work. */
    public static final int BRICK = 8;

    public GridSize {
        requireBricks(x, "x");
        requireBricks(y, "y");
        requireBricks(z, "z");
    }

    public int cells() {
        return x * y * z;
    }

    /** Y is the slowest axis, so one Y level is one contiguous slice: a tile of the density atlas. */
    public int index(int cellX, int cellY, int cellZ) {
        return cellX + x * (cellZ + z * cellY);
    }

    public boolean contains(int cellX, int cellY, int cellZ) {
        return cellX >= 0 && cellX < x && cellY >= 0 && cellY < y && cellZ >= 0 && cellZ < z;
    }

    public int bricksX() {
        return x / BRICK;
    }

    public int bricksY() {
        return y / BRICK;
    }

    public int bricksZ() {
        return z / BRICK;
    }

    public int brickCount() {
        return bricksX() * bricksY() * bricksZ();
    }

    /** Bricks are numbered as cells are: X fastest, then Z, then Y. */
    public int brickIndex(int brickX, int brickY, int brickZ) {
        return brickX + bricksX() * (brickZ + bricksZ() * brickY);
    }

    int brickOfCell(int cellX, int cellY, int cellZ) {
        return brickIndex(cellX / BRICK, cellY / BRICK, cellZ / BRICK);
    }

    /** The brick of the cell at an index as {@link #index} gives it. */
    int brickOfIndex(int cell) {
        return brickOfCell(cell % x, cell / (x * z), cell / x % z);
    }

    private static void requireBricks(int cells, String axis) {
        if (cells <= 0 || cells % BRICK != 0) {
            throw new IllegalArgumentException("Grid " + axis + " must be a positive multiple of " + BRICK + ", got " + cells);
        }
    }
}
