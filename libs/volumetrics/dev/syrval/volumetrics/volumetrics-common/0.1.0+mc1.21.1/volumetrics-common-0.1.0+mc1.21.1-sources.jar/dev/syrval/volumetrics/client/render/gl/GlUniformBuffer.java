package dev.syrval.volumetrics.client.render.gl;

import com.mojang.blaze3d.platform.GlStateManager;
import java.nio.ByteBuffer;
import java.util.function.Consumer;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL31;

/** The memory of one uniform block: written on the CPU each frame and sent whole. */
public final class GlUniformBuffer implements AutoCloseable {
    private final int id = GlStateManager._glGenBuffers();
    private final ByteBuffer data;

    /** @param bytes the size of the block, as the program that declares it reports it */
    public GlUniformBuffer(int bytes) {
        this.data = ByteBuffer.allocateDirect(bytes);
    }

    /**
     * Fills the buffer through a writer and sends it.
     *
     * @throws IllegalStateException if what was written is not the size of the block: the shader's declaration
     *                               and the code that fills it have come apart
     */
    public void write(Consumer<Std140Writer> fields) {
        Std140Writer writer = new Std140Writer(data);
        fields.accept(writer);
        if (writer.blockBytes() != data.capacity()) {
            throw new IllegalStateException("A uniform block of " + data.capacity() + " bytes was given " + writer.blockBytes());
        }
        data.clear();
        GlStateManager._glBindBuffer(GL31.GL_UNIFORM_BUFFER, id);
        // A new store each frame, so the driver need not wait for the frame still using the old one.
        GlStateManager._glBufferData(GL31.GL_UNIFORM_BUFFER, data, GL15.GL_STREAM_DRAW);
        GlStateManager._glBindBuffer(GL31.GL_UNIFORM_BUFFER, 0);
    }

    int id() {
        return id;
    }

    @Override
    public void close() {
        GlStateManager._glDeleteBuffers(id);
    }
}
