package dev.syrval.volumetrics;

import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import org.slf4j.Logger;

public final class Volumetrics {
    public static final String MOD_ID = "volumetrics";
    public static final Logger LOGGER = LogUtils.getLogger();

    private Volumetrics() {}

    /** Called once by each loader entrypoint, on both sides. */
    public static void init() {
        LOGGER.info("Volumetrics initialised");
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }
}
