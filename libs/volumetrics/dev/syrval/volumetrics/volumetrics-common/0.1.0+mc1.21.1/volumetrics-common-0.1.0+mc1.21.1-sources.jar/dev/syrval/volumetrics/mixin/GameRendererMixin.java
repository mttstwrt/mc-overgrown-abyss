package dev.syrval.volumetrics.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.syrval.volumetrics.client.AfterLevelSource;
import dev.syrval.volumetrics.client.LevelView;
import java.util.function.Consumer;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import org.joml.Matrix4f;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Tells the mod when the level has been drawn: right after {@code LevelRenderer.renderLevel} returns, with
 * everything of the level in the main target, and before the main depth is cleared for the hand. NeoForge has an
 * event at this very place and Fabric's nearest one is earlier, inside the level's own drawing. That is not the
 * same under a shader pack: Iris writes the pack's finished picture over the main target as that method
 * returns, so gas drawn any earlier would be lost. The main depth is the level's there too, with or without a
 * pack. One place for both loaders, so that the gas is drawn at the same moment whatever the loader.
 *
 * <p>The call is wrapped, not followed, because its arguments are needed: see {@link LevelView}.
 */
@Mixin(GameRenderer.class)
abstract class GameRendererMixin implements AfterLevelSource {
    @Unique
    private @Nullable Consumer<LevelView> volumetrics$afterLevel;

    @Override
    public void volumetrics$afterLevel(@Nullable Consumer<LevelView> listener) {
        this.volumetrics$afterLevel = listener;
    }

    @WrapOperation(method = "renderLevel(Lnet/minecraft/client/DeltaTracker;)V", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/LevelRenderer;renderLevel(Lnet/minecraft/client/DeltaTracker;ZLnet/minecraft/client/Camera;Lnet/minecraft/client/renderer/GameRenderer;Lnet/minecraft/client/renderer/LightTexture;Lorg/joml/Matrix4f;Lorg/joml/Matrix4f;)V"))
    private void volumetrics$levelDrawn(LevelRenderer levelRenderer, DeltaTracker deltaTracker, boolean renderBlockOutline,
                                        Camera camera, GameRenderer gameRenderer, LightTexture lightTexture,
                                        Matrix4f viewRotation, Matrix4f projection, Operation<Void> original) {
        original.call(levelRenderer, deltaTracker, renderBlockOutline, camera, gameRenderer, lightTexture, viewRotation, projection);
        if (volumetrics$afterLevel != null) {
            // The same partial tick the game drew the level with.
            volumetrics$afterLevel.accept(new LevelView(camera, viewRotation, projection, deltaTracker.getGameTimeDeltaPartialTick(true)));
        }
    }
}
