package dev.syrval.volumetrics.api;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.sim.SourceShape;
import net.minecraft.world.phys.Vec3;

/** The region an emitter fills with gas, relative to the point it is anchored to. */
public sealed interface EmitterShape {
    Codec<EmitterShape> CODEC = Codec.STRING.dispatch("type", EmitterShape::type, EmitterShape::codecFor);

    String type();

    /** The shape in the world, standing on or centred at the anchor as its kind says. */
    SourceShape at(Vec3 anchor);

    /** An upright disc standing on the anchor: the usual shape for gas lying on or rising off a surface. */
    record Disc(float radius, float height) implements EmitterShape {
        static final MapCodec<Disc> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                Codec.floatRange(0.05f, 128f).fieldOf("radius").forGetter(Disc::radius),
                Codec.floatRange(0.05f, 128f).optionalFieldOf("height", 1f).forGetter(Disc::height)
        ).apply(instance, Disc::new));

        @Override
        public String type() {
            return "volumetrics:disc";
        }

        @Override
        public SourceShape at(Vec3 anchor) {
            return new SourceShape.Cylinder(anchor.x, anchor.y, anchor.z, radius, height);
        }
    }

    /** A ball centred on the anchor. */
    record Sphere(float radius) implements EmitterShape {
        static final MapCodec<Sphere> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                Codec.floatRange(0.05f, 128f).fieldOf("radius").forGetter(Sphere::radius)
        ).apply(instance, Sphere::new));

        @Override
        public String type() {
            return "volumetrics:sphere";
        }

        @Override
        public SourceShape at(Vec3 anchor) {
            return new SourceShape.Sphere(anchor.x, anchor.y, anchor.z, radius);
        }
    }

    /** A box standing on the anchor, centred on it sideways. */
    record Box(float width, float height, float depth) implements EmitterShape {
        static final MapCodec<Box> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                Codec.floatRange(0.05f, 256f).fieldOf("width").forGetter(Box::width),
                Codec.floatRange(0.05f, 256f).fieldOf("height").forGetter(Box::height),
                Codec.floatRange(0.05f, 256f).fieldOf("depth").forGetter(Box::depth)
        ).apply(instance, Box::new));

        @Override
        public String type() {
            return "volumetrics:box";
        }

        @Override
        public SourceShape at(Vec3 anchor) {
            return new SourceShape.Box(anchor.x - width / 2, anchor.y, anchor.z - depth / 2,
                    anchor.x + width / 2, anchor.y + height, anchor.z + depth / 2);
        }
    }

    private static MapCodec<? extends EmitterShape> codecFor(String type) {
        return switch (type) {
            case "volumetrics:disc" -> Disc.CODEC;
            case "volumetrics:sphere" -> Sphere.CODEC;
            case "volumetrics:box" -> Box.CODEC;
            default -> MapCodec.unit(() -> {
                throw new IllegalArgumentException("Unknown emitter shape " + type);
            });
        };
    }
}
