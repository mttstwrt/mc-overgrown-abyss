package dev.syrval.volumetrics.sim;

/** The density of one gas in every cell of a window, to be read: by a finer window taking its edge from it, say. */
public interface GasDensities {
    GridSize size();

    float density(int cellX, int cellY, int cellZ);

    /** Whether a brick may hold gas; false means every cell of it is certainly empty. */
    boolean brickHasGas(int brickX, int brickY, int brickZ);
}
