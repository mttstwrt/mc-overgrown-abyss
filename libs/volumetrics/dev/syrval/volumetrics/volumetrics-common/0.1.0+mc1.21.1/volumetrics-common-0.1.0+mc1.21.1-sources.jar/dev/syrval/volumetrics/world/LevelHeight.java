package dev.syrval.volumetrics.world;

import net.minecraft.world.level.Level;

/** The heights a level's blocks lie between; the one place that names them, since their names change between versions. */
final class LevelHeight {
    private LevelHeight() {}

    /** The lowest block of the level. */
    static int bottom(Level level) {
        return level.getMinBuildHeight();
    }

    /** One above the highest block of the level. */
    static int top(Level level) {
        return level.getMaxBuildHeight();
    }
}
