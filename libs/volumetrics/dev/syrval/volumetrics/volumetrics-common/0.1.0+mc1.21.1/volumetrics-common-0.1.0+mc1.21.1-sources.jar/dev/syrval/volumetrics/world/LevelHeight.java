package dev.syrval.volumetrics.world;

import net.minecraft.world.level.Level;

/** The heights a level's blocks lie between; the one place that names them, since their names change between versions. */
public final class LevelHeight {
    private LevelHeight() {}

    /** The lowest block of the level. */
    public static int bottom(Level level) {
        //? if >=26.1 {
        /*return level.getMinY();
        *///?} else {
        return level.getMinBuildHeight();
        //?}
    }

    /** One above the highest block of the level. */
    public static int top(Level level) {
        //? if >=26.1 {
        /*return level.getMinY() + level.getHeight();
        *///?} else {
        return level.getMaxBuildHeight();
        //?}
    }
}
