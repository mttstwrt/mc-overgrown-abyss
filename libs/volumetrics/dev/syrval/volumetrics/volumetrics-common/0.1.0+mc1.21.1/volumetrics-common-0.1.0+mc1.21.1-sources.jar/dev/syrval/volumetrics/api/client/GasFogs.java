package dev.syrval.volumetrics.api.client;

import dev.syrval.volumetrics.api.Fog;
import dev.syrval.volumetrics.client.EmitterHolder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;

/**
 * Fogs a mod puts in one client level from its own code (see {@link Fog}). Like {@link GasEmitters} they exist on
 * this client only and go with the level; a mod that wants every player to see the same fog makes it on each client.
 * They are kept while the player has gas turned off, and drawn again when it is back on.
 *
 * <p>The fogs nearest the camera are drawn, up to sixteen of them at once, of those that reach within the game's
 * render distance. A fog costs nothing where no ray from the camera passes through it.
 *
 * <p>For the client thread only, as is every method of a {@link Handle}. Never touch this from code that also runs
 * on a dedicated server.
 */
public interface GasFogs {
    /**
     * The fogs of a level.
     *
     * @throws IllegalStateException off the client thread
     */
    static GasFogs of(ClientLevel level) {
        if (!Minecraft.getInstance().isSameThread()) {
            throw new IllegalStateException("Gas fogs are for the client thread only");
        }
        return ((EmitterHolder) level).volumetrics$fogs();
    }

    Handle add(Fog fog);

    /** One fog, for as long as it is wanted. */
    interface Handle {
        /** Makes the fog another, from the next frame on: thicker, moved, of another look. */
        void set(Fog fog);

        /** Takes the fog away for good. Harmless a second time; setting it afterwards does nothing. */
        void remove();
    }
}
