#include <volumetrics:gas_depth.glsl>

// The gas, at a fraction of the resolution of the screen.
uniform sampler2D GasSampler;
uniform sampler2D DepthSampler;

in vec2 texCoord;

out vec4 fragColor;

// The pipeline defines:
//   SHOW_EDGES  1 to paint the pixels that took the gas of the texel nearest in depth opaque magenta, and the ones
//               that needed the wider search cyan
#ifndef SHOW_EDGES
#define SHOW_EDGES 0
#endif

// How far apart in depth, as a share of the nearer, a gas texel and this pixel may be for the texel to stand in
// for the pixel's own march: the same scene surface, give or take a slope.
#define EDGE_GAP 0.1

void main() {
    // One blended read of the gas texels around this pixel: where they are all empty there is nothing to add.
    if (textureLod(GasSampler, texCoord, 0.0).a <= 0.0) {
        discard;
    }

    ivec2 gasSize = textureSize(GasSampler, 0);
    vec2 position = texCoord * vec2(gasSize) - 0.5;
    ivec2 corner = ivec2(floor(position));
    vec2 blend = position - vec2(corner);
    float here = gasViewDistance(textureLod(DepthSampler, (texCoord) * ContentScale, 0.0).r);

    // Plain stretching would smear gas across the outline of anything in front of it. Each of the four gas
    // texels around this pixel counts for less the more the depth it was marched against differs from this
    // pixel's own.
    vec4 total = vec4(0.0);
    float weights = 0.0;
    float nearestGap = 1.0e9;
    for (int i = 0; i < 4; i++) {
        ivec2 offset = ivec2(i & 1, i >> 1);
        ivec2 texel = clamp(corner + offset, ivec2(0), gasSize - 1);
        float there = gasViewDistance(textureLod(DepthSampler, ((vec2(texel) + 0.5) / vec2(gasSize)) * ContentScale, 0.0).r);
        float gap = gasDepthGap(there, here);
        float near = mix(1.0 - blend.x, blend.x, float(offset.x)) * mix(1.0 - blend.y, blend.y, float(offset.y));
        float weight = (near + 0.01) / (0.02 + gap);
        total += texelFetch(GasSampler, texel, 0) * weight;
        weights += weight;
        nearestGap = min(nearestGap, gap);
    }
    // Most pixels are inside a surface, or so close to its outline that one of the four is on the same one.
    if (nearestGap <= EDGE_GAP) {
        fragColor = total / weights;
        return;
    }

    // All four were marched against something else: this pixel is at an outline and, with the gas texels this
    // coarse, the texels that match it may be a little further off. Look at the sixteen around it and take just
    // those, the nearer the more.
    total = vec4(0.0);
    weights = 0.0;
    vec4 nearest = vec4(0.0);
    nearestGap = 1.0e9;
    for (int i = 0; i < 16; i++) {
        ivec2 texel = clamp(corner + ivec2(i & 3, i >> 2) - 1, ivec2(0), gasSize - 1);
        float there = gasViewDistance(textureLod(DepthSampler, ((vec2(texel) + 0.5) / vec2(gasSize)) * ContentScale, 0.0).r);
        float gap = gasDepthGap(there, here);
        vec4 gas = texelFetch(GasSampler, texel, 0);
        if (gap < nearestGap) {
            nearestGap = gap;
            nearest = gas;
        }
        if (gap <= EDGE_GAP) {
            vec2 away = vec2(texel) - position;
            float weight = 1.0 / (1.0 + dot(away, away));
            total += gas * weight;
            weights += weight;
        }
    }
    if (weights > 0.0) {
#if SHOW_EDGES
        fragColor = vec4(0.0, 1.0, 1.0, 1.0);
#else
        fragColor = total / weights;
#endif
        return;
    }

    // Nothing around has this pixel's depth: it sees a surface that is only a few pixels wide at the gas texels'
    // size, so the best that can be done is the gas of the texel nearest in depth.
#if SHOW_EDGES
    fragColor = vec4(1.0, 0.0, 1.0, 1.0);
#else
    fragColor = nearest;
#endif
}
