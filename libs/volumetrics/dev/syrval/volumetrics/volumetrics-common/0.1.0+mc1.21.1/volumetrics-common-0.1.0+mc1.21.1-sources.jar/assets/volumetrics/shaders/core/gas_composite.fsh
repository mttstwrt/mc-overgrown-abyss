#include <volumetrics:gas_depth.glsl>

// The gas, at a fraction of the resolution of the screen.
uniform sampler2D GasSampler;
uniform sampler2D DepthSampler;

in vec2 texCoord;

out vec4 fragColor;

void main() {
    // One blended read of the gas texels around this pixel: where they are all empty there is nothing to add.
    if (textureLod(GasSampler, texCoord, 0.0).a <= 0.0) {
        discard;
    }

    ivec2 gasSize = textureSize(GasSampler, 0);
    vec2 position = texCoord * vec2(gasSize) - 0.5;
    ivec2 corner = ivec2(floor(position));
    vec2 blend = position - vec2(corner);
    float here = gasViewDistance(textureLod(DepthSampler, texCoord, 0.0).r);

    // Plain stretching would smear gas across the outline of anything in front of it. Each of the four gas
    // texels around this pixel counts for less the more the depth it was marched against differs from this
    // pixel's own.
    vec4 total = vec4(0.0);
    float weights = 0.0;
    for (int i = 0; i < 4; i++) {
        ivec2 offset = ivec2(i & 1, i >> 1);
        ivec2 texel = clamp(corner + offset, ivec2(0), gasSize - 1);
        float there = gasViewDistance(textureLod(DepthSampler, (vec2(texel) + 0.5) / vec2(gasSize), 0.0).r);
        float near = mix(1.0 - blend.x, blend.x, float(offset.x)) * mix(1.0 - blend.y, blend.y, float(offset.y));
        float weight = (near + 0.01) / (0.02 + gasDepthGap(there, here));
        total += texelFetch(GasSampler, texel, 0) * weight;
        weights += weight;
    }
    fragColor = total / weights;
}
