package dev.syrval.volumetrics.api;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Locale;

/**
 * How a gas looks.
 *
 * @param color          RGB, 0xRRGGBB; written {@code "#RRGGBB"} in JSON
 * @param opacity        how much light a block's depth of gas at full density stops: light passing through
 *                       {@code n} such blocks is dimmed to {@code exp(-opacity * n)}
 * @param skyLight       how strongly the gas is lit by the sky above it, 0 to 1
 * @param blockLight     how strongly it is lit by nearby light sources, 0 to 1
 * @param emissive       light of its own, added whatever the surroundings
 * @param forwardScatter extra glow when looking through the gas towards the sun or moon
 */
public record Appearance(int color, float opacity, float skyLight, float blockLight, float emissive,
                         float forwardScatter, Noise noise) {
    private static final Codec<Integer> COLOR_CODEC = Codec.STRING.comapFlatMap(Appearance::parseColor,
            color -> String.format(Locale.ROOT, "#%06X", color));

    public static final Codec<Appearance> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            COLOR_CODEC.fieldOf("color").forGetter(Appearance::color),
            Codec.floatRange(0f, 16f).fieldOf("opacity").forGetter(Appearance::opacity),
            Codec.floatRange(0f, 1f).optionalFieldOf("sky_light", 1f).forGetter(Appearance::skyLight),
            Codec.floatRange(0f, 1f).optionalFieldOf("block_light", 0.5f).forGetter(Appearance::blockLight),
            Codec.floatRange(0f, 4f).optionalFieldOf("emissive", 0f).forGetter(Appearance::emissive),
            Codec.floatRange(0f, 4f).optionalFieldOf("forward_scatter", 0.3f).forGetter(Appearance::forwardScatter),
            Noise.CODEC.optionalFieldOf("noise", Noise.DEFAULT).forGetter(Appearance::noise)
    ).apply(instance, Appearance::new));

    public Appearance {
        if ((color & 0xFF000000) != 0) {
            throw new IllegalArgumentException("Color must be 0xRRGGBB, got " + Integer.toHexString(color));
        }
        requireRange(opacity, 0f, 16f, "opacity");
        requireRange(skyLight, 0f, 1f, "sky_light");
        requireRange(blockLight, 0f, 1f, "block_light");
        requireRange(emissive, 0f, 4f, "emissive");
        requireRange(forwardScatter, 0f, 4f, "forward_scatter");
        if (noise == null) {
            throw new IllegalArgumentException("Appearance needs noise settings");
        }
    }

    public float red() {
        return (color >> 16 & 0xFF) / 255f;
    }

    public float green() {
        return (color >> 8 & 0xFF) / 255f;
    }

    public float blue() {
        return (color & 0xFF) / 255f;
    }

    /**
     * The wisps drawn into the gas so that coarse cells do not read as blocks.
     *
     * @param scale    wisps per block: 0.1 gives features about ten blocks across
     * @param speed    blocks per second the pattern drifts, in the direction the gas moves
     * @param strength 0 leaves the gas smooth, 1 lets the wisps cut it down to nothing in places
     */
    public record Noise(float scale, float speed, float strength) {
        public static final Noise DEFAULT = new Noise(0.12f, 0.4f, 0.5f);

        public static final Codec<Noise> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                Codec.floatRange(0f, 4f).optionalFieldOf("scale", DEFAULT.scale).forGetter(Noise::scale),
                Codec.floatRange(0f, 16f).optionalFieldOf("speed", DEFAULT.speed).forGetter(Noise::speed),
                Codec.floatRange(0f, 1f).optionalFieldOf("strength", DEFAULT.strength).forGetter(Noise::strength)
        ).apply(instance, Noise::new));

        public Noise {
            requireRange(scale, 0f, 4f, "noise scale");
            requireRange(speed, 0f, 16f, "noise speed");
            requireRange(strength, 0f, 1f, "noise strength");
        }
    }

    private static DataResult<Integer> parseColor(String text) {
        if (text.length() != 7 || text.charAt(0) != '#') {
            return DataResult.error(() -> "Color must look like #RRGGBB, got " + text);
        }
        try {
            return DataResult.success(Integer.parseInt(text.substring(1), 16));
        } catch (NumberFormatException e) {
            return DataResult.error(() -> "Color must look like #RRGGBB, got " + text);
        }
    }

    private static void requireRange(float value, float min, float max, String name) {
        if (!(value >= min && value <= max)) {
            throw new IllegalArgumentException(name + " must be between " + min + " and " + max + ", got " + value);
        }
    }
}
