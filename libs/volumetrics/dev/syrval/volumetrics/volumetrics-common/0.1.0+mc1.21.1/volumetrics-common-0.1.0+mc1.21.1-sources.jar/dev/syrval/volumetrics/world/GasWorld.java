package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.sim.Source;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * The gas of one client level. Two windows of cells follow the camera, a fine one for what is near and a coarse
 * one of the same number of cells around it for what is far; each knows the world inside it and the emitters
 * feeding it. Everything here runs on the client thread except the stepping, which {@link SimWorker} does on its
 * own.
 */
public final class GasWorld implements AutoCloseable, WorldChangeListener {
    /** How many kinds of gas the windows hold at once: one for each channel of the density texture. */
    public static final int SLOTS = 4;
    /** Number of windows. Index 0 is the fine one. */
    public static final int WINDOWS = 2;

    private static final GridSize SIZE = new GridSize(128, 64, 128);
    /**
     * Edge of a cell of each window, in blocks. The coarse window reaches 256 blocks from the camera each way and
     * 128 up and down. Cells of 8 would reach twice as far, but a layer of mist on a distant floor then hangs
     * visibly above it: gas is drawn as filling the cells it is in.
     */
    private static final int[] CELL_SIZES = {2, 4};
    /** The simulation steps every other tick. */
    private static final int STEP_TICKS = 2;
    private static final float STEP_SECONDS = STEP_TICKS / 20f;
    /**
     * Client-thread time a tick may spend reading the world: this much on sections that are waiting to be read,
     * and of it only this little on going round the ones that have been.
     */
    private static final long WAITING_BUDGET_NANOS = 1_000_000;
    private static final long SWEEP_BUDGET_NANOS = 150_000;

    private final GasWindow[] windows = new GasWindow[WINDOWS];
    private final SimWorker worker;
    /** Emitters made from code, by another mod or with the debug command. */
    private final LevelEmitters placed;
    private final @Nullable Medium[] slots = new Medium[SLOTS];
    private final boolean[] slotHasGas = new boolean[SLOTS];

    private int ticks;
    private long scanNanosSmoothed;

    /**
     * @param rules  the block-placed emitter definitions of the level's datapacks
     * @param placed the emitters made from code in the level, which may be added to and changed at any time
     */
    public GasWorld(List<BlockEmitterRule> rules, LevelEmitters placed) {
        this.placed = placed;
        for (int window = 0; window < WINDOWS; window++) {
            windows[window] = new GasWindow(SIZE, CELL_SIZES[window], rules);
        }
        this.worker = new SimWorker(SIZE, STEP_SECONDS);
    }

    /** The size of every window, in cells. */
    public GridSize size() {
        return SIZE;
    }

    public LightGrid light(int window) {
        return windows[window].light();
    }

    /** Where a window is now, which is where its light is; null before it has first followed the camera. */
    public @Nullable GridPlacement placement(int window) {
        return windows[window].placement();
    }

    @Override
    public void chunkArrived(int chunkX, int chunkZ) {
        for (GasWindow window : windows) {
            window.chunkArrived(chunkX, chunkZ);
        }
    }

    @Override
    public void blockChanged(int blockX, int blockY, int blockZ, boolean byPlayer) {
        for (GasWindow window : windows) {
            window.blockChanged(blockX, blockY, blockZ, byPlayer);
        }
    }

    @Override
    public void sectionTouched(int sectionX, int sectionY, int sectionZ) {
        for (GasWindow window : windows) {
            window.sectionTouched(sectionX, sectionY, sectionZ);
        }
    }

    /** The medium in a slot of the density texture, or null if the slot is free. */
    public @Nullable Medium medium(int slot) {
        return slots[slot];
    }

    /** Emitters feeding each window, the ones made from code included. */
    public int emitterCount(int window) {
        GridPlacement placement = windows[window].placement();
        return (placement == null ? 0 : placed.reaching(placement, SIZE).size()) + windows[window].emitterCount();
    }

    /** Chunk sections of a window that are waiting to be read: more than a few means the scan is behind the camera. */
    public int waitingSections(int window) {
        return windows[window].waitingSections();
    }

    /** Chunk sections of a window that are waiting to have their light alone read again. */
    public int waitingForLight(int window) {
        return windows[window].waitingForLight();
    }

    /** Seconds of simulated time between two snapshots, for blending from one to the next. */
    public float stepSeconds() {
        return STEP_SECONDS;
    }

    public long lastStepNanos() {
        return worker.lastStepNanos();
    }

    /** Client-thread time a tick spends reading the world, smoothed over recent ticks. */
    public long scanNanos() {
        return scanNanosSmoothed;
    }

    /**
     * The newest simulation result not yet taken, one snapshot for each window, or null. Give it back with
     * {@link #recycle}.
     */
    public @Nullable List<GasSnapshot> takeSnapshots() {
        List<GasSnapshot> snapshots = worker.takeLatest();
        if (snapshots != null) {
            for (int slot = 0; slot < SLOTS; slot++) {
                slotHasGas[slot] = false;
                for (GasSnapshot snapshot : snapshots) {
                    slotHasGas[slot] |= snapshot.slotHasGas(slot);
                }
            }
        }
        return snapshots;
    }

    public void recycle(List<GasSnapshot> snapshots) {
        worker.recycle(snapshots);
    }

    /** Once per client tick while the game is not paused. */
    public void tick(ClientLevel level, Vec3 camera) {
        for (GasWindow window : windows) {
            window.follow(camera);
        }
        long start = System.nanoTime();
        readWorld(level, start);
        scanNanosSmoothed += (System.nanoTime() - start - scanNanosSmoothed) / 16;
        if (ticks++ % STEP_TICKS == 0) {
            step();
        }
    }

    @Override
    public void close() {
        worker.close();
    }

    /**
     * What is waiting to be read comes first, the fine window's before the coarse one's, since that is where the
     * player is. Going round what has been read already is left the start of the tick's time, two parts of it to
     * the fine window and one to the coarse, and gets none in a tick that the waiting sections have used up.
     */
    private void readWorld(ClientLevel level, long start) {
        for (GasWindow window : windows) {
            window.readWaiting(level, start + WAITING_BUDGET_NANOS);
        }
        windows[0].sweep(level, start + SWEEP_BUDGET_NANOS * 2 / 3);
        windows[1].sweep(level, start + SWEEP_BUDGET_NANOS);
    }

    private void step() {
        List<List<Emitter>> active = new ArrayList<>();
        for (GasWindow window : windows) {
            GridPlacement placement = window.placement();
            if (placement == null) {
                return;
            }
            List<Emitter> feeding = placed.reaching(placement, SIZE);
            window.addEmittersTo(feeding);
            active.add(feeding);
        }
        assignSlots(active);

        List<SimWorker.WindowStep> steps = new ArrayList<>();
        for (int index = 0; index < WINDOWS; index++) {
            GasWindow window = windows[index];
            List<SimWorker.MediumStep> media = new ArrayList<>();
            for (int slot = 0; slot < SLOTS; slot++) {
                Medium medium = slots[slot];
                if (medium == null) {
                    continue;
                }
                List<Source> sources = new ArrayList<>();
                for (Emitter emitter : active.get(index)) {
                    if (emitter.medium().equals(medium)) {
                        sources.add(emitter.source());
                    }
                }
                media.add(new SimWorker.MediumStep(slot, medium.simulation().slowedToStable(window.cellSize(), STEP_SECONDS), sources));
            }
            // Nothing giving off gas and none left over: the simulation has nothing to do.
            if (media.isEmpty()) {
                return;
            }
            GridPlacement placement = window.placement();
            steps.add(new SimWorker.WindowStep(placement, window.occupancyForStep(), media));
        }
        worker.submit(new SimWorker.Request(steps));
    }

    /**
     * A medium keeps its slot while anything emits it and, after that, until its last gas has thinned away.
     * With every slot taken a new medium waits; it is not drawn until one frees up.
     */
    private void assignSlots(List<List<Emitter>> active) {
        for (int slot = 0; slot < SLOTS; slot++) {
            Medium medium = slots[slot];
            if (medium != null && !slotHasGas[slot] && !isEmitted(medium, active)) {
                slots[slot] = null;
            }
        }
        for (List<Emitter> feeding : active) {
            for (Emitter emitter : feeding) {
                if (slotOf(emitter.medium()) < 0) {
                    int free = slotOf(null);
                    if (free >= 0) {
                        slots[free] = emitter.medium();
                        // Until the first step with this medium reports back, assume it holds gas, so the slot is kept.
                        slotHasGas[free] = true;
                    }
                }
            }
        }
    }

    private static boolean isEmitted(Medium medium, List<List<Emitter>> active) {
        for (List<Emitter> feeding : active) {
            for (Emitter emitter : feeding) {
                if (emitter.medium().equals(medium)) {
                    return true;
                }
            }
        }
        return false;
    }

    private int slotOf(@Nullable Medium medium) {
        for (int slot = 0; slot < SLOTS; slot++) {
            if (medium == null ? slots[slot] == null : medium.equals(slots[slot])) {
                return slot;
            }
        }
        return -1;
    }
}
