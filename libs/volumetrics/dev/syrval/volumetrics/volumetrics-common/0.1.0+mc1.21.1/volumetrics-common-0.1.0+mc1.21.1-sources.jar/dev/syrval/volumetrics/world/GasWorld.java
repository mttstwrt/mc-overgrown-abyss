package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.ambient.AmbientState;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.sim.BrickMask;
import dev.syrval.volumetrics.sim.CascadeLayout;
import dev.syrval.volumetrics.sim.Draft;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.sim.Push;
import dev.syrval.volumetrics.sim.SimEngine;
import dev.syrval.volumetrics.sim.SimEngines;
import dev.syrval.volumetrics.sim.WindowInputs;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * The gas of one client level. A cascade of windows of cells follows the camera, the levels of a
 * {@link CascadeLayout}: the finest for what is near, and each one around it with cells twice as large, stepped half
 * as often, for what is further. The client thread moves the windows, copies the chunk sections in them out of the
 * world as they need reading and hands on the emitters made from code as they change; {@link ScanWorker} scans the
 * copies on a thread of its own, and {@link SimWorker} keeps what the scans come to, gives each kind of gas a slot and steps the gas on
 * another.
 *
 * <p>There are {@link #MAX_KINDS} slots; a kind costs the simulation in proportion to how much of it there is, and the
 * renderer a page of its density textures for every four slots in use.
 */
public final class GasWorld implements AutoCloseable, WorldChangeListener {
    /** How many kinds of gas the windows hold at once: four to each page of the density textures, at most eight pages. */
    public static final int MAX_KINDS = GasSnapshot.KINDS_PER_PAGE * BrickMask.MAX_PAGES;
    /**
     * The levels when none are asked for: two, reaching 128 and 256 blocks from the camera each way, the coarse one 384
     * blocks high, as much as a world of the usual height (a window is kept inside the world's height where it can be).
     */
    public static final CascadeLayout DEFAULT_LAYOUT = CascadeLayout.of(256, CascadeLayout.MAX_REACH, 384);

    /** The base step, level 0's, is every other tick; level k steps every 2^k of them. */
    private static final int STEP_TICKS = 2;
    private static final float STEP_SECONDS = STEP_TICKS / 20f;
    /**
     * Client-thread time a tick may spend copying chunk sections out of the world for the scan thread, the sections
     * the player has changed apart: those are copied whatever the time.
     */
    private static final long CAPTURE_BUDGET_NANOS = 300_000;
    /**
     * Of that, the start of the tick's time that going round the sections already read may use: the same share as when
     * the client thread scanned, which with copying far quicker than scanning still goes round faster than it did.
     */
    private static final long SWEEP_BUDGET_NANOS = CAPTURE_BUDGET_NANOS * 3 / 20;
    /**
     * How many sections may be copied whose scans have not yet been written into the windows. Past this nothing more
     * is copied, the sections the player has changed apart, so copies do not pile up if the scan thread falls behind.
     */
    private static final int MAX_IN_FLIGHT = 1024;

    private static final float SCROLL_WRAP = 1 << 15;
    private final CascadeLayout layout;
    private final GasWindow[] windows;
    private final ScanWorker scans;
    private final SimWorker worker;
    /** Emitters made from code, by another mod or with the debug command. */
    private final LevelEmitters placed;

    /** What the windows are told from outside; changes only on the client thread, and is immutable. */
    private WindowInputs inputs = WindowInputs.NONE;
    private final Map<Medium, ResourceLocation> mediumIds;
    /**
     * For each medium, how far its pattern has been carried, in blocks east and south, then what pushes it now in
     * blocks per second. Client thread only.
     */
    private final Map<Medium, float[]> carried = new IdentityHashMap<>();
    private long carriedAt = Long.MIN_VALUE;
    private int ticks;
    private long scanNanosSmoothed;

    /**
     * @param rules  the block-placed emitter definitions of the level's datapacks
     * @param placed the emitters made from code in the level, which may be added to and changed at any time
     */
    public GasWorld(List<BlockEmitterRule> rules, LevelEmitters placed) {
        this(rules, placed, Map.of());
    }

    /**
     * @param mediumIds the id of each medium of the level, compared by identity, which is how the server's settings
     *                  name the media whose buoyancy they set
     */
    public GasWorld(List<BlockEmitterRule> rules, LevelEmitters placed, Map<Medium, ResourceLocation> mediumIds) {
        this(rules, placed, mediumIds, SimEngines.byName(SimEngines.DEFAULT), DEFAULT_LAYOUT);
    }

    /**
     * @param engine makes the engine that moves the gas of each window
     * @param layout the levels; fixed for the life of this, so a change of them makes a new one
     */
    public GasWorld(List<BlockEmitterRule> rules, LevelEmitters placed, Map<Medium, ResourceLocation> mediumIds, SimEngine.Factory engine,
                    CascadeLayout layout) {
        this.placed = placed;
        this.mediumIds = mediumIds;
        this.layout = layout;
        int levels = layout.levels();
        this.windows = new GasWindow[levels];
        BlockFlags blockFlags = BlockFlags.build(rules);
        SectionScanner[] scanners = new SectionScanner[levels];
        int[] cellSizes = new int[levels];
        for (int window = 0; window < levels; window++) {
            cellSizes[window] = layout.cellSize(window);
            windows[window] = new GasWindow(layout.size(window), cellSizes[window], window);
            scanners[window] = new SectionScanner(cellSizes[window], rules, blockFlags);
        }
        this.scans = new ScanWorker(scanners, MAX_IN_FLIGHT);
        this.worker = new SimWorker(layout.sizes(), cellSizes, STEP_SECONDS, scans, mediumIds, engine);
        placed.attach(worker.emitterOps());
    }

    /** Sets the air that buoyant gas floats in; takes effect with the next step. */
    public void setAmbient(AmbientState ambient) {
        worker.setAmbient(ambient);
        inputs = inputs.withAmbient(ambient.profile());
    }

    /** Sets the wind that pushes the gas, in blocks per second towards east and south; takes effect with the next step. */
    public void setWind(float x, float z) {
        inputs = new WindowInputs(inputs.ambient(), x, z, inputs.gameTime());
    }

    /**
     * Carries each medium's pattern on by what pushes the gas, for the game ticks since the last call. Once a client
     * tick, after {@link #setWind}. A paused game does not carry it.
     */
    public void tickScroll(long gameTime) {
        long ticks = carriedAt == Long.MIN_VALUE ? 0 : Math.clamp(gameTime - carriedAt, 0, 20);
        carriedAt = gameTime;
        mediumIds.forEach((medium, id) -> {
            Draft.Vector push = Push.of(medium.properties(), idHash(id), inputs.windX(), inputs.windZ(), gameTime);
            float[] state = carried.computeIfAbsent(medium, m -> new float[4]);
            // Far enough that the jump back is rare (half an hour at the fastest push), near enough for float detail.
            state[0] = (state[0] + push.x() * ticks / 20f) % SCROLL_WRAP;
            state[1] = (state[1] + push.z() * ticks / 20f) % SCROLL_WRAP;
            state[2] = push.x();
            state[3] = push.z();
        });
    }

    /** How far the medium's pattern has been carried by now, in blocks east and south, between ticks by {@code partialTick}. */
    public float[] carried(Medium medium, float partialTick) {
        float[] state = carried.get(medium);
        if (state == null) {
            return new float[2];
        }
        return new float[] {state[0] + state[2] * partialTick / 20f, state[1] + state[3] * partialTick / 20f};
    }

    /** A number for a medium that is the same on every machine, for its draft: the hash of its id. */
    static int idHash(ResourceLocation id) {
        return id.toString().hashCode();
    }

    /** The levels this was made with. */
    public CascadeLayout layout() {
        return layout;
    }

    /** How many levels (windows) there are. */
    public int levels() {
        return windows.length;
    }

    /** The size of each window, in cells, the fine one first. */
    public List<GridSize> sizes() {
        return layout.sizes();
    }

    @Override
    public void chunkArrived(int chunkX, int chunkZ) {
        for (GasWindow window : windows) {
            window.chunkArrived(chunkX, chunkZ);
        }
    }

    @Override
    public void blockChanged(int blockX, int blockY, int blockZ, boolean byPlayer) {
        for (GasWindow window : windows) {
            window.blockChanged(blockX, blockY, blockZ, byPlayer);
        }
    }

    @Override
    public void sectionTouched(int sectionX, int sectionY, int sectionZ) {
        for (GasWindow window : windows) {
            window.sectionTouched(sectionX, sectionY, sectionZ);
        }
    }

    /** How many slots held a kind of gas at the last step. */
    public int kindsInUse() {
        return worker.kindsInUse();
    }

    /** Bricks of gas the simulation holds, every window and kind together: 2 KB each. */
    public int bricksHeld() {
        return worker.bricksHeld();
    }

    /** The edge of a window's cells, in blocks. */
    public int cellSize(int window) {
        return layout.cellSize(window);
    }

    /** A window's recent step times (averaged over {@value WindowStepStats#AVERAGED} steps) and last brick counts. */
    public WindowStepStats stepStats(int window) {
        return worker.stepStats(window);
    }

    /**
     * Emitters feeding each window at the last step, the ones made from code included. The outermost window holds every
     * other, so its count is all the emitters there are in reach.
     */
    public int emitterCount(int window) {
        return worker.emitterCount(window);
    }

    /** Chunk sections of a window that are waiting to be read: more than a few means the scan is behind the camera. */
    public int waitingSections(int window) {
        return windows[window].waitingSections();
    }

    /** Chunk sections of a window that are waiting to have their light alone read again. */
    public int waitingForLight(int window) {
        return windows[window].waitingForLight();
    }

    /**
     * Seconds of simulated time in a base step: between two snapshots of level 0, and the unit of
     * {@link GasSnapshot#fromStep} and {@link GasSnapshot#toStep}. Level k's snapshots are 2^k base steps apart.
     */
    public float stepSeconds() {
        return STEP_SECONDS;
    }

    public long lastStepNanos() {
        return worker.lastStepNanos();
    }

    /** Client-thread time a tick spends copying chunk sections out of the world to be scanned, smoothed over recent ticks. */
    public long scanNanos() {
        return scanNanosSmoothed;
    }

    /** Scan-thread time a chunk section takes, smoothed over recent sections. */
    public long scanThreadNanosPerSection() {
        return scans.nanosPerSection();
    }

    /** Chunk sections copied out of the world whose scans have not yet been written into the windows. */
    public int sectionsInFlight() {
        return scans.inFlight();
    }

    /** Of those, the ones scanned and waiting for a step to be written in. */
    public int scanResultsWaiting() {
        return scans.resultsWaiting() + worker.resultsWaiting();
    }

    /** Light updates the renderer has not taken yet. */
    public int lightUpdatesWaiting() {
        return worker.lightUpdatesWaiting();
    }

    /**
     * A level's newest snapshot not yet taken, or null; there is one each time the level steps, and it says the base
     * steps it is from and to. The coarser levels' snapshots of a step are there before level 0's. Give it back with
     * {@link #recycle}.
     */
    public @Nullable GasSnapshot takeSnapshot(int level) {
        return worker.takeLatest(level);
    }

    public void recycle(int level, GasSnapshot snapshot) {
        worker.recycle(level, snapshot);
    }

    /**
     * The oldest change to the light of a window not yet taken, or null. Every one is to be taken and sent, in order;
     * give each of its buffers back with {@link #recycleLightSlice} once sent.
     */
    public @Nullable LightUpdate takeLightUpdate() {
        return worker.takeLightUpdate();
    }

    public void recycleLightSlice(ByteBuffer slice) {
        worker.recycleLightSlice(slice);
    }

    /** Once per client tick while the game is not paused. */
    public void tick(ClientLevel level, Vec3 camera) {
        long tickStart = System.nanoTime();
        MainThreadTime.addScan(scans.takeScanned(), scans.takeScanNanos());
        for (GasWindow window : windows) {
            window.follow(camera, LevelHeight.bottom(level), LevelHeight.top(level));
        }
        long start = System.nanoTime();
        captureWorld(level);
        scanNanosSmoothed += (System.nanoTime() - start - scanNanosSmoothed) / 16;
        long stepNanos = 0;
        inputs = inputs.withGameTime(level.getGameTime());
        if (ticks++ % STEP_TICKS == 0) {
            long stepStart = System.nanoTime();
            step();
            stepNanos = System.nanoTime() - stepStart;
            MainThreadTime.add(MainThreadTime.Category.STEP, stepNanos);
        }
        MainThreadTime.add(MainThreadTime.Category.WORLD, System.nanoTime() - tickStart - stepNanos);
    }

    @Override
    public void close() {
        placed.detach(worker.emitterOps());
        scans.close();
        worker.close();
    }


    /**
     * Copies sections out of the world for the scan thread. What the player has changed comes first and is not held to
     * the time, then what is waiting to be read, the fine window's before the coarser ones', since that is where the
     * player is. Going round what has been read already is left the start of the tick's time, half of it to the finest
     * window and the rest to the others by how many cells each has, and gets none in a tick that the waiting sections
     * have used up.
     */
    private void captureWorld(ClientLevel level) {
        for (GasWindow window : windows) {
            window.captureChangedByPlayer(level, scans);
        }
        long start = System.nanoTime();
        for (GasWindow window : windows) {
            window.captureWaiting(level, start + CAPTURE_BUDGET_NANOS, scans);
        }
        windows[0].sweep(level, start + SWEEP_BUDGET_NANOS / 2, scans);
        long outerCells = 0;
        for (int window = 1; window < windows.length; window++) {
            outerCells += layout.size(window).cells();
        }
        long cellsSoFar = 0;
        for (int window = 1; window < windows.length; window++) {
            cellsSoFar += layout.size(window).cells();
            windows[window].sweep(level, start + SWEEP_BUDGET_NANOS / 2 + SWEEP_BUDGET_NANOS / 2 * cellsSoFar / outerCells, scans);
        }
        scans.wake();
    }

    /**
     * Asks the simulation for a step with each window where it is now; the rest, the emitters made from code
     * included, it keeps itself.
     */
    private void step() {
        List<SimWorker.WindowRequest> requests = new ArrayList<>(windows.length);
        for (int index = 0; index < windows.length; index++) {
            GasWindow window = windows[index];
            GridPlacement placement = window.placement();
            if (placement == null) {
                return;
            }
            requests.add(new SimWorker.WindowRequest(placement, window.epoch(), inputs));
        }
        worker.submit(new SimWorker.Request(requests));
    }
}
