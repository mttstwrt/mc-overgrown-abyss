package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.ambient.AmbientState;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.sim.BrickMask;
import dev.syrval.volumetrics.sim.Draft;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.sim.Push;
import dev.syrval.volumetrics.sim.SimEngine;
import dev.syrval.volumetrics.sim.SimEngines;
import dev.syrval.volumetrics.sim.WindowInputs;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * The gas of one client level. Two windows of cells follow the camera, a fine one for what is near and a coarse
 * one around it for what is far. The client thread moves the windows, copies the chunk sections in them out of the
 * world as they need reading and hands on the emitters made from code as they change; {@link ScanWorker} scans the
 * copies on a thread of its own, and {@link SimWorker} keeps what the scans come to, gives each kind of gas a slot and steps the gas on
 * another.
 *
 * <p>There are {@link #MAX_KINDS} slots; a kind costs the simulation in proportion to how much of it there is, and the
 * renderer a page of its density textures for every four slots in use.
 */
public final class GasWorld implements AutoCloseable, WorldChangeListener {
    /** How many kinds of gas the windows hold at once: four to each page of the density textures, at most eight pages. */
    public static final int MAX_KINDS = GasSnapshot.KINDS_PER_PAGE * BrickMask.MAX_PAGES;
    /** Number of windows. Index 0 is the fine one. */
    public static final int WINDOWS = 2;

    /**
     * The size of each window in cells. The fine one reaches 128 blocks from the camera each way and 64 up and down.
     * The coarse one reaches 256 each way and 192 up and down: as much as the height of a world of the usual 384
     * blocks, and a window is kept inside the world's height where it can be, so in such a world it holds all of it.
     */
    private static final List<GridSize> SIZES = List.of(new GridSize(128, 64, 128), new GridSize(128, 96, 128));
    /**
     * Edge of a cell of each window, in blocks. Cells of 8 would reach twice as far, but a layer of mist on a distant
     * floor then hangs visibly above it: gas is drawn as filling the cells it is in.
     */
    private static final int[] CELL_SIZES = {2, 4};
    /** The simulation steps every other tick. */
    private static final int STEP_TICKS = 2;
    private static final float STEP_SECONDS = STEP_TICKS / 20f;
    /**
     * Client-thread time a tick may spend copying chunk sections out of the world for the scan thread, the sections
     * the player has changed apart: those are copied whatever the time.
     */
    private static final long CAPTURE_BUDGET_NANOS = 300_000;
    /**
     * Of that, the start of the tick's time that going round the sections already read may use: the same share as when
     * the client thread scanned, which with copying far quicker than scanning still goes round faster than it did.
     */
    private static final long SWEEP_BUDGET_NANOS = CAPTURE_BUDGET_NANOS * 3 / 20;
    /**
     * How many sections may be copied whose scans have not yet been written into the windows. Past this nothing more
     * is copied, the sections the player has changed apart, so copies do not pile up if the scan thread falls behind.
     */
    private static final int MAX_IN_FLIGHT = 1024;

    private static final float SCROLL_WRAP = 1 << 15;
    private final GasWindow[] windows = new GasWindow[WINDOWS];
    private final ScanWorker scans;
    private final SimWorker worker;
    /** Emitters made from code, by another mod or with the debug command. */
    private final LevelEmitters placed;

    /** What the windows are told from outside; changes only on the client thread, and is immutable. */
    private WindowInputs inputs = WindowInputs.NONE;
    private final Map<Medium, ResourceLocation> mediumIds;
    /**
     * For each medium, how far its pattern has been carried, in blocks east and south, then what pushes it now in
     * blocks per second. Client thread only.
     */
    private final Map<Medium, float[]> carried = new IdentityHashMap<>();
    private long carriedAt = Long.MIN_VALUE;
    private int ticks;
    private long scanNanosSmoothed;

    /**
     * @param rules  the block-placed emitter definitions of the level's datapacks
     * @param placed the emitters made from code in the level, which may be added to and changed at any time
     */
    public GasWorld(List<BlockEmitterRule> rules, LevelEmitters placed) {
        this(rules, placed, Map.of());
    }

    /**
     * @param mediumIds the id of each medium of the level, compared by identity, which is how the server's settings
     *                  name the media whose buoyancy they set
     */
    public GasWorld(List<BlockEmitterRule> rules, LevelEmitters placed, Map<Medium, ResourceLocation> mediumIds) {
        this(rules, placed, mediumIds, SimEngines.byName(SimEngines.DEFAULT));
    }

    /** @param engine makes the engine that moves the gas of each window */
    public GasWorld(List<BlockEmitterRule> rules, LevelEmitters placed, Map<Medium, ResourceLocation> mediumIds, SimEngine.Factory engine) {
        this.placed = placed;
        this.mediumIds = mediumIds;
        BlockFlags blockFlags = BlockFlags.build(rules);
        SectionScanner[] scanners = new SectionScanner[WINDOWS];
        for (int window = 0; window < WINDOWS; window++) {
            windows[window] = new GasWindow(SIZES.get(window), CELL_SIZES[window], window);
            scanners[window] = new SectionScanner(CELL_SIZES[window], rules, blockFlags);
        }
        this.scans = new ScanWorker(scanners, MAX_IN_FLIGHT);
        this.worker = new SimWorker(SIZES, CELL_SIZES, STEP_SECONDS, scans, mediumIds, engine);
        placed.attach(worker.emitterOps());
    }

    /** Sets the air that buoyant gas floats in; takes effect with the next step. */
    public void setAmbient(AmbientState ambient) {
        worker.setAmbient(ambient);
        inputs = inputs.withAmbient(ambient.profile());
    }

    /** Sets the wind that pushes the gas, in blocks per second towards east and south; takes effect with the next step. */
    public void setWind(float x, float z) {
        inputs = new WindowInputs(inputs.ambient(), x, z, inputs.gameTime());
    }

    /**
     * Carries each medium's pattern on by what pushes the gas, for the game ticks since the last call. Once a client
     * tick, after {@link #setWind}. A paused game does not carry it.
     */
    public void tickScroll(long gameTime) {
        long ticks = carriedAt == Long.MIN_VALUE ? 0 : Math.clamp(gameTime - carriedAt, 0, 20);
        carriedAt = gameTime;
        mediumIds.forEach((medium, id) -> {
            Draft.Vector push = Push.of(medium.properties(), idHash(id), inputs.windX(), inputs.windZ(), gameTime);
            float[] state = carried.computeIfAbsent(medium, m -> new float[4]);
            // Far enough that the jump back is rare (half an hour at the fastest push), near enough for float detail.
            state[0] = (state[0] + push.x() * ticks / 20f) % SCROLL_WRAP;
            state[1] = (state[1] + push.z() * ticks / 20f) % SCROLL_WRAP;
            state[2] = push.x();
            state[3] = push.z();
        });
    }

    /** How far the medium's pattern has been carried by now, in blocks east and south, between ticks by {@code partialTick}. */
    public float[] carried(Medium medium, float partialTick) {
        float[] state = carried.get(medium);
        if (state == null) {
            return new float[2];
        }
        return new float[] {state[0] + state[2] * partialTick / 20f, state[1] + state[3] * partialTick / 20f};
    }

    /** A number for a medium that is the same on every machine, for its draft: the hash of its id. */
    static int idHash(ResourceLocation id) {
        return id.toString().hashCode();
    }

    /** The size of each window, in cells, the fine one first. */
    public List<GridSize> sizes() {
        return SIZES;
    }

    @Override
    public void chunkArrived(int chunkX, int chunkZ) {
        for (GasWindow window : windows) {
            window.chunkArrived(chunkX, chunkZ);
        }
    }

    @Override
    public void blockChanged(int blockX, int blockY, int blockZ, boolean byPlayer) {
        for (GasWindow window : windows) {
            window.blockChanged(blockX, blockY, blockZ, byPlayer);
        }
    }

    @Override
    public void sectionTouched(int sectionX, int sectionY, int sectionZ) {
        for (GasWindow window : windows) {
            window.sectionTouched(sectionX, sectionY, sectionZ);
        }
    }

    /** How many slots held a kind of gas at the last step. */
    public int kindsInUse() {
        return worker.kindsInUse();
    }

    /** Bricks of gas the simulation holds, every window and kind together: 2 KB each. */
    public int bricksHeld() {
        return worker.bricksHeld();
    }

    /** Emitters feeding each window at the last step, the ones made from code included. */
    public int emitterCount(int window) {
        return worker.emitterCount(window);
    }

    /** Chunk sections of a window that are waiting to be read: more than a few means the scan is behind the camera. */
    public int waitingSections(int window) {
        return windows[window].waitingSections();
    }

    /** Chunk sections of a window that are waiting to have their light alone read again. */
    public int waitingForLight(int window) {
        return windows[window].waitingForLight();
    }

    /** Seconds of simulated time between two snapshots, for blending from one to the next. */
    public float stepSeconds() {
        return STEP_SECONDS;
    }

    public long lastStepNanos() {
        return worker.lastStepNanos();
    }

    /** Client-thread time a tick spends copying chunk sections out of the world to be scanned, smoothed over recent ticks. */
    public long scanNanos() {
        return scanNanosSmoothed;
    }

    /** Scan-thread time a chunk section takes, smoothed over recent sections. */
    public long scanThreadNanosPerSection() {
        return scans.nanosPerSection();
    }

    /** Chunk sections copied out of the world whose scans have not yet been written into the windows. */
    public int sectionsInFlight() {
        return scans.inFlight();
    }

    /** Of those, the ones scanned and waiting for a step to be written in. */
    public int scanResultsWaiting() {
        return scans.resultsWaiting() + worker.resultsWaiting();
    }

    /** Light updates the renderer has not taken yet. */
    public int lightUpdatesWaiting() {
        return worker.lightUpdatesWaiting();
    }

    /**
     * The newest simulation result not yet taken, one snapshot for each window, or null. Give it back with
     * {@link #recycle}.
     */
    public @Nullable List<GasSnapshot> takeSnapshots() {
        return worker.takeLatest();
    }

    public void recycle(List<GasSnapshot> snapshots) {
        worker.recycle(snapshots);
    }

    /**
     * The oldest change to the light of a window not yet taken, or null. Every one is to be taken and sent, in order;
     * give each of its buffers back with {@link #recycleLightSlice} once sent.
     */
    public @Nullable LightUpdate takeLightUpdate() {
        return worker.takeLightUpdate();
    }

    public void recycleLightSlice(ByteBuffer slice) {
        worker.recycleLightSlice(slice);
    }

    /** Once per client tick while the game is not paused. */
    public void tick(ClientLevel level, Vec3 camera) {
        long tickStart = System.nanoTime();
        MainThreadTime.addScan(scans.takeScanned(), scans.takeScanNanos());
        for (GasWindow window : windows) {
            window.follow(camera, LevelHeight.bottom(level), LevelHeight.top(level));
        }
        long start = System.nanoTime();
        captureWorld(level);
        scanNanosSmoothed += (System.nanoTime() - start - scanNanosSmoothed) / 16;
        long stepNanos = 0;
        inputs = inputs.withGameTime(level.getGameTime());
        if (ticks++ % STEP_TICKS == 0) {
            long stepStart = System.nanoTime();
            step();
            stepNanos = System.nanoTime() - stepStart;
            MainThreadTime.add(MainThreadTime.Category.STEP, stepNanos);
        }
        MainThreadTime.add(MainThreadTime.Category.WORLD, System.nanoTime() - tickStart - stepNanos);
    }

    @Override
    public void close() {
        placed.detach(worker.emitterOps());
        scans.close();
        worker.close();
    }


    /**
     * Copies sections out of the world for the scan thread. What the player has changed comes first and is not held to
     * the time, then what is waiting to be read, the fine window's before the coarse one's, since that is where the
     * player is. Going round what has been read already is left the start of the tick's time, two parts of it to the
     * fine window and one to the coarse, and gets none in a tick that the waiting sections have used up.
     */
    private void captureWorld(ClientLevel level) {
        for (GasWindow window : windows) {
            window.captureChangedByPlayer(level, scans);
        }
        long start = System.nanoTime();
        for (GasWindow window : windows) {
            window.captureWaiting(level, start + CAPTURE_BUDGET_NANOS, scans);
        }
        windows[0].sweep(level, start + SWEEP_BUDGET_NANOS * 2 / 3, scans);
        windows[1].sweep(level, start + SWEEP_BUDGET_NANOS, scans);
        scans.wake();
    }

    /**
     * Asks the simulation for a step with each window where it is now; the rest, the emitters made from code
     * included, it keeps itself.
     */
    private void step() {
        List<SimWorker.WindowRequest> requests = new ArrayList<>(WINDOWS);
        for (int index = 0; index < WINDOWS; index++) {
            GasWindow window = windows[index];
            GridPlacement placement = window.placement();
            if (placement == null) {
                return;
            }
            requests.add(new SimWorker.WindowRequest(placement, window.epoch(), inputs));
        }
        worker.submit(new SimWorker.Request(requests));
    }
}
