package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.sim.BrickMask;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.sim.Source;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * The gas of one client level. Two windows of cells follow the camera, a fine one for what is near and a coarse
 * one around it for what is far; each knows the world inside it and the emitters feeding it. Everything here runs on
 * the client thread except the stepping, which {@link SimWorker} does on its own.
 *
 * <p>Each kind of gas near the camera has a slot, which it keeps while anything gives it off or any of it is left.
 * There are {@link #MAX_KINDS} slots; a kind costs the simulation in proportion to how much of it there is, and the
 * renderer a page of its density textures for every four slots in use.
 */
public final class GasWorld implements AutoCloseable, WorldChangeListener {
    /** How many kinds of gas the windows hold at once: four to each page of the density textures, at most eight pages. */
    public static final int MAX_KINDS = GasSnapshot.KINDS_PER_PAGE * BrickMask.MAX_PAGES;
    /** Number of windows. Index 0 is the fine one. */
    public static final int WINDOWS = 2;

    /**
     * The size of each window in cells. The fine one reaches 128 blocks from the camera each way and 64 up and down.
     * The coarse one reaches 256 each way and 192 up and down: as much as the height of a world of the usual 384
     * blocks, and a window is kept inside the world's height where it can be, so in such a world it holds all of it.
     */
    private static final List<GridSize> SIZES = List.of(new GridSize(128, 64, 128), new GridSize(128, 96, 128));
    /**
     * Edge of a cell of each window, in blocks. Cells of 8 would reach twice as far, but a layer of mist on a distant
     * floor then hangs visibly above it: gas is drawn as filling the cells it is in.
     */
    private static final int[] CELL_SIZES = {2, 4};
    /** The simulation steps every other tick. */
    private static final int STEP_TICKS = 2;
    private static final float STEP_SECONDS = STEP_TICKS / 20f;
    /**
     * Client-thread time a tick may spend reading the world: this much on sections that are waiting to be read,
     * and of it only this little on going round the ones that have been.
     */
    private static final long WAITING_BUDGET_NANOS = 1_000_000;
    private static final long SWEEP_BUDGET_NANOS = 150_000;

    private final GasWindow[] windows = new GasWindow[WINDOWS];
    private final SimWorker worker;
    /** Emitters made from code, by another mod or with the debug command. */
    private final LevelEmitters placed;
    private final @Nullable Medium[] slots = new Medium[MAX_KINDS];
    private final boolean[] slotHasGas = new boolean[MAX_KINDS];
    private final Map<Medium, Integer> slotOf = new HashMap<>();
    private boolean toldOfWaiting;

    private int ticks;
    private long scanNanosSmoothed;

    /**
     * @param rules  the block-placed emitter definitions of the level's datapacks
     * @param placed the emitters made from code in the level, which may be added to and changed at any time
     */
    public GasWorld(List<BlockEmitterRule> rules, LevelEmitters placed) {
        this.placed = placed;
        for (int window = 0; window < WINDOWS; window++) {
            windows[window] = new GasWindow(SIZES.get(window), CELL_SIZES[window], rules);
        }
        this.worker = new SimWorker(SIZES, STEP_SECONDS);
    }

    /** The size of each window, in cells, the fine one first. */
    public List<GridSize> sizes() {
        return SIZES;
    }

    public LightGrid light(int window) {
        return windows[window].light();
    }

    /** Where a window is now, which is where its light is; null before it has first followed the camera. */
    public @Nullable GridPlacement placement(int window) {
        return windows[window].placement();
    }

    @Override
    public void chunkArrived(int chunkX, int chunkZ) {
        for (GasWindow window : windows) {
            window.chunkArrived(chunkX, chunkZ);
        }
    }

    @Override
    public void blockChanged(int blockX, int blockY, int blockZ, boolean byPlayer) {
        for (GasWindow window : windows) {
            window.blockChanged(blockX, blockY, blockZ, byPlayer);
        }
    }

    @Override
    public void sectionTouched(int sectionX, int sectionY, int sectionZ) {
        for (GasWindow window : windows) {
            window.sectionTouched(sectionX, sectionY, sectionZ);
        }
    }

    /** The medium in a slot of the density texture, or null if the slot is free. */
    public @Nullable Medium medium(int slot) {
        return slots[slot];
    }

    /** How many slots hold a kind of gas just now. */
    public int kindsInUse() {
        return slotOf.size();
    }

    /** Bricks of gas the simulation holds, every window and kind together: 2 KB each. */
    public int bricksHeld() {
        return worker.bricksHeld();
    }

    /** Emitters feeding each window, the ones made from code included. */
    public int emitterCount(int window) {
        GridPlacement placement = windows[window].placement();
        return (placement == null ? 0 : placed.reaching(placement, SIZES.get(window)).size()) + windows[window].emitterCount();
    }

    /** Chunk sections of a window that are waiting to be read: more than a few means the scan is behind the camera. */
    public int waitingSections(int window) {
        return windows[window].waitingSections();
    }

    /** Chunk sections of a window that are waiting to have their light alone read again. */
    public int waitingForLight(int window) {
        return windows[window].waitingForLight();
    }

    /** Seconds of simulated time between two snapshots, for blending from one to the next. */
    public float stepSeconds() {
        return STEP_SECONDS;
    }

    public long lastStepNanos() {
        return worker.lastStepNanos();
    }

    /** Client-thread time a tick spends reading the world, smoothed over recent ticks. */
    public long scanNanos() {
        return scanNanosSmoothed;
    }

    /**
     * The newest simulation result not yet taken, one snapshot for each window, or null. Give it back with
     * {@link #recycle}.
     */
    public @Nullable List<GasSnapshot> takeSnapshots() {
        List<GasSnapshot> snapshots = worker.takeLatest();
        if (snapshots != null) {
            for (int slot = 0; slot < MAX_KINDS; slot++) {
                slotHasGas[slot] = false;
                for (GasSnapshot snapshot : snapshots) {
                    slotHasGas[slot] |= snapshot.slotHasGas(slot);
                }
            }
        }
        return snapshots;
    }

    public void recycle(List<GasSnapshot> snapshots) {
        worker.recycle(snapshots);
    }

    /** Once per client tick while the game is not paused. */
    public void tick(ClientLevel level, Vec3 camera) {
        for (GasWindow window : windows) {
            window.follow(camera, LevelHeight.bottom(level), LevelHeight.top(level));
        }
        long start = System.nanoTime();
        readWorld(level, start);
        scanNanosSmoothed += (System.nanoTime() - start - scanNanosSmoothed) / 16;
        if (ticks++ % STEP_TICKS == 0) {
            step();
        }
    }

    @Override
    public void close() {
        worker.close();
    }

    /**
     * What is waiting to be read comes first, the fine window's before the coarse one's, since that is where the
     * player is. Going round what has been read already is left the start of the tick's time, two parts of it to
     * the fine window and one to the coarse, and gets none in a tick that the waiting sections have used up.
     */
    private void readWorld(ClientLevel level, long start) {
        for (GasWindow window : windows) {
            window.readWaiting(level, start + WAITING_BUDGET_NANOS);
        }
        windows[0].sweep(level, start + SWEEP_BUDGET_NANOS * 2 / 3);
        windows[1].sweep(level, start + SWEEP_BUDGET_NANOS);
    }

    private void step() {
        List<List<Emitter>> active = new ArrayList<>();
        for (int index = 0; index < WINDOWS; index++) {
            GridPlacement placement = windows[index].placement();
            if (placement == null) {
                return;
            }
            List<Emitter> feeding = placed.reaching(placement, SIZES.get(index));
            windows[index].addEmittersTo(feeding);
            active.add(feeding);
        }
        assignSlots(active);

        List<SimWorker.WindowStep> steps = new ArrayList<>();
        for (int index = 0; index < WINDOWS; index++) {
            GasWindow window = windows[index];
            // Each kind's sources, by slot. A kind that has no slot yet waits.
            List<List<Source>> sources = new ArrayList<>(MAX_KINDS);
            for (int slot = 0; slot < MAX_KINDS; slot++) {
                sources.add(null);
            }
            for (Emitter emitter : active.get(index)) {
                Integer slot = slotOf.get(emitter.medium());
                if (slot != null) {
                    List<Source> kind = sources.get(slot);
                    if (kind == null) {
                        kind = new ArrayList<>();
                        sources.set(slot, kind);
                    }
                    kind.add(emitter.source());
                }
            }
            List<SimWorker.MediumStep> media = new ArrayList<>();
            for (int slot = 0; slot < MAX_KINDS; slot++) {
                Medium medium = slots[slot];
                if (medium != null) {
                    List<Source> kind = sources.get(slot);
                    media.add(new SimWorker.MediumStep(slot, medium.simulation().slowedToStable(window.cellSize(), STEP_SECONDS),
                            kind == null ? List.of() : kind));
                }
            }
            // Nothing giving off gas and none left over: the simulation has nothing to do.
            if (media.isEmpty()) {
                return;
            }
            steps.add(new SimWorker.WindowStep(window.placement(), window.occupancyForStep(), media));
        }
        worker.submit(new SimWorker.Request(steps));
    }

    /**
     * A medium keeps its slot while anything emits it and, after that, until its last gas has thinned away.
     * With every slot taken a new medium waits; it is not drawn until one frees up.
     */
    private void assignSlots(List<List<Emitter>> active) {
        Map<Medium, Boolean> emitted = new HashMap<>();
        for (List<Emitter> feeding : active) {
            for (Emitter emitter : feeding) {
                emitted.put(emitter.medium(), Boolean.TRUE);
            }
        }
        for (int slot = 0; slot < MAX_KINDS; slot++) {
            Medium medium = slots[slot];
            if (medium != null && !slotHasGas[slot] && !emitted.containsKey(medium)) {
                slots[slot] = null;
                slotOf.remove(medium);
            }
        }
        for (Medium medium : emitted.keySet()) {
            if (slotOf.containsKey(medium)) {
                continue;
            }
            int free = freeSlot();
            if (free < 0) {
                if (!toldOfWaiting) {
                    toldOfWaiting = true;
                    Volumetrics.LOGGER.warn("More than {} kinds of gas are near the camera; the rest wait until a kind is gone", MAX_KINDS);
                }
                continue;
            }
            slots[free] = medium;
            slotOf.put(medium, free);
            // Until the first step with this medium reports back, assume it holds gas, so the slot is kept.
            slotHasGas[free] = true;
        }
    }

    /** The lowest free slot, so that the kinds in use take as few pages as they can; -1 if none is free. */
    private int freeSlot() {
        for (int slot = 0; slot < MAX_KINDS; slot++) {
            if (slots[slot] == null) {
                return slot;
            }
        }
        return -1;
    }
}
