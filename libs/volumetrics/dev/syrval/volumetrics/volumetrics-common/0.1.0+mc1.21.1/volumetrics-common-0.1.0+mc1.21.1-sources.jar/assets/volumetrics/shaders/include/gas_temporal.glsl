#ifndef VOLUMETRICS_GAS_TEMPORAL_GLSL
#define VOLUMETRICS_GAS_TEMPORAL_GLSL

// What the gas passes need to add frames together: the march takes its samples at offsets that change every
// frame, and the accumulate pass blends each frame's march into what the frames before it made, moved to where it
// is on this frame's screen. GasRenderer fills this block each frame that it does so.
layout(std140) uniform GasTemporal {
    // The previous frame's projection times its view rotation: takes an offset from the previous frame's camera,
    // in blocks and world axes, to that frame's clip space. The same two matrices the march works from.
    mat4 GasPrevViewProj;
    // Where the camera is now less where it was on the previous frame, in blocks.
    vec3 GasCameraDelta;
    // How much of the frames before goes into this one, 0 to 1, where they hold anything for a pixel at all.
    float GasHistoryWeight;
    // 1 if what the previous frame made can be used, 0 if it is to be thrown away: on the first frame, after the
    // gas target has changed size or the quality setting has changed, after a frame without the gas passes, and
    // after the camera has jumped.
    int GasHistoryValid;
    // Counts the frames drawn this way, wrapping round now and then: it moves the march's offsets on.
    int GasFrameIndex;
};

#endif
