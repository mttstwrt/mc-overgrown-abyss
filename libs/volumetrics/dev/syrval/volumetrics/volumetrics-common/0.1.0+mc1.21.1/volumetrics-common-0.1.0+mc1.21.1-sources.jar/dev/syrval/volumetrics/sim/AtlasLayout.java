package dev.syrval.volumetrics.sim;

/**
 * How the Y slices of a grid sit side by side as tiles of one 2D texture. The game's GPU API has no 3D textures,
 * so this is the shape a grid takes on the GPU: slice {@code y} is the tile at column {@code y % tilesPerRow},
 * row {@code y / tilesPerRow}, with cell X along the tile's width and cell Z along its height.
 */
public record AtlasLayout(GridSize size, int tilesPerRow) {
    public AtlasLayout {
        if (tilesPerRow <= 0) {
            throw new IllegalArgumentException("Tiles per row must be positive, got " + tilesPerRow);
        }
    }

    /** The squarest layout, which keeps both texture dimensions as small as they can be. */
    public static AtlasLayout of(GridSize size) {
        return new AtlasLayout(size, (int) Math.ceil(Math.sqrt(size.y())));
    }

    public int tileRows() {
        return (size.y() + tilesPerRow - 1) / tilesPerRow;
    }

    public int width() {
        return tilesPerRow * size.x();
    }

    public int height() {
        return tileRows() * size.z();
    }

    /** Texel column of the first cell of a slice. */
    public int tileX(int slice) {
        return (slice % tilesPerRow) * size.x();
    }

    /** Texel row of the first cell of a slice. */
    public int tileY(int slice) {
        return (slice / tilesPerRow) * size.z();
    }
}
