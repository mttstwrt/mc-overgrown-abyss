package dev.syrval.volumetrics.api.wind;

import java.util.List;

/**
 * The wind of a level at one moment, in blocks per second towards east (x) and south (z). Gas is pushed by it as far as
 * its medium's {@code wind_response} says. Where an area contains a position, the first such area's wind is used
 * there instead of {@code x} and {@code z}. The library clamps each component to 16 blocks per second and keeps
 * the first {@value #MAX_AREAS} areas.
 */
public record Wind(float x, float z, List<WindArea> areas) {
    public static final int MAX_AREAS = 64;
    /** The largest wind component, in blocks per second. */
    public static final float MAX_SPEED = 16f;

    public Wind {
        areas = List.copyOf(areas);
    }

    /** A wind that is the same everywhere. */
    public static Wind uniform(float x, float z) {
        return new Wind(x, z, List.of());
    }
}
