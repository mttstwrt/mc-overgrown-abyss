package dev.syrval.volumetrics.api.wind;

import dev.syrval.volumetrics.Volumetrics;
import org.jspecify.annotations.Nullable;

/** Where a mod that has a wind registers it. Server only. */
public final class Winds {
    private static volatile @Nullable WindProvider provider;

    private Winds() {}

    /**
     * Sets the one provider of wind. A second registration replaces the first, which is logged.
     */
    public static synchronized void register(WindProvider newProvider) {
        WindProvider old = provider;
        if (old != null) {
            Volumetrics.LOGGER.info("Wind provider {} replaces {}", newProvider.getClass().getName(), old.getClass().getName());
        }
        provider = newProvider;
    }

    /** The registered provider, or null. */
    public static @Nullable WindProvider provider() {
        return provider;
    }
}
