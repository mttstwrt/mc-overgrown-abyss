package dev.syrval.volumetrics.api.wind;

/**
 * A box of blocks with a wind of its own, in blocks per second towards east (x) and south (z). The bounds are block
 * coordinates and both ends are inside; they may be given in either order.
 */
public record WindArea(int minX, int minY, int minZ, int maxX, int maxY, int maxZ, float x, float z) {
    /** Whether the block at these coordinates is inside the box. */
    public boolean contains(int blockX, int blockY, int blockZ) {
        return blockX >= Math.min(minX, maxX) && blockX <= Math.max(minX, maxX)
                && blockY >= Math.min(minY, maxY) && blockY <= Math.max(minY, maxY)
                && blockZ >= Math.min(minZ, maxZ) && blockZ <= Math.max(minZ, maxZ);
    }
}
