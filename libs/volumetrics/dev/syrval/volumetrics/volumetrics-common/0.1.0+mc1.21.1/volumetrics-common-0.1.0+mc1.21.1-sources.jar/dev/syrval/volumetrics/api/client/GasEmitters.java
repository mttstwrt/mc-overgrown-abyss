package dev.syrval.volumetrics.api.client;

import dev.syrval.volumetrics.api.EmitterFlow;
import dev.syrval.volumetrics.api.EmitterShape;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.client.EmitterHolder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;

/**
 * Emitters a mod makes from its own code, in one client level. They exist on this client only: nothing about
 * them is sent to anyone. A mod that wants every player to see the same gas makes the same emitters on each
 * client, from something all of them know: the game time, say, or a packet of its own.
 *
 * <p>The emitters belong to the level and go when it does. They are kept while the player has gas turned off,
 * and feed again when it is turned back on. Gas an emitter has given off stays where it is when the emitter
 * moves or is removed, and thins by its medium's decay.
 *
 * <p>For the client thread only, as is every method of a {@link Handle}. Never touch this from code that also
 * runs on a dedicated server.
 */
public interface GasEmitters {
    /**
     * The emitters of a level.
     *
     * @throws IllegalStateException off the client thread
     */
    static GasEmitters of(ClientLevel level) {
        if (!Minecraft.getInstance().isSameThread()) {
            throw new IllegalStateException("Gas emitters are for the client thread only");
        }
        return ((EmitterHolder) level).volumetrics$emitters();
    }

    /**
     * @param medium the gas: one of the level's datapacks, from the registry {@code VolumetricsRegistries.MEDIUM},
     *               or one made in code
     * @param shape  the region filled, relative to the anchor
     * @param anchor where the shape stands or is centred, as its kind says, in blocks
     * @param rate   density each cell in the shape gains per second, up to the medium's max density
     * @return the emitter, which pushes no gas around until it is given a flow ({@link Handle#setFlow})
     * @throws IllegalArgumentException if the rate is negative or not a number
     */
    Handle add(Medium medium, EmitterShape shape, Vec3 anchor, float rate);

    /** One emitter, for as long as it is wanted. */
    interface Handle {
        /** Puts the emitter somewhere else, from the next step of the simulation on. */
        void moveTo(Vec3 anchor);

        /** @throws IllegalArgumentException if the rate is negative or not a number */
        void setRate(float rate);

        /**
         * Makes the emitter push the gas of its medium near it along a heading or towards a point, from the next step of
         * the simulation on; null stops it. A point to push towards stays where it is when the emitter moves.
         */
        void setFlow(EmitterFlow flow);

        /** Takes the emitter away for good. Harmless a second time; moving it or setting its rate afterwards does nothing. */
        void remove();
    }
}
