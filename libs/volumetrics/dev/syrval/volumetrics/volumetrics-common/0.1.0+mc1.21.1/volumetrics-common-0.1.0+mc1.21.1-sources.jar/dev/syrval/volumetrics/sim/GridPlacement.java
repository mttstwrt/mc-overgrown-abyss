package dev.syrval.volumetrics.sim;

/**
 * Where the window sits in the world: the world cell of its corner, and the cell edge in blocks.
 * World cell n covers blocks {@code [n * cellSize, (n + 1) * cellSize)} on each axis.
 */
public record GridPlacement(int originX, int originY, int originZ, int cellSize) {
    public GridPlacement {
        if (cellSize <= 0) {
            throw new IllegalArgumentException("Cell size must be positive, got " + cellSize);
        }
    }

    /** Window-local cell holding a block coordinate on one axis; may lie outside the window. */
    public int localX(double blockX) {
        return worldCell(blockX) - originX;
    }

    public int localY(double blockY) {
        return worldCell(blockY) - originY;
    }

    public int localZ(double blockZ) {
        return worldCell(blockZ) - originZ;
    }

    public double centreX(int localX) {
        return (originX + localX + 0.5) * cellSize;
    }

    public double centreY(int localY) {
        return (originY + localY + 0.5) * cellSize;
    }

    public double centreZ(int localZ) {
        return (originZ + localZ + 0.5) * cellSize;
    }

    /** Whether a window of {@code size} cells placed here holds any part of the box around a shape. */
    public boolean reaches(GridSize size, SourceShape shape) {
        return overlaps(originX, size.x(), shape.minX(), shape.maxX())
                && overlaps(originY, size.y(), shape.minY(), shape.maxY())
                && overlaps(originZ, size.z(), shape.minZ(), shape.maxZ());
    }

    private boolean overlaps(int origin, int cells, double min, double max) {
        return max >= (double) origin * cellSize && min < ((double) origin + cells) * cellSize;
    }

    public GridPlacement moved(int cellsX, int cellsY, int cellsZ) {
        return new GridPlacement(originX + cellsX, originY + cellsY, originZ + cellsZ, cellSize);
    }

    private int worldCell(double block) {
        return (int) Math.floor(block / cellSize);
    }
}
