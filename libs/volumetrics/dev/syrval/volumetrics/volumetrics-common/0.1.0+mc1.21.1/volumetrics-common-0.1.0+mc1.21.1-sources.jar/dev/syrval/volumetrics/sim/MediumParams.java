package dev.syrval.volumetrics.sim;

/**
 * How one gas moves.
 *
 * @param gravity    blocks per second; positive sinks, negative rises
 * @param dispersion square blocks per second; how fast the gas spreads from dense cells to thin ones
 * @param decay      fraction of the gas lost per second
 * @param maxDensity the most a cell holds before gravity stops packing more in, which is what makes gas pool
 * @param driftX     blocks per second the gas is carried towards positive X, which is east; negative, towards west
 * @param driftZ     the same towards positive Z, which is south
 */
public record MediumParams(float gravity, float dispersion, float decay, float maxDensity, float driftX, float driftZ) {
    public MediumParams {
        if (!Float.isFinite(gravity)) {
            throw new IllegalArgumentException("Gravity must be finite, got " + gravity);
        }
        if (!Float.isFinite(dispersion) || dispersion < 0) {
            throw new IllegalArgumentException("Dispersion must be finite and not negative, got " + dispersion);
        }
        if (!Float.isFinite(decay) || decay < 0) {
            throw new IllegalArgumentException("Decay must be finite and not negative, got " + decay);
        }
        if (!Float.isFinite(maxDensity) || maxDensity <= 0) {
            throw new IllegalArgumentException("Max density must be finite and positive, got " + maxDensity);
        }
        if (!Float.isFinite(driftX) || !Float.isFinite(driftZ)) {
            throw new IllegalArgumentException("Drift must be finite, got " + driftX + ", " + driftZ);
        }
    }

    /** A gas that nothing carries sideways. */
    public MediumParams(float gravity, float dispersion, float decay, float maxDensity) {
        this(gravity, dispersion, decay, maxDensity, 0f, 0f);
    }

    public boolean drifts() {
        return driftX != 0f || driftZ != 0f;
    }

    /**
     * The largest share of a cell's gas that can leave it in one step. Above 1 a cell could give away more than
     * it holds and the step would oscillate, so such values must be clamped before they reach the stepper.
     */
    public float outflowFraction(int cellSize, float dt) {
        return gravityFraction(cellSize, dt) + 6 * diffusionFraction(cellSize, dt)
                + driftFractionX(cellSize, dt) + driftFractionZ(cellSize, dt);
    }

    public boolean isStable(int cellSize, float dt) {
        return outflowFraction(cellSize, dt) <= 1;
    }

    /**
     * These values if a step with them is stable, and otherwise the same gas slowed down until it is: a datapack
     * may ask for more speed than a coarse grid can carry in one step.
     */
    public MediumParams slowedToStable(int cellSize, float dt) {
        float outflow = outflowFraction(cellSize, dt);
        if (outflow <= 1) {
            return this;
        }
        float scale = 0.999f / outflow;
        return new MediumParams(gravity * scale, dispersion * scale, decay, maxDensity, driftX * scale, driftZ * scale);
    }

    float gravityFraction(int cellSize, float dt) {
        return Math.abs(gravity) * dt / cellSize;
    }

    float diffusionFraction(int cellSize, float dt) {
        return dispersion * dt / (cellSize * cellSize);
    }

    /** The share of a cell's gas that drift pushes along X in one step, whichever way. */
    float driftFractionX(int cellSize, float dt) {
        return Math.abs(driftX) * dt / cellSize;
    }

    float driftFractionZ(int cellSize, float dt) {
        return Math.abs(driftZ) * dt / cellSize;
    }
}
