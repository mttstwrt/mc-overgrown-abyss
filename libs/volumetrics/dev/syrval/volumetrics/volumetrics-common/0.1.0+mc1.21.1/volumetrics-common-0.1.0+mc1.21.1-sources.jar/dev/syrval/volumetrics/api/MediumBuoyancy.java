package dev.syrval.volumetrics.api;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.sim.AmbientProfile;
import dev.syrval.volumetrics.sim.Buoyancy;
import java.util.Optional;

/**
 * How a medium's gas floats in the air of the level it is in, instead of having a gravity of its own. Written as the
 * {@code buoyancy} object of a medium's {@code simulation}, and in the server's config file to change one.
 *
 * @param density   how dense the gas is relative to air at sea level, above 1 sinks it and below 1 lifts it
 * @param settlesAt the height, in blocks above sea level, where the gas stops rising or sinking: the same thing as a
 *                  density, written as the place it makes for; may be negative
 * @param speed     blocks per second the gas moves when it is twice as dense as the air around it; empty for the
 *                  server's default
 */
public record MediumBuoyancy(Optional<Float> density, Optional<Float> settlesAt, Optional<Float> speed) {
    /** The fields as written; a buoyancy with both or neither of the two would be refused by the record itself. */
    private record Raw(Optional<Float> density, Optional<Float> settlesAt, Optional<Float> speed) {}

    private static final Codec<Raw> RAW_CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.floatRange(1e-4f, 1e4f).optionalFieldOf("density").forGetter(Raw::density),
            Codec.floatRange(-1e5f, 1e5f).optionalFieldOf("settles_at").forGetter(Raw::settlesAt),
            Codec.floatRange(0f, 1e4f).optionalFieldOf("speed").forGetter(Raw::speed)
    ).apply(instance, Raw::new));

    public static final Codec<MediumBuoyancy> CODEC = RAW_CODEC.flatXmap(
            raw -> raw.density().isPresent() == raw.settlesAt().isPresent()
                    ? DataResult.error(() -> "buoyancy needs exactly one of density and settles_at")
                    : DataResult.success(new MediumBuoyancy(raw.density(), raw.settlesAt(), raw.speed())),
            buoyancy -> DataResult.success(new Raw(buoyancy.density(), buoyancy.settlesAt(), buoyancy.speed())));

    public MediumBuoyancy {
        if (density.isPresent() == settlesAt.isPresent()) {
            throw new IllegalArgumentException("Buoyancy needs exactly one of density and settles_at");
        }
    }

    /** The server's default speed, for a buoyancy that sets none. */
    public Buoyancy resolve(AmbientProfile profile, float defaultSpeed) {
        float at = speed.orElse(defaultSpeed);
        return settlesAt.isPresent()
                ? Buoyancy.settlingAt(profile, settlesAt.get(), at)
                : new Buoyancy(density.get(), at);
    }
}
