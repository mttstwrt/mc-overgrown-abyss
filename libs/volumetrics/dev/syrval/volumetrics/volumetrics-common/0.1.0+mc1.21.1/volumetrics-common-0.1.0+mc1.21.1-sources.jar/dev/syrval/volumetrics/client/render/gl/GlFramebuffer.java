package dev.syrval.volumetrics.client.render.gl;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import org.jspecify.annotations.Nullable;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

/**
 * Something to draw into: one colour texture, all of it, and no depth. With no depth attached, a pass that draws
 * into it may read any depth texture, the level's own included, and no depth test applies to it.
 */
public final class GlFramebuffer implements AutoCloseable {
    private final int id = GlStateManager.glGenFramebuffers();
    private final int colorTexture;
    private final int width;
    private final int height;

    /**
     * @param colorTexture the texture drawn into; it is not this object's to delete
     * @param width        the texture's size
     */
    public GlFramebuffer(int colorTexture, int width, int height) {
        this.colorTexture = colorTexture;
        this.width = width;
        this.height = height;
        int before = GlStateManager.getBoundFramebuffer();
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, id);
        GlStateManager._glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, colorTexture, 0);
        int status = GlStateManager.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER);
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, before);
        if (status != GL30.GL_FRAMEBUFFER_COMPLETE) {
            GlStateManager._glDeleteFramebuffers(id);
            throw new IllegalStateException("Framebuffer is not complete: status 0x" + Integer.toHexString(status));
        }
    }

    /**
     * Something to draw into a target's colour with and nothing else: a pass that reads the target's depth
     * texture cannot draw into anything that depth is attached to, as the target's own framebuffer is. The one
     * passed in if it is still for the target's colour texture. After the window has been resized that is
     * another texture, though it may have been given the old one's number, so the size is compared as well.
     */
    public static GlFramebuffer colorOnly(@Nullable GlFramebuffer current, RenderTarget target) {
        if (current != null && current.colorTexture == target.getColorTextureId()
                && current.width == target.width && current.height == target.height) {
            return current;
        }
        if (current != null) {
            current.close();
        }
        return new GlFramebuffer(target.getColorTextureId(), target.width, target.height);
    }

    int id() {
        return id;
    }

    int width() {
        return width;
    }

    int height() {
        return height;
    }

    @Override
    public void close() {
        GlStateManager._glDeleteFramebuffers(id);
    }
}
