package dev.syrval.volumetrics.client.render;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.api.Appearance;
import dev.syrval.volumetrics.api.Fog;
import dev.syrval.volumetrics.api.FogShape;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.client.LevelView;
import dev.syrval.volumetrics.client.render.gl.GlFramebuffer;
import dev.syrval.volumetrics.client.render.gl.GlProgram;
import dev.syrval.volumetrics.client.render.gl.GlTexture;
import dev.syrval.volumetrics.client.render.gl.GlUniformBuffer;
import dev.syrval.volumetrics.client.render.gl.ScreenPass;
import dev.syrval.volumetrics.client.render.gl.Std140Writer;
import dev.syrval.volumetrics.sim.AtlasLayout;
import dev.syrval.volumetrics.sim.BrickMask;
import dev.syrval.volumetrics.sim.CellBox;
import dev.syrval.volumetrics.sim.CellRect;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.sim.LevelSchedule;
import dev.syrval.volumetrics.world.GasSnapshot;
import dev.syrval.volumetrics.world.GasWorld;
import dev.syrval.volumetrics.world.LevelFogs;
import dev.syrval.volumetrics.world.LightUpdate;
import dev.syrval.volumetrics.world.MainThreadTime;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.server.packs.resources.ResourceProvider;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL45;
import org.jspecify.annotations.Nullable;

/**
 * Draws the gas of one {@link GasWorld}, and the fogs of its level. Three passes: a ray march through the density
 * atlases and the fogs into a target a fraction of the size of the screen, a filter that averages the grain of the
 * march away, and a depth-aware stretch of the result over the level. What this package asks of OpenGL it asks
 * through the {@code gl} package.
 *
 * <p>With temporal accumulation a fourth pass comes after the march: each frame marches with fewer samples, at
 * offsets that change from frame to frame, and is blended into what the frames before it made, moved to where
 * that is on this frame's screen. The filter then averages that blend instead of the march.
 *
 * <p>Every level of the cascade is drawn, from textures all the levels share side by side ({@link LevelAtlas}). The
 * density textures hold a page for every four slots in use, one page above the other; they are made again, taller,
 * when more kinds of gas come near than they have pages for.
 */
public final class GasRenderer implements AutoCloseable {
    /** March, accumulate, filter, composite. */
    private static final int PASSES = 4;

    /** Light slices the world scan has changed that are sent to the GPU in one frame, at most. */
    private static final int LIGHT_SLICES_PER_FRAME = 8;
    /** Slices of a whole light update sent each frame, to the texture that is not being read yet. */
    private static final int WHOLE_LIGHT_SLICES_PER_FRAME = 16;
    private static final float MOON_STRENGTH = 0.25f;
    private static final long TICKS_PER_HOUR = 72_000;
    private static final Vector4f NOTHING = new Vector4f(0f, 0f, 0f, 0f);
    /** Edge of the noise texture, and how far its green channel is moved along from its red; gas_march.fsh has the same. */
    private static final int NOISE_SIZE = 256;
    private static final int NOISE_SHIFT_X = 37;
    private static final int NOISE_SHIFT_Y = 239;
    private static final long NOISE_SEED = 0x766F6C756D65L;
    /** Below this the game takes the edge of what is drawn to be this far off, for its fog. */
    private static final float MIN_FOG_DISTANCE = 32f;
    /** The most fogs drawn at once; gas_field.glsl has the same. */
    private static final int MAX_FOGS = 16;
    /** Fogs are drawn that come within the render distance and this much more: past it the game's own fog hides all. */
    private static final double FOG_MARGIN = 32;
    /** The frames before are thrown away when the camera has moved further than this since the last, in blocks. */
    private static final double MAX_HISTORY_MOVE = 8;
    /**
     * The frame count that moves the march's offsets on wraps round at this. A Fibonacci number: that many steps of
     * the golden ratio come back almost exactly to where they started, so the wrap shows no jump, and the count
     * stays small enough for a float to keep its fraction.
     */
    private static final int FRAME_INDEX_PERIOD = 1597;

    /** Whether it has been logged that the device has no room for every level, or for every page of one. */
    private static boolean levelsLogged;
    private static boolean pagesLogged;
    /** Where each drawn level lies in the textures below; a level the device has no room for is not drawn. */
    private final LevelAtlas atlas;
    /** The levels of the cascade that are drawn, the finest first. */
    private final DrawnLevel[] levels;
    /**
     * The two density textures. Each level has its newest snapshot in one of them and the one before in the other,
     * which one is which changing each time the level steps.
     */
    private final GlTexture[] density = new GlTexture[2];
    /** How many pages the density textures have room for, as many as the slots in use take up. */
    private int pages = 1;
    /** Each level's light, twice: the shader reads its front copy, and a whole update is built in the other. */
    private final GlTexture lightTexture;
    /** For each level, the bricks either of its two snapshots holds gas in: the march blends the two, so it reads both. */
    private final GlTexture brickTexture;
    /** The kind of gas in each slot at the newest step taken, null for a free slot. */
    private final @Nullable Medium[] slotMedia = new Medium[GasWorld.MAX_KINDS];
    /** A light update partly sent, and how many of its slices have been; null if none is. */
    private @Nullable LightUpdate lightUpdate;
    private int lightUpdateSent;
    /** Time spent sending the whole update in progress, over the frames it has taken so far. */
    private long lightWholeNanos;
    /** Zeros, as many as the largest slice has texels: wipes what a texture held. */
    private final ByteBuffer zeroTexels;
    private final ByteBuffer brickTexels;
    private Options options;
    private final ResourceProvider resources;
    /** The march, compiled for each quality setting, with that setting's step lengths, when it is first drawn with. */
    private final Map<Quality, GlProgram> march = new EnumMap<>(Quality.class);
    /** The same for temporal accumulation: offsets that change each frame, and fewer, longer steps. */
    private final Map<Quality, GlProgram> temporalMarch = new EnumMap<>(Quality.class);
    private final GlProgram accumulate;
    private final GlProgram filter;
    private GlProgram composite;
    private final GlProgram mergeDepth;
    private final GlTexture noiseTexture;
    private final GlUniformBuffer gameUbo;
    private final GlUniformBuffer temporalUbo;
    private String inputs = "not drawn yet";
    private final ScreenPass pass = new ScreenPass();
    private final Matrix4f inverseViewRotation = new Matrix4f();
    private final @Nullable PassTimer timer;
    private @Nullable GlUniformBuffer frameUbo;
    private @Nullable Reduced marched;
    private @Nullable Reduced filtered;
    private @Nullable GlFramebuffer mainColor;
    /** The level's depth with Voxy's far terrain in it, as a colour, on frames a shader pack keeps that apart. */
    private @Nullable Reduced mergedDepth;
    private @Nullable GlUniformBuffer farUbo;
    private final Matrix4f farInverseProjection = new Matrix4f();
    /** The accumulate pass's two targets, used in turn: one is drawn into while the other, the frame before's, is read. */
    private final @Nullable Reduced[] history = new Reduced[2];
    /** Which of the two the accumulate pass draws into on this frame. */
    private int historyIndex;
    /** Whether the history target drawn into last holds the frame just before, drawn with temporal accumulation. */
    private boolean historyKept;
    /** The projection times the view rotation of the last frame drawn with temporal accumulation. */
    private final Matrix4f previousViewProjection = new Matrix4f();
    /** That frame's quality, and its camera's position. */
    private @Nullable Quality previousQuality;
    private double previousCameraX;
    private double previousCameraY;
    private double previousCameraZ;
    private int frameIndex;
    /** When level 0's newest snapshot was taken: what blending from its previous one is timed from. */
    private long newestNanos;
    private long uploadNanos;
    private long lightMoveNanos;
    private int fogsDrawn;

    /**
     * What the experiments set about how the gas is drawn (see {@code Experiments}), changed with {@link #setOptions}.
     *
     * @param skipEmptySpace false makes the march walk through every brick, gas or none: only for measuring what
     *                       skipping saves; a change shows from the next upload of gas
     * @param showEdges      paints the pixels that took the gas of the texel nearest in depth magenta and those that
     *                       needed the wider search cyan: only for seeing how many there are
     * @param temporalScale  with temporal accumulation, the samples a ray takes as a share of the quality's own
     * @param historyWeight  with temporal accumulation, how much of the frames before goes into each frame, 0 to 1
     */
    public record Options(boolean skipEmptySpace, boolean showEdges, float temporalScale, float historyWeight) {}

    /**
     * @param sizes           the size of each of the gas world's levels, the finest first
     * @param resources       where the shaders are read from
     * @param measureGpuTime  whether to time the passes on the GPU, for {@link #gpuNanos}
     * @param options         what the experiments set, until {@link #setOptions}
     */
    public GasRenderer(List<GridSize> sizes, ResourceProvider resources, boolean measureGpuTime, Options options) {
        this.resources = resources;
        int maxTextureSize = GL11.glGetInteger(GL11.GL_MAX_TEXTURE_SIZE);
        this.atlas = LevelAtlas.fit(sizes, maxTextureSize, Long.MAX_VALUE);
        if (atlas.levels() < atlas.wanted() && !levelsLogged) {
            levelsLogged = true;
            Volumetrics.LOGGER.warn("Drawing {} of the {} levels of the gas: the device's textures are at most {} texels across",
                    atlas.levels(), atlas.wanted(), maxTextureSize);
        }
        int sliceCells = 0;
        int bricks = 0;
        for (int level = 0; level < atlas.levels(); level++) {
            GridSize size = atlas.size(level);
            sliceCells = Math.max(sliceCells, size.x() * size.z());
            bricks = Math.max(bricks, size.brickCount());
        }
        this.zeroTexels = ByteBuffer.allocateDirect(sliceCells * GasSnapshot.KINDS_PER_PAGE);
        this.brickTexels = ByteBuffer.allocateDirect(bricks);
        for (int index = 0; index < density.length; index++) {
            density[index] = new GlTexture(GlTexture.Format.RGBA8, atlas.width(), atlas.densityHeight(pages), true, false);
        }
        this.lightTexture = new GlTexture(GlTexture.Format.RG8, atlas.width(), atlas.lightHeight(), true, false);
        this.brickTexture = new GlTexture(GlTexture.Format.R8, atlas.brickWidth(), atlas.brickHeight(), false, false);
        this.levels = new DrawnLevel[atlas.levels()];
        for (int level = 0; level < levels.length; level++) {
            levels[level] = new DrawnLevel(level);
            // A fog may be drawn before any gas is: until then no brick holds any.
            putBricks(levels[level]);
        }
        this.options = options;
        this.accumulate = new GlProgram(resources, "core/gas_accumulate.fsh", Map.of());
        this.filter = new GlProgram(resources, "core/gas_filter.fsh", Map.of());
        this.composite = new GlProgram(resources, "core/gas_composite.fsh", compositeDefines(options));
        this.mergeDepth = new GlProgram(resources, "core/gas_depth_merge.fsh", Map.of());
        this.gameUbo = new GlUniformBuffer(filter.blockBytes("GasGame"));
        this.temporalUbo = new GlUniformBuffer(accumulate.blockBytes("GasTemporal"));
        this.noiseTexture = new GlTexture(GlTexture.Format.RG8, NOISE_SIZE, NOISE_SIZE, true, true);
        noiseTexture.upload(noiseTexels(), 0, 0, NOISE_SIZE, NOISE_SIZE);
        this.timer = measureGpuTime && PassTimer.supported() ? new PassTimer(PASSES) : null;
    }

    /**
     * Nanoseconds of GPU time one of the four passes takes: 0 for the march, 1 for the accumulate pass, 2 for the
     * filter, 3 for the composite. 0 if not measured or not drawn yet; next to nothing for the accumulate pass
     * without temporal accumulation, which does not draw it.
     */
    public long gpuNanos(int pass) {
        return timer == null ? 0 : timer.nanos(pass);
    }

    /** Render-thread time it took to hand the last simulation step to the GPU, in nanoseconds. */
    public long uploadNanos() {
        return uploadNanos;
    }

    /**
     * Render-thread time it last took to send a level's light whole after the level had moved, in nanoseconds:
     * what crossing into another chunk section costs one frame, for each level that moved.
     */
    public long lightMoveNanos() {
        return lightMoveNanos;
    }

    /** How many fogs the last frame drew. */
    public int fogsDrawn() {
        return fogsDrawn;
    }

    /** How many pages of the density textures each drawn level holds, the finest first. */
    public String pages() {
        StringBuilder pages = new StringBuilder();
        for (DrawnLevel level : levels) {
            pages.append(pages.isEmpty() ? "" : ", ").append(level.pages);
        }
        return pages.toString();
    }

    /**
     * @param fogs     the fogs of the level
     * @param main     what the gas is drawn over
     * @param depth    the texture holding the depth of the level in it, which is not always the main target's own
     * @param lightmap the game's lightmap texture for the level: what it makes of a sky and a block light level at
     *                 this moment, which is what the gas is lit by
     * @param view     what the level in the main target was drawn with
     * @param scale    the share of the depth texture, from its bottom left, that the level was drawn into: 1 unless a shader
     *                 pack draws it smaller and scales the colour up afterwards, leaving the depth as it was drawn
     * @param temporal whether to march with fewer samples and blend the frames together; false draws each frame
     *                 on its own
     */
    public void render(GasWorld world, LevelFogs fogs, RenderTarget main, int depth, int lightmap, LevelView view, ClientLevel level,
                       Quality quality, float scale, boolean temporal) {
        // A frame that leaves before its passes are drawn leaves nothing for the next one to build on.
        boolean continuing = historyKept;
        historyKept = false;
        inputs = describeInputs(main, depth);
        long takeStart = System.nanoTime();
        takeNewestStep(world);
        MainThreadTime.add(MainThreadTime.Category.TAKE, System.nanoTime() - takeStart);
        long lightStart = System.nanoTime();
        uploadLight(world);
        MainThreadTime.add(MainThreadTime.Category.LIGHT, System.nanoTime() - lightStart);
        fogsDrawn = 0;
        boolean hasGas = false;
        for (DrawnLevel drawn : levels) {
            // Nothing can be drawn before there is light to draw it by.
            if (drawn.lightPlacement == null) {
                return;
            }
            GridPlacement placement = drawn.buffers[drawn.newest].placement;
            hasGas |= placement != null && (drawn.buffers[0].hasGas || drawn.buffers[1].hasGas);
            // A level that has moved between its two snapshots, or has only one, shows its newest.
            drawn.blends = placement != null && placement.equals(drawn.buffers[1 - drawn.newest].placement);
        }
        Vec3 camera = view.camera().getPosition();
        List<Fog> drawn = fogs.isEmpty() ? List.of()
                : fogs.nearest(camera, Minecraft.getInstance().gameRenderer.getRenderDistance() + FOG_MARGIN, MAX_FOGS);
        // Nothing to draw costs nothing: no passes at all.
        if (!hasGas && drawn.isEmpty()) {
            return;
        }
        fogsDrawn = drawn.size();

        // The moment shown, in base steps: between level 0's two snapshots, as far on as the time since its newest.
        // Every level is shown at that moment, between its own two snapshots.
        float sinceStep = (System.nanoTime() - newestNanos) / 1e9f;
        double shown = (double) levels[0].fromStep + Math.min(1f, sinceStep / world.stepSeconds());
        GlProgram marchProgram = march(quality, temporal);
        if (frameUbo == null) {
            frameUbo = new GlUniformBuffer(marchProgram.blockBytes("GasField"));
        }
        writeFrameUniforms(world, frameUbo, drawn, view, level, shown);

        int divisor = quality.marchDivisor(main.height);
        int contentWidth = Math.max(1, Math.round(main.width * scale));
        int contentHeight = Math.max(1, Math.round(main.height * scale));
        int width = Math.max(1, main.width / divisor);
        int height = Math.max(1, main.height / divisor);
        writeGameUniforms(view, level, (float) contentWidth / main.width, (float) contentHeight / main.height);
        boolean resized = marched == null || marched.color.width() != width || marched.color.height() != height;
        marched = sized(marched, width, height, GlTexture.Format.RGBA8);
        filtered = sized(filtered, width, height, GlTexture.Format.RGBA8);
        mainColor = GlFramebuffer.colorOnly(mainColor, main);
        if (temporal) {
            historyIndex = 1 - historyIndex;
            for (int index = 0; index < history.length; index++) {
                history[index] = sized(history[index], width, height, GlTexture.Format.RGBA16F);
            }
            writeTemporalUniforms(view, quality, continuing && !resized);
        }

        boolean timing = timer != null && timer.begin();
        pass.begin();
        int levelDepth = levelDepth(main, depth);
        if (timing) {
            timer.mark();
        }
        marchProgram.setBlock("GasField", frameUbo);
        marchProgram.setBlock("GasGame", gameUbo);
        if (temporal) {
            marchProgram.setBlock("GasTemporal", temporalUbo);
        }
        marchProgram.setTexture("DepthSampler", levelDepth);
        marchProgram.setTexture("NoiseSampler", noiseTexture.id());
        marchProgram.setTexture("LightmapSampler", lightmap);
        marchProgram.setTexture("GasDensity0Sampler", density[0].id());
        marchProgram.setTexture("GasDensity1Sampler", density[1].id());
        marchProgram.setTexture("GasLightSampler", lightTexture.id());
        marchProgram.setTexture("GasBrickSampler", brickTexture.id());
        pass.draw(marched.framebuffer, marchProgram, ScreenPass.Blend.NONE);
        if (timing) {
            timer.mark();
        }
        // The filter averages the march, or with temporal accumulation what this frame and the ones before make of it.
        Reduced grainy = marched;
        if (temporal) {
            Reduced written = history[historyIndex];
            accumulate.setBlock("GasGame", gameUbo);
            accumulate.setBlock("GasField", frameUbo);
            accumulate.setBlock("GasTemporal", temporalUbo);
            accumulate.setTexture("GasSampler", marched.color.id());
            accumulate.setTexture("HistorySampler", history[1 - historyIndex].color.id());
            accumulate.setTexture("DepthSampler", levelDepth);
            pass.draw(written.framebuffer, accumulate, ScreenPass.Blend.NONE);
            grainy = written;
            historyKept = true;
        }
        if (timing) {
            timer.mark();
        }
        filter.setBlock("GasGame", gameUbo);
        filter.setTexture("GasSampler", grainy.color.id());
        filter.setTexture("DepthSampler", levelDepth);
        pass.draw(filtered.framebuffer, filter, ScreenPass.Blend.NONE);
        if (timing) {
            timer.mark();
        }
        // Colour only: the level's depth is read here, so it cannot also be attached to what is drawn into.
        // The march writes colour already multiplied by coverage.
        composite.setBlock("GasGame", gameUbo);
        composite.setTexture("GasSampler", filtered.color.id());
        composite.setTexture("DepthSampler", levelDepth);
        pass.draw(mainColor, composite, ScreenPass.Blend.PREMULTIPLIED_ALPHA);
        if (timing) {
            timer.mark();
        }
        pass.end(main);
    }

    /**
     * The level's depth, with the terrain Voxy draws past the render distance in it on a frame a shader pack keeps
     * that apart; the depth as given otherwise. Drawn inside the gas's pass.
     */
    private int levelDepth(RenderTarget main, int depth) {
        int far = FarTerrainDepth.takeDrawnDepth(farInverseProjection);
        if (far == 0) {
            return depth;
        }
        if (farUbo == null) {
            farUbo = new GlUniformBuffer(mergeDepth.blockBytes("GasFarDepth"));
        }
        farUbo.write(uniforms -> uniforms.putMat4f(farInverseProjection));
        // Read texel for texel, as the game's depth is: blended depths would put the edge of a hill in mid-air.
        if (mergedDepth == null || mergedDepth.color.width() != main.width || mergedDepth.color.height() != main.height) {
            if (mergedDepth != null) {
                mergedDepth.close();
            }
            GlTexture color = new GlTexture(GlTexture.Format.R32F, main.width, main.height, false, false);
            mergedDepth = new Reduced(color, new GlFramebuffer(color.id(), main.width, main.height));
        }
        mergeDepth.setBlock("GasGame", gameUbo);
        mergeDepth.setBlock("GasFarDepth", farUbo);
        mergeDepth.setTexture("DepthSampler", depth);
        mergeDepth.setTexture("FarDepthSampler", far);
        pass.draw(mergedDepth.framebuffer, mergeDepth, ScreenPass.Blend.NONE);
        return mergedDepth.color.id();
    }

    /** What the game or a shader pack had set up when the gas passes were reached, for working out where the level is. */
    public String inputs() {
        return inputs;
    }

    private static String describeInputs(RenderTarget main, int depth) {
        int[] viewport = new int[4];
        GL11.glGetIntegerv(GL11.GL_VIEWPORT, viewport);
        int framebuffer = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        String depthSize;
        try {
            depthSize = GL45.glGetTextureLevelParameteri(depth, 0, GL11.GL_TEXTURE_WIDTH) + "x"
                    + GL45.glGetTextureLevelParameteri(depth, 0, GL11.GL_TEXTURE_HEIGHT);
        } catch (RuntimeException | Error e) {
            depthSize = "unknown";
        }
        return "viewport " + viewport[0] + "," + viewport[1] + " " + viewport[2] + "x" + viewport[3] + ", draw framebuffer "
                + framebuffer + ", main " + main.width + "x" + main.height + " (view " + main.viewWidth + "x" + main.viewHeight
                + "), depth texture " + depthSize;
    }

    /** The size the gas was last marched at, 0 by 0 before the first frame. */
    public int marchWidth() {
        return marched == null ? 0 : marched.color.width();
    }

    public int marchHeight() {
        return marched == null ? 0 : marched.color.height();
    }

    /**
     * From the next frame. The composite is compiled again if the edges are shown or hidden, and the temporal march
     * when it is first drawn with after its share of samples changed.
     */
    public void setOptions(Options options) {
        Options before = this.options;
        this.options = options;
        if (options.showEdges() != before.showEdges()) {
            composite.close();
            composite = new GlProgram(resources, "core/gas_composite.fsh", compositeDefines(options));
        }
        if (options.temporalScale() != before.temporalScale()) {
            temporalMarch.values().forEach(GlProgram::close);
            temporalMarch.clear();
        }
    }

    private static Map<String, String> compositeDefines(Options options) {
        return Map.of("SHOW_EDGES", options.showEdges() ? "1" : "0");
    }

    @Override
    public void close() {
        for (GlTexture texture : density) {
            texture.close();
        }
        lightTexture.close();
        brickTexture.close();
        march.values().forEach(GlProgram::close);
        temporalMarch.values().forEach(GlProgram::close);
        accumulate.close();
        filter.close();
        composite.close();
        mergeDepth.close();
        noiseTexture.close();
        gameUbo.close();
        temporalUbo.close();
        pass.close();
        if (frameUbo != null) {
            frameUbo.close();
        }
        if (marched != null) {
            marched.close();
        }
        if (filtered != null) {
            filtered.close();
        }
        for (Reduced target : history) {
            if (target != null) {
                target.close();
            }
        }
        if (mainColor != null) {
            mainColor.close();
        }
        if (mergedDepth != null) {
            mergedDepth.close();
        }
        if (farUbo != null) {
            farUbo.close();
        }
        if (timer != null) {
            timer.close();
        }
    }

    private GlProgram march(Quality quality, boolean temporal) {
        return (temporal ? temporalMarch : march).computeIfAbsent(quality,
                setting -> new GlProgram(resources, "core/gas_march.fsh", marchDefines(setting, temporal)));
    }

    /**
     * With temporal accumulation a ray takes fewer samples, and its steps are longer by as much: what one frame
     * steps over, the frames before it have sampled.
     */
    private Map<String, String> marchDefines(Quality setting, boolean temporal) {
        float scale = temporal ? options.temporalScale() : 1f;
        return Map.of(
                "TEMPORAL", temporal ? "1" : "0",
                "MIN_STEP_BLOCKS", Float.toString(setting.minStepBlocks() / scale),
                "STEP_GROWTH", Float.toString(setting.stepGrowth() / scale),
                "MAX_SAMPLES", Integer.toString(fewerSamples(setting.maxSamples(), scale)),
                "FOG_MIN_STEP_BLOCKS", Float.toString(setting.fogMinStepBlocks() / scale),
                "FOG_STEP_GROWTH", Float.toString(setting.fogStepGrowth() / scale),
                "FOG_MAX_SAMPLES", Integer.toString(fewerSamples(setting.fogMaxSamples(), scale)));
    }

    private static int fewerSamples(int samples, float scale) {
        return Math.max(1, Math.round(samples * scale));
    }

    /**
     * Sends each drawn level's snapshot, if it has stepped since, to the density texture that holds its older one. Each
     * level has snapshots of its own, as often as it steps. Those of a level that is not drawn are given back as they are.
     */
    private void takeNewestStep(GasWorld world) {
        long start = System.nanoTime();
        boolean taken = false;
        for (int level = 0; level < world.levels(); level++) {
            GasSnapshot snapshot = world.takeSnapshot(level);
            if (snapshot == null) {
                continue;
            }
            if (level < levels.length) {
                DrawnLevel drawn = levels[level];
                take(drawn, snapshot, 1 - drawn.newest);
                drawn.newest = 1 - drawn.newest;
                drawn.fromStep = snapshot.fromStep();
                drawn.toStep = snapshot.toStep();
                if (level == 0) {
                    for (int slot = 0; slot < slotMedia.length; slot++) {
                        slotMedia[slot] = snapshot.medium(slot);
                    }
                    newestNanos = System.nanoTime();
                }
                taken = true;
            }
            world.recycle(level, snapshot);
        }
        if (taken) {
            uploadNanos = System.nanoTime() - start;
        }
    }

    /**
     * Sends the light the simulation has changed, in the order it was changed. After a level has moved all of its
     * light goes, a few slices each frame, to the level's back copy of its light while the shader keeps reading the
     * front one by the old place; when the last slice is up the two swap and the level's light is for the new place.
     * Partial updates go to the front copy, a few slices each frame, and what is left of an update waits for the next
     * frame. The light of a level that is not drawn is given back as it comes.
     */
    private void uploadLight(GasWorld world) {
        int partialSent = 0;
        while (true) {
            LightUpdate update = lightUpdate;
            if (update == null) {
                update = world.takeLightUpdate();
                if (update == null) {
                    return;
                }
                if (update.window() >= levels.length) {
                    // A level that is not drawn.
                    for (ByteBuffer slice : update.buffers()) {
                        world.recycleLightSlice(slice);
                    }
                    continue;
                }
                lightUpdate = update;
                lightUpdateSent = 0;
                lightWholeNanos = 0;
            }
            DrawnLevel drawn = levels[update.window()];
            boolean whole = update.whole();
            int row = atlas.lightSlotHeight() * (whole ? 1 - drawn.lightFront : drawn.lightFront);
            int limit = whole ? Math.min(update.slices().length, lightUpdateSent + WHOLE_LIGHT_SLICES_PER_FRAME) : update.slices().length;
            long start = System.nanoTime();
            while (lightUpdateSent < limit && (whole || partialSent < LIGHT_SLICES_PER_FRAME)) {
                int y = update.slices()[lightUpdateSent];
                ByteBuffer slice = update.buffers()[lightUpdateSent];
                lightTexture.upload(slice, drawn.column + drawn.atlas.tileX(y), row + drawn.atlas.tileY(y), drawn.size.x(), drawn.size.z());
                world.recycleLightSlice(slice);
                lightUpdateSent++;
                partialSent += whole ? 0 : 1;
            }
            lightWholeNanos += System.nanoTime() - start;
            if (lightUpdateSent < update.slices().length) {
                return;
            }
            if (whole) {
                drawn.lightFront = 1 - drawn.lightFront;
                drawn.lightPlacement = update.placement();
                lightMoveNanos = lightWholeNanos;
            }
            lightUpdate = null;
        }
    }

    /** Must write exactly the fields of the GasField block in gas_field.glsl, in its order. */
    private void writeFrameUniforms(GasWorld world, GlUniformBuffer buffer, List<Fog> fogs, LevelView view, ClientLevel level, double shown) {
        view.viewRotation().invert(inverseViewRotation);
        float seconds = (level.getGameTime() % TICKS_PER_HOUR + view.partialTick()) / 20f;
        Vec3 camera = view.camera().getPosition();
        buffer.write(uniforms -> {
            uniforms.putMat4f(inverseViewRotation);
            putCamera(uniforms, camera);
            for (int index = 0; index < LevelSchedule.MAX_LEVELS; index++) {
                if (index < levels.length) {
                    putBox(uniforms, levels[index].box());
                } else {
                    uniforms.putIVec4(0, 0, 0, 1);
                }
            }
            for (int index = 0; index < LevelSchedule.MAX_LEVELS; index++) {
                if (index < levels.length) {
                    putBox(uniforms, levels[index].lightPlacement);
                } else {
                    uniforms.putIVec4(0, 0, 0, 1);
                }
            }
            putBounds(uniforms);
            for (int index = 0; index < LevelSchedule.MAX_LEVELS; index++) {
                DrawnLevel drawn = index < levels.length ? levels[index] : null;
                uniforms.putVec4(drawn == null ? NOTHING
                        : new Vector4f(drawn.size.x(), drawn.size.y(), drawn.size.z(), drawn.pages));
            }
            for (int index = 0; index < LevelSchedule.MAX_LEVELS; index++) {
                DrawnLevel drawn = index < levels.length ? levels[index] : null;
                uniforms.putVec4(drawn == null ? NOTHING : new Vector4f(drawn.atlas.tilesPerRow(), drawn.atlas.tileRows(),
                        drawn.column, atlas.lightSlotHeight() * drawn.lightFront));
            }
            for (int index = 0; index < LevelSchedule.MAX_LEVELS; index++) {
                DrawnLevel drawn = index < levels.length ? levels[index] : null;
                uniforms.putVec4(drawn == null ? NOTHING : new Vector4f(drawn.blend(shown), drawn.newest, drawn.brickColumn, 0f));
            }
            uniforms.putFloat(seconds).putInt(fogs.size()).putInt(levels.length).putFloat(0f);
            putSun(uniforms, level, view.partialTick());
            for (int slot = 0; slot < GasWorld.MAX_KINDS; slot++) {
                Medium medium = slotMedia[slot];
                uniforms.putVec4(medium == null ? NOTHING : color(medium.appearance()));
            }
            for (int slot = 0; slot < GasWorld.MAX_KINDS; slot++) {
                Medium medium = slotMedia[slot];
                uniforms.putVec4(medium == null ? NOTHING : light(medium.appearance()));
            }
            for (int slot = 0; slot < GasWorld.MAX_KINDS; slot++) {
                Medium medium = slotMedia[slot];
                if (medium == null) {
                    uniforms.putVec4(NOTHING);
                } else {
                    Appearance.Noise noise = medium.appearance().noise();
                    uniforms.putVec4(noise.scale(), noise.speed(), noise.strength(), medium.simulation().gravity() >= 0 ? 1f : -1f);
                }
            }
            for (int slot = 0; slot < GasWorld.MAX_KINDS; slot++) {
                Medium medium = slotMedia[slot];
                if (medium == null) {
                    uniforms.putVec4(NOTHING);
                } else {
                    float[] carried = world.carried(medium, view.partialTick());
                    uniforms.putVec4(carried[0], carried[1], 0f, 0f);
                }
            }
            for (int index = 0; index < MAX_FOGS; index++) {
                if (index < fogs.size()) {
                    Fog fog = fogs.get(index);
                    uniforms.putVec4((float) (fog.anchor().x - camera.x), (float) (fog.anchor().y - camera.y),
                            (float) (fog.anchor().z - camera.z), fog.shape().height());
                } else {
                    uniforms.putVec4(NOTHING);
                }
            }
            for (int index = 0; index < MAX_FOGS; index++) {
                if (index < fogs.size()) {
                    Fog fog = fogs.get(index);
                    switch (fog.shape()) {
                        case FogShape.Round round -> uniforms.putVec4(round.bottomRadius(), round.topRadius(), fog.edge(), 0f);
                        case FogShape.Box box -> uniforms.putVec4(box.width() / 2, box.depth() / 2, fog.edge(), 1f);
                    }
                } else {
                    uniforms.putVec4(NOTHING);
                }
            }
            for (int index = 0; index < MAX_FOGS; index++) {
                uniforms.putVec4(index < fogs.size() ? new Vector4f(fogs.get(index).bottomDensity(), fogs.get(index).topDensity(), 0f, 0f) : NOTHING);
            }
            for (int index = 0; index < MAX_FOGS; index++) {
                uniforms.putVec4(index < fogs.size() ? color(fogs.get(index).appearance()) : NOTHING);
            }
            for (int index = 0; index < MAX_FOGS; index++) {
                uniforms.putVec4(index < fogs.size() ? light(fogs.get(index).appearance()) : NOTHING);
            }
            for (int index = 0; index < MAX_FOGS; index++) {
                if (index < fogs.size()) {
                    Appearance.Noise noise = fogs.get(index).appearance().noise();
                    uniforms.putVec4(noise.scale(), noise.speed(), noise.strength(), 0f);
                } else {
                    uniforms.putVec4(NOTHING);
                }
            }
        });
    }

    /**
     * Must write exactly the fields of the GasTemporal block in gas_temporal.glsl, in its order. Then remembers this
     * frame's camera, for the next.
     *
     * @param continuing whether the other history target holds the frame just before this one, at this size
     */
    private void writeTemporalUniforms(LevelView view, Quality quality, boolean continuing) {
        Vec3 camera = view.camera().getPosition();
        // Taken apart in doubles: far from the world's origin a float cannot hold a position to a fraction of a block.
        double dx = camera.x - previousCameraX;
        double dy = camera.y - previousCameraY;
        double dz = camera.z - previousCameraZ;
        boolean valid = continuing && quality == previousQuality
                && dx * dx + dy * dy + dz * dz <= MAX_HISTORY_MOVE * MAX_HISTORY_MOVE;
        temporalUbo.write(uniforms -> uniforms
                .putMat4f(previousViewProjection)
                .putVec3((float) dx, (float) dy, (float) dz)
                .putFloat(options.historyWeight())
                .putInt(valid ? 1 : 0)
                .putInt(frameIndex));
        view.projection().mul(view.viewRotation(), previousViewProjection);
        previousCameraX = camera.x;
        previousCameraY = camera.y;
        previousCameraZ = camera.z;
        previousQuality = quality;
        frameIndex = (frameIndex + 1) % FRAME_INDEX_PERIOD;
    }

    private static Vector4f color(Appearance look) {
        return new Vector4f(look.red(), look.green(), look.blue(), look.opacity());
    }

    private static Vector4f light(Appearance look) {
        return new Vector4f(look.skyLight(), look.blockLight(), look.emissive(), look.forwardScatter());
    }

    /**
     * Must write exactly the fields of the GasGame block in gas_game.glsl, in its order. The game has turned its
     * fog off by the time it has drawn the level, so the fog is set up once more as the game sets it up for
     * terrain, read, and turned off again.
     */
    private void writeGameUniforms(LevelView view, ClientLevel level, float contentX, float contentY) {
        Minecraft minecraft = Minecraft.getInstance();
        Vec3 camera = view.camera().getPosition();
        // As the game asks it: with the camera's x and its height.
        boolean thickFog = level.effects().isFoggyAt(Mth.floor(camera.x), Mth.floor(camera.y))
                || minecraft.gui.getBossOverlay().shouldCreateWorldFog();
        FogRenderer.setupFog(view.camera(), FogRenderer.FogMode.FOG_TERRAIN,
                Math.max(minecraft.gameRenderer.getRenderDistance(), MIN_FOG_DISTANCE), thickFog, view.partialTick());
        FogRenderer.levelFogColor();
        float start = RenderSystem.getShaderFogStart();
        float end = RenderSystem.getShaderFogEnd();
        int shape = RenderSystem.getShaderFogShape().getIndex();
        float[] color = RenderSystem.getShaderFogColor();
        FogRenderer.setupNoFog();
        gameUbo.write(uniforms -> uniforms
                .putMat4f(view.projection())
                .putVec4(color[0], color[1], color[2], color[3])
                .putFloat(start).putFloat(end).putInt(shape)
                .putVec2(contentX, contentY));
    }

    /**
     * The camera as the block it is in and the way from the camera to that block's corner, kept apart so that
     * the shader's positions stay exact far from the world's origin.
     */
    private static void putCamera(Std140Writer uniforms, Vec3 camera) {
        int blockX = Mth.floor(camera.x);
        int blockY = Mth.floor(camera.y);
        int blockZ = Mth.floor(camera.z);
        uniforms.putIVec4(blockX, blockY, blockZ, 0);
        uniforms.putVec4((float) (blockX - camera.x), (float) (blockY - camera.y), (float) (blockZ - camera.z), 0f);
    }

    /** A level's corner in block coordinates, and the edge of one of its cells. */
    private static void putBox(Std140Writer uniforms, GridPlacement placement) {
        int cell = placement.cellSize();
        uniforms.putIVec4(placement.originX() * cell, placement.originY() * cell, placement.originZ() * cell, cell);
    }

    /** The box of blocks that all the gas of every level lies in: its low corner, then its high one. */
    private void putBounds(Std140Writer uniforms) {
        int[] low = {Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE};
        int[] high = {Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE};
        for (DrawnLevel drawn : levels) {
            GridPlacement placement = drawn.buffers[drawn.newest].placement;
            CellBox box = drawn.bricks.bounds().orElse(null);
            if (placement == null || box == null) {
                continue;
            }
            int cell = placement.cellSize();
            low[0] = Math.min(low[0], (placement.originX() + box.minX()) * cell);
            low[1] = Math.min(low[1], (placement.originY() + box.minY()) * cell);
            low[2] = Math.min(low[2], (placement.originZ() + box.minZ()) * cell);
            high[0] = Math.max(high[0], (placement.originX() + box.maxX()) * cell);
            high[1] = Math.max(high[1], (placement.originY() + box.maxY()) * cell);
            high[2] = Math.max(high[2], (placement.originZ() + box.maxZ()) * cell);
        }
        if (low[0] > high[0]) {
            // No brick is marked in any level: an empty box at the origin, which no ray is inside of.
            Arrays.fill(low, 0);
            Arrays.fill(high, 0);
        }
        uniforms.putIVec4(low[0], low[1], low[2], 0);
        uniforms.putIVec4(high[0], high[1], high[2], 0);
    }

    /**
     * The direction to whichever of sun and moon is above the horizon, the way the sky renderer places them:
     * straight up at angle 0, turning about the north-south axis, the moon opposite the sun.
     */
    private static void putSun(Std140Writer uniforms, ClientLevel level, float partialTick) {
        if (level.effects().skyType() == DimensionSpecialEffects.SkyType.NONE) {
            uniforms.putVec4(0f, 1f, 0f, 0f);
            return;
        }
        float sunAngle = level.getSunAngle(partialTick);
        boolean sunUp = Math.cos(sunAngle) >= 0;
        float angle = sunUp ? sunAngle : sunAngle + Mth.PI;
        float height = (float) Math.cos(angle);
        // Fades out as the body nears the horizon, and with rain.
        float strength = Math.clamp(height * 4f, 0f, 1f) * (1f - level.getRainLevel(partialTick)) * (sunUp ? 1f : MOON_STRENGTH);
        uniforms.putVec4((float) -Math.sin(angle), height, 0f, strength);
    }

    /**
     * Random bytes in red, and in green the red of the texel {@code NOISE_SHIFT} further on, wrapping round. To
     * the shader the texture is a stack of layers, each the one below moved along by that shift, so red and
     * green at one place are two layers one above the other: 3D noise from a single read of a 2D texture.
     */
    private static ByteBuffer noiseTexels() {
        byte[] values = new byte[NOISE_SIZE * NOISE_SIZE];
        new Random(NOISE_SEED).nextBytes(values);
        ByteBuffer texels = ByteBuffer.allocateDirect(values.length * 2);
        for (int y = 0; y < NOISE_SIZE; y++) {
            for (int x = 0; x < NOISE_SIZE; x++) {
                int above = (x + NOISE_SHIFT_X) % NOISE_SIZE + NOISE_SIZE * ((y + NOISE_SHIFT_Y) % NOISE_SIZE);
                texels.put(2 * (x + NOISE_SIZE * y), values[x + NOISE_SIZE * y]);
                texels.put(2 * (x + NOISE_SIZE * y) + 1, values[above]);
            }
        }
        return texels;
    }

    /** A colour target of the given size: the one passed in if it already is, a new one in its place otherwise. */
    private static Reduced sized(@Nullable Reduced target, int width, int height, GlTexture.Format format) {
        if (target != null && target.color.width() == width && target.color.height() == height) {
            return target;
        }
        if (target != null) {
            target.close();
        }
        GlTexture color = new GlTexture(format, width, height, true, false);
        return new Reduced(color, new GlFramebuffer(color.id(), width, height));
    }

    /** A colour target a fraction of the size of the screen: its texture, and what draws into it. */
    private record Reduced(GlTexture color, GlFramebuffer framebuffer) implements AutoCloseable {
        @Override
        public void close() {
            framebuffer.close();
            color.close();
        }
    }

    private static boolean inside(CellRect inner, CellRect outer) {
        return inner.x() >= outer.x() && inner.z() >= outer.z()
                && inner.x() + inner.width() <= outer.x() + outer.width() && inner.z() + inner.depth() <= outer.z() + outer.depth();
    }

    /**
     * Sends one simulation step of a level to its part of one of the two density textures, and the bricks of both of
     * its snapshots to its part of the brick texture.
     */
    private void take(DrawnLevel level, GasSnapshot snapshot, int index) {
        if (snapshot.pages() > pages) {
            grow(snapshot.pages());
        }
        LevelBuffer target = level.buffers[index];
        GlTexture texture = density[index];
        AtlasLayout layout = level.atlas;
        for (int page = 0; page < level.pages; page++) {
            for (int y = 0; y < level.size.y(); y++) {
                // Only the part of a slice that holds gas is sent, together with the part that held gas when this
                // texture was last written, which may need wiping.
                CellRect now = snapshot.sliceBounds(page, y);
                CellRect before = target.written[page][y];
                int tileX = level.column + layout.tileX(y);
                int tileY = page * layout.height() + layout.tileY(y);
                if (before != null && (now == null || !inside(before, now))) {
                    texture.upload(zeroTexels, 0, tileX + before.x(), tileY + before.z(), before.width(), before.depth());
                }
                if (now != null) {
                    texture.upload(snapshot.uploadBuffer(), snapshot.uploadOffset(page, y), tileX + now.x(), tileY + now.z(),
                            now.width(), now.depth());
                }
                if (before != null || now != null) {
                    target.written[page][y] = now;
                }
            }
        }
        target.placement = snapshot.placement();
        target.hasGas = snapshot.hasGas();
        target.bricks.set(snapshot.bricks());

        if (options.skipEmptySpace()) {
            level.bricks.set(level.buffers[0].bricks);
            level.bricks.include(level.buffers[1].bricks);
        } else {
            level.bricks.markAll();
        }
        putBricks(level);
    }

    private void putBricks(DrawnLevel level) {
        level.bricks.put(brickTexels);
        brickTexture.upload(brickTexels, level.brickColumn, 0, level.bricks.width(), level.bricks.height());
    }

    /**
     * Makes both density textures again with room for more pages. What they held is lost, for every level: each level's
     * two snapshots are written whole the next times, until then it shows no gas but what it takes next, and until
     * both have been written its newest is not blended with the other.
     */
    private void grow(int wanted) {
        pages = wanted;
        for (int index = 0; index < density.length; index++) {
            density[index].close();
            density[index] = new GlTexture(GlTexture.Format.RGBA8, atlas.width(), atlas.densityHeight(pages), true, false);
        }
        for (DrawnLevel level : levels) {
            level.pages = atlas.pages(level.index, pages);
            if (level.pages < pages && !pagesLogged) {
                pagesLogged = true;
                Volumetrics.LOGGER.warn("Level {} of the gas holds {} of its {} pages: the device's textures are not tall enough",
                        level.index, level.pages, pages);
            }
            level.buffers[0] = new LevelBuffer(level);
            level.buffers[1] = new LevelBuffer(level);
            level.bricks.clear();
            putBricks(level);
        }
    }

    /** What the renderer keeps of one drawn level of the cascade: where it lies in the shared textures, and its state. */
    private final class DrawnLevel {
        final int index;
        final GridSize size;
        final AtlasLayout atlas;
        /** The texel column the level starts at in the density and the light textures, and in the brick texture. */
        final int column;
        final int brickColumn;
        /** How many pages of the density textures the level holds. */
        int pages;
        /** What each of the two density textures holds of the level. */
        final LevelBuffer[] buffers = new LevelBuffer[2];
        /** Which of the two copies of its light the shader reads; a whole update is built in the other. */
        int lightFront;
        /** Where the level was when its light was last sent whole, or null if it never has been. */
        @Nullable GridPlacement lightPlacement;
        /** The bricks either of its two snapshots holds gas in. */
        final BrickMask bricks;
        /** Which of the two density textures holds the level's newest snapshot. */
        int newest;
        /** The base steps the newest snapshot's step began and ended at ({@link GasSnapshot#fromStep}); -1 before the first. */
        long fromStep = -1;
        long toStep = -1;
        /** Whether this frame blends the level's two snapshots; see where it is set. */
        boolean blends;

        DrawnLevel(int index) {
            this.index = index;
            this.size = GasRenderer.this.atlas.size(index);
            this.atlas = GasRenderer.this.atlas.atlas(index);
            this.column = GasRenderer.this.atlas.column(index);
            this.brickColumn = GasRenderer.this.atlas.brickColumn(index);
            this.pages = GasRenderer.this.atlas.pages(index, GasRenderer.this.pages);
            this.buffers[0] = new LevelBuffer(this);
            this.buffers[1] = new LevelBuffer(this);
            this.bricks = new BrickMask(size);
        }

        /** Where the gas of the newest step is, or the light's place before there is any gas. */
        GridPlacement box() {
            GridPlacement placement = buffers[newest].placement;
            return placement != null ? placement : lightPlacement;
        }

        /**
         * How far between its two snapshots the level is shown, 0 at the one before to 1 at the newest, at a moment in
         * base steps; 1 if it is not blended.
         */
        float blend(double shown) {
            if (!blends || toStep <= fromStep) {
                return 1f;
            }
            return (float) Math.clamp((shown - fromStep) / (toStep - fromStep), 0.0, 1.0);
        }
    }

    /** What one of the two density textures holds of a level, and what was last written to it there. */
    private static final class LevelBuffer {
        /** For each page and slice, the part of it that the texture holds gas in, or null if it holds none there. */
        final @Nullable CellRect[][] written;
        final BrickMask bricks;
        @Nullable GridPlacement placement;
        boolean hasGas;

        LevelBuffer(DrawnLevel level) {
            this.written = new CellRect[level.pages][level.size.y()];
            this.bricks = new BrickMask(level.size);
            // A new texture holds whatever was in its memory: the first step written to it must cover every slice.
            for (CellRect[] page : written) {
                Arrays.fill(page, CellRect.of(level.size));
            }
        }
    }
}
