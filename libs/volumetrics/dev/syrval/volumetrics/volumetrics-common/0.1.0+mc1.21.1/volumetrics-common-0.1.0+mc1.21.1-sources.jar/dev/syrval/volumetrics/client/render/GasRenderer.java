package dev.syrval.volumetrics.client.render;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.syrval.volumetrics.api.Appearance;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.client.LevelView;
import dev.syrval.volumetrics.client.render.gl.GlFramebuffer;
import dev.syrval.volumetrics.client.render.gl.GlProgram;
import dev.syrval.volumetrics.client.render.gl.GlTexture;
import dev.syrval.volumetrics.client.render.gl.GlUniformBuffer;
import dev.syrval.volumetrics.client.render.gl.ScreenPass;
import dev.syrval.volumetrics.client.render.gl.Std140Writer;
import dev.syrval.volumetrics.sim.AtlasLayout;
import dev.syrval.volumetrics.sim.BrickMask;
import dev.syrval.volumetrics.sim.CellBox;
import dev.syrval.volumetrics.sim.CellRect;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.world.GasSnapshot;
import dev.syrval.volumetrics.world.GasWorld;
import dev.syrval.volumetrics.world.LightGrid;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.server.packs.resources.ResourceProvider;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.jspecify.annotations.Nullable;

/**
 * Draws the gas of one {@link GasWorld}. Three passes: a ray march through the density atlases into a target a
 * fraction of the size of the screen, a filter that averages the grain of the march away, and a depth-aware
 * stretch of the result over the level. What this package asks of OpenGL it asks through the {@code gl} package.
 */
public final class GasRenderer implements AutoCloseable {
    /** March, filter, composite. */
    private static final int PASSES = 3;

    /** What the shaders call each window's textures: "Gas", then this, then what the texture is. The fine window first. */
    private static final String[] WINDOW_NAMES = {"", "Far"};
    /** Light slices the world scan has changed that are sent to the GPU in one frame, at most. */
    private static final int LIGHT_SLICES_PER_FRAME = 8;
    private static final float MOON_STRENGTH = 0.25f;
    private static final long TICKS_PER_HOUR = 72_000;
    private static final Vector4f NOTHING = new Vector4f(0f, 0f, 0f, 0f);
    /** Edge of the noise texture, and how far its green channel is moved along from its red; gas_march.fsh has the same. */
    private static final int NOISE_SIZE = 256;
    private static final int NOISE_SHIFT_X = 37;
    private static final int NOISE_SHIFT_Y = 239;
    private static final long NOISE_SEED = 0x766F6C756D65L;
    /** Below this the game takes the edge of what is drawn to be this far off, for its fog. */
    private static final float MIN_FOG_DISTANCE = 32f;

    private final GridSize size;
    private final AtlasLayout atlas;
    private final WindowTextures[] windows = new WindowTextures[GasWorld.WINDOWS];
    private final ByteBuffer lightSlice;
    private final ByteBuffer densityTexels;
    private final ByteBuffer brickTexels;
    private final boolean skipEmptySpace;
    private final ResourceProvider resources;
    /** The march, compiled for each quality setting, with that setting's step lengths, when it is first drawn with. */
    private final Map<Quality, GlProgram> march = new EnumMap<>(Quality.class);
    private final GlProgram filter;
    private final GlProgram composite;
    private final GlTexture noiseTexture;
    private final GlUniformBuffer gameUbo;
    private final ScreenPass pass = new ScreenPass();
    private final Matrix4f inverseViewRotation = new Matrix4f();
    private final @Nullable PassTimer timer;
    private @Nullable GlUniformBuffer frameUbo;
    private @Nullable Reduced marched;
    private @Nullable Reduced filtered;
    private @Nullable GlFramebuffer mainColor;
    /** Which of each window's two density textures holds the newest simulation step. */
    private int newest;
    private long newestNanos;
    private long uploadNanos;
    private long lightMoveNanos;

    /**
     * @param resources       where the shaders are read from
     * @param measureGpuTime  whether to time the passes on the GPU, for {@link #gpuNanos}
     * @param skipEmptySpace  false makes the march walk through every brick, gas or none: only for measuring
     *                        what skipping saves
     */
    public GasRenderer(GridSize size, ResourceProvider resources, boolean measureGpuTime, boolean skipEmptySpace) {
        this.size = size;
        this.atlas = AtlasLayout.of(size);
        this.resources = resources;
        for (int window = 0; window < windows.length; window++) {
            windows[window] = new WindowTextures(WINDOW_NAMES[window]);
        }
        this.lightSlice = ByteBuffer.allocateDirect(size.x() * size.z() * 2);
        this.densityTexels = ByteBuffer.allocateDirect(size.x() * size.z() * GasWorld.SLOTS);
        this.brickTexels = ByteBuffer.allocateDirect(windows[0].bricks.width() * windows[0].bricks.height());
        this.skipEmptySpace = skipEmptySpace;
        this.filter = new GlProgram(resources, "core/gas_filter.fsh", Map.of());
        this.composite = new GlProgram(resources, "core/gas_composite.fsh", Map.of());
        this.gameUbo = new GlUniformBuffer(filter.blockBytes("GasGame"));
        this.noiseTexture = new GlTexture(GlTexture.Format.RG8, NOISE_SIZE, NOISE_SIZE, true, true);
        noiseTexture.upload(noiseTexels(), 0, 0, NOISE_SIZE, NOISE_SIZE);
        this.timer = measureGpuTime && PassTimer.supported() ? new PassTimer(PASSES) : null;
    }

    /**
     * Nanoseconds of GPU time one of the three passes takes: 0 for the march, 1 for the filter, 2 for the
     * composite. 0 if not measured or not drawn yet.
     */
    public long gpuNanos(int pass) {
        return timer == null ? 0 : timer.nanos(pass);
    }

    /** Render-thread time it took to hand the last simulation step to the GPU, in nanoseconds. */
    public long uploadNanos() {
        return uploadNanos;
    }

    /**
     * Render-thread time it last took to send a window's light whole after the window had moved, in nanoseconds:
     * what crossing into another chunk section costs one frame, for each window that moved.
     */
    public long lightMoveNanos() {
        return lightMoveNanos;
    }

    /**
     * @param main     what the gas is drawn over
     * @param depth    the texture holding the depth of the level in it, which is not always the main target's own
     * @param lightmap the game's lightmap texture for the level: what it makes of a sky and a block light level at
     *                 this moment, which is what the gas is lit by
     * @param view     what the level in the main target was drawn with
     */
    public void render(GasWorld world, RenderTarget main, int depth, int lightmap, LevelView view, ClientLevel level, Quality quality) {
        takeNewestStep(world);
        uploadLight(world);
        boolean hasGas = false;
        boolean canBlend = true;
        for (WindowTextures window : windows) {
            // Nothing can be drawn before the first step has arrived, or before there is light to draw it by.
            if (window.density[newest].placement == null || window.lightPlacement == null) {
                return;
            }
            hasGas |= window.density[0].hasGas || window.density[1].hasGas;
            canBlend &= window.density[newest].placement.equals(window.density[1 - newest].placement);
        }
        // Nothing to draw costs nothing: no passes at all.
        if (!hasGas) {
            return;
        }

        float sinceStep = (System.nanoTime() - newestNanos) / 1e9f;
        float blend = canBlend ? Math.min(1f, sinceStep / world.stepSeconds()) : 1f;
        GlProgram marchProgram = march(quality);
        if (frameUbo == null) {
            frameUbo = new GlUniformBuffer(marchProgram.blockBytes("GasField"));
        }
        writeFrameUniforms(frameUbo, world, view, level, blend);
        writeGameUniforms(view, level);

        int width = Math.max(1, main.width / quality.marchDivisor());
        int height = Math.max(1, main.height / quality.marchDivisor());
        marched = sized(marched, width, height);
        filtered = sized(filtered, width, height);
        mainColor = GlFramebuffer.colorOnly(mainColor, main);

        boolean timing = timer != null && timer.begin();
        pass.begin();
        if (timing) {
            timer.mark();
        }
        marchProgram.setBlock("GasField", frameUbo);
        marchProgram.setBlock("GasGame", gameUbo);
        marchProgram.setTexture("DepthSampler", depth);
        marchProgram.setTexture("NoiseSampler", noiseTexture.id());
        marchProgram.setTexture("LightmapSampler", lightmap);
        for (WindowTextures window : windows) {
            // With nothing to blend from, the newest step stands in for the one before it.
            marchProgram.setTexture("Gas" + window.name + "DensitySampler", window.density[newest].texture.id());
            marchProgram.setTexture("Gas" + window.name + "PreviousDensitySampler", window.density[canBlend ? 1 - newest : newest].texture.id());
            marchProgram.setTexture("Gas" + window.name + "LightSampler", window.lightTexture.id());
            marchProgram.setTexture("Gas" + window.name + "BrickSampler", window.brickTexture.id());
        }
        pass.draw(marched.framebuffer, marchProgram, ScreenPass.Blend.NONE);
        if (timing) {
            timer.mark();
        }
        filter.setBlock("GasGame", gameUbo);
        filter.setTexture("GasSampler", marched.color.id());
        filter.setTexture("DepthSampler", depth);
        pass.draw(filtered.framebuffer, filter, ScreenPass.Blend.NONE);
        if (timing) {
            timer.mark();
        }
        // Colour only: the level's depth is read here, so it cannot also be attached to what is drawn into.
        // The march writes colour already multiplied by coverage.
        composite.setBlock("GasGame", gameUbo);
        composite.setTexture("GasSampler", filtered.color.id());
        composite.setTexture("DepthSampler", depth);
        pass.draw(mainColor, composite, ScreenPass.Blend.PREMULTIPLIED_ALPHA);
        if (timing) {
            timer.mark();
        }
        pass.end(main);
    }

    @Override
    public void close() {
        for (WindowTextures window : windows) {
            window.close();
        }
        march.values().forEach(GlProgram::close);
        filter.close();
        composite.close();
        noiseTexture.close();
        gameUbo.close();
        pass.close();
        if (frameUbo != null) {
            frameUbo.close();
        }
        if (marched != null) {
            marched.close();
        }
        if (filtered != null) {
            filtered.close();
        }
        if (mainColor != null) {
            mainColor.close();
        }
        if (timer != null) {
            timer.close();
        }
    }

    private GlProgram march(Quality quality) {
        return march.computeIfAbsent(quality, setting -> new GlProgram(resources, "core/gas_march.fsh", Map.of(
                "MIN_STEP_BLOCKS", Float.toString(setting.minStepBlocks()),
                "STEP_GROWTH", Float.toString(setting.stepGrowth()),
                "MAX_SAMPLES", Integer.toString(setting.maxSamples()))));
    }

    /** If the simulation has finished a step, sends it to the older of each window's two density textures. */
    private void takeNewestStep(GasWorld world) {
        List<GasSnapshot> snapshots = world.takeSnapshots();
        if (snapshots == null) {
            return;
        }
        long start = System.nanoTime();
        for (int window = 0; window < windows.length; window++) {
            windows[window].take(snapshots.get(window), 1 - newest);
        }
        world.recycle(snapshots);
        newest = 1 - newest;
        newestNanos = System.nanoTime();
        uploadNanos = newestNanos - start;
    }

    /**
     * Sends the light the world scan has changed. After a window has moved all of its light goes at once, with
     * the place it is now for: the shader reads light by that place and not by the gas's, which only follows
     * with the next simulation step.
     */
    private void uploadLight(GasWorld world) {
        int sent = 0;
        for (int window = 0; window < windows.length; window++) {
            LightGrid light = world.light(window);
            GridPlacement placement = world.placement(window);
            if (placement == null) {
                continue;
            }
            boolean whole = light.hasMoved();
            long start = System.nanoTime();
            for (int y = 0; y < size.y(); y++) {
                if (light.isSliceDirty(y) && (whole || sent < LIGHT_SLICES_PER_FRAME)) {
                    light.takeSlice(y, lightSlice);
                    windows[window].lightTexture.upload(lightSlice, atlas.tileX(y), atlas.tileY(y), size.x(), size.z());
                    sent += whole ? 0 : 1;
                }
            }
            if (whole) {
                light.allSlicesTaken();
                windows[window].lightPlacement = placement;
                lightMoveNanos = System.nanoTime() - start;
            }
        }
    }

    /** Must write exactly the fields of the GasField block in gas_field.glsl, in its order. */
    private void writeFrameUniforms(GlUniformBuffer buffer, GasWorld world, LevelView view, ClientLevel level, float blend) {
        view.viewRotation().invert(inverseViewRotation);
        float seconds = (level.getGameTime() % TICKS_PER_HOUR + view.partialTick()) / 20f;
        buffer.write(uniforms -> {
            uniforms.putMat4f(inverseViewRotation);
            putCamera(uniforms, view.camera().getPosition());
            for (WindowTextures window : windows) {
                putBox(uniforms, window.density[newest].placement);
            }
            for (WindowTextures window : windows) {
                putBox(uniforms, window.lightPlacement);
            }
            putBounds(uniforms);
            uniforms.putVec3(size.x(), size.y(), size.z()).putFloat(blend);
            uniforms.putVec2(atlas.tilesPerRow(), atlas.tileRows()).putFloat(seconds).putFloat(0f);
            putSun(uniforms, level, view.partialTick());
            for (int slot = 0; slot < GasWorld.SLOTS; slot++) {
                Medium medium = world.medium(slot);
                if (medium == null) {
                    uniforms.putVec4(NOTHING);
                } else {
                    Appearance look = medium.appearance();
                    uniforms.putVec4(look.red(), look.green(), look.blue(), look.opacity());
                }
            }
            for (int slot = 0; slot < GasWorld.SLOTS; slot++) {
                Medium medium = world.medium(slot);
                if (medium == null) {
                    uniforms.putVec4(NOTHING);
                } else {
                    Appearance look = medium.appearance();
                    uniforms.putVec4(look.skyLight(), look.blockLight(), look.emissive(), look.forwardScatter());
                }
            }
            for (int slot = 0; slot < GasWorld.SLOTS; slot++) {
                Medium medium = world.medium(slot);
                if (medium == null) {
                    uniforms.putVec4(NOTHING);
                } else {
                    Appearance.Noise noise = medium.appearance().noise();
                    uniforms.putVec4(noise.scale(), noise.speed(), noise.strength(), medium.simulation().gravity() >= 0 ? 1f : -1f);
                }
            }
            for (int slot = 0; slot < GasWorld.SLOTS; slot++) {
                Medium medium = world.medium(slot);
                if (medium == null) {
                    uniforms.putVec4(NOTHING);
                } else {
                    uniforms.putVec4(medium.simulation().driftX(), medium.simulation().driftZ(), 0f, 0f);
                }
            }
        });
    }

    /**
     * Must write exactly the fields of the GasGame block in gas_game.glsl, in its order. The game has turned its
     * fog off by the time it has drawn the level, so the fog is set up once more as the game sets it up for
     * terrain, read, and turned off again.
     */
    private void writeGameUniforms(LevelView view, ClientLevel level) {
        Minecraft minecraft = Minecraft.getInstance();
        Vec3 camera = view.camera().getPosition();
        // As the game asks it: with the camera's x and its height.
        boolean thickFog = level.effects().isFoggyAt(Mth.floor(camera.x), Mth.floor(camera.y))
                || minecraft.gui.getBossOverlay().shouldCreateWorldFog();
        FogRenderer.setupFog(view.camera(), FogRenderer.FogMode.FOG_TERRAIN,
                Math.max(minecraft.gameRenderer.getRenderDistance(), MIN_FOG_DISTANCE), thickFog, view.partialTick());
        FogRenderer.levelFogColor();
        float start = RenderSystem.getShaderFogStart();
        float end = RenderSystem.getShaderFogEnd();
        int shape = RenderSystem.getShaderFogShape().getIndex();
        float[] color = RenderSystem.getShaderFogColor();
        FogRenderer.setupNoFog();
        gameUbo.write(uniforms -> uniforms
                .putMat4f(view.projection())
                .putVec4(color[0], color[1], color[2], color[3])
                .putFloat(start).putFloat(end).putInt(shape));
    }

    /**
     * The camera as the block it is in and the way from the camera to that block's corner, kept apart so that
     * the shader's positions stay exact far from the world's origin.
     */
    private static void putCamera(Std140Writer uniforms, Vec3 camera) {
        int blockX = Mth.floor(camera.x);
        int blockY = Mth.floor(camera.y);
        int blockZ = Mth.floor(camera.z);
        uniforms.putIVec4(blockX, blockY, blockZ, 0);
        uniforms.putVec4((float) (blockX - camera.x), (float) (blockY - camera.y), (float) (blockZ - camera.z), 0f);
    }

    /** A window's corner in block coordinates, and the edge of one of its cells. */
    private static void putBox(Std140Writer uniforms, GridPlacement placement) {
        int cell = placement.cellSize();
        uniforms.putIVec4(placement.originX() * cell, placement.originY() * cell, placement.originZ() * cell, cell);
    }

    /** The box of blocks that all the gas of every window lies in: its low corner, then its high one. */
    private void putBounds(Std140Writer uniforms) {
        int[] low = {Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE};
        int[] high = {Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE};
        for (WindowTextures window : windows) {
            GridPlacement placement = window.density[newest].placement;
            CellBox box = window.bricks.bounds().orElse(null);
            if (box == null) {
                continue;
            }
            int cell = placement.cellSize();
            low[0] = Math.min(low[0], (placement.originX() + box.minX()) * cell);
            low[1] = Math.min(low[1], (placement.originY() + box.minY()) * cell);
            low[2] = Math.min(low[2], (placement.originZ() + box.minZ()) * cell);
            high[0] = Math.max(high[0], (placement.originX() + box.maxX()) * cell);
            high[1] = Math.max(high[1], (placement.originY() + box.maxY()) * cell);
            high[2] = Math.max(high[2], (placement.originZ() + box.maxZ()) * cell);
        }
        if (low[0] > high[0]) {
            // No brick is marked in any window: an empty box at the origin, which no ray is inside of.
            Arrays.fill(low, 0);
            Arrays.fill(high, 0);
        }
        uniforms.putIVec4(low[0], low[1], low[2], 0);
        uniforms.putIVec4(high[0], high[1], high[2], 0);
    }

    /**
     * The direction to whichever of sun and moon is above the horizon, the way the sky renderer places them:
     * straight up at angle 0, turning about the north-south axis, the moon opposite the sun.
     */
    private static void putSun(Std140Writer uniforms, ClientLevel level, float partialTick) {
        if (level.effects().skyType() == DimensionSpecialEffects.SkyType.NONE) {
            uniforms.putVec4(0f, 1f, 0f, 0f);
            return;
        }
        float sunAngle = level.getSunAngle(partialTick);
        boolean sunUp = Math.cos(sunAngle) >= 0;
        float angle = sunUp ? sunAngle : sunAngle + Mth.PI;
        float height = (float) Math.cos(angle);
        // Fades out as the body nears the horizon, and with rain.
        float strength = Math.clamp(height * 4f, 0f, 1f) * (1f - level.getRainLevel(partialTick)) * (sunUp ? 1f : MOON_STRENGTH);
        uniforms.putVec4((float) -Math.sin(angle), height, 0f, strength);
    }

    /**
     * Random bytes in red, and in green the red of the texel {@code NOISE_SHIFT} further on, wrapping round. To
     * the shader the texture is a stack of layers, each the one below moved along by that shift, so red and
     * green at one place are two layers one above the other: 3D noise from a single read of a 2D texture.
     */
    private static ByteBuffer noiseTexels() {
        byte[] values = new byte[NOISE_SIZE * NOISE_SIZE];
        new Random(NOISE_SEED).nextBytes(values);
        ByteBuffer texels = ByteBuffer.allocateDirect(values.length * 2);
        for (int y = 0; y < NOISE_SIZE; y++) {
            for (int x = 0; x < NOISE_SIZE; x++) {
                int above = (x + NOISE_SHIFT_X) % NOISE_SIZE + NOISE_SIZE * ((y + NOISE_SHIFT_Y) % NOISE_SIZE);
                texels.put(2 * (x + NOISE_SIZE * y), values[x + NOISE_SIZE * y]);
                texels.put(2 * (x + NOISE_SIZE * y) + 1, values[above]);
            }
        }
        return texels;
    }

    /** A colour target of the given size: the one passed in if it already is, a new one in its place otherwise. */
    private static Reduced sized(@Nullable Reduced target, int width, int height) {
        if (target != null && target.color.width() == width && target.color.height() == height) {
            return target;
        }
        if (target != null) {
            target.close();
        }
        GlTexture color = new GlTexture(GlTexture.Format.RGBA8, width, height, true, false);
        return new Reduced(color, new GlFramebuffer(color.id(), width, height));
    }

    /** A colour target a fraction of the size of the screen: its texture, and what draws into it. */
    private record Reduced(GlTexture color, GlFramebuffer framebuffer) implements AutoCloseable {
        @Override
        public void close() {
            framebuffer.close();
            color.close();
        }
    }

    /** What one window of the gas world has on the GPU. */
    private final class WindowTextures implements AutoCloseable {
        final String name;
        final DensityTexture[] density = {new DensityTexture(), new DensityTexture()};
        final GlTexture lightTexture = new GlTexture(GlTexture.Format.RG8, atlas.width(), atlas.height(), true, false);
        /** Where the window was when its light was last sent whole, or null if it never has been. */
        @Nullable GridPlacement lightPlacement;
        /** The bricks either of the two density textures holds gas in: the march blends the two, so it reads both. */
        final BrickMask bricks = new BrickMask(size);
        final GlTexture brickTexture = new GlTexture(GlTexture.Format.R8, bricks.width(), bricks.height(), false, false);

        WindowTextures(String name) {
            this.name = name;
        }

        /** Sends one simulation step to one of the two density textures, and the bricks of both to the brick texture. */
        void take(GasSnapshot snapshot, int index) {
            DensityTexture target = density[index];
            for (int y = 0; y < size.y(); y++) {
                // Only the part of a slice that holds gas is sent, together with the part that held gas when this
                // texture was last written, which may need wiping.
                CellRect now = snapshot.sliceBounds(y);
                CellRect before = target.written[y];
                CellRect area = now == null ? before : before == null ? now : now.union(before);
                if (area != null) {
                    snapshot.copySlice(y, area, densityTexels);
                    target.texture.upload(densityTexels, atlas.tileX(y) + area.x(), atlas.tileY(y) + area.z(), area.width(), area.depth());
                    target.written[y] = now;
                }
            }
            target.placement = snapshot.placement();
            target.hasGas = snapshot.hasGas();
            target.bricks.set(snapshot.bricks());

            if (skipEmptySpace) {
                bricks.set(density[0].bricks);
                bricks.include(density[1].bricks);
            } else {
                bricks.markAll();
            }
            bricks.put(brickTexels);
            brickTexture.upload(brickTexels, 0, 0, bricks.width(), bricks.height());
        }

        @Override
        public void close() {
            for (DensityTexture texture : density) {
                texture.texture.close();
            }
            lightTexture.close();
            brickTexture.close();
        }
    }

    /** One of a window's two density atlases, and what was last written to it. */
    private final class DensityTexture {
        final GlTexture texture = new GlTexture(GlTexture.Format.RGBA8, atlas.width(), atlas.height(), true, false);
        /** For each slice, the part of it that the texture holds gas in, or null if it holds none there. */
        final @Nullable CellRect[] written = new CellRect[size.y()];
        final BrickMask bricks = new BrickMask(size);
        @Nullable GridPlacement placement;
        boolean hasGas;

        DensityTexture() {
            // A new texture holds whatever was in its memory: the first step written to it must cover every slice.
            Arrays.fill(written, CellRect.of(size));
        }
    }
}
