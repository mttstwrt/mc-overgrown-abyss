package dev.syrval.volumetrics.sim;

/**
 * What pushes a kind of gas sideways at a moment: its own drift, the wind as far as it follows the wind, and its draft.
 * The engines move the gas by it and the renderer carries the gas's pattern by it, so both agree.
 */
public final class Push {
    /** The most the medium's drift, the wind and the draft together push, in blocks per second. */
    public static final float MAX = 16f;

    private Push() {}

    /**
     * Blocks per second east and south. Never more than {@link #MAX} when the wind or the draft adds anything; the
     * medium's own drift as it is when neither does.
     */
    public static Draft.Vector of(MediumProperties properties, int idHash, float windX, float windZ, long gameTicks) {
        MediumParams own = properties.params();
        float addX = properties.windResponse() * windX;
        float addZ = properties.windResponse() * windZ;
        if (properties.draft() != null) {
            Draft.Vector draft = Draft.at(idHash, gameTicks, properties.draft());
            addX += draft.x();
            addZ += draft.z();
        }
        if (addX == 0f && addZ == 0f) {
            return new Draft.Vector(own.driftX(), own.driftZ());
        }
        double x = own.driftX() + addX;
        double z = own.driftZ() + addZ;
        double length = Math.sqrt(x * x + z * z);
        if (length > MAX) {
            x *= MAX / length;
            z *= MAX / length;
        }
        return new Draft.Vector((float) x, (float) z);
    }
}
