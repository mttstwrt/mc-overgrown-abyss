package dev.syrval.volumetrics.client.render;

import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.client.render.gl.GlComputeProgram;
import dev.syrval.volumetrics.client.render.gl.GlTexture;
import dev.syrval.volumetrics.sim.BrickMask;
import dev.syrval.volumetrics.sim.CellBox;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.world.GasWorld;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;
import net.minecraft.server.packs.resources.ResourceProvider;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;
import org.lwjgl.opengl.GL11;

/**
 * A check that the compute layer works, not a simulation: one level of its own, around where the camera was when it
 * was first drawn, whose density a compute shader writes every frame as a pattern moving with time. The light and the
 * bricks are filled once from the CPU; no CPU copy of the density is made.
 */
final class ComputeTestFields implements GasFields {
    private static final String SHADER = "compute/field_test.comp";
    private static final GridSize SIZE = new GridSize(48, 32, 48);
    /** The compute shader's group: 8 x 8 cells of one slice. */
    private static final int GROUP = 8;

    private final LevelAtlas atlas;
    private final GlTexture[] density = new GlTexture[2];
    private final GlTexture lightTexture;
    private final GlTexture brickTexture;
    private final GlComputeProgram program;
    private final @Nullable Medium[] slotMedia = new Medium[GasWorld.MAX_KINDS];
    private final long startNanos = System.nanoTime();
    /** Where the level lies in the world, once the camera is known. */
    private @Nullable GridPlacement placement;
    private boolean noMediumLogged;

    /** @throws IllegalStateException if the compute shader does not compile or link */
    ComputeTestFields(ResourceProvider resources) {
        this.program = new GlComputeProgram(resources, SHADER, Map.of());
        int maxTextureSize = GL11.glGetInteger(GL11.GL_MAX_TEXTURE_SIZE);
        this.atlas = LevelAtlas.fit(List.of(SIZE), maxTextureSize, Long.MAX_VALUE);
        ByteBuffer zeros = ByteBuffer.allocateDirect(atlas.width() * atlas.densityHeight(1) * 4);
        for (int index = 0; index < density.length; index++) {
            density[index] = new GlTexture(GlTexture.Format.RGBA8, atlas.width(), atlas.densityHeight(1), true, false);
            // Both hold something known; the shader writes the first every frame, the other is never shown.
            density[index].upload(zeros, 0, 0, atlas.width(), atlas.densityHeight(1));
        }
        this.lightTexture = new GlTexture(GlTexture.Format.RG8, atlas.width(), atlas.lightHeight(), true, false);
        // Full sky light, no block light, in both copies.
        ByteBuffer light = ByteBuffer.allocateDirect(atlas.width() * atlas.lightHeight() * 2);
        for (int texel = 0; texel < atlas.width() * atlas.lightHeight(); texel++) {
            light.put(2 * texel, (byte) 255);
        }
        lightTexture.upload(light, 0, 0, atlas.width(), atlas.lightHeight());
        this.brickTexture = new GlTexture(GlTexture.Format.R8, atlas.brickWidth(), atlas.brickHeight(), false, false);
        // Every brick holds page 0.
        BrickMask bricks = new BrickMask(SIZE);
        bricks.markAll();
        ByteBuffer brickTexels = ByteBuffer.allocateDirect(SIZE.brickCount());
        bricks.put(brickTexels);
        brickTexture.upload(brickTexels, 0, 0, bricks.width(), bricks.height());
    }

    @Override
    public boolean prepare(GasWorld world, Vec3 camera) {
        if (placement == null) {
            placement = new GridPlacement(Mth.floor(camera.x) - SIZE.x() / 2, Mth.floor(camera.y) - SIZE.y() / 2,
                    Mth.floor(camera.z) - SIZE.z() / 2, 1);
        }
        if (slotMedia[0] == null) {
            slotMedia[0] = world.firstMedium();
            if (slotMedia[0] == null) {
                if (!noMediumLogged) {
                    noMediumLogged = true;
                    Volumetrics.LOGGER.warn("The compute_test field source has no kind of gas to draw: the gas world knows none");
                }
                return false;
            }
        }
        float seconds = (System.nanoTime() - startNanos) / 1e9f;
        int tilesPerRow = atlas.atlas(0).tilesPerRow();
        program.dispatch(density[0].id(), (SIZE.x() + GROUP - 1) / GROUP, (SIZE.z() + GROUP - 1) / GROUP, SIZE.y(), uniforms -> {
            uniforms.setInt4("Grid", SIZE.x(), SIZE.y(), SIZE.z(), tilesPerRow);
            uniforms.setInt4("Corner", atlas.column(0), 0, 0, 0);
            uniforms.setFloat("Time", seconds);
        });
        return true;
    }

    @Override
    public boolean hasGas() {
        return true;
    }

    @Override
    public FieldLevel[] levels() {
        return new FieldLevel[] {new FieldLevel(placement, placement, SIZE, 1, atlas.atlas(0), atlas.column(0), atlas.brickColumn(0), 0,
                1f, 0, placement, new CellBox(0, 0, 0, SIZE.x(), SIZE.y(), SIZE.z()))};
    }

    @Override
    public @Nullable Medium[] slotMedia() {
        return slotMedia;
    }

    @Override
    public GlTexture density(int index) {
        return density[index];
    }

    @Override
    public GlTexture light() {
        return lightTexture;
    }

    @Override
    public GlTexture bricks() {
        return brickTexture;
    }

    @Override
    public String pages() {
        return "1";
    }

    @Override
    public long uploadNanos() {
        return 0;
    }

    @Override
    public long lightMoveNanos() {
        return 0;
    }

    @Override
    public void setSkipEmptySpace(boolean skipEmptySpace) {}

    @Override
    public FieldSource source() {
        return FieldSource.COMPUTE_TEST;
    }

    @Override
    public void close() {
        program.close();
        for (GlTexture texture : density) {
            texture.close();
        }
        lightTexture.close();
        brickTexture.close();
    }
}
