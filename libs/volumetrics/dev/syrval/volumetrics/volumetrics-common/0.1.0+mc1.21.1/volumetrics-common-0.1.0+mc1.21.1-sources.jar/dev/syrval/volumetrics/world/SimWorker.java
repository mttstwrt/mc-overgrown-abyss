package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.ambient.AmbientState;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.api.MediumBuoyancy;
import dev.syrval.volumetrics.sim.Buoyancy;
import dev.syrval.volumetrics.sim.EngineWindow;
import dev.syrval.volumetrics.sim.GasField;
import dev.syrval.volumetrics.sim.GasStore;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.sim.SimEngine;
import dev.syrval.volumetrics.sim.SimEngines;
import dev.syrval.volumetrics.sim.Source;
import dev.syrval.volumetrics.sim.WindowInputs;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import net.minecraft.resources.ResourceLocation;
import org.jspecify.annotations.Nullable;

/**
 * Runs the simulation on a thread of its own, one step at a time. The game thread hands it where each window is and
 * the emitters made from code; the rest a step needs this thread keeps itself: what it knows of the world in each
 * window ({@link SimWindow}), written from the scans of chunk sections as they come back from the {@link ScanWorker},
 * and which kind of gas has which slot. Neither thread ever waits for the other. If a step is still running when the
 * next is due, that one is skipped and the gas simply moves a little slower: the next carries all there is, and the
 * scans wait in their queue.
 *
 * <p>Each window has one {@link GasField} that every kind of gas is stepped in, in turn, and keeps each kind
 * between steps in a {@link GasStore} of its own, which holds only the bricks with gas in them: so the memory a
 * window takes grows with how much gas there is, not with how many kinds.
 *
 * <p>Each kind of gas near the camera has a slot, which it keeps while anything gives it off or any of it is left.
 * After each step the light that has changed goes to the renderer as {@link LightUpdate}s, through a queue of their
 * own: a snapshot nobody took gives way to a newer one, but light that is never sent would be missing for good.
 */
final class SimWorker implements AutoCloseable {
    private static final int LIGHT_BYTES_PER_CELL = 2;
    /**
     * Bytes of light updates the renderer may leave untaken. Past this, a window's light goes as one whole update
     * instead of more slices, and the updates of it before are dropped.
     */
    private static final long MAX_PENDING_LIGHT_BYTES = 32L << 20;

    private final List<GridSize> sizes;
    private final int[] cellSizes;
    private final float stepSeconds;
    private final ScanResults scans;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "Volumetrics simulation");
        thread.setDaemon(true);
        return thread;
    });
    private final AtomicBoolean busy = new AtomicBoolean();
    private final AtomicReference<@Nullable List<GasSnapshot>> latest = new AtomicReference<>();
    private final ConcurrentLinkedQueue<List<GasSnapshot>> spare = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<LightUpdate> lightUpdates = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<ByteBuffer> spareLightSlices = new ConcurrentLinkedQueue<>();
    /** Bytes of the light updates in the queue: added to here, taken off by the renderer or when they are dropped. */
    private final AtomicLong pendingLightBytes = new AtomicLong();
    private final int lightSliceBytes;
    private volatile long lastStepNanos;
    private volatile int bricksHeld;
    private volatile int kindsInUse;
    private volatile int resultsWaiting;
    private final AtomicIntegerArray emitterCounts;
    /** The air that buoyant gas floats in, as the client thread last set it; null until it has. */
    private volatile @Nullable AmbientState ambient;
    /** The id of each medium of the level, which is how the server's settings name them. */
    private final Map<Medium, ResourceLocation> mediumIds;
    /** Changes to the emitters made from code, put on by the client thread and applied at the start of a step. */
    private final ConcurrentLinkedQueue<EmitterOp> emitterOps = new ConcurrentLinkedQueue<>();

    // Touched by the simulation thread only.
    private final SimWindow[] windows;
    /** For each window, what moves its gas. */
    private final SimEngine[] engines;
    private final EmitterIndex emitterIndex = new EmitterIndex();
    /** For each window, where its gases are stepped; made when first needed. */
    private final @Nullable GasField[] workspaces;
    /** For each window and slot, the gas of that kind there. */
    private final @Nullable GasStore[][] stores;
    private final @Nullable Medium[] slots = new Medium[GasWorld.MAX_KINDS];
    private final Map<Medium, Integer> slotOf = new HashMap<>();
    private boolean toldOfWaiting;
    /** How each medium was last logged as moving up and down. */
    private final Map<Medium, String> described = new HashMap<>();

    /**
     * @param sizes     the size of each window, the fine one first
     * @param cellSizes the edge of each window's cells, in blocks
     * @param scans     where the scans of chunk sections come from
     */
    SimWorker(List<GridSize> sizes, int[] cellSizes, float stepSeconds, ScanResults scans) {
        this(sizes, cellSizes, stepSeconds, scans, Map.of());
    }

    SimWorker(List<GridSize> sizes, int[] cellSizes, float stepSeconds, ScanResults scans, Map<Medium, ResourceLocation> mediumIds) {
        this(sizes, cellSizes, stepSeconds, scans, mediumIds, SimEngines.byName(SimEngines.DEFAULT));
    }

    /**
     * @param mediumIds the id of each medium that can be emitted, by identity, for the server's settings to name them
     * @param engine    makes the engine that moves the gas of each window
     */
    SimWorker(List<GridSize> sizes, int[] cellSizes, float stepSeconds, ScanResults scans, Map<Medium, ResourceLocation> mediumIds,
              SimEngine.Factory engine) {
        this.mediumIds = mediumIds;
        this.sizes = List.copyOf(sizes);
        this.cellSizes = cellSizes.clone();
        this.stepSeconds = stepSeconds;
        this.scans = scans;
        this.windows = new SimWindow[sizes.size()];
        this.engines = new SimEngine[sizes.size()];
        this.workspaces = new GasField[sizes.size()];
        this.stores = new GasStore[sizes.size()][GasWorld.MAX_KINDS];
        this.emitterCounts = new AtomicIntegerArray(sizes.size());
        int sliceCells = 0;
        for (int window = 0; window < sizes.size(); window++) {
            windows[window] = new SimWindow(sizes.get(window), cellSizes[window]);
            sliceCells = Math.max(sliceCells, sizes.get(window).x() * sizes.get(window).z());
        }
        for (int window = sizes.size() - 1; window >= 0; window--) {
            engines[window] = engine.create(sizes.get(window), cellSizes[window], window + 1 < sizes.size() ? engines[window + 1] : null);
        }
        this.lightSliceBytes = sliceCells * LIGHT_BYTES_PER_CELL;
    }

    /** What one step works from: every window, the fine one first. */
    record Request(List<WindowRequest> windows) {}

    /**
     * @param placement where the window is now
     * @param epoch     how many times the window had moved on the client thread by then
     * @param inputs    what the window is told from outside for this step
     */
    record WindowRequest(GridPlacement placement, int epoch, WindowInputs inputs) {
        WindowRequest(GridPlacement placement, int epoch) {
            this(placement, epoch, WindowInputs.NONE);
        }
    }

    /**
     * @param medium    the medium, which is also what its caches in the engine are keyed by
     * @param floats    whether the air moves it instead of a gravity of its own
     * @param buoyancy  how it floats; null if it does not, or the air is not known yet
     */
    private record MediumStep(int slot, Medium medium, List<Source> sources, boolean floats, @Nullable Buoyancy buoyancy) {}

    /** Sets the air that buoyant gas floats in, from the next step on. Any thread. */
    void setAmbient(AmbientState ambient) {
        this.ambient = ambient;
    }

    /** Starts a step unless one is running. */
    void submit(Request request) {
        if (!busy.compareAndSet(false, true)) {
            return;
        }
        executor.execute(() -> {
            try {
                step(request);
            } catch (RuntimeException e) {
                Volumetrics.LOGGER.error("Gas simulation step failed", e);
            } finally {
                busy.set(false);
            }
        });
    }

    /**
     * The newest finished step nobody has taken yet, one snapshot for each window, or null. Give it back with
     * {@link #recycle} when done.
     */
    @Nullable List<GasSnapshot> takeLatest() {
        return latest.getAndSet(null);
    }

    void recycle(List<GasSnapshot> snapshots) {
        spare.add(snapshots);
    }

    /** The oldest light update not yet taken, or null. Every one must be taken, in order. */
    @Nullable LightUpdate takeLightUpdate() {
        LightUpdate update = lightUpdates.poll();
        if (update != null) {
            pendingLightBytes.addAndGet(-bytes(update));
        }
        return update;
    }

    /** Gives back a buffer of a light update once it has been sent. */
    void recycleLightSlice(ByteBuffer slice) {
        spareLightSlices.add(slice);
    }

    /** Light updates not yet taken. Counts them one by one: for the statistics only. */
    int lightUpdatesWaiting() {
        return lightUpdates.size();
    }

    long lastStepNanos() {
        return lastStepNanos;
    }

    /** Bricks of gas held after the last step, every window and kind together: what the gas takes in memory. */
    int bricksHeld() {
        return bricksHeld;
    }

    /** How many slots held a kind of gas at the last step. */
    int kindsInUse() {
        return kindsInUse;
    }

    /** Emitters feeding a window at the last step, the ones made from code and those at blocks. */
    int emitterCount(int window) {
        return emitterCounts.get(window);
    }

    /** Where changes to the emitters made from code are put, to be applied by the next step. */
    ConcurrentLinkedQueue<EmitterOp> emitterOps() {
        return emitterOps;
    }

    /** Scans taken from the scan thread that wait for a step with their window where they were copied. */
    int resultsWaiting() {
        return resultsWaiting;
    }

    @Override
    public void close() {
        executor.shutdownNow();
    }

    private void step(Request request) {
        long start = System.nanoTime();
        for (int window = 0; window < windows.length; window++) {
            follow(window, request.windows().get(window));
        }
        takeScans();
        for (EmitterOp op; (op = emitterOps.poll()) != null; ) {
            emitterIndex.apply(op);
        }

        List<List<Emitter>> active = new ArrayList<>();
        for (int window = 0; window < windows.length; window++) {
            List<Emitter> feeding = new ArrayList<>();
            emitterIndex.gather(request.windows().get(window).placement(), sizes.get(window), feeding);
            windows[window].addEmittersTo(feeding);
            active.add(feeding);
            emitterCounts.set(window, feeding.size());
        }
        assignSlots(active);
        List<List<MediumStep>> media = new ArrayList<>();
        for (int window = 0; window < windows.length; window++) {
            media.add(mediumSteps(window, active.get(window)));
        }
        // Nothing giving off gas and none left over: there is nothing to step.
        if (!media.getFirst().isEmpty()) {
            stepGas(media, request);
        }
        publishLight();
        lastStepNanos = System.nanoTime() - start;
    }

    /** Moves a window, and its gas the other way, so that the gas stays where it was in the world. */
    private void follow(int window, WindowRequest request) {
        SimWindow sim = windows[window];
        GridPlacement previous = sim.placement();
        GridPlacement next = request.placement();
        sim.follow(next, request.epoch());
        if (previous == null || previous.equals(next)) {
            return;
        }
        int dx = next.originX() - previous.originX();
        int dy = next.originY() - previous.originY();
        int dz = next.originZ() - previous.originZ();
        for (GasStore store : stores[window]) {
            if (store != null) {
                store.shift(dx, dy, dz);
            }
        }
        engines[window].shift(dx, dy, dz);
    }

    /**
     * Writes the scans that have come back into their windows, in the order they came. A scan of a section copied
     * after a move this step does not make yet waits, and so does every later one of its window, keeping the order.
     */
    private void takeScans() {
        for (SimWindow sim : windows) {
            while (!sim.waiting().isEmpty() && sim.waiting().getFirst().epoch() <= sim.epoch()) {
                sim.apply(sim.waiting().removeFirst());
                scans.done();
            }
        }
        for (SectionResult result = scans.poll(); result != null; result = scans.poll()) {
            SimWindow sim = windows[result.window()];
            if (!sim.waiting().isEmpty() || result.epoch() > sim.epoch()) {
                sim.waiting().addLast(result);
            } else {
                sim.apply(result);
                scans.done();
            }
        }
        int waiting = 0;
        for (SimWindow sim : windows) {
            waiting += sim.waiting().size();
        }
        resultsWaiting = waiting;
    }

    /**
     * A medium keeps its slot while anything emits it and, after that, until its last gas has thinned away.
     * With every slot taken a new medium waits; it is not drawn until one frees up.
     */
    private void assignSlots(List<List<Emitter>> active) {
        Map<Medium, Boolean> emitted = new HashMap<>();
        for (List<Emitter> feeding : active) {
            for (Emitter emitter : feeding) {
                emitted.put(emitter.medium(), Boolean.TRUE);
            }
        }
        for (int slot = 0; slot < GasWorld.MAX_KINDS; slot++) {
            Medium medium = slots[slot];
            if (medium != null && !slotHasGas(slot) && !emitted.containsKey(medium)) {
                slots[slot] = null;
                slotOf.remove(medium);
                for (GasStore[] windowStores : stores) {
                    windowStores[slot] = null;
                }
            }
        }
        for (Medium medium : emitted.keySet()) {
            if (slotOf.containsKey(medium)) {
                continue;
            }
            int free = freeSlot();
            if (free < 0) {
                if (!toldOfWaiting) {
                    toldOfWaiting = true;
                    Volumetrics.LOGGER.warn("More than {} kinds of gas are near the camera; the rest wait until a kind is gone", GasWorld.MAX_KINDS);
                }
                continue;
            }
            slots[free] = medium;
            slotOf.put(medium, free);
        }
        kindsInUse = slotOf.size();
    }

    /** Whether any window holds gas of the slot's kind. */
    private boolean slotHasGas(int slot) {
        for (GasStore[] windowStores : stores) {
            GasStore store = windowStores[slot];
            if (store != null && !store.isEmpty()) {
                return true;
            }
        }
        return false;
    }

    /** The lowest free slot, so that the kinds in use take as few pages as they can; -1 if none is free. */
    private int freeSlot() {
        for (int slot = 0; slot < GasWorld.MAX_KINDS; slot++) {
            if (slots[slot] == null) {
                return slot;
            }
        }
        return -1;
    }

    /** Each slot in use, with the sources of its kind that feed the window. A kind that has no slot yet waits. */
    private List<MediumStep> mediumSteps(int window, List<Emitter> feeding) {
        List<List<Source>> sources = new ArrayList<>(GasWorld.MAX_KINDS);
        for (int slot = 0; slot < GasWorld.MAX_KINDS; slot++) {
            sources.add(null);
        }
        for (Emitter emitter : feeding) {
            Integer slot = slotOf.get(emitter.medium());
            if (slot != null) {
                List<Source> kind = sources.get(slot);
                if (kind == null) {
                    kind = new ArrayList<>();
                    sources.set(slot, kind);
                }
                kind.add(emitter.source());
            }
        }
        List<MediumStep> media = new ArrayList<>();
        for (int slot = 0; slot < GasWorld.MAX_KINDS; slot++) {
            Medium medium = slots[slot];
            if (medium != null) {
                List<Source> kind = sources.get(slot);
                List<Source> sourcesOfKind = kind == null ? List.of() : kind;
                AmbientState air = ambient;
                MediumBuoyancy buoyancy = buoyancyOf(medium, air);
                if (window == 0) {
                    describe(medium, buoyancy, air);
                }
                Buoyancy resolved = buoyancy == null || air == null ? null : buoyancy.resolve(air.profile(), air.buoyancySpeed());
                media.add(new MediumStep(slot, medium, sourcesOfKind, buoyancy != null, resolved));
            }
        }
        return media;
    }

    /** Logs how a medium moves up and down whenever that changes, so a setting can be seen to have taken. */
    private void describe(Medium medium, @Nullable MediumBuoyancy buoyancy, @Nullable AmbientState air) {
        String how;
        if (buoyancy == null) {
            how = "gravity " + medium.simulation().gravity();
        } else if (air == null) {
            how = "floats, but the air is not known yet";
        } else {
            Buoyancy resolved = buoyancy.resolve(air.profile(), air.buoyancySpeed());
            how = String.format(java.util.Locale.ROOT, "floats, density %.3f, settles at y %.1f, speed %.1f",
                    resolved.density(), air.profile().heightOf(resolved.density()), resolved.speed());
        }
        if (!how.equals(described.put(medium, how))) {
            ResourceLocation id = mediumIds.get(medium);
            Volumetrics.LOGGER.info("Gas {}: {}", id != null ? id : "made in code", how);
        }
    }

    /** The medium's own buoyancy or the one the server sets for it; the server's wins. Null for a gas with a gravity. */
    private @Nullable MediumBuoyancy buoyancyOf(Medium medium, @Nullable AmbientState air) {
        if (air != null) {
            ResourceLocation id = mediumIds.get(medium);
            MediumBuoyancy set = id == null ? null : air.media().get(id);
            if (set != null) {
                return set;
            }
        }
        return medium.buoyancy().orElse(null);
    }

    /** A number for the medium that is the same on every machine: the hash of its id. */
    private int idHash(Medium medium) {
        ResourceLocation id = mediumIds.get(medium);
        return id == null ? 0 : GasWorld.idHash(id);
    }

    private void stepGas(List<List<MediumStep>> media, Request request) {
        int held = 0;
        // Coarse windows first: a finer window takes what is at its edge from the next coarser one.
        for (int window = sizes.size() - 1; window >= 0; window--) {
            SimWindow sim = windows[window];
            GridPlacement placement = sim.placement();
            boolean[] used = new boolean[GasWorld.MAX_KINDS];
            List<EngineWindow.Kind> kinds = new ArrayList<>();
            for (MediumStep medium : media.get(window)) {
                int slot = medium.slot();
                used[slot] = true;
                GasStore store = stores[window][slot];
                if (store == null) {
                    store = new GasStore(sizes.get(window));
                    stores[window][slot] = store;
                }
                kinds.add(new EngineWindow.Kind(medium.medium(), medium.medium().properties(), idHash(medium.medium()), medium.floats(), medium.buoyancy(),
                        medium.sources(), store, window + 1 < sizes.size() ? stores[window + 1][slot] : null));
            }
            engines[window].step(new EngineWindow(placement, sim.occupancy(), workspace(window),
                    window + 1 < sizes.size() ? windows[window + 1].placement() : null, kinds), request.windows().get(window).inputs(), stepSeconds);
            for (EngineWindow.Kind kind : kinds) {
                held += kind.store().bricksHeld();
            }
            for (int slot = 0; slot < GasWorld.MAX_KINDS; slot++) {
                if (!used[slot]) {
                    stores[window][slot] = null;
                }
            }
        }
        bricksHeld = held;

        List<GasSnapshot> snapshots = spare.poll();
        if (snapshots == null) {
            snapshots = new ArrayList<>();
            for (int window = 0; window < sizes.size(); window++) {
                snapshots.add(new GasSnapshot(sizes.get(window), windows[window].placement()));
            }
        }
        for (int window = 0; window < sizes.size(); window++) {
            float[] full = new float[GasWorld.MAX_KINDS];
            for (MediumStep medium : media.get(window)) {
                full[medium.slot()] = medium.medium().simulation().maxDensity();
            }
            snapshots.get(window).write(windows[window].placement(), stores[window], full);
            snapshots.get(window).setMedia(slots);
        }
        List<GasSnapshot> unseen = latest.getAndSet(snapshots);
        if (unseen != null) {
            spare.add(unseen);
        }
    }

    /**
     * Hands the renderer each window's light that has changed: all of it after the window has moved, the first time,
     * or when the renderer has left too much untaken, and then without the updates of the window before it, which it
     * replaces; otherwise the slices that changed.
     */
    private void publishLight() {
        for (int window = 0; window < windows.length; window++) {
            SimWindow sim = windows[window];
            LightGrid light = sim.light();
            GridPlacement placement = sim.placement();
            if (placement == null) {
                continue;
            }
            int height = sizes.get(window).y();
            boolean whole = light.hasMoved();
            int count = whole ? height : light.dirtySlices();
            if (count == 0) {
                continue;
            }
            if (!whole && pendingLightBytes.get() + (long) count * lightSliceBytes > MAX_PENDING_LIGHT_BYTES) {
                whole = true;
                count = height;
            }
            if (whole) {
                dropLightUpdates(window);
            }
            int[] slices = new int[count];
            ByteBuffer[] buffers = new ByteBuffer[count];
            int taken = 0;
            for (int y = 0; y < height; y++) {
                if (whole || light.isSliceDirty(y)) {
                    ByteBuffer buffer = lightSlice();
                    light.takeSlice(y, buffer);
                    slices[taken] = y;
                    buffers[taken] = buffer;
                    taken++;
                }
            }
            if (whole) {
                light.allSlicesTaken();
            }
            LightUpdate update = new LightUpdate(window, placement, whole, slices, buffers);
            pendingLightBytes.addAndGet(bytes(update));
            lightUpdates.add(update);
        }
    }

    /** Takes back the updates of a window the renderer has not taken yet, which a whole update replaces. */
    private void dropLightUpdates(int window) {
        for (LightUpdate update : lightUpdates) {
            // The renderer may take it meanwhile; then it is the renderer's.
            if (update.window() == window && lightUpdates.remove(update)) {
                pendingLightBytes.addAndGet(-bytes(update));
                for (ByteBuffer buffer : update.buffers()) {
                    spareLightSlices.add(buffer);
                }
            }
        }
    }

    private ByteBuffer lightSlice() {
        ByteBuffer slice = spareLightSlices.poll();
        return slice != null ? slice : ByteBuffer.allocateDirect(lightSliceBytes);
    }

    private long bytes(LightUpdate update) {
        return (long) update.slices().length * lightSliceBytes;
    }

    private GasField workspace(int window) {
        GasField field = workspaces[window];
        if (field == null) {
            field = new GasField(sizes.get(window));
            workspaces[window] = field;
        }
        return field;
    }
}
