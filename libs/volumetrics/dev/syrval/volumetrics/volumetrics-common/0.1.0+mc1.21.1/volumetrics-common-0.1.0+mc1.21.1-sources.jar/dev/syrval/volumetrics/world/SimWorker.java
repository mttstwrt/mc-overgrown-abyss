package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.sim.GasField;
import dev.syrval.volumetrics.sim.GasStepper;
import dev.syrval.volumetrics.sim.GasStore;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.sim.MediumParams;
import dev.syrval.volumetrics.sim.Nesting;
import dev.syrval.volumetrics.sim.Occupancy;
import dev.syrval.volumetrics.sim.Source;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import org.jspecify.annotations.Nullable;

/**
 * Runs the simulation on a thread of its own, one step at a time. The game thread hands it everything a step
 * needs and later picks up the result; neither ever waits for the other. If a step is still running when the
 * next is due, that one is skipped and the gas simply moves a little slower.
 *
 * <p>Each window has one {@link GasField} that every kind of gas is stepped in, in turn, and keeps each kind
 * between steps in a {@link GasStore} of its own, which holds only the bricks with gas in them: so the memory a
 * window takes grows with how much gas there is, not with how many kinds.
 */
final class SimWorker implements AutoCloseable {
    /** Densities under this are dropped; a byte of the density texture cannot show them anyway. */
    private static final float MIN_DENSITY = 1f / 512f;

    private final List<GridSize> sizes;
    private final float stepSeconds;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "Volumetrics simulation");
        thread.setDaemon(true);
        return thread;
    });
    private final AtomicBoolean busy = new AtomicBoolean();
    private final AtomicReference<@Nullable List<GasSnapshot>> latest = new AtomicReference<>();
    private final ConcurrentLinkedQueue<List<GasSnapshot>> spare = new ConcurrentLinkedQueue<>();
    private volatile long lastStepNanos;
    private volatile int bricksHeld;

    // Touched by the simulation thread only.
    private final GasStepper stepper = new GasStepper(MIN_DENSITY);
    /** For each window, where its gases are stepped; made when first needed. */
    private final @Nullable GasField[] workspaces;
    /** For each window and slot, the gas of that kind there. */
    private final @Nullable GasStore[][] stores;
    private final @Nullable GridPlacement[] placements;

    /** @param sizes the size of each window, the fine one first */
    SimWorker(List<GridSize> sizes, float stepSeconds) {
        this.sizes = List.copyOf(sizes);
        this.stepSeconds = stepSeconds;
        this.workspaces = new GasField[sizes.size()];
        this.stores = new GasStore[sizes.size()][GasWorld.MAX_KINDS];
        this.placements = new GridPlacement[sizes.size()];
    }

    /** What one step works from: every window, the fine one first, each stepping the same media. */
    record Request(List<WindowStep> windows) {}

    /** The occupancy must not be changed once it has been passed in. */
    record WindowStep(GridPlacement placement, Occupancy occupancy, List<MediumStep> media) {}

    record MediumStep(int slot, MediumParams params, List<Source> sources) {}

    /** Starts a step unless one is running. */
    void submit(Request request) {
        if (!busy.compareAndSet(false, true)) {
            return;
        }
        executor.execute(() -> {
            try {
                step(request);
            } catch (RuntimeException e) {
                Volumetrics.LOGGER.error("Gas simulation step failed", e);
            } finally {
                busy.set(false);
            }
        });
    }

    /**
     * The newest finished step nobody has taken yet, one snapshot for each window, or null. Give it back with
     * {@link #recycle} when done.
     */
    @Nullable List<GasSnapshot> takeLatest() {
        return latest.getAndSet(null);
    }

    void recycle(List<GasSnapshot> snapshots) {
        spare.add(snapshots);
    }

    long lastStepNanos() {
        return lastStepNanos;
    }

    /** Bricks of gas held after the last step, every window and kind together: what the gas takes in memory. */
    int bricksHeld() {
        return bricksHeld;
    }

    @Override
    public void close() {
        executor.shutdownNow();
    }

    private void step(Request request) {
        long start = System.nanoTime();
        int held = 0;
        // Coarse windows first: a finer window takes what is at its edge from the next coarser one.
        for (int window = sizes.size() - 1; window >= 0; window--) {
            WindowStep step = request.windows().get(window);
            follow(window, step.placement());
            boolean[] used = new boolean[GasWorld.MAX_KINDS];
            for (MediumStep medium : step.media()) {
                int slot = medium.slot();
                used[slot] = true;
                GasStore store = stores[window][slot];
                if (store == null) {
                    store = new GasStore(sizes.get(window));
                    stores[window][slot] = store;
                }
                GasStore coarser = window + 1 < sizes.size() ? stores[window + 1][slot] : null;
                // Nothing given off here, none left here and none to come in at the edge: nothing can change.
                if (medium.sources().isEmpty() && store.isEmpty() && (coarser == null || coarser.isEmpty())) {
                    continue;
                }
                GasField field = workspace(window);
                store.loadInto(field);
                stepper.step(field, step.occupancy(), medium.params(), step.placement(), medium.sources(), stepSeconds);
                if (coarser != null) {
                    Nesting.edgeFromCoarse(field, step.placement(), step.occupancy(),
                            coarser, request.windows().get(window + 1).placement(), MIN_DENSITY);
                }
                store.takeFrom(field);
                held += store.bricksHeld();
            }
            for (int slot = 0; slot < GasWorld.MAX_KINDS; slot++) {
                if (!used[slot]) {
                    stores[window][slot] = null;
                }
            }
        }
        bricksHeld = held;

        List<GasSnapshot> snapshots = spare.poll();
        if (snapshots == null) {
            snapshots = new ArrayList<>();
            for (int window = 0; window < sizes.size(); window++) {
                snapshots.add(new GasSnapshot(sizes.get(window), request.windows().get(window).placement()));
            }
        }
        for (int window = 0; window < sizes.size(); window++) {
            WindowStep step = request.windows().get(window);
            float[] full = new float[GasWorld.MAX_KINDS];
            for (MediumStep medium : step.media()) {
                full[medium.slot()] = medium.params().maxDensity();
            }
            snapshots.get(window).write(step.placement(), stores[window], full);
        }
        List<GasSnapshot> unseen = latest.getAndSet(snapshots);
        if (unseen != null) {
            spare.add(unseen);
        }
        lastStepNanos = System.nanoTime() - start;
    }

    private GasField workspace(int window) {
        GasField field = workspaces[window];
        if (field == null) {
            field = new GasField(sizes.get(window));
            workspaces[window] = field;
        }
        return field;
    }

    /** Moves a window's gas the other way when the window moves, so it stays where it was in the world. */
    private void follow(int window, GridPlacement next) {
        GridPlacement previous = placements[window];
        placements[window] = next;
        if (previous == null || previous.equals(next)) {
            return;
        }
        for (GasStore store : stores[window]) {
            if (store != null) {
                store.shift(next.originX() - previous.originX(), next.originY() - previous.originY(), next.originZ() - previous.originZ());
            }
        }
    }
}
