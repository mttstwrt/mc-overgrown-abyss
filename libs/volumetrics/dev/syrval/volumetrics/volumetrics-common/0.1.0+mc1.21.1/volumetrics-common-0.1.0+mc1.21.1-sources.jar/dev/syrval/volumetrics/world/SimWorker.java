package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.ambient.AmbientState;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.api.MediumBuoyancy;
import dev.syrval.volumetrics.sim.Buoyancy;
import dev.syrval.volumetrics.sim.EngineWindow;
import dev.syrval.volumetrics.sim.GasField;
import dev.syrval.volumetrics.sim.GasStore;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.sim.LevelSchedule;
import dev.syrval.volumetrics.sim.OuterLevel;
import dev.syrval.volumetrics.sim.SimEngine;
import dev.syrval.volumetrics.sim.SimEngines;
import dev.syrval.volumetrics.sim.StepStats;
import dev.syrval.volumetrics.sim.Source;
import dev.syrval.volumetrics.sim.WindowInputs;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReferenceArray;
import net.minecraft.resources.ResourceLocation;
import org.jspecify.annotations.Nullable;

/**
 * Runs the simulation on a thread of its own, one step at a time. The game thread hands it where each window is and
 * the emitters made from code; the rest a step needs this thread keeps itself: what it knows of the world in each
 * window ({@link SimWindow}), written from the scans of chunk sections as they come back from the {@link ScanWorker},
 * and which kind of gas has which slot. Neither thread ever waits for the other. If a step is still running when the
 * next is due, that one is skipped and the gas simply moves a little slower: the next carries all there is, and the
 * scans wait in their queue.
 *
 * <p>Each window has one {@link GasField} that every kind of gas is stepped in, in turn, and keeps each kind
 * between steps in a {@link GasStore} of its own, which holds only the bricks with gas in them: so the memory a
 * window takes grows with how much gas there is, not with how many kinds.
 *
 * <p>The windows are the levels of a cascade, the finest first, each stepped as {@link LevelSchedule} says: level k
 * every 2^k base steps, by 2^k base steps at once, the coarser levels first. Each level hands the renderer a snapshot
 * of its own whenever it steps, which says the base steps it went from and to.
 *
 * <p>Each kind of gas near the camera has a slot, which it keeps while anything gives it off or any of it is left.
 * After each step the light that has changed goes to the renderer as {@link LightUpdate}s, through a queue of their
 * own: a snapshot nobody took gives way to a newer one, but light that is never sent would be missing for good.
 */
final class SimWorker implements AutoCloseable {
    private static final int LIGHT_BYTES_PER_CELL = 2;
    /**
     * Bytes of light updates the renderer may leave untaken. Past this, a window's light goes as one whole update
     * instead of more slices, and the updates of it before are dropped.
     */
    private static final long MAX_PENDING_LIGHT_BYTES = 32L << 20;

    private final List<GridSize> sizes;
    private final int[] cellSizes;
    /** Seconds of a base step: level 0's step. */
    private final float stepSeconds;
    private final ScanResults scans;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "Volumetrics simulation");
        thread.setDaemon(true);
        return thread;
    });
    private final AtomicBoolean busy = new AtomicBoolean();
    /** By level: its newest snapshot nobody has taken yet, or null. */
    private final AtomicReferenceArray<@Nullable GasSnapshot> latest;
    /** By level: snapshots given back, to be written again. */
    private final List<ConcurrentLinkedQueue<GasSnapshot>> spare = new ArrayList<>();
    private final ConcurrentLinkedQueue<LightUpdate> lightUpdates = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<ByteBuffer> spareLightSlices = new ConcurrentLinkedQueue<>();
    /** Bytes of the light updates in the queue: added to here, taken off by the renderer or when they are dropped. */
    private final AtomicLong pendingLightBytes = new AtomicLong();
    private final int lightSliceBytes;
    private volatile long lastStepNanos;
    private volatile int bricksHeld;
    private volatile int kindsInUse;
    private volatile int resultsWaiting;
    private final AtomicIntegerArray emitterCounts;
    private final WindowStepStats.Recorder[] stepStats;
    /** The air that buoyant gas floats in, as the client thread last set it; null until it has. */
    private volatile @Nullable AmbientState ambient;
    /** The id of each medium of the level, which is how the server's settings name them. */
    private final Map<Medium, ResourceLocation> mediumIds;
    /** Changes to the emitters made from code, put on by the client thread and applied at the start of a step. */
    private final ConcurrentLinkedQueue<EmitterOp> emitterOps = new ConcurrentLinkedQueue<>();

    // Touched by the simulation thread only.
    private final SimWindow[] windows;
    /** For each window, what moves its gas. */
    private final SimEngine[] engines;
    private final EmitterIndex emitterIndex = new EmitterIndex();
    /** For each window, where its gases are stepped; made when first needed. */
    private final @Nullable GasField[] workspaces;
    /** For each window and slot, the gas of that kind there. */
    private final @Nullable GasStore[][] stores;
    /** For each window and slot, its gas as the next finer window reads it at its edge; made when first needed. */
    private final @Nullable OuterLevel[][] outer;
    /** The base step the next step is: how many steps have run. */
    private long baseStep;
    private final @Nullable Medium[] slots = new Medium[GasWorld.MAX_KINDS];
    private final Map<Medium, Integer> slotOf = new HashMap<>();
    private boolean toldOfWaiting;
    /** How each medium was last logged as moving up and down. */
    private final Map<Medium, String> described = new HashMap<>();

    /**
     * @param sizes     the size of each window, the fine one first
     * @param cellSizes the edge of each window's cells, in blocks
     * @param scans     where the scans of chunk sections come from
     */
    SimWorker(List<GridSize> sizes, int[] cellSizes, float stepSeconds, ScanResults scans) {
        this(sizes, cellSizes, stepSeconds, scans, Map.of());
    }

    SimWorker(List<GridSize> sizes, int[] cellSizes, float stepSeconds, ScanResults scans, Map<Medium, ResourceLocation> mediumIds) {
        this(sizes, cellSizes, stepSeconds, scans, mediumIds, SimEngines.byName(SimEngines.DEFAULT));
    }

    /**
     * @param mediumIds the id of each medium that can be emitted, by identity, for the server's settings to name them
     * @param engine    makes the engine that moves the gas of each window
     */
    SimWorker(List<GridSize> sizes, int[] cellSizes, float stepSeconds, ScanResults scans, Map<Medium, ResourceLocation> mediumIds,
              SimEngine.Factory engine) {
        this.mediumIds = mediumIds;
        this.sizes = List.copyOf(sizes);
        this.cellSizes = cellSizes.clone();
        this.stepSeconds = stepSeconds;
        this.scans = scans;
        this.windows = new SimWindow[sizes.size()];
        this.engines = new SimEngine[sizes.size()];
        this.workspaces = new GasField[sizes.size()];
        this.stores = new GasStore[sizes.size()][GasWorld.MAX_KINDS];
        this.outer = new OuterLevel[sizes.size()][GasWorld.MAX_KINDS];
        this.latest = new AtomicReferenceArray<>(sizes.size());
        for (int window = 0; window < sizes.size(); window++) {
            spare.add(new ConcurrentLinkedQueue<>());
        }
        this.emitterCounts = new AtomicIntegerArray(sizes.size());
        this.stepStats = new WindowStepStats.Recorder[sizes.size()];
        for (int window = 0; window < stepStats.length; window++) {
            stepStats[window] = new WindowStepStats.Recorder();
        }
        int sliceCells = 0;
        for (int window = 0; window < sizes.size(); window++) {
            windows[window] = new SimWindow(sizes.get(window), cellSizes[window]);
            sliceCells = Math.max(sliceCells, sizes.get(window).x() * sizes.get(window).z());
        }
        for (int window = sizes.size() - 1; window >= 0; window--) {
            engines[window] = engine.create(sizes.get(window), cellSizes[window], window + 1 < sizes.size() ? engines[window + 1] : null);
        }
        this.lightSliceBytes = sliceCells * LIGHT_BYTES_PER_CELL;
    }

    /** What one step works from: every window, the fine one first. */
    record Request(List<WindowRequest> windows) {}

    /**
     * @param placement where the window is now
     * @param epoch     how many times the window had moved on the client thread by then
     * @param inputs    what the window is told from outside for this step
     */
    record WindowRequest(GridPlacement placement, int epoch, WindowInputs inputs) {
        WindowRequest(GridPlacement placement, int epoch) {
            this(placement, epoch, WindowInputs.NONE);
        }
    }

    /**
     * @param medium    the medium, which is also what its caches in the engine are keyed by
     * @param floats    whether the air moves it instead of a gravity of its own
     * @param buoyancy  how it floats; null if it does not, or the air is not known yet
     */
    private record MediumStep(int slot, Medium medium, List<Source> sources, boolean floats, @Nullable Buoyancy buoyancy) {}

    /** Sets the air that buoyant gas floats in, from the next step on. Any thread. */
    void setAmbient(AmbientState ambient) {
        this.ambient = ambient;
    }

    /** Starts a step unless one is running. */
    void submit(Request request) {
        if (!busy.compareAndSet(false, true)) {
            return;
        }
        executor.execute(() -> {
            try {
                step(request);
            } catch (RuntimeException e) {
                Volumetrics.LOGGER.error("Gas simulation step failed", e);
            } finally {
                busy.set(false);
            }
        });
    }

    /**
     * The window's newest snapshot nobody has taken yet, or null: one comes each time the window (level) steps. Give it
     * back with {@link #recycle} when done.
     */
    @Nullable GasSnapshot takeLatest(int window) {
        return latest.getAndSet(window, null);
    }

    void recycle(int window, GasSnapshot snapshot) {
        spare.get(window).add(snapshot);
    }

    /** The oldest light update not yet taken, or null. Every one must be taken, in order. */
    @Nullable LightUpdate takeLightUpdate() {
        LightUpdate update = lightUpdates.poll();
        if (update != null) {
            pendingLightBytes.addAndGet(-bytes(update));
        }
        return update;
    }

    /** Gives back a buffer of a light update once it has been sent. */
    void recycleLightSlice(ByteBuffer slice) {
        spareLightSlices.add(slice);
    }

    /** Light updates not yet taken. Counts them one by one: for the statistics only. */
    int lightUpdatesWaiting() {
        return lightUpdates.size();
    }

    /** A window's recent step times and last brick counts; see {@link WindowStepStats}. */
    WindowStepStats stepStats(int window) {
        return stepStats[window].stats();
    }

    long lastStepNanos() {
        return lastStepNanos;
    }

    /** Bricks of gas held after the last step, every window and kind together: what the gas takes in memory. */
    int bricksHeld() {
        return bricksHeld;
    }

    /** How many slots held a kind of gas at the last step. */
    int kindsInUse() {
        return kindsInUse;
    }

    /** Emitters feeding a window at the last step, the ones made from code and those at blocks. */
    int emitterCount(int window) {
        return emitterCounts.get(window);
    }

    /** Where changes to the emitters made from code are put, to be applied by the next step. */
    ConcurrentLinkedQueue<EmitterOp> emitterOps() {
        return emitterOps;
    }

    /** Scans taken from the scan thread that wait for a step with their window where they were copied. */
    int resultsWaiting() {
        return resultsWaiting;
    }

    @Override
    public void close() {
        executor.shutdownNow();
    }

    private void step(Request request) {
        long start = System.nanoTime();
        long step = baseStep++;
        for (int window = 0; window < windows.length; window++) {
            follow(window, request.windows().get(window));
        }
        takeScans();
        for (EmitterOp op; (op = emitterOps.poll()) != null; ) {
            emitterIndex.apply(op);
        }

        List<List<Emitter>> active = new ArrayList<>();
        for (int window = 0; window < windows.length; window++) {
            List<Emitter> feeding = new ArrayList<>();
            emitterIndex.gather(request.windows().get(window).placement(), sizes.get(window), feeding);
            windows[window].addEmittersTo(feeding);
            active.add(feeding);
            emitterCounts.set(window, feeding.size());
        }
        assignSlots(active);
        List<List<MediumStep>> media = new ArrayList<>();
        for (int window = 0; window < windows.length; window++) {
            media.add(mediumSteps(window, active.get(window)));
        }
        // Nothing giving off gas and none left over: there is nothing to step.
        if (!media.getFirst().isEmpty()) {
            stepGas(media, request, step);
        }
        publishLight();
        lastStepNanos = System.nanoTime() - start;
    }

    /** Moves a window, and its gas the other way, so that the gas stays where it was in the world. */
    private void follow(int window, WindowRequest request) {
        SimWindow sim = windows[window];
        GridPlacement previous = sim.placement();
        GridPlacement next = request.placement();
        sim.follow(next, request.epoch());
        if (previous == null || previous.equals(next)) {
            return;
        }
        int dx = next.originX() - previous.originX();
        int dy = next.originY() - previous.originY();
        int dz = next.originZ() - previous.originZ();
        for (GasStore store : stores[window]) {
            if (store != null) {
                store.shift(dx, dy, dz);
            }
        }
        engines[window].shift(dx, dy, dz);
    }

    /**
     * Writes the scans that have come back into their windows, in the order they came. A scan of a section copied
     * after a move this step does not make yet waits, and so does every later one of its window, keeping the order.
     */
    private void takeScans() {
        for (SimWindow sim : windows) {
            while (!sim.waiting().isEmpty() && sim.waiting().getFirst().epoch() <= sim.epoch()) {
                sim.apply(sim.waiting().removeFirst());
                scans.done();
            }
        }
        for (SectionResult result = scans.poll(); result != null; result = scans.poll()) {
            SimWindow sim = windows[result.window()];
            if (!sim.waiting().isEmpty() || result.epoch() > sim.epoch()) {
                sim.waiting().addLast(result);
            } else {
                sim.apply(result);
                scans.done();
            }
        }
        int waiting = 0;
        for (SimWindow sim : windows) {
            waiting += sim.waiting().size();
        }
        resultsWaiting = waiting;
    }

    /**
     * A medium keeps its slot while anything emits it and, after that, until its last gas has thinned away.
     * With every slot taken a new medium waits; it is not drawn until one frees up.
     */
    private void assignSlots(List<List<Emitter>> active) {
        Map<Medium, Boolean> emitted = new HashMap<>();
        for (List<Emitter> feeding : active) {
            for (Emitter emitter : feeding) {
                emitted.put(emitter.medium(), Boolean.TRUE);
            }
        }
        for (int slot = 0; slot < GasWorld.MAX_KINDS; slot++) {
            Medium medium = slots[slot];
            if (medium != null && !slotHasGas(slot) && !emitted.containsKey(medium)) {
                slots[slot] = null;
                slotOf.remove(medium);
                for (GasStore[] windowStores : stores) {
                    windowStores[slot] = null;
                }
            }
        }
        for (Medium medium : emitted.keySet()) {
            if (slotOf.containsKey(medium)) {
                continue;
            }
            int free = freeSlot();
            if (free < 0) {
                if (!toldOfWaiting) {
                    toldOfWaiting = true;
                    Volumetrics.LOGGER.warn("More than {} kinds of gas are near the camera; the rest wait until a kind is gone", GasWorld.MAX_KINDS);
                }
                continue;
            }
            slots[free] = medium;
            slotOf.put(medium, free);
        }
        kindsInUse = slotOf.size();
    }

    /** Whether any window holds gas of the slot's kind. */
    private boolean slotHasGas(int slot) {
        for (GasStore[] windowStores : stores) {
            GasStore store = windowStores[slot];
            if (store != null && !store.isEmpty()) {
                return true;
            }
        }
        return false;
    }

    /** The lowest free slot, so that the kinds in use take as few pages as they can; -1 if none is free. */
    private int freeSlot() {
        for (int slot = 0; slot < GasWorld.MAX_KINDS; slot++) {
            if (slots[slot] == null) {
                return slot;
            }
        }
        return -1;
    }

    /** Each slot in use, with the sources of its kind that feed the window. A kind that has no slot yet waits. */
    private List<MediumStep> mediumSteps(int window, List<Emitter> feeding) {
        List<List<Source>> sources = new ArrayList<>(GasWorld.MAX_KINDS);
        for (int slot = 0; slot < GasWorld.MAX_KINDS; slot++) {
            sources.add(null);
        }
        for (Emitter emitter : feeding) {
            Integer slot = slotOf.get(emitter.medium());
            if (slot != null) {
                List<Source> kind = sources.get(slot);
                if (kind == null) {
                    kind = new ArrayList<>();
                    sources.set(slot, kind);
                }
                kind.add(emitter.source());
            }
        }
        List<MediumStep> media = new ArrayList<>();
        for (int slot = 0; slot < GasWorld.MAX_KINDS; slot++) {
            Medium medium = slots[slot];
            if (medium != null) {
                List<Source> kind = sources.get(slot);
                List<Source> sourcesOfKind = kind == null ? List.of() : kind;
                AmbientState air = ambient;
                MediumBuoyancy buoyancy = buoyancyOf(medium, air);
                if (window == 0) {
                    describe(medium, buoyancy, air);
                }
                Buoyancy resolved = buoyancy == null || air == null ? null : buoyancy.resolve(air.profile(), air.buoyancySpeed());
                media.add(new MediumStep(slot, medium, sourcesOfKind, buoyancy != null, resolved));
            }
        }
        return media;
    }

    /** Logs how a medium moves up and down whenever that changes, so a setting can be seen to have taken. */
    private void describe(Medium medium, @Nullable MediumBuoyancy buoyancy, @Nullable AmbientState air) {
        String how;
        if (buoyancy == null) {
            how = "gravity " + medium.simulation().gravity();
        } else if (air == null) {
            how = "floats, but the air is not known yet";
        } else {
            Buoyancy resolved = buoyancy.resolve(air.profile(), air.buoyancySpeed());
            how = String.format(java.util.Locale.ROOT, "floats, density %.3f, settles at y %.1f, speed %.1f",
                    resolved.density(), air.profile().heightOf(resolved.density()), resolved.speed());
        }
        if (!how.equals(described.put(medium, how))) {
            ResourceLocation id = mediumIds.get(medium);
            Volumetrics.LOGGER.info("Gas {}: {}", id != null ? id : "made in code", how);
        }
    }

    /** The medium's own buoyancy or the one the server sets for it; the server's wins. Null for a gas with a gravity. */
    private @Nullable MediumBuoyancy buoyancyOf(Medium medium, @Nullable AmbientState air) {
        if (air != null) {
            ResourceLocation id = mediumIds.get(medium);
            MediumBuoyancy set = id == null ? null : air.media().get(id);
            if (set != null) {
                return set;
            }
        }
        return medium.buoyancy().orElse(null);
    }

    /** A number for the medium that is the same on every machine: the hash of its id. */
    private int idHash(Medium medium) {
        ResourceLocation id = mediumIds.get(medium);
        return id == null ? 0 : GasWorld.idHash(id);
    }

    /** Steps the levels due at base step {@code step}, the coarsest first, and hands each its snapshot. */
    private void stepGas(List<List<MediumStep>> media, Request request, long step) {
        long[] engineNanos = new long[sizes.size()];
        StepStats[] counts = new StepStats[sizes.size()];
        boolean[] stepped = new boolean[sizes.size()];
        // Coarse windows first: a finer window takes what is at its edge from the next coarser one.
        for (int window = sizes.size() - 1; window >= 0; window--) {
            if (!LevelSchedule.steps(window, step)) {
                continue;
            }
            stepped[window] = true;
            SimWindow sim = windows[window];
            GridPlacement placement = sim.placement();
            boolean[] used = new boolean[GasWorld.MAX_KINDS];
            List<EngineWindow.Kind> kinds = new ArrayList<>();
            for (MediumStep medium : media.get(window)) {
                int slot = medium.slot();
                used[slot] = true;
                GasStore store = stores[window][slot];
                if (store == null) {
                    store = new GasStore(sizes.get(window));
                    stores[window][slot] = store;
                }
                kinds.add(new EngineWindow.Kind(medium.medium(), medium.medium().properties(), idHash(medium.medium()), medium.floats(), medium.buoyancy(),
                        medium.sources(), store, window + 1 < sizes.size() ? coarserAt(window + 1, slot, window, step) : null));
                if (window > 0) {
                    // What the finer window's edge reads from, as it is before this step, to read between it and the newest.
                    outerOf(window, slot).remember(placement, sizes.get(window - 1), windows[window - 1].placement(), step);
                }
            }
            long engineStart = System.nanoTime();
            engines[window].step(new EngineWindow(placement, sim.occupancy(), workspace(window),
                    window + 1 < sizes.size() ? windows[window + 1].placement() : null, kinds), request.windows().get(window).inputs(),
                    LevelSchedule.stepSeconds(window, stepSeconds));
            engineNanos[window] = System.nanoTime() - engineStart;
            counts[window] = engines[window].lastStats();
            for (int slot = 0; slot < GasWorld.MAX_KINDS; slot++) {
                if (!used[slot]) {
                    stores[window][slot] = null;
                    outer[window][slot] = null;
                }
            }
        }
        int held = 0;
        for (GasStore[] windowStores : stores) {
            for (GasStore store : windowStores) {
                if (store != null) {
                    held += store.bricksHeld();
                }
            }
        }
        bricksHeld = held;

        GasSnapshot[] written = new GasSnapshot[sizes.size()];
        for (int window = 0; window < sizes.size(); window++) {
            if (!stepped[window]) {
                continue;
            }
            long snapshotStart = System.nanoTime();
            GasSnapshot snapshot = spare.get(window).poll();
            if (snapshot == null) {
                snapshot = new GasSnapshot(sizes.get(window), windows[window].placement());
            }
            float[] full = new float[GasWorld.MAX_KINDS];
            for (MediumStep medium : media.get(window)) {
                full[medium.slot()] = medium.medium().simulation().maxDensity();
            }
            snapshot.write(windows[window].placement(), stores[window], full);
            snapshot.setMedia(slots);
            snapshot.setSteps(step, step + LevelSchedule.interval(window));
            written[window] = snapshot;
            stepStats[window].record(engineNanos[window], counts[window], System.nanoTime() - snapshotStart);
        }
        // The finest last: when the renderer sees its new snapshot, the coarser ones of the same step are there.
        for (int window = sizes.size() - 1; window >= 0; window--) {
            if (written[window] != null) {
                GasSnapshot unseen = latest.getAndSet(window, written[window]);
                if (unseen != null) {
                    spare.get(window).add(unseen);
                }
            }
        }
    }

    /** The slot's gas in a window as the finer window reads it at its edge, made or made again for the store it has now. */
    private OuterLevel outerOf(int window, int slot) {
        GasStore store = stores[window][slot];
        OuterLevel view = outer[window][slot];
        if (view == null || view.store() != store) {
            view = new OuterLevel(store, LevelSchedule.stepSeconds(window, stepSeconds));
            outer[window][slot] = view;
        }
        return view;
    }

    /**
     * The slot's gas in window {@code coarser} as window {@code finer} reads it when stepped at base step {@code step}:
     * between the coarser window's last two states, by where the finer step ends; null if the coarser has none of it.
     */
    private @Nullable OuterLevel coarserAt(int coarser, int slot, int finer, long step) {
        if (stores[coarser][slot] == null) {
            return null;
        }
        OuterLevel view = outerOf(coarser, slot);
        float fraction = view.rememberedAt() == Long.MIN_VALUE ? 1f : LevelSchedule.fraction(finer, step, view.rememberedAt());
        view.at(fraction, windows[coarser].placement());
        return view;
    }

    /**
     * Hands the renderer each window's light that has changed: all of it after the window has moved, the first time,
     * or when the renderer has left too much untaken, and then without the updates of the window before it, which it
     * replaces; otherwise the slices that changed.
     */
    private void publishLight() {
        for (int window = 0; window < windows.length; window++) {
            SimWindow sim = windows[window];
            LightGrid light = sim.light();
            GridPlacement placement = sim.placement();
            if (placement == null) {
                continue;
            }
            int height = sizes.get(window).y();
            boolean whole = light.hasMoved();
            int count = whole ? height : light.dirtySlices();
            if (count == 0) {
                continue;
            }
            if (!whole && pendingLightBytes.get() + (long) count * lightSliceBytes > MAX_PENDING_LIGHT_BYTES) {
                whole = true;
                count = height;
            }
            if (whole) {
                dropLightUpdates(window);
            }
            int[] slices = new int[count];
            ByteBuffer[] buffers = new ByteBuffer[count];
            int taken = 0;
            for (int y = 0; y < height; y++) {
                if (whole || light.isSliceDirty(y)) {
                    ByteBuffer buffer = lightSlice();
                    light.takeSlice(y, buffer);
                    slices[taken] = y;
                    buffers[taken] = buffer;
                    taken++;
                }
            }
            if (whole) {
                light.allSlicesTaken();
            }
            LightUpdate update = new LightUpdate(window, placement, whole, slices, buffers);
            pendingLightBytes.addAndGet(bytes(update));
            lightUpdates.add(update);
        }
    }

    /** Takes back the updates of a window the renderer has not taken yet, which a whole update replaces. */
    private void dropLightUpdates(int window) {
        for (LightUpdate update : lightUpdates) {
            // The renderer may take it meanwhile; then it is the renderer's.
            if (update.window() == window && lightUpdates.remove(update)) {
                pendingLightBytes.addAndGet(-bytes(update));
                for (ByteBuffer buffer : update.buffers()) {
                    spareLightSlices.add(buffer);
                }
            }
        }
    }

    private ByteBuffer lightSlice() {
        ByteBuffer slice = spareLightSlices.poll();
        return slice != null ? slice : ByteBuffer.allocateDirect(lightSliceBytes);
    }

    private long bytes(LightUpdate update) {
        return (long) update.slices().length * lightSliceBytes;
    }

    private GasField workspace(int window) {
        GasField field = workspaces[window];
        if (field == null) {
            field = new GasField(sizes.get(window));
            workspaces[window] = field;
        }
        return field;
    }
}
