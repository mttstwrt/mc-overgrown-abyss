package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.sim.GasField;
import dev.syrval.volumetrics.sim.GasStepper;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.sim.MediumParams;
import dev.syrval.volumetrics.sim.Nesting;
import dev.syrval.volumetrics.sim.Occupancy;
import dev.syrval.volumetrics.sim.Source;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import org.jspecify.annotations.Nullable;

/**
 * Runs the simulation on a thread of its own, one step at a time. The game thread hands it everything a step
 * needs and later picks up the result; neither ever waits for the other. If a step is still running when the
 * next is due, that one is skipped and the gas simply moves a little slower.
 */
final class SimWorker implements AutoCloseable {
    /** Densities under this are dropped; a byte of the density texture cannot show them anyway. */
    private static final float MIN_DENSITY = 1f / 512f;

    private final GridSize size;
    private final float stepSeconds;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "Volumetrics simulation");
        thread.setDaemon(true);
        return thread;
    });
    private final AtomicBoolean busy = new AtomicBoolean();
    private final AtomicReference<@Nullable List<GasSnapshot>> latest = new AtomicReference<>();
    private final ConcurrentLinkedQueue<List<GasSnapshot>> spare = new ConcurrentLinkedQueue<>();
    private volatile long lastStepNanos;

    // Touched by the simulation thread only.
    private final GasStepper stepper = new GasStepper(MIN_DENSITY);
    private final @Nullable GasField[][] fields = new GasField[GasWorld.WINDOWS][GasWorld.SLOTS];
    private final @Nullable GridPlacement[] placements = new GridPlacement[GasWorld.WINDOWS];

    SimWorker(GridSize size, float stepSeconds) {
        this.size = size;
        this.stepSeconds = stepSeconds;
    }

    /** What one step works from: every window, the fine one first, each stepping the same media. */
    record Request(List<WindowStep> windows) {}

    /** The occupancy must not be changed once it has been passed in. */
    record WindowStep(GridPlacement placement, Occupancy occupancy, List<MediumStep> media) {}

    record MediumStep(int slot, MediumParams params, List<Source> sources) {}

    /** Starts a step unless one is running. */
    void submit(Request request) {
        if (!busy.compareAndSet(false, true)) {
            return;
        }
        executor.execute(() -> {
            try {
                step(request);
            } catch (RuntimeException e) {
                Volumetrics.LOGGER.error("Gas simulation step failed", e);
            } finally {
                busy.set(false);
            }
        });
    }

    /**
     * The newest finished step nobody has taken yet, one snapshot for each window, or null. Give it back with
     * {@link #recycle} when done.
     */
    @Nullable List<GasSnapshot> takeLatest() {
        return latest.getAndSet(null);
    }

    void recycle(List<GasSnapshot> snapshots) {
        spare.add(snapshots);
    }

    long lastStepNanos() {
        return lastStepNanos;
    }

    @Override
    public void close() {
        executor.shutdownNow();
    }

    private void step(Request request) {
        long start = System.nanoTime();
        // Coarse windows first: a finer window takes what is at its edge from the next coarser one.
        for (int window = GasWorld.WINDOWS - 1; window >= 0; window--) {
            WindowStep step = request.windows().get(window);
            follow(window, step.placement());
            boolean[] used = new boolean[GasWorld.SLOTS];
            for (MediumStep medium : step.media()) {
                used[medium.slot()] = true;
                GasField field = fields[window][medium.slot()];
                if (field == null) {
                    field = new GasField(size);
                    fields[window][medium.slot()] = field;
                }
                stepper.step(field, step.occupancy(), medium.params(), step.placement(), medium.sources(), stepSeconds);
                GasField coarser = window + 1 < GasWorld.WINDOWS ? fields[window + 1][medium.slot()] : null;
                if (coarser != null) {
                    Nesting.edgeFromCoarse(field, step.placement(), step.occupancy(),
                            coarser, request.windows().get(window + 1).placement(), MIN_DENSITY);
                }
            }
            for (int slot = 0; slot < GasWorld.SLOTS; slot++) {
                if (!used[slot]) {
                    fields[window][slot] = null;
                }
            }
        }

        List<GasSnapshot> snapshots = spare.poll();
        if (snapshots == null) {
            snapshots = new ArrayList<>();
            for (WindowStep step : request.windows()) {
                snapshots.add(new GasSnapshot(size, step.placement()));
            }
        }
        for (int window = 0; window < GasWorld.WINDOWS; window++) {
            WindowStep step = request.windows().get(window);
            float[] full = new float[GasWorld.SLOTS];
            for (MediumStep medium : step.media()) {
                full[medium.slot()] = medium.params().maxDensity();
            }
            snapshots.get(window).write(step.placement(), fields[window], full);
        }
        List<GasSnapshot> unseen = latest.getAndSet(snapshots);
        if (unseen != null) {
            spare.add(unseen);
        }
        lastStepNanos = System.nanoTime() - start;
    }

    /** Moves a window's gas the other way when the window moves, so it stays where it was in the world. */
    private void follow(int window, GridPlacement next) {
        GridPlacement previous = placements[window];
        placements[window] = next;
        if (previous == null || previous.equals(next)) {
            return;
        }
        for (GasField field : fields[window]) {
            if (field != null) {
                field.shift(next.originX() - previous.originX(), next.originY() - previous.originY(), next.originZ() - previous.originZ());
            }
        }
    }
}
