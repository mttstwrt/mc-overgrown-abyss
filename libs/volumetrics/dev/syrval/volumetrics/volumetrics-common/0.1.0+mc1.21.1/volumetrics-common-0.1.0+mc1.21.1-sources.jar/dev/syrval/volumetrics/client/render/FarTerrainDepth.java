package dev.syrval.volumetrics.client.render;

import dev.syrval.volumetrics.Volumetrics;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.function.IntSupplier;
import java.util.function.Supplier;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.jspecify.annotations.Nullable;

/**
 * The depth of the terrain Voxy draws past the game's render distance, under an Iris shader pack. Without a pack Voxy
 * writes that terrain into the game's depth, and the gas stops at it there already. With one, Voxy keeps the depth in
 * a texture of its own and hands it to Iris for the pack, by the names packs read it by. The mixins on Iris pass on
 * what is handed over under those names, so this names none of Iris's or Voxy's types and loads without either.
 *
 * <p>Iris has a pipeline for each dimension a pack has drawn, and each has a texture of its own from Voxy: what was
 * handed over is kept for the pipeline it was handed to. All of it runs on the render thread.
 */
public final class FarTerrainDepth {
    private static final String DEPTH = "vxDepthTexOpaque";
    private static final String PROJECTION = "vxProj";
    private static final String INVERSE_PROJECTION = "vxProjInv";
    private static final boolean VOXY = present("me.cortex.voxy.client.VoxyClient");
    /** Whether Iris draws with a shader pack, from its public API, for saying when Voxy's depth goes missing. */
    private static final @Nullable MethodHandle SHADER_PACK_IN_USE = VOXY ? findShaderPackInUse() : null;

    /** What was handed to each pipeline, until the pipeline is destroyed. */
    private static final Map<Object, Found> found = new WeakHashMap<>();
    /**
     * What was handed over since it was last put with a pipeline: to one being made, while it is made, or to the one
     * drawing, whose programs Iris also makes as they are first needed.
     */
    private static @Nullable Found pending;
    /** The pipeline that last began drawing a level, and whether it has since the gas last took its depth. */
    private static @Nullable Object drawing;
    private static boolean drawn;
    private static boolean warned;
    private static boolean announced;
    /** How often each mixin has been reached, for the warning: which of them no longer fits Iris. */
    private static int samplersSeen;
    private static int depthsSeen;
    private static int projectionsSeen;
    private static int pipelinesMade;
    private static int levelsBegun;

    private FarTerrainDepth() {
    }

    /** A pack's program is given a texture under these names. */
    public static void samplerAdded(IntSupplier texture, String[] names) {
        samplersSeen++;
        for (String name : names) {
            if (DEPTH.equals(name)) {
                depthsSeen++;
                pending().texture = texture;
                return;
            }
        }
    }

    /** A pack's pipeline is given a matrix uniform of this name, set from this. */
    public static void matrixUniformAdded(String name, Supplier<? extends Matrix4fc> value) {
        boolean inverse = INVERSE_PROJECTION.equals(name);
        if (inverse || PROJECTION.equals(name)) {
            projectionsSeen++;
            Found here = pending();
            // Either will do, as both are the same projection: the one not inverted is kept when there are both.
            if (here.projection == null || !inverse) {
                here.projection = value;
                here.inverted = inverse;
            }
        }
    }

    /** A pipeline is made: what was handed over while it was being made is its own. */
    public static void pipelineMade(Object pipeline) {
        pipelinesMade++;
        if (pending != null) {
            found.put(pipeline, pending);
            pending = null;
        }
    }

    /** A pipeline begins drawing a level. */
    public static void pipelineDrawing(Object pipeline) {
        settle();
        drawing = pipeline;
        drawn = true;
        levelsBegun++;
    }

    /** A pipeline has drawn the level: the programs it made while drawing are its own. */
    public static void pipelineDrawn() {
        settle();
    }

    public static void pipelineDestroyed(Object pipeline) {
        settle();
        found.remove(pipeline);
        if (drawing == pipeline) {
            drawing = null;
        }
    }

    /**
     * Voxy's depth texture, if a pack drew the level with it on this frame, with the inverse of the projection it was
     * drawn with put in {@code inverseProjection}; 0 otherwise. Its depth runs 0 to 1 and is cleared to 1. Each frame
     * it is drawn, the first call has it and later ones do not.
     */
    static int takeDrawnDepth(Matrix4f inverseProjection) {
        boolean wasDrawn = drawn;
        drawn = false;
        settle();
        Found here = wasDrawn && drawing != null ? found.get(drawing) : null;
        if (here == null || here.texture == null || here.projection == null) {
            if (!warned && VOXY && shaderPackInUse()) {
                warned = true;
                Volumetrics.LOGGER.warn("A shader pack draws with Voxy, but Voxy's depth was not found: the pack does not support Voxy, "
                        + "or this version of Iris no longer fits the mod. Gas shows through Voxy's far terrain. Seen: {} samplers, {} Voxy depths, "
                        + "{} Voxy projections, {} pipelines made, {} levels begun; this frame drawn by a pipeline: {}, it has a depth: {}, a projection: {}",
                        samplersSeen, depthsSeen, projectionsSeen, pipelinesMade, levelsBegun, wasDrawn,
                        here != null && here.texture != null, here != null && here.projection != null);
            }
            return 0;
        }
        try {
            int texture = here.texture.getAsInt();
            Matrix4fc projection = here.projection.get();
            if (texture <= 0 || projection == null) {
                return 0;
            }
            if (here.inverted) {
                inverseProjection.set(projection);
            } else {
                projection.invert(inverseProjection);
            }
            if (!announced) {
                announced = true;
                Volumetrics.LOGGER.info("Gas stops at Voxy's far terrain under the shader pack");
            }
            return texture;
        } catch (RuntimeException e) {
            if (!warned) {
                warned = true;
                Volumetrics.LOGGER.warn("Voxy's depth could not be read through Iris; gas shows through its far terrain", e);
            }
            return 0;
        }
    }

    private static boolean present(String className) {
        try {
            Class.forName(className, false, FarTerrainDepth.class.getClassLoader());
            return true;
        } catch (ClassNotFoundException | LinkageError e) {
            return false;
        }
    }

    /** Iris's public answer, found by name: null if Iris is not there, or it does not have it. */
    private static @Nullable MethodHandle findShaderPackInUse() {
        try {
            Class<?> api = Class.forName("net.irisshaders.iris.api.v0.IrisApi", false, FarTerrainDepth.class.getClassLoader());
            Object instance = api.getMethod("getInstance").invoke(null);
            return MethodHandles.publicLookup().findVirtual(api, "isShaderPackInUse", MethodType.methodType(boolean.class)).bindTo(instance);
        } catch (ReflectiveOperationException | LinkageError | RuntimeException e) {
            return null;
        }
    }

    private static boolean shaderPackInUse() {
        if (SHADER_PACK_IN_USE == null) {
            return false;
        }
        try {
            return (boolean) SHADER_PACK_IN_USE.invokeExact();
        } catch (Throwable e) {
            return false;
        }
    }

    private static Found pending() {
        if (pending == null) {
            pending = new Found();
        }
        return pending;
    }

    /** What was handed over outside the making of a pipeline is the drawing one's. */
    private static void settle() {
        if (pending != null && drawing != null) {
            found.computeIfAbsent(drawing, pipeline -> new Found()).take(pending);
            pending = null;
        }
    }

    private static final class Found {
        private @Nullable IntSupplier texture;
        private @Nullable Supplier<? extends Matrix4fc> projection;
        private boolean inverted;

        void take(Found newer) {
            if (newer.texture != null) {
                texture = newer.texture;
            }
            if (newer.projection != null) {
                projection = newer.projection;
                inverted = newer.inverted;
            }
        }
    }
}
