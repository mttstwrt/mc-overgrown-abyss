package dev.syrval.volumetrics.sim;

/** A rectangle of cells in one horizontal slice of a grid: {@code width} cells along X from {@code x}, {@code depth} along Z from {@code z}. */
public record CellRect(int x, int z, int width, int depth) {
    public CellRect {
        if (x < 0 || z < 0 || width <= 0 || depth <= 0) {
            throw new IllegalArgumentException("Not a rectangle of cells: " + x + ", " + z + ", " + width + " by " + depth);
        }
    }

    /** The whole slice. */
    public static CellRect of(GridSize size) {
        return new CellRect(0, 0, size.x(), size.z());
    }

    /** The smallest rectangle that holds both. */
    public CellRect union(CellRect other) {
        int minX = Math.min(x, other.x);
        int minZ = Math.min(z, other.z);
        return new CellRect(minX, minZ, Math.max(x + width, other.x + other.width) - minX, Math.max(z + depth, other.z + other.depth) - minZ);
    }
}
