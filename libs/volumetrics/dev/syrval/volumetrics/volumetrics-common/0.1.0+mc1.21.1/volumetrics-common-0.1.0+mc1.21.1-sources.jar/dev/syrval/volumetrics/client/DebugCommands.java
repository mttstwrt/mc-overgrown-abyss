package dev.syrval.volumetrics.client;

import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.client.render.Quality;
import java.util.Arrays;
import java.util.Locale;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * The client-side {@code /volumetrics} command: gas off and on, the quality setting, figures on what the gas costs,
 * and, for trying gases out by hand, emitters and fogs where you stand (or at coordinates) on this client only, which
 * can then be moved (the emitters) and removed. The loaders' command source types differ and the command needs neither, so it is
 * built for whichever one the loader registers it with.
 */
public final class DebugCommands {
    private DebugCommands() {}

    public static <S> LiteralArgumentBuilder<S> create(VolumetricsClient client) {
        return DebugCommands.<S>literal("volumetrics")
                .then(DebugCommands.<S>literal("emit")
                        .then(DebugCommands.<S, ResourceLocation>argument("medium", ResourceLocationArgument.id())
                                .suggests((context, builder) -> SharedSuggestionProvider.suggestResource(client.mediumIds(), builder))
                                .then(DebugCommands.<S, Float>argument("radius", FloatArgumentType.floatArg(0.25f, 96f))
                                        .then(DebugCommands.<S, Float>argument("rate", FloatArgumentType.floatArg(0f, 20f))
                                                .executes(context -> emit(client, context, null))
                                                .then(DebugCommands.<S, Double>argument("x", DoubleArgumentType.doubleArg())
                                                        .then(DebugCommands.<S, Double>argument("y", DoubleArgumentType.doubleArg())
                                                                .then(DebugCommands.<S, Double>argument("z", DoubleArgumentType.doubleArg())
                                                                        .executes(context -> emit(client, context, new Vec3(
                                                                                DoubleArgumentType.getDouble(context, "x"),
                                                                                DoubleArgumentType.getDouble(context, "y"),
                                                                                DoubleArgumentType.getDouble(context, "z")))))))))))
                .then(DebugCommands.<S>literal("fog")
                        .then(DebugCommands.<S, ResourceLocation>argument("medium", ResourceLocationArgument.id())
                                .suggests((context, builder) -> SharedSuggestionProvider.suggestResource(client.mediumIds(), builder))
                                .then(DebugCommands.<S, Float>argument("radius", FloatArgumentType.floatArg(1f, 512f))
                                        .then(DebugCommands.<S, Float>argument("height", FloatArgumentType.floatArg(1f, 512f))
                                                .then(DebugCommands.<S, Float>argument("density", FloatArgumentType.floatArg(0f, 4f))
                                                        .executes(context -> fog(client, context, null))
                                                        .then(DebugCommands.<S, Double>argument("x", DoubleArgumentType.doubleArg())
                                                                .then(DebugCommands.<S, Double>argument("y", DoubleArgumentType.doubleArg())
                                                                        .then(DebugCommands.<S, Double>argument("z", DoubleArgumentType.doubleArg())
                                                                                .executes(context -> fog(client, context, new Vec3(
                                                                                        DoubleArgumentType.getDouble(context, "x"),
                                                                                        DoubleArgumentType.getDouble(context, "y"),
                                                                                        DoubleArgumentType.getDouble(context, "z"))))))))))))
                .then(DebugCommands.<S>literal("move")
                        .then(DebugCommands.<S, Double>argument("dx", DoubleArgumentType.doubleArg())
                                .then(DebugCommands.<S, Double>argument("dy", DoubleArgumentType.doubleArg())
                                        .then(DebugCommands.<S, Double>argument("dz", DoubleArgumentType.doubleArg())
                                                .executes(context -> {
                                                    say("Moved " + client.moveEmitters(new Vec3(
                                                            DoubleArgumentType.getDouble(context, "dx"),
                                                            DoubleArgumentType.getDouble(context, "dy"),
                                                            DoubleArgumentType.getDouble(context, "dz"))) + " emitters");
                                                    return 1;
                                                })))))
                .then(DebugCommands.<S>literal("clear").executes(context -> {
                    say("Removed " + client.clearEmitters() + " emitters and " + client.clearFogs() + " fogs");
                    return 1;
                }))
                .then(DebugCommands.<S>literal("stats").executes(context -> {
                    say(client.stats());
                    return 1;
                }))
                .then(DebugCommands.<S>literal("enabled")
                        .executes(context -> {
                            say(client.enabled() ? "Gas is on" : "Gas is off");
                            return 1;
                        })
                        .then(DebugCommands.<S, Boolean>argument("enabled", BoolArgumentType.bool())
                                .executes(context -> {
                                    client.setEnabled(BoolArgumentType.getBool(context, "enabled"));
                                    say(client.enabled() ? "Gas is on" : "Gas is off");
                                    return 1;
                                })))
                .then(DebugCommands.<S>literal("quality")
                        .executes(context -> {
                            say("Quality is " + client.quality().getSerializedName());
                            return 1;
                        })
                        .then(DebugCommands.<S, String>argument("setting", StringArgumentType.word())
                                .suggests((context, builder) -> SharedSuggestionProvider.suggest(
                                        Arrays.stream(Quality.values()).map(Quality::getSerializedName), builder))
                                .executes(context -> setQuality(client, StringArgumentType.getString(context, "setting")))));
    }

    private static int setQuality(VolumetricsClient client, String name) {
        Optional<Quality> quality = Arrays.stream(Quality.values()).filter(value -> value.getSerializedName().equals(name)).findFirst();
        if (quality.isEmpty()) {
            say("No quality setting " + name);
            return 0;
        }
        client.setQuality(quality.get());
        say("Quality is now " + name);
        return 1;
    }

    private static <S> int emit(VolumetricsClient client, CommandContext<S> context, @Nullable Vec3 at) {
        ResourceLocation id = context.getArgument("medium", ResourceLocation.class);
        Optional<Medium> medium = client.medium(id);
        LocalPlayer player = Minecraft.getInstance().player;
        if (medium.isEmpty() || player == null) {
            say("No medium " + id + " in this world's datapacks");
            return 0;
        }
        Vec3 position = at != null ? at : player.position();
        float radius = FloatArgumentType.getFloat(context, "radius");
        float rate = FloatArgumentType.getFloat(context, "rate");
        if (!client.emit(medium.get(), position, radius, rate)) {
            say(client.enabled() ? "No level to emit into" : "Gas is off (/volumetrics enabled true)");
            return 0;
        }
        say("Emitting " + id + " at " + String.format(Locale.ROOT, "%.1f %.1f %.1f", position.x, position.y, position.z));
        return 1;
    }

    private static <S> int fog(VolumetricsClient client, CommandContext<S> context, @Nullable Vec3 at) {
        ResourceLocation id = context.getArgument("medium", ResourceLocation.class);
        Optional<Medium> medium = client.medium(id);
        LocalPlayer player = Minecraft.getInstance().player;
        if (medium.isEmpty() || player == null) {
            say("No medium " + id + " in this world's datapacks");
            return 0;
        }
        Vec3 position = at != null ? at : player.position();
        float radius = FloatArgumentType.getFloat(context, "radius");
        float height = FloatArgumentType.getFloat(context, "height");
        float density = FloatArgumentType.getFloat(context, "density");
        if (!client.fog(medium.get(), position, radius, height, density)) {
            say(client.enabled() ? "No level to put fog in" : "Gas is off (/volumetrics enabled true)");
            return 0;
        }
        say("Fog of " + id + " standing at " + String.format(Locale.ROOT, "%.1f %.1f %.1f", position.x, position.y, position.z));
        return 1;
    }

    private static void say(String message) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player != null) {
            player.sendSystemMessage(Component.literal(message));
        }
    }

    private static <S> LiteralArgumentBuilder<S> literal(String name) {
        return LiteralArgumentBuilder.literal(name);
    }

    private static <S, T> RequiredArgumentBuilder<S, T> argument(String name, ArgumentType<T> type) {
        return RequiredArgumentBuilder.argument(name, type);
    }
}
