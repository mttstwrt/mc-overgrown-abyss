package dev.syrval.volumetrics.client;

import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.client.render.Quality;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.commands.SharedSuggestionProvider;
//? if >=26.1 {
/*import net.minecraft.commands.arguments.IdentifierArgument;
*///?} else {
import net.minecraft.commands.arguments.ResourceLocationArgument;
//?}
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * The client-side {@code /volumetrics} command: the settings screen, gas off and on, the quality setting, the simulation's reach, temporal accumulation off and
 * on, the {@link Experiments}, figures on what the gas costs, and, for trying gases out by hand, emitters and fogs where you stand (or at
 * coordinates) on this client only, which can then be moved (the emitters) and removed. The loaders' command source types differ and the command needs neither, so it is
 * built for whichever one the loader registers it with.
 */
public final class DebugCommands {
    private DebugCommands() {}

    public static <S> LiteralArgumentBuilder<S> create(VolumetricsClient client) {
        return DebugCommands.<S>literal("volumetrics")
                .then(DebugCommands.<S>literal("emit")
                        .then(DebugCommands.<S, ResourceLocation>argument("medium", /*? if >=26.1 {*//*IdentifierArgument*//*?} else {*/ResourceLocationArgument/*?}*/.id())
                                .suggests((context, builder) -> SharedSuggestionProvider.suggestResource(client.mediumIds(), builder))
                                .then(DebugCommands.<S, Float>argument("radius", FloatArgumentType.floatArg(0.25f, 96f))
                                        .then(DebugCommands.<S, Float>argument("rate", FloatArgumentType.floatArg(0f, 20f))
                                                .executes(context -> emit(client, context, null))
                                                .then(DebugCommands.<S, Double>argument("x", DoubleArgumentType.doubleArg())
                                                        .then(DebugCommands.<S, Double>argument("y", DoubleArgumentType.doubleArg())
                                                                .then(DebugCommands.<S, Double>argument("z", DoubleArgumentType.doubleArg())
                                                                        .executes(context -> emit(client, context, new Vec3(
                                                                                DoubleArgumentType.getDouble(context, "x"),
                                                                                DoubleArgumentType.getDouble(context, "y"),
                                                                                DoubleArgumentType.getDouble(context, "z")))))))))))
                .then(DebugCommands.<S>literal("fog")
                        .then(DebugCommands.<S, ResourceLocation>argument("medium", /*? if >=26.1 {*//*IdentifierArgument*//*?} else {*/ResourceLocationArgument/*?}*/.id())
                                .suggests((context, builder) -> SharedSuggestionProvider.suggestResource(client.mediumIds(), builder))
                                .then(DebugCommands.<S, Float>argument("radius", FloatArgumentType.floatArg(1f, 512f))
                                        .then(DebugCommands.<S, Float>argument("height", FloatArgumentType.floatArg(1f, 512f))
                                                .then(DebugCommands.<S, Float>argument("density", FloatArgumentType.floatArg(0f, 4f))
                                                        .executes(context -> fog(client, context, null))
                                                        .then(DebugCommands.<S, Double>argument("x", DoubleArgumentType.doubleArg())
                                                                .then(DebugCommands.<S, Double>argument("y", DoubleArgumentType.doubleArg())
                                                                        .then(DebugCommands.<S, Double>argument("z", DoubleArgumentType.doubleArg())
                                                                                .executes(context -> fog(client, context, new Vec3(
                                                                                        DoubleArgumentType.getDouble(context, "x"),
                                                                                        DoubleArgumentType.getDouble(context, "y"),
                                                                                        DoubleArgumentType.getDouble(context, "z"))))))))))))
                .then(DebugCommands.<S>literal("move")
                        .then(DebugCommands.<S, Double>argument("dx", DoubleArgumentType.doubleArg())
                                .then(DebugCommands.<S, Double>argument("dy", DoubleArgumentType.doubleArg())
                                        .then(DebugCommands.<S, Double>argument("dz", DoubleArgumentType.doubleArg())
                                                .executes(context -> {
                                                    say("Moved " + client.moveEmitters(new Vec3(
                                                            DoubleArgumentType.getDouble(context, "dx"),
                                                            DoubleArgumentType.getDouble(context, "dy"),
                                                            DoubleArgumentType.getDouble(context, "dz"))) + " emitters");
                                                    return 1;
                                                })))))
                .then(DebugCommands.<S>literal("clear").executes(context -> {
                    say("Removed " + client.clearEmitters() + " emitters and " + client.clearFogs() + " fogs");
                    return 1;
                }))
                .then(DebugCommands.<S>literal("stats").executes(context -> {
                    say(client.stats());
                    return 1;
                }))
                .then(DebugCommands.<S>literal("enabled")
                        .executes(context -> {
                            say(client.enabled() ? "Gas is on" : "Gas is off");
                            return 1;
                        })
                        .then(DebugCommands.<S, Boolean>argument("enabled", BoolArgumentType.bool())
                                .executes(context -> {
                                    client.setEnabled(BoolArgumentType.getBool(context, "enabled"));
                                    say(client.enabled() ? "Gas is on" : "Gas is off");
                                    return 1;
                                })))
                .then(DebugCommands.<S>literal("quality")
                        .executes(context -> {
                            say("Quality is " + client.quality().getSerializedName());
                            return 1;
                        })
                        .then(DebugCommands.<S, String>argument("setting", StringArgumentType.word())
                                .suggests((context, builder) -> SharedSuggestionProvider.suggest(
                                        Arrays.stream(Quality.values()).map(Quality::getSerializedName), builder))
                                .executes(context -> setQuality(client, StringArgumentType.getString(context, "setting")))))
                .then(DebugCommands.<S>literal("scale")
                        .executes(context -> {
                            say("Render scale (share of the depth buffer the shader draws the level into) is " + client.scale());
                            return 1;
                        })
                        .then(DebugCommands.<S, Float>argument("factor", FloatArgumentType.floatArg(0.25f, 2f))
                                .executes(context -> {
                                    client.setScale(FloatArgumentType.getFloat(context, "factor"));
                                    say("Render scale (share of the depth buffer the shader draws the level into) is now " + client.scale());
                                    return 1;
                                })))
                .then(DebugCommands.<S>literal("reach")
                        .executes(context -> {
                            say("Simulation reach is " + client.reach());
                            return 1;
                        })
                        .then(DebugCommands.<S, Float>argument("scale", FloatArgumentType.floatArg(0.25f, 1f))
                                .executes(context -> {
                                    client.setReach(FloatArgumentType.getFloat(context, "scale"));
                                    say("Simulation reach is now " + client.reach() + "; the gas starts again with the levels for it");
                                    return 1;
                                })))
                .then(DebugCommands.<S>literal("temporal")
                        .executes(context -> {
                            say(client.temporal() ? "Temporal accumulation is on" : "Temporal accumulation is off");
                            return 1;
                        })
                        .then(DebugCommands.<S>literal("on").executes(context -> setTemporal(client, true)))
                        .then(DebugCommands.<S>literal("off").executes(context -> setTemporal(client, false))))
                .then(DebugCommands.<S>literal("settings").executes(context -> {
                    SettingsScreen.open(client);
                    return 1;
                }))
                .then(DebugCommands.<S>literal("experiment")
                        .executes(context -> {
                            StringBuilder lines = new StringBuilder();
                            for (Experiments.Category category : Experiments.Category.values()) {
                                lines.append(lines.isEmpty() ? "" : "\n").append(category == Experiments.Category.DEBUG ? "Debug:" : "Experiments:");
                                Experiments.all().stream().filter(experiment -> experiment.category() == category)
                                        .forEach(experiment -> lines.append("\n").append(client.experiments().describe(experiment)));
                            }
                            say(lines.toString());
                            return 1;
                        })
                        .then(DebugCommands.<S, String>argument("name", StringArgumentType.word())
                                .suggests((context, builder) -> SharedSuggestionProvider.suggest(
                                        Experiments.all().stream().map(Experiments.Experiment::name), builder))
                                .executes(context -> showExperiment(client, StringArgumentType.getString(context, "name")))
                                .then(DebugCommands.<S, String>argument("value", StringArgumentType.word())
                                        .suggests((context, builder) -> {
                                            Experiments.Experiment<?> experiment = Experiments.byName(StringArgumentType.getString(context, "name"));
                                            return SharedSuggestionProvider.suggest(experiment == null ? List.of()
                                                    : Stream.concat(experiment.suggestions().stream(), Stream.of("default")).toList(), builder);
                                        })
                                        .executes(context -> setExperiment(client, StringArgumentType.getString(context, "name"),
                                                StringArgumentType.getString(context, "value"))))));
    }

    private static int showExperiment(VolumetricsClient client, String name) {
        Experiments.Experiment<?> experiment = Experiments.byName(name);
        if (experiment == null) {
            say("No experiment " + name + " (/volumetrics experiment lists them)");
            return 0;
        }
        say(client.experiments().describe(experiment));
        return 1;
    }

    private static int setExperiment(VolumetricsClient client, String name, String value) {
        Experiments.Experiment<?> experiment = Experiments.byName(name);
        if (experiment == null) {
            say("No experiment " + name + " (/volumetrics experiment lists them)");
            return 0;
        }
        if (!client.setExperiment(experiment, value)) {
            say(value + " is not a value of " + name + ": " + experiment.description());
            return 0;
        }
        say("Now " + client.experiments().describe(experiment));
        return 1;
    }

    private static int setTemporal(VolumetricsClient client, boolean temporal) {
        client.setTemporal(temporal);
        say(temporal ? "Temporal accumulation is now on" : "Temporal accumulation is now off");
        return 1;
    }

    private static int setQuality(VolumetricsClient client, String name) {
        Optional<Quality> quality = Arrays.stream(Quality.values()).filter(value -> value.getSerializedName().equals(name)).findFirst();
        if (quality.isEmpty()) {
            say("No quality setting " + name);
            return 0;
        }
        client.setQuality(quality.get());
        say("Quality is now " + name);
        return 1;
    }

    private static <S> int emit(VolumetricsClient client, CommandContext<S> context, @Nullable Vec3 at) {
        ResourceLocation id = context.getArgument("medium", ResourceLocation.class);
        Optional<Medium> medium = client.medium(id);
        LocalPlayer player = Minecraft.getInstance().player;
        if (medium.isEmpty() || player == null) {
            say("No medium " + id + " in this world's datapacks");
            return 0;
        }
        Vec3 position = at != null ? at : player.position();
        float radius = FloatArgumentType.getFloat(context, "radius");
        float rate = FloatArgumentType.getFloat(context, "rate");
        if (!client.emit(medium.get(), position, radius, rate)) {
            say(client.enabled() ? "No level to emit into" : "Gas is off (/volumetrics enabled true)");
            return 0;
        }
        say("Emitting " + id + " at " + String.format(Locale.ROOT, "%.1f %.1f %.1f", position.x, position.y, position.z));
        return 1;
    }

    private static <S> int fog(VolumetricsClient client, CommandContext<S> context, @Nullable Vec3 at) {
        ResourceLocation id = context.getArgument("medium", ResourceLocation.class);
        Optional<Medium> medium = client.medium(id);
        LocalPlayer player = Minecraft.getInstance().player;
        if (medium.isEmpty() || player == null) {
            say("No medium " + id + " in this world's datapacks");
            return 0;
        }
        Vec3 position = at != null ? at : player.position();
        float radius = FloatArgumentType.getFloat(context, "radius");
        float height = FloatArgumentType.getFloat(context, "height");
        float density = FloatArgumentType.getFloat(context, "density");
        if (!client.fog(medium.get(), position, radius, height, density)) {
            say(client.enabled() ? "No level to put fog in" : "Gas is off (/volumetrics enabled true)");
            return 0;
        }
        say("Fog of " + id + " standing at " + String.format(Locale.ROOT, "%.1f %.1f %.1f", position.x, position.y, position.z));
        return 1;
    }

    private static void say(String message) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player != null) {
            player.sendSystemMessage(Component.literal(message));
        }
    }

    private static <S> LiteralArgumentBuilder<S> literal(String name) {
        return LiteralArgumentBuilder.literal(name);
    }

    private static <S, T> RequiredArgumentBuilder<S, T> argument(String name, ArgumentType<T> type) {
        return RequiredArgumentBuilder.argument(name, type);
    }
}
