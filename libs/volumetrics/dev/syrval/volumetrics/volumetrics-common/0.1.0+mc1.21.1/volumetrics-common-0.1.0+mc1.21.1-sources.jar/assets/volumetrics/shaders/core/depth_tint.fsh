uniform sampler2D DepthSampler;

layout(std140) uniform VolumetricsCamera {
    // The projection the level was drawn with.
    mat4 ProjMat;
    mat4 InverseViewRotation;
    // xyz of the first: the block the camera is in. xyz of the second: from the camera to that block's low
    // corner. Kept apart so that positions stay exact far from the world's origin.
    ivec4 CameraBlock;
    vec4 CameraOffset;
};

in vec2 texCoord;

out vec4 fragColor;

// How close, in blocks, a pixel must be to a grid plane to be drawn as part of its line.
const float LINE_HALF_WIDTH = 0.04;

float gridLine(float coordinate, float spacing) {
    float toNearest = abs(fract(coordinate / spacing + 0.5) - 0.5) * spacing;
    return 1.0 - step(LINE_HALF_WIDTH, toNearest);
}

void main() {
    float depth = texture(DepthSampler, texCoord).r;
    // The sky is where nothing was drawn, at the clear value of 1.
    if (depth >= 1.0) {
        fragColor = vec4(0.0);
        return;
    }

    vec4 unprojected = inverse(ProjMat) * vec4(texCoord * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec3 viewPos = unprojected.xyz / unprojected.w;
    vec3 fromCamera = (InverseViewRotation * vec4(viewPos, 0.0)).xyz;
    vec3 world = vec3(CameraBlock.xyz) - CameraOffset.xyz + fromCamera;

    float haze = 1.0 - exp(-length(viewPos) * 0.015);
    vec4 color = vec4(0.55, 0.7, 0.95, haze * 0.8);

    // Chunk borders in cyan, and a contour every four blocks half-way up a block, in yellow. If world positions
    // are right these stay glued to the blocks as the camera moves.
    float chunkBorder = max(gridLine(world.x, 16.0), gridLine(world.z, 16.0));
    float contour = gridLine(world.y - 0.5, 4.0);
    color = mix(color, vec4(1.0, 0.9, 0.1, 1.0), contour);
    color = mix(color, vec4(0.1, 1.0, 1.0, 1.0), chunkBorder);

    fragColor = color;
}
