package dev.syrval.volumetrics.sim;

import java.util.ArrayDeque;
import java.util.Arrays;

/**
 * One kind's gas in a level of the cascade as the next finer level reads it at its edge ({@link Nesting}): between
 * the level's last two states. The level steps ahead of the finer one ({@link LevelSchedule}); just before it steps,
 * {@link #remember} keeps what its store holds in the bricks the finer level's edge reads from, and {@link #at} says
 * where the finer step ends within the level's step. Reads then blend what was kept into the store's newest gas by that
 * fraction. Where nothing was kept, as before the level's first step or where the finer level has since moved to, they
 * give the newest gas.
 *
 * <p>Without {@link #remember} it is the store's newest gas, as when both levels step together.
 */
public final class OuterLevel implements GasDensities {
    private static final int BRICK = GridSize.BRICK;

    private final GasStore store;
    private final GridSize size;
    private final float stepSeconds;
    /** By brick, at the placement then: what the store held before the step, null where it held nothing or was not kept. */
    private final float[][] previous;
    /** By brick: whether it was kept, the empty ones too. */
    private final boolean[] kept;
    /** By brick: the store's {@link GasStore#changeSum} before the step. */
    private final double[] previousChanges;
    private final ArrayDeque<float[]> spare = new ArrayDeque<>();
    private GridPlacement previousPlacement;
    private int previousHeld;
    private long rememberedAt = Long.MIN_VALUE;
    /** Mark of the bricks to keep, by the finer level's edge; scratch. */
    private boolean[] sampled;

    // How reads blend, as last set by at().
    private float fraction = 1f;
    private boolean blending;
    private boolean moved;
    private int offsetX;
    private int offsetY;
    private int offsetZ;

    /** The store's newest gas only, for a level stepped as often as the finer one. */
    public OuterLevel(GasStore store) {
        this(store, Float.NaN);
    }

    /** @param stepSeconds the seconds a step of this level spans, NaN if the same as the finer level's */
    public OuterLevel(GasStore store, float stepSeconds) {
        this.store = store;
        this.size = store.size();
        this.stepSeconds = stepSeconds;
        this.previous = new float[size.brickCount()][];
        this.kept = new boolean[size.brickCount()];
        this.previousChanges = new double[size.brickCount()];
    }

    public GasStore store() {
        return store;
    }

    /** The seconds a step of this level spans; NaN if the same as the finer level's. */
    public float stepSeconds() {
        return stepSeconds;
    }

    /** The base step at which {@link #remember} was last called; {@link Long#MIN_VALUE} if never. */
    public long rememberedAt() {
        return rememberedAt;
    }

    /**
     * Just before this level steps: keeps what it holds now in the bricks the finer level's edge reads from.
     *
     * @param placement      where this level is
     * @param finer          the finer level's size
     * @param finerPlacement where the finer level is
     * @param step           the base step it is called at, for {@link #rememberedAt}
     */
    public void remember(GridPlacement placement, GridSize finer, GridPlacement finerPlacement, long step) {
        for (int brick = 0; brick < previous.length; brick++) {
            if (previous[brick] != null) {
                spare.push(previous[brick]);
                previous[brick] = null;
            }
        }
        Arrays.fill(kept, false);
        previousHeld = 0;
        if (sampled == null) {
            sampled = new boolean[size.brickCount()];
        }
        Arrays.fill(sampled, false);
        Nesting.markSampled(finer, finerPlacement, size, placement, sampled);
        for (int brick = 0; brick < sampled.length; brick++) {
            if (!sampled[brick]) {
                continue;
            }
            kept[brick] = true;
            previousChanges[brick] = store.changeSum(brick);
            float[] cells = store.brickCells(brick);
            if (cells != null) {
                float[] copy = spare.isEmpty() ? new float[GasStore.BRICK_CELLS] : spare.pop();
                System.arraycopy(cells, 0, copy, 0, GasStore.BRICK_CELLS);
                previous[brick] = copy;
                previousHeld++;
            }
        }
        previousPlacement = placement;
        rememberedAt = step;
        at(1f, placement);
    }

    /**
     * Before the finer level reads this: its step ends {@code fraction} of the way through this level's last step (0
     * at what was kept, 1 at the newest), with this level now at {@code placement}.
     */
    public void at(float fraction, GridPlacement placement) {
        this.fraction = fraction;
        this.blending = previousPlacement != null && fraction < 1f;
        if (previousPlacement != null) {
            offsetX = placement.originX() - previousPlacement.originX();
            offsetY = placement.originY() - previousPlacement.originY();
            offsetZ = placement.originZ() - previousPlacement.originZ();
            moved = offsetX != 0 || offsetY != 0 || offsetZ != 0;
        }
    }

    @Override
    public GridSize size() {
        return size;
    }

    public boolean isEmpty() {
        return store.isEmpty() && !(blending && previousHeld > 0);
    }

    @Override
    public float density(int cellX, int cellY, int cellZ) {
        float newest = store.density(cellX, cellY, cellZ);
        if (!blending) {
            return newest;
        }
        int x = cellX + offsetX;
        int y = cellY + offsetY;
        int z = cellZ + offsetZ;
        if (!size.contains(x, y, z)) {
            return newest;
        }
        int brick = size.brickOfCell(x, y, z);
        if (!kept[brick]) {
            return newest;
        }
        float[] cells = previous[brick];
        float before = cells == null ? 0f : cells[GasStore.inBrick(x % BRICK, y % BRICK, z % BRICK)];
        return before + (newest - before) * fraction;
    }

    @Override
    public boolean brickHasGas(int brickX, int brickY, int brickZ) {
        if (store.brickHasGas(brickX, brickY, brickZ)) {
            return true;
        }
        if (!blending || previousHeld == 0) {
            return false;
        }
        int minX = Math.floorDiv(brickX * BRICK + offsetX, BRICK);
        int minY = Math.floorDiv(brickY * BRICK + offsetY, BRICK);
        int minZ = Math.floorDiv(brickZ * BRICK + offsetZ, BRICK);
        int maxX = Math.floorDiv(brickX * BRICK + BRICK - 1 + offsetX, BRICK);
        int maxY = Math.floorDiv(brickY * BRICK + BRICK - 1 + offsetY, BRICK);
        int maxZ = Math.floorDiv(brickZ * BRICK + BRICK - 1 + offsetZ, BRICK);
        for (int by = Math.max(0, minY); by <= Math.min(size.bricksY() - 1, maxY); by++) {
            for (int bz = Math.max(0, minZ); bz <= Math.min(size.bricksZ() - 1, maxZ); bz++) {
                for (int bx = Math.max(0, minX); bx <= Math.min(size.bricksX() - 1, maxX); bx++) {
                    if (previous[size.brickIndex(bx, by, bz)] != null) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /** See {@link GasStore#trackChanges()}. */
    public void trackChanges() {
        store.trackChanges();
    }

    /**
     * Whether {@link #changeSum} bounds how far what is read here moves: the store tracks its changes, and while reads
     * blend, this level has not moved since {@link #remember} (the kept sums are by the brick as it was).
     */
    boolean tracksChanges() {
        return store.tracksChanges() && !(blending && moved);
    }

    /** See {@link GasStore#trackedKeep()}: of this level's own step. */
    float trackedKeep() {
        return store.trackedKeep();
    }

    /** The store's {@link GasStore#changeSum} at the time read, between the kept sum and the newest by the fraction. */
    double changeSum(int brick) {
        double newest = store.changeSum(brick);
        if (!blending || !kept[brick]) {
            return newest;
        }
        return previousChanges[brick] + (newest - previousChanges[brick]) * fraction;
    }
}
