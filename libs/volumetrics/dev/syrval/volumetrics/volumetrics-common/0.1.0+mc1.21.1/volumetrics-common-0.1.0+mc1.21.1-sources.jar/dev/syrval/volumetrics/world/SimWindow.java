package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import dev.syrval.volumetrics.sim.Occupancy;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.util.ArrayDeque;
import java.util.List;
import net.minecraft.core.SectionPos;
import org.jspecify.annotations.Nullable;

/**
 * What the simulation thread knows of the world inside one window: what stands in the way of gas, how each cell is
 * lit and which blocks give gas off, all written from the scans of chunk sections, and where the window was for the
 * step being taken. Simulation thread only.
 */
final class SimWindow {
    private static final int SECTION_BLOCKS = 16;

    private final GridSize size;
    private final int cellsPerSection;
    private final Occupancy occupancy;
    private final LightGrid light;
    /** Emitters at blocks a datapack rule names, by the chunk section the blocks are in. */
    private final Long2ObjectOpenHashMap<List<Emitter>> blockEmitters = new Long2ObjectOpenHashMap<>();
    /**
     * Scans of sections copied after moves of the window this thread has not made yet, in the order they came: each
     * waits for the step that has the window where it was copied, or further on.
     */
    private final ArrayDeque<SectionResult> waiting = new ArrayDeque<>();
    private @Nullable GridPlacement placement;
    /** How many times the window had moved on the client thread when it was where it is now for this thread. */
    private int epoch;

    SimWindow(GridSize size, int cellSize) {
        this.size = size;
        this.cellsPerSection = SECTION_BLOCKS / cellSize;
        this.occupancy = new Occupancy(size);
        this.light = new LightGrid(size);
    }

    Occupancy occupancy() {
        return occupancy;
    }

    LightGrid light() {
        return light;
    }

    /** Where the window is for the step being taken, or null before the first. */
    @Nullable GridPlacement placement() {
        return placement;
    }

    int epoch() {
        return epoch;
    }

    ArrayDeque<SectionResult> waiting() {
        return waiting;
    }

    /**
     * Moves the window to where the client thread had it, numbered {@code epoch}. What it knows of the world moves the
     * other way within it, so it stays where it was in the world; cells that enter are closed and dark until their
     * sections are read, and the emitters of sections that leave go.
     */
    void follow(GridPlacement next, int nextEpoch) {
        epoch = nextEpoch;
        GridPlacement previous = placement;
        placement = next;
        if (previous == null || previous.equals(next)) {
            return;
        }
        int dx = next.originX() - previous.originX();
        int dy = next.originY() - previous.originY();
        int dz = next.originZ() - previous.originZ();
        occupancy.shift(dx, dy, dz);
        light.shift(dx, dy, dz);
        blockEmitters.keySet().removeIf(section -> !size.contains(SectionPos.x(section) * cellsPerSection - next.originX(),
                SectionPos.y(section) * cellsPerSection - next.originY(), SectionPos.z(section) * cellsPerSection - next.originZ()));
    }

    /**
     * Writes what the scan made of a section into the window: its cells' occupancy and light, and the emitters at its
     * blocks. Nothing is written for a section that is no longer inside the window, which has moved since the section
     * was copied; it is read again if it comes back in.
     */
    void apply(SectionResult result) {
        GridPlacement window = placement;
        if (window == null) {
            return;
        }
        int cellX = result.sectionX() * cellsPerSection - window.originX();
        int cellY = result.sectionY() * cellsPerSection - window.originY();
        int cellZ = result.sectionZ() * cellsPerSection - window.originZ();
        if (!size.contains(cellX, cellY, cellZ)
                || !size.contains(cellX + cellsPerSection - 1, cellY + cellsPerSection - 1, cellZ + cellsPerSection - 1)) {
            return;
        }
        byte[] cells = result.cells();
        byte[] cellLight = result.light();
        for (int y = 0; y < cellsPerSection; y++) {
            for (int z = 0; z < cellsPerSection; z++) {
                for (int x = 0; x < cellsPerSection; x++) {
                    int cell = x + cellsPerSection * (z + cellsPerSection * y);
                    if (cells != null) {
                        int flags = cells[cell];
                        if ((flags & SectionResult.CLOSED) != 0) {
                            occupancy.setBlocked(cellX + x, cellY + y, cellZ + z, true);
                        } else {
                            occupancy.setSolidSides(cellX + x, cellY + y, cellZ + z, flags);
                        }
                    }
                    light.set(cellX + x, cellY + y, cellZ + z, cellLight[2 * cell], cellLight[2 * cell + 1]);
                }
            }
        }
        List<Emitter> emitters = result.emitters();
        if (emitters != null) {
            long section = SectionPos.asLong(result.sectionX(), result.sectionY(), result.sectionZ());
            if (emitters.isEmpty()) {
                blockEmitters.remove(section);
            } else {
                blockEmitters.put(section, emitters);
            }
        }
    }

    void addEmittersTo(List<Emitter> emitters) {
        blockEmitters.values().forEach(emitters::addAll);
    }

    int blockEmitterCount() {
        int count = 0;
        for (List<Emitter> section : blockEmitters.values()) {
            count += section.size();
        }
        return count;
    }
}
