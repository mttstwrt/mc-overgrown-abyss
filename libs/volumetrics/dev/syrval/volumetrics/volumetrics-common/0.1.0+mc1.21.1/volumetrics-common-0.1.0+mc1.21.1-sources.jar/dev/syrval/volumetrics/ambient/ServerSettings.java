package dev.syrval.volumetrics.ambient;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.api.MediumBuoyancy;
import dev.syrval.volumetrics.sim.AmbientProfile;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Optional;
import net.minecraft.resources.ResourceLocation;

/**
 * What the server decides about the air gas floats in, kept as JSON in the game's config folder: how the air thins
 * with height in each dimension, how fast buoyant gas moves, and the buoyancy of single media. A client with no
 * word from the server uses the defaults.
 *
 * @param buoyancySpeed      blocks per second for a buoyancy that sets no speed of its own
 * @param defaultScaleHeight blocks of height over which the air thins by a factor of e, for a dimension not in
 *                           {@code dimensions}
 * @param dimensions         the dimensions that are not the default, by id
 * @param media              buoyancy for a medium by id, replacing or adding to the medium file's
 */
public record ServerSettings(float buoyancySpeed, float defaultScaleHeight, Map<ResourceLocation, DimensionSetting> dimensions,
                             Map<ResourceLocation, MediumBuoyancy> media) {
    public static final String FILE_NAME = "volumetrics-server.json";
    // With the default scale height, gas closes in on its height by a factor of e about every 5 s: well within the
    // half-life of the built-in media, which would otherwise mostly decay on the way.
    public static final float DEFAULT_SPEED = 48f;
    public static final float DEFAULT_SCALE_HEIGHT = 256f;
    public static final ServerSettings DEFAULT = new ServerSettings(DEFAULT_SPEED, DEFAULT_SCALE_HEIGHT,
            Map.of(ResourceLocation.withDefaultNamespace("the_nether"), DimensionSetting.FLAT,
                    ResourceLocation.withDefaultNamespace("the_end"), DimensionSetting.FLAT),
            Map.of());

    public static final Codec<ServerSettings> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.floatRange(0f, 1e4f).optionalFieldOf("buoyancy_speed", DEFAULT_SPEED).forGetter(ServerSettings::buoyancySpeed),
            Codec.floatRange(1f, 1e6f).optionalFieldOf("default_scale_height", DEFAULT_SCALE_HEIGHT).forGetter(ServerSettings::defaultScaleHeight),
            Codec.unboundedMap(ResourceLocation.CODEC, DimensionSetting.CODEC).optionalFieldOf("dimensions", DEFAULT.dimensions).forGetter(ServerSettings::dimensions),
            Codec.unboundedMap(ResourceLocation.CODEC, MediumBuoyancy.CODEC).optionalFieldOf("media", Map.of()).forGetter(ServerSettings::media)
    ).apply(instance, ServerSettings::new));
    /** The same with every field written, defaults included, so the file shows what can be set. */
    private static final Codec<ServerSettings> FULL_CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.FLOAT.fieldOf("buoyancy_speed").forGetter(ServerSettings::buoyancySpeed),
            Codec.FLOAT.fieldOf("default_scale_height").forGetter(ServerSettings::defaultScaleHeight),
            Codec.unboundedMap(ResourceLocation.CODEC, DimensionSetting.CODEC).fieldOf("dimensions").forGetter(ServerSettings::dimensions),
            Codec.unboundedMap(ResourceLocation.CODEC, MediumBuoyancy.CODEC).fieldOf("media").forGetter(ServerSettings::media)
    ).apply(instance, ServerSettings::new));
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public ServerSettings {
        dimensions = Map.copyOf(dimensions);
        media = Map.copyOf(media);
    }

    /** The air of a dimension: flat if it is set so, otherwise thinning with its scale height. */
    public AmbientState stateFor(ResourceLocation dimension, int seaLevel, int minY, int maxY) {
        DimensionSetting setting = dimensions.get(dimension);
        AmbientProfile profile = setting != null && setting.flat()
                ? AmbientProfile.flat(seaLevel, minY, maxY)
                : AmbientProfile.exponential(seaLevel, minY, maxY, setting != null ? setting.scaleHeight() : defaultScaleHeight);
        return new AmbientState(profile, buoyancySpeed, media);
    }

    /**
     * The settings in a file. Missing, it is written with the defaults, which are returned; unreadable, it is left
     * as it is and the defaults are returned.
     */
    public static ServerSettings load(Path file) {
        if (!Files.exists(file)) {
            DEFAULT.save(file);
            return DEFAULT;
        }
        try (Reader reader = Files.newBufferedReader(file)) {
            return CODEC.parse(JsonOps.INSTANCE, JsonParser.parseReader(reader))
                    .resultOrPartial(problem -> Volumetrics.LOGGER.warn("Ignoring {}: {}", file, problem))
                    .orElse(DEFAULT);
        } catch (IOException | JsonParseException e) {
            Volumetrics.LOGGER.warn("Ignoring {}, which could not be read", file, e);
            return DEFAULT;
        }
    }

    void save(Path file) {
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, GSON.toJson(FULL_CODEC.encodeStart(JsonOps.INSTANCE, this).getOrThrow()) + "\n");
        } catch (IOException e) {
            Volumetrics.LOGGER.warn("Could not write {}", file, e);
        }
    }

    /**
     * How the air of one dimension thins: not at all, or by a factor of e every {@code scaleHeight} blocks.
     * Written {@code {"flat": true}} or {@code {"scale_height": 256}}.
     */
    public record DimensionSetting(boolean flat, float scaleHeight) {
        public static final DimensionSetting FLAT = new DimensionSetting(true, 0f);

        private record Raw(Optional<Boolean> flat, Optional<Float> scaleHeight) {}

        private static final Codec<Raw> RAW_CODEC = RecordCodecBuilder.create(instance -> instance.group(
                Codec.BOOL.optionalFieldOf("flat").forGetter(Raw::flat),
                Codec.floatRange(1f, 1e6f).optionalFieldOf("scale_height").forGetter(Raw::scaleHeight)
        ).apply(instance, Raw::new));

        public static final Codec<DimensionSetting> CODEC = RAW_CODEC.flatXmap(
                raw -> raw.flat().orElse(false)
                        ? DataResult.success(FLAT)
                        : raw.scaleHeight().isPresent()
                                ? DataResult.success(new DimensionSetting(false, raw.scaleHeight().get()))
                                : DataResult.error(() -> "a dimension needs \"flat\": true or a \"scale_height\""),
                setting -> DataResult.success(setting.flat()
                        ? new Raw(Optional.of(true), Optional.empty())
                        : new Raw(Optional.empty(), Optional.of(setting.scaleHeight()))));
    }
}
