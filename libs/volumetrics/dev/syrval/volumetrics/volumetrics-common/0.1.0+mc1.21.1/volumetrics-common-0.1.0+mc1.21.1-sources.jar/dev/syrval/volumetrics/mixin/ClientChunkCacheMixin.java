package dev.syrval.volumetrics.mixin;

import dev.syrval.volumetrics.client.WorldChangeSource;
import net.minecraft.client.multiplayer.ClientChunkCache;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.LightLayer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Tells the mod when the client's own light engine has relit a chunk section: a torch placed, a roof closed.
 * The engine reports it here, and from here the game's renderer is told to draw the section again; see
 * {@code ClientLevelMixin} for why the mod listens on this side of that call.
 */
@Mixin(ClientChunkCache.class)
abstract class ClientChunkCacheMixin {
    @Shadow
    @Final
    ClientLevel level;

    @Inject(method = "onLightUpdate(Lnet/minecraft/world/level/LightLayer;Lnet/minecraft/core/SectionPos;)V", at = @At("HEAD"))
    private void volumetrics$lightChanged(LightLayer layer, SectionPos section, CallbackInfo callback) {
        ((WorldChangeSource) level).volumetrics$sectionTouched(section.x(), section.y(), section.z());
    }
}
