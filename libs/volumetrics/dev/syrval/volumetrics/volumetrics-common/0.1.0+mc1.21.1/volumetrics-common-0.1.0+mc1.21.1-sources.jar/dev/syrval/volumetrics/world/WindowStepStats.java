package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.sim.StepStats;

/**
 * What a window's recent steps cost and did, for the statistics: times are averaged over the last {@link #AVERAGED}
 * steps, brick counts are those of the last step (see {@link StepStats}).
 *
 * @param stepNanos     the engine step, including the nesting
 * @param nestNanos     the part of it that sets the window's edge from the coarser window
 * @param snapshotNanos writing the window's snapshot for the renderer
 * @param last          the last step's counts
 */
public record WindowStepStats(double stepNanos, double nestNanos, double snapshotNanos, StepStats last) {
    public static final int AVERAGED = 20;
    public static final WindowStepStats NONE = new WindowStepStats(0, 0, 0, StepStats.NONE);

    /** Keeps the last {@link #AVERAGED} steps of one window. Written by the simulation thread only; read through {@link #stats()}. */
    static final class Recorder {
        private final long[] step = new long[AVERAGED];
        private final long[] nest = new long[AVERAGED];
        private final long[] snapshot = new long[AVERAGED];
        private int next;
        private int count;
        private volatile WindowStepStats stats = NONE;

        void record(long stepNanos, StepStats counts, long snapshotNanos) {
            step[next] = stepNanos;
            nest[next] = counts.nestNanos();
            snapshot[next] = snapshotNanos;
            next = (next + 1) % AVERAGED;
            count = Math.min(count + 1, AVERAGED);
            stats = new WindowStepStats(mean(step), mean(nest), mean(snapshot), counts);
        }

        private double mean(long[] values) {
            long sum = 0;
            for (int i = 0; i < count; i++) {
                sum += values[i];
            }
            return (double) sum / count;
        }

        WindowStepStats stats() {
            return stats;
        }
    }
}
