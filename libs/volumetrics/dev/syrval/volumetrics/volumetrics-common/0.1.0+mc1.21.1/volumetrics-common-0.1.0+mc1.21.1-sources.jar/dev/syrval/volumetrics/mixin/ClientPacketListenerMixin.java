package dev.syrval.volumetrics.mixin;

import dev.syrval.volumetrics.client.WorldChangeSource;
//? if >=26.1 {
/*import net.minecraft.client.Minecraft;
*///?}
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.world.level.chunk.LevelChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Tells the mod when a chunk has arrived from the server. This is the one place where that is known with the
 * chunk's light already in: the loaders' chunk events fire when its blocks are there and its light is not yet.
 * The game then marks the chunk and the eight around it to be drawn again, which by itself would have the mod
 * read nine chunks for every one that arrives.
 */
@Mixin(ClientPacketListener.class)
abstract class ClientPacketListenerMixin {
    @Inject(method = "enableChunkLight(Lnet/minecraft/world/level/chunk/LevelChunk;II)V", at = @At("TAIL"))
    private void volumetrics$chunkArrived(LevelChunk chunk, int x, int z, CallbackInfo callback) {
        //? if >=26.1 {
        /*((WorldChangeSource) Minecraft.getInstance().levelExtractor).volumetrics$chunkArrived(x, z);
        *///?} else {
        ((WorldChangeSource) chunk.getLevel()).volumetrics$chunkArrived(x, z);
        //?}
    }
}
