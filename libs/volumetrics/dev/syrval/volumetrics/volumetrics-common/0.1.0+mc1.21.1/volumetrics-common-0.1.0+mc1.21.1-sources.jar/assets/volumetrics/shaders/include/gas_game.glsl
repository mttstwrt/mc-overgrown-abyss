#ifndef VOLUMETRICS_GAS_GAME_GLSL
#define VOLUMETRICS_GAS_GAME_GLSL

// What the gas passes need of the game's own state. This version of the game hands its shaders such things one
// loose uniform at a time, and only its own shaders; GasRenderer fills this block each frame instead.
layout(std140) uniform GasGame {
    // The projection the level was drawn with, view bobbing included.
    mat4 ProjMat;
    // The game's distance fog over terrain. rgb: its colour. a: how much of that colour it is at its thickest.
    vec4 FogColor;
    // Blocks from the camera at which the fog begins, and at which it hides everything.
    float FogStart;
    float FogEnd;
    // 0: the distance is taken straight from the camera. 1: as the larger of the distance sideways and the
    // distance up or down, which is how the game fogs terrain towards the edge of what is loaded.
    int FogShape;
    // The share of the depth texture, from its bottom left, that the level was drawn into. Less than 1 when a shader
    // pack draws the level smaller than the window and scales it up afterwards.
    vec2 ContentScale;
};

// How much of the game's fog lies over something at an offset from the camera, in blocks and world axes: 0 for
// none to 1 for all of it. The curve the game's own terrain shaders use.
float gasFog(vec3 fromCamera) {
    float away = FogShape == 0 ? length(fromCamera) : max(length(fromCamera.xz), abs(fromCamera.y));
    if (away <= FogStart) {
        return 0.0;
    }
    return away < FogEnd ? smoothstep(FogStart, FogEnd, away) : 1.0;
}

#endif
