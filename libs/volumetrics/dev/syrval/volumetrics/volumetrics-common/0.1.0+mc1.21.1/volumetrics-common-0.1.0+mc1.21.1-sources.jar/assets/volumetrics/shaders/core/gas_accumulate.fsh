#include <volumetrics:gas_game.glsl>
#include <volumetrics:gas_field.glsl>
#include <volumetrics:gas_temporal.glsl>

// This frame's march, grainy: each pixel's ray took its samples at offsets that change from frame to frame.
uniform sampler2D GasSampler;
// What this pass made on the previous frame, at the same size: many frames' marches blended together.
uniform sampler2D HistorySampler;
// The level's depth, which this frame's rays were marched against.
uniform sampler2D DepthSampler;

in vec2 texCoord;

// The gas as the march gives it, with the grain of one frame averaged away over many.
out vec4 fragColor;

void main() {
    ivec2 size = textureSize(GasSampler, 0);
    ivec2 centre = ivec2(gl_FragCoord.xy);
    vec4 current = texelFetch(GasSampler, centre, 0);

    // What the frames before give is kept to what this frame's march gives around this pixel. Gas that has moved
    // on, or that something has come in front of, would otherwise linger where it was.
    vec4 low = current;
    vec4 high = current;
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec4 there = texelFetch(GasSampler, clamp(centre + ivec2(x, y), ivec2(0), size - 1), 0);
            low = min(low, there);
            high = max(high, there);
        }
    }
    // Where there is no gas around this pixel, nothing of the frames before survives being kept to that: most of
    // the screen ends here.
    if (high.a <= 0.0 || GasHistoryValid == 0) {
        fragColor = current;
        return;
    }

    // This pixel's ray and the distance to the scene along it, as the march works them out.
    float depth = textureLod(DepthSampler, (texCoord) * ContentScale, 0.0).r;
    bool sky = depth >= 1.0;
    depth = min(depth, 0.99999);
    vec4 unprojected = inverse(ProjMat) * vec4(texCoord * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec3 fromCamera = (GasInverseViewRotation * vec4(unprojected.xyz / unprojected.w, 0.0)).xyz;
    float sceneBlocks = length(fromCamera);
    vec3 ray = normalize(fromCamera);

    // Where the scene this pixel shows was on the previous frame's screen, seen from where the camera was then:
    // the gas in front of it is taken to have been in front of it then too. The sky is so far off that only
    // turning the camera moves it.
    vec4 previous = sky ? GasPrevViewProj * vec4(ray, 0.0)
                        : GasPrevViewProj * vec4(ray * sceneBlocks + GasCameraDelta, 1.0);
    // Behind the previous camera, or off the edge of its screen: the previous frame did not see it.
    if (previous.w <= 0.0) {
        fragColor = current;
        return;
    }
    vec2 previousCoord = previous.xy / previous.w * 0.5 + 0.5;
    if (any(lessThan(previousCoord, vec2(0.0))) || any(greaterThan(previousCoord, vec2(1.0)))) {
        fragColor = current;
        return;
    }

    vec4 history = clamp(textureLod(HistorySampler, previousCoord, 0.0), low, high);
    fragColor = mix(current, history, GasHistoryWeight);
}
