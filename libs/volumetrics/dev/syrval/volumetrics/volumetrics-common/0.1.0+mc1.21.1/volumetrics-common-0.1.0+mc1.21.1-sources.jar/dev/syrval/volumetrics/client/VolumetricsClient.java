package dev.syrval.volumetrics.client;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.GlUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.api.EmitterDefinition;
import dev.syrval.volumetrics.api.EmitterShape;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.api.Placement;
import dev.syrval.volumetrics.api.VolumetricsRegistries;
import dev.syrval.volumetrics.api.client.GasEmitters;
import dev.syrval.volumetrics.client.dev.GateCapture;
import dev.syrval.volumetrics.client.render.DepthTintPass;
import dev.syrval.volumetrics.client.render.GasRenderer;
import dev.syrval.volumetrics.client.render.Quality;
import dev.syrval.volumetrics.world.BlockEmitterRule;
import dev.syrval.volumetrics.world.GasWorld;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * The client side of the mod. The loader's client entrypoint makes one and forwards its events here; nothing in
 * this package may be touched from code that also runs on a dedicated server. Everything here is called on the
 * client thread, which is also the render thread.
 */
public final class VolumetricsClient implements AutoCloseable {
    /** Draws a depth tint and a world-space grid over the level: the check that depth and position are read right. */
    private static final boolean DEBUG_DEPTH_TINT = Boolean.getBoolean("volumetrics.debug.depth_tint");
    /** Times the gas passes on the GPU, for {@code /volumetrics stats}. */
    private static final boolean DEBUG_GPU_TIME = Boolean.getBoolean("volumetrics.debug.gpu_time");
    /** Makes the march walk through empty space too, to measure what skipping it saves. */
    private static final boolean DEBUG_NO_SKIP = Boolean.getBoolean("volumetrics.debug.no_skip");
    /** Height of the slab of cells a debug emitter feeds. */
    private static final float EMITTER_HEIGHT = 2;
    /** Which of the textures the game hands its own shaders is the lightmap. */
    private static final int LIGHTMAP_SHADER_TEXTURE = 2;

    private final @Nullable GateCapture capture = GateCapture.fromSystemProperty();
    private final Path settingsFile;
    /** The emitters made with the debug command in the current level. */
    private final List<DebugEmitter> debugEmitters = new ArrayList<>();
    private ClientSettings settings;
    private @Nullable DepthTintPass depthTint;
    private @Nullable ClientLevel level;
    private @Nullable GasWorld gas;
    private @Nullable GasRenderer renderer;
    private boolean backendLogged;
    private boolean listeningForLevelDrawn;

    /** @param settingsFile where the player's settings are kept; it need not exist */
    public VolumetricsClient(Path settingsFile) {
        this.settingsFile = settingsFile;
        this.settings = ClientSettings.load(settingsFile);
    }

    /** Once per client tick. */
    public void tick() {
        Minecraft minecraft = Minecraft.getInstance();
        if (!listeningForLevelDrawn) {
            // Not in the constructor: the loader makes this object before the game has made its renderer.
            levelDrawn(minecraft).volumetrics$afterLevel(this::afterLevelRendered);
            listeningForLevelDrawn = true;
        }
        boolean wanted = minecraft.level != null && settings.enabled();
        if (minecraft.level != level) {
            // They were the old level's and went with it.
            debugEmitters.clear();
        }
        if (minecraft.level != level || wanted != (gas != null)) {
            // The gas belongs to the level it was simulated in, and there is none while the player has it off.
            closeGas();
            level = minecraft.level;
            if (wanted) {
                gas = new GasWorld(blockRules(level.registryAccess()), ((EmitterHolder) level).volumetrics$emitters());
                worldChanges(level).volumetrics$listen(gas);
            }
        }
        if (capture != null) {
            capture.tick(minecraft);
        }
        if (gas != null && level != null && !minecraft.isPaused()) {
            gas.tick(level, minecraft.gameRenderer.getMainCamera().getPosition());
        }
    }

    /**
     * Once per frame: the level, translucents included, is in the main target and its depth is still there; the
     * hand has not been drawn yet. Under a shader pack the main target holds the pack's finished picture, and its
     * depth is the level's all the same.
     */
    private void afterLevelRendered(LevelView view) {
        Minecraft minecraft = Minecraft.getInstance();
        logBackendOnce();
        if (DEBUG_DEPTH_TINT) {
            if (depthTint == null) {
                depthTint = new DepthTintPass(minecraft.getResourceManager());
            }
            depthTint.render(minecraft.getMainRenderTarget(), levelDepthTexture(minecraft), view);
        }
        if (gas != null && level != null) {
            if (renderer == null) {
                renderer = new GasRenderer(gas.size(), minecraft.getResourceManager(), DEBUG_GPU_TIME, !DEBUG_NO_SKIP);
            }
            renderer.render(gas, minecraft.getMainRenderTarget(), levelDepthTexture(minecraft), lightmapTexture(minecraft),
                    view, level, settings.quality());
        }
        if (capture != null) {
            capture.afterLevelRendered(minecraft);
        }
    }

    @Override
    public void close() {
        if (listeningForLevelDrawn) {
            levelDrawn(Minecraft.getInstance()).volumetrics$afterLevel(null);
            listeningForLevelDrawn = false;
        }
        closeGas();
        if (depthTint != null) {
            depthTint.close();
            depthTint = null;
        }
    }

    /**
     * Adds a disc-shaped emitter on this client only, the way another mod would. False if there is no gas to add
     * to: no level, or gas is off.
     */
    boolean emit(Medium medium, Vec3 base, float radius, float rate) {
        if (gas == null || level == null) {
            return false;
        }
        GasEmitters.Handle handle = GasEmitters.of(level).add(medium, new EmitterShape.Disc(radius, EMITTER_HEIGHT), base, rate);
        debugEmitters.add(new DebugEmitter(handle, base));
        return true;
    }

    /** Moves every emitter made with {@link #emit} by the same offset, in blocks, and says how many there were. */
    int moveEmitters(Vec3 by) {
        debugEmitters.replaceAll(emitter -> emitter.movedBy(by));
        return debugEmitters.size();
    }

    /** A medium of the current level's datapacks, by id. */
    Optional<Medium> medium(ResourceLocation id) {
        return media().flatMap(registry -> registry.getOptional(id));
    }

    Set<ResourceLocation> mediumIds() {
        return media().map(Registry::keySet).orElse(Set.of());
    }

    /** Removes the emitters made with {@link #emit}, and no others. */
    int clearEmitters() {
        int count = debugEmitters.size();
        debugEmitters.forEach(emitter -> emitter.handle().remove());
        debugEmitters.clear();
        return count;
    }

    Quality quality() {
        return settings.quality();
    }

    /** Takes effect on the next frame and is remembered for the next session. */
    void setQuality(Quality quality) {
        settings = new ClientSettings(settings.enabled(), quality);
        settings.save(settingsFile);
    }

    boolean enabled() {
        return settings.enabled();
    }

    /**
     * Turns all gas off or on again, from the next tick, and is remembered for the next session. Off, the mod
     * keeps no simulation, reads nothing of the world and draws nothing; on again, gas starts from nothing.
     */
    void setEnabled(boolean enabled) {
        settings = new ClientSettings(enabled, settings.quality());
        settings.save(settingsFile);
    }

    String stats() {
        if (!settings.enabled()) {
            return "Gas is off (/volumetrics enabled true)";
        }
        if (gas == null) {
            return "No level";
        }
        String gpu = "not measured (-Dvolumetrics.debug.gpu_time=true)";
        if (renderer != null && DEBUG_GPU_TIME) {
            double march = renderer.gpuNanos(0) / 1e6;
            double filter = renderer.gpuNanos(1) / 1e6;
            double composite = renderer.gpuNanos(2) / 1e6;
            gpu = String.format(Locale.ROOT, "%.3f ms (march %.3f, filter %.3f, composite %.3f)",
                    march + filter + composite, march, filter, composite);
        }
        RenderTarget screen = Minecraft.getInstance().getMainRenderTarget();
        return String.format(Locale.ROOT,
                "%d emitters near, %d in all; simulation step %.2f ms; world scan %.3f ms a tick, %d sections waiting near "
                        + "(and %d for their light), %d far (and %d); upload %.2f ms a step, %.2f ms for a window's light "
                        + "after a move; quality %s at %dx%d; gas passes on GPU %s",
                gas.emitterCount(0), gas.emitterCount(GasWorld.WINDOWS - 1), gas.lastStepNanos() / 1e6, gas.scanNanos() / 1e6,
                gas.waitingSections(0), gas.waitingForLight(0),
                gas.waitingSections(GasWorld.WINDOWS - 1), gas.waitingForLight(GasWorld.WINDOWS - 1),
                renderer == null ? 0 : renderer.uploadNanos() / 1e6, renderer == null ? 0 : renderer.lightMoveNanos() / 1e6,
                settings.quality().getSerializedName(), screen.width, screen.height, gpu);
    }

    /** Empty on a server that does not have the mod: its registries are simply not there. */
    private Optional<Registry<Medium>> media() {
        return level == null ? Optional.empty() : level.registryAccess().registry(VolumetricsRegistries.MEDIUM);
    }

    /** The emitter definitions that are placed by block, each with its medium looked up. */
    private static List<BlockEmitterRule> blockRules(RegistryAccess registries) {
        Optional<Registry<EmitterDefinition>> emitters = registries.registry(VolumetricsRegistries.EMITTER);
        Optional<Registry<Medium>> media = registries.registry(VolumetricsRegistries.MEDIUM);
        if (emitters.isEmpty() || media.isEmpty()) {
            return List.of();
        }
        List<BlockEmitterRule> rules = new ArrayList<>();
        emitters.get().entrySet().forEach(entry -> {
            EmitterDefinition definition = entry.getValue();
            Medium medium = media.get().get(definition.medium());
            if (medium == null) {
                Volumetrics.LOGGER.warn("Emitter {} names a medium that does not exist: {}",
                        entry.getKey().location(), definition.medium().location());
            } else if (definition.placement() instanceof Placement.Block(var blocks, var state)) {
                rules.add(new BlockEmitterRule(entry.getKey().location(), blocks, state, medium,
                        definition.shape(), definition.offset(), definition.rate()));
            }
        });
        return rules;
    }

    private void closeGas() {
        if (renderer != null) {
            renderer.close();
            renderer = null;
        }
        if (gas != null) {
            // The level the gas was made for, which is the one still in the field while this runs.
            worldChanges(level).volumetrics$listen(null);
            gas.close();
            gas = null;
        }
    }

    /** The game's renderer as the mod's mixin has made it; see {@code GameRendererMixin}. */
    private static AfterLevelSource levelDrawn(Minecraft minecraft) {
        return (AfterLevelSource) minecraft.gameRenderer;
    }

    /** The game's level as the mod's mixin has made it; see {@code ClientLevelMixin}. */
    private static WorldChangeSource worldChanges(ClientLevel level) {
        return (WorldChangeSource) level;
    }

    /**
     * The texture that holds the level's depth once the level has been drawn. It is the main target's, except
     * with the graphics setting on Fabulous: there the game draws translucent things into targets of their own
     * and lays them over the main one at the end, wiping the main target's depth as it does. The target for
     * translucent blocks still has it then: a copy of the solid level's depth, and those blocks' own.
     */
    private static int levelDepthTexture(Minecraft minecraft) {
        RenderTarget translucent = minecraft.levelRenderer.getTranslucentTarget();
        return (translucent != null ? translucent : minecraft.getMainRenderTarget()).getDepthTextureId();
    }

    /**
     * The game's lightmap for the level, as the number of its texture. The game keeps the texture to itself;
     * putting it where the game's own shaders find it, as the game does before it draws anything lit, leaves
     * that number where it can be read.
     */
    private static int lightmapTexture(Minecraft minecraft) {
        minecraft.gameRenderer.lightTexture().turnOnLightLayer();
        return RenderSystem.getShaderTexture(LIGHTMAP_SHADER_TEXTURE);
    }

    /** An emitter made with the debug command, and where it was last put: a handle does not tell. */
    private record DebugEmitter(GasEmitters.Handle handle, Vec3 base) {
        DebugEmitter movedBy(Vec3 offset) {
            Vec3 to = base.add(offset);
            handle.moveTo(to);
            return new DebugEmitter(handle, to);
        }
    }

    private void logBackendOnce() {
        if (backendLogged) {
            return;
        }
        backendLogged = true;
        Volumetrics.LOGGER.info("Volumetrics is rendering on OpenGL ({}, {})", GlUtil.getRenderer(), GlUtil.getOpenGLVersion());
    }
}
