package dev.syrval.volumetrics.client;

import com.mojang.blaze3d.pipeline.RenderTarget;
//? if <26.1 {
import com.mojang.blaze3d.platform.GlUtil;
//?}
import com.mojang.blaze3d.systems.RenderSystem;
//? if >=26.1 {
/*import com.mojang.renderpearl.api.device.DeviceInfo;
*///?}
import dev.syrval.volumetrics.Volumetrics;
import dev.syrval.volumetrics.ambient.AmbientPayload;
import dev.syrval.volumetrics.ambient.ClientAmbient;
import dev.syrval.volumetrics.ambient.ClientAmbient.Resolved;
import dev.syrval.volumetrics.ambient.ClientWind;
import dev.syrval.volumetrics.api.EmitterDefinition;
import dev.syrval.volumetrics.api.EmitterShape;
import dev.syrval.volumetrics.api.Fog;
import dev.syrval.volumetrics.api.FogShape;
import dev.syrval.volumetrics.api.Medium;
import dev.syrval.volumetrics.api.Placement;
import dev.syrval.volumetrics.api.VolumetricsRegistries;
import dev.syrval.volumetrics.api.wind.Wind;
import dev.syrval.volumetrics.api.client.GasEmitters;
import dev.syrval.volumetrics.api.client.GasFogs;
import dev.syrval.volumetrics.client.dev.GateCapture;
import dev.syrval.volumetrics.client.render.DepthTintPass;
import dev.syrval.volumetrics.client.render.FieldSource;
import dev.syrval.volumetrics.client.render.GasRenderer;
import dev.syrval.volumetrics.client.render.Quality;
import dev.syrval.volumetrics.sim.CascadeLayout;
import dev.syrval.volumetrics.sim.SimEngines;
import dev.syrval.volumetrics.sim.StepStats;
import dev.syrval.volumetrics.world.BlockEmitterRule;
import dev.syrval.volumetrics.world.GasWorld;
import dev.syrval.volumetrics.world.LevelHeight;
import dev.syrval.volumetrics.world.MainThreadTime;
import dev.syrval.volumetrics.world.WindowStepStats;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * The client side of the mod. The loader's client entrypoint makes one and forwards its events here; nothing in
 * this package may be touched from code that also runs on a dedicated server. Everything here is called on the
 * client thread, which is also the render thread.
 */
public final class VolumetricsClient implements AutoCloseable {
    /** Height of the slab of cells a debug emitter feeds. */
    private static final float EMITTER_HEIGHT = 2;
    //? if <26.1 {
    // Which of the textures the game hands its own shaders is the lightmap.
    private static final int LIGHTMAP_SHADER_TEXTURE = 2;
    //?}

    /** Ticks into a level, at 20 a second, before the defaults are logged as what it uses. */
    private static final int AMBIENT_FALLBACK_LOG_TICKS = 60;

    private final @Nullable GateCapture capture = GateCapture.fromSystemProperty();
    private final Path settingsFile;
    /** The emitters made with the debug command in the current level. */
    private final List<DebugEmitter> debugEmitters = new ArrayList<>();
    /** The fogs made with the debug command in the current level. */
    private final List<GasFogs.Handle> debugFogs = new ArrayList<>();
    private ClientSettings settings;
    private final Experiments experiments;
    private @Nullable DepthTintPass depthTint;
    private @Nullable ClientLevel level;
    private @Nullable GasWorld gas;
    // The air that was last handed to `gas`, and what it came from, to see when it is out of date.
    private @Nullable GasWorld ambientFor;
    private @Nullable AmbientPayload ambientFrom;
    private @Nullable Resolved ambient;
    private int ambientTicksWithoutServer;
    private boolean ambientLogged;
    // The wind last handed to `gas`, and whether it is the server's.
    private float windX;
    private float windZ;
    private boolean windFromServer;
    private @Nullable GasRenderer renderer;
    private long lastHitchLogNanos = Long.MIN_VALUE / 2;
    private boolean backendLogged;
    private boolean listeningForLevelDrawn;

    /** @param settingsFile where the player's settings are kept; it need not exist */
    public VolumetricsClient(Path settingsFile) {
        this.settingsFile = settingsFile;
        this.settings = ClientSettings.load(settingsFile);
        this.experiments = new Experiments(settings.experiments());
    }

    /** Once per client tick. */
    public void tick() {
        Minecraft minecraft = Minecraft.getInstance();
        if (!listeningForLevelDrawn) {
            // Not in the constructor: the loader makes this object before the game has made its renderer.
            levelDrawn(minecraft).volumetrics$afterLevel(this::afterLevelRendered);
            listeningForLevelDrawn = true;
        }
        boolean wanted = minecraft.level != null && settings.enabled();
        if (minecraft.level != level) {
            // They were the old level's and went with it.
            debugEmitters.clear();
            debugFogs.clear();
        }
        CascadeLayout layout = minecraft.level == null ? null : layout(minecraft, minecraft.level, settings.reach());
        if (minecraft.level != level || wanted != (gas != null) || gas != null && !gas.layout().equals(layout)) {
            // The gas belongs to the level it was simulated in, and there is none while the player has it off. Other
            // levels of the cascade (the render distance or the reach changed) start the gas again from nothing.
            closeGas();
            level = minecraft.level;
            if (wanted) {
                gas = new GasWorld(blockRules(level.registryAccess()), ((EmitterHolder) level).volumetrics$emitters(),
                        mediumIds(level.registryAccess()),
                        SimEngines.byName(experiments.get(Experiments.ENGINE), experiments.get(Experiments.SLEEP)), layout);
                Volumetrics.LOGGER.info("Gas levels: {} of {} cells (cells of {} blocks), reach {}", layout.levels(),
                        layout.sizes(), layout.cellSizes(), settings.reach());
                worldChanges(/*? if >=26.1 {*//*minecraft*//*?} else {*/level/*?}*/).volumetrics$listen(gas);
            }
        }
        if (minecraft.level == null) {
            // What a server sent is about the level the player has just left.
            ClientAmbient.clear();
            ClientWind.clear();
        }
        if (gas != null && level != null) {
            updateAmbient(gas, level);
            updateWind(gas, level);
        }
        if (capture != null) {
            capture.tick(minecraft);
        }
        if (gas != null && level != null && !minecraft.isPaused()) {
            gas.tick(level, minecraft.gameRenderer./*? if >=26.1 {*//*mainCamera().position()*//*?} else {*/getMainCamera().getPosition()/*?}*/);
        }
    }

    /** The levels of the cascade for the render distance, the reach scale and the level's height. */
    private static CascadeLayout layout(Minecraft minecraft, ClientLevel level, float reach) {
        return CascadeLayout.of(minecraft.options.getEffectiveRenderDistance() * 16, reach,
                LevelHeight.top(level) - LevelHeight.bottom(level));
    }

    /**
     * Hands the simulation the air of the level whenever the server has sent something new, or at first. Without a
     * word from the server for this dimension it is the defaults; that is logged once a couple of seconds into the
     * level, so that a server's word that is on its way does not get a line about the defaults first.
     */
    private void updateAmbient(GasWorld gas, ClientLevel level) {
        AmbientPayload payload = ClientAmbient.received();
        ResourceLocation dimension = level.dimension()./*? if >=26.1 {*//*identifier*//*?} else {*/location/*?}*/();
        if (gas != ambientFor || payload != ambientFrom) {
            //? if >=26.1 {
            /*int seaLevel = level.getSeaLevel();
            *///?} else {
            // The client's level hard-codes this one, whatever the dimension; vanilla only syncs it from 26.1.
            int seaLevel = 63;
            //?}
            Resolved resolved = ClientAmbient.resolve(dimension, seaLevel, LevelHeight.bottom(level), LevelHeight.top(level) - 1);
            gas.setAmbient(resolved.state());
            ambientFor = gas;
            ambientFrom = payload;
            ambient = resolved;
            ambientTicksWithoutServer = 0;
            ambientLogged = false;
        }
        Resolved resolved = ambient;
        if (!ambientLogged && resolved != null && (resolved.fromServer() || ++ambientTicksWithoutServer >= AMBIENT_FALLBACK_LOG_TICKS)) {
            ambientLogged = true;
            Volumetrics.LOGGER.info("Ambient profile for {}: from {} ({})", dimension,
                    resolved.fromServer() ? "server" : "fallback", resolved.state().describe());
        }
    }

    /**
     * Hands the simulation the server's wind at the camera: the first area of the wind that contains it, else the
     * wind of the level. Zero when the server has sent none, so that gas keeps its own drift and draft.
     */
    private void updateWind(GasWorld gas, ClientLevel level) {
        Vec3 camera = Minecraft.getInstance().gameRenderer./*? if >=26.1 {*//*mainCamera().position()*//*?} else {*/getMainCamera().getPosition()/*?}*/;
        Wind wind = ClientWind.windOf(level.dimension()./*? if >=26.1 {*//*identifier*//*?} else {*/location/*?}*/());
        float[] at = ClientWind.at(wind, Mth.floor(camera.x), Mth.floor(camera.y), Mth.floor(camera.z));
        windFromServer = wind != null;
        windX = at[0];
        windZ = at[1];
        gas.setWind(windX, windZ);
        gas.tickScroll(level.getGameTime());
    }

    /** Each medium of the level by the id its datapack gave it, to match the server's settings; by identity. */
    private static Map<Medium, ResourceLocation> mediumIds(RegistryAccess registries) {
        Map<Medium, ResourceLocation> ids = new IdentityHashMap<>();
        registries./*? if >=26.1 {*//*lookup*//*?} else {*/registry/*?}*/(VolumetricsRegistries.MEDIUM).ifPresent(media ->
                media.entrySet().forEach(entry -> ids.put(entry.getValue(),
                        entry.getKey()./*? if >=26.1 {*//*identifier*//*?} else {*/location/*?}*/())));
        return ids;
    }

    /**
     * Once per frame: the level, translucents included, is in the main target and its depth is still there; the
     * hand has not been drawn yet. Under a shader pack the main target holds the pack's finished picture, and its
     * depth is the level's, the game's own way round.
     */
    private void afterLevelRendered(/*? if >=26.1 {*//*?} else {*/LevelView view/*?}*/) {
        Minecraft minecraft = Minecraft.getInstance();
        logBackendOnce();
        if (experiments.get(Experiments.DEPTH_TINT)) {
            if (depthTint == null) {
                depthTint = new DepthTintPass(/*? if <26.1 {*/minecraft.getResourceManager()/*?}*/);
            }
            //? if >=26.1 {
            /*depthTint.render(minecraft.gameRenderer.mainRenderTarget(),
                    minecraft.gameRenderer.gameRenderState().levelRenderState.cameraRenderState);
            *///?} else {
            depthTint.render(minecraft.getMainRenderTarget(), levelDepthTexture(minecraft), view);
            //?}
        }
        if (gas != null && level != null) {
            if (renderer == null) {
                //? if >=26.1 {
                /*renderer = new GasRenderer(gas.sizes(), experiments.get(Experiments.GPU_TIME), rendererOptions(), fieldSource());
                *///?} else {
                renderer = new GasRenderer(gas.sizes(), minecraft.getResourceManager(), experiments.get(Experiments.GPU_TIME),
                        rendererOptions(), fieldSource());
                //?}
            }
            long renderStart = System.nanoTime();
            long takeLightBefore = MainThreadTime.get(MainThreadTime.Category.TAKE) + MainThreadTime.get(MainThreadTime.Category.LIGHT);
            //? if >=26.1 {
            /*renderer.render(gas, ((EmitterHolder) level).volumetrics$fogs(), minecraft.gameRenderer.mainRenderTarget(),
                    minecraft.gameRenderer.levelLightmap(), minecraft.gameRenderer.gameRenderState().levelRenderState,
                    levelDrawn(minecraft).volumetrics$levelProjection(), level.getGameTime(), settings.quality(), settings.scale(),
                    temporal());
            *///?} else {
            renderer.render(gas, ((EmitterHolder) level).volumetrics$fogs(), minecraft.getMainRenderTarget(), levelDepthTexture(minecraft),
                    lightmapTexture(minecraft), view, level, settings.quality(), settings.scale(), temporal());
            //?}
            long takeLight = MainThreadTime.get(MainThreadTime.Category.TAKE) + MainThreadTime.get(MainThreadTime.Category.LIGHT) - takeLightBefore;
            MainThreadTime.add(MainThreadTime.Category.DRAW, Math.max(0, System.nanoTime() - renderStart - takeLight));
        }
        endMainThreadFrame();
        if (capture != null) {
            capture.afterLevelRendered(minecraft);
        }
    }

    private void endMainThreadFrame() {
        int total = MainThreadTime.endFrame();
        if (experiments.get(Experiments.MAIN_THREAD) && total > 2000) {
            long now = System.nanoTime();
            if (now - lastHitchLogNanos >= 1_000_000_000L) {
                lastHitchLogNanos = now;
                Volumetrics.LOGGER.info("Main thread hitch {} us: world {}, step {}, take {}, light {}, draw {}", total,
                        MainThreadTime.lastFrameMicros(MainThreadTime.Category.WORLD), MainThreadTime.lastFrameMicros(MainThreadTime.Category.STEP),
                        MainThreadTime.lastFrameMicros(MainThreadTime.Category.TAKE), MainThreadTime.lastFrameMicros(MainThreadTime.Category.LIGHT),
                        MainThreadTime.lastFrameMicros(MainThreadTime.Category.DRAW));
            }
        }
    }

    @Override
    public void close() {
        if (listeningForLevelDrawn) {
            levelDrawn(Minecraft.getInstance()).volumetrics$afterLevel(null);
            listeningForLevelDrawn = false;
        }
        closeGas();
        if (depthTint != null) {
            depthTint.close();
            depthTint = null;
        }
    }

    /**
     * Adds a disc-shaped emitter on this client only, the way another mod would. False if there is no gas to add
     * to: no level, or gas is off.
     */
    boolean emit(Medium medium, Vec3 base, float radius, float rate) {
        if (gas == null || level == null) {
            return false;
        }
        GasEmitters.Handle handle = GasEmitters.of(level).add(medium, new EmitterShape.Disc(radius, EMITTER_HEIGHT), base, rate);
        debugEmitters.add(new DebugEmitter(handle, base));
        return true;
    }

    /**
     * Adds a round fog on this client only, the way another mod would, standing at {@code base}, as thick throughout
     * but for an edge a quarter of its smaller size deep. False if there is no gas to add to: no level, or gas is off.
     */
    boolean fog(Medium medium, Vec3 base, float radius, float height, float density) {
        if (gas == null || level == null) {
            return false;
        }
        Fog fog = new Fog(medium.appearance(), new FogShape.Round(radius, height), base, density, Math.min(radius, height) / 4);
        debugFogs.add(GasFogs.of(level).add(fog));
        return true;
    }

    /** Removes the fogs made with {@link #fog}, and no others. */
    int clearFogs() {
        int count = debugFogs.size();
        debugFogs.forEach(GasFogs.Handle::remove);
        debugFogs.clear();
        return count;
    }

    /** Moves every emitter made with {@link #emit} by the same offset, in blocks, and says how many there were. */
    int moveEmitters(Vec3 by) {
        debugEmitters.replaceAll(emitter -> emitter.movedBy(by));
        return debugEmitters.size();
    }

    /** A medium of the current level's datapacks, by id. */
    Optional<Medium> medium(ResourceLocation id) {
        return media().flatMap(registry -> registry.getOptional(id));
    }

    Set<ResourceLocation> mediumIds() {
        return media().map(Registry::keySet).orElse(Set.of());
    }

    /** Removes the emitters made with {@link #emit}, and no others. */
    int clearEmitters() {
        int count = debugEmitters.size();
        debugEmitters.forEach(emitter -> emitter.handle().remove());
        debugEmitters.clear();
        return count;
    }

    Quality quality() {
        return settings.quality();
    }

    /** Takes effect on the next frame and is remembered for the next session. */
    void setQuality(Quality quality) {
        settings = new ClientSettings(settings.enabled(), quality, settings.scale(), settings.reach(), settings.experiments());
        settings.save(settingsFile);
    }

    float scale() {
        return settings.scale();
    }

    /** Takes effect on the next frame and is remembered for the next session. */
    void setScale(float scale) {
        settings = new ClientSettings(settings.enabled(), settings.quality(),
                Math.clamp(scale, ClientSettings.MIN_SCALE, ClientSettings.MAX_SCALE), settings.reach(), settings.experiments());
        settings.save(settingsFile);
    }

    float reach() {
        return settings.reach();
    }

    /**
     * Sets the reach scale of the simulation (see {@link ClientSettings#reach}), remembered for the next session. From
     * the next tick the levels of the cascade are made again for it, and the gas starts again from nothing.
     */
    void setReach(float reach) {
        settings = new ClientSettings(settings.enabled(), settings.quality(), settings.scale(),
                Math.clamp(reach, CascadeLayout.MIN_REACH, CascadeLayout.MAX_REACH), settings.experiments());
        settings.save(settingsFile);
    }

    boolean temporal() {
        return experiments.get(Experiments.TEMPORAL);
    }

    /**
     * Turns temporal accumulation on or off from the next frame: each frame marched with fewer samples and blended
     * into the frames before it, or each frame drawn on its own. The {@link Experiments#TEMPORAL} experiment, so kept in
     * the settings file.
     */
    void setTemporal(boolean temporal) {
        setExperiment(Experiments.TEMPORAL, temporal ? "true" : "default");
    }

    boolean enabled() {
        return settings.enabled();
    }

    /**
     * Turns all gas off or on again, from the next tick, and is remembered for the next session. Off, the mod
     * keeps no simulation, reads nothing of the world and draws nothing; on again, gas starts from nothing.
     */
    void setEnabled(boolean enabled) {
        settings = new ClientSettings(enabled, settings.quality(), settings.scale(), settings.reach(), settings.experiments());
        settings.save(settingsFile);
    }

    Experiments experiments() {
        return experiments;
    }

    /**
     * Reads the settings file again, as the settings screen does when it opens, so that an edit made by hand while the
     * game runs counts: each setting and experiment that differs from what the client has is set as its command would
     * set it. A file that is gone or cannot be read changes nothing.
     */
    void reloadSettings() {
        ClientSettings file = ClientSettings.read(settingsFile);
        if (file == null) {
            return;
        }
        if (file.enabled() != settings.enabled()) {
            setEnabled(file.enabled());
        }
        if (file.quality() != settings.quality()) {
            setQuality(file.quality());
        }
        if (file.scale() != settings.scale()) {
            setScale(file.scale());
        }
        if (file.reach() != settings.reach()) {
            setReach(file.reach());
        }
        Map<String, String> saved = experiments.saved();
        for (Experiments.Experiment<?> experiment : Experiments.all()) {
            String text = file.experiments().get(experiment.name());
            if (!Objects.equals(text, saved.get(experiment.name())) && !setExperiment(experiment, text == null ? "default" : text)) {
                Volumetrics.LOGGER.warn("Ignoring the saved experiment {}={}, which is not a value of it", experiment.name(), text);
            }
        }
    }

    /**
     * Sets an experiment from text ({@code default} for its default) and remembers it for the next session, then does
     * what the change needs (see {@link Experiments.Rebuild}). False, and nothing changed, if the text is not a value of it.
     */
    boolean setExperiment(Experiments.Experiment<?> experiment, String text) {
        if (!experiments.set(experiment, text)) {
            return false;
        }
        settings = new ClientSettings(settings.enabled(), settings.quality(), settings.scale(), settings.reach(), experiments.saved());
        settings.save(settingsFile);
        switch (experiment.rebuild()) {
            case NOTHING, SHADERS -> {
                if (renderer != null) {
                    renderer.setOptions(rendererOptions());
                }
            }
            case RENDERER -> {
                if (renderer != null) {
                    renderer.close();
                    renderer = null;
                }
            }
            // The next tick makes it again, as when gas is turned on.
            case GAS -> closeGas();
        }
        Volumetrics.LOGGER.info("Experiment {} set; the change needed {}", experiments.describe(experiment), experiment.rebuild());
        return true;
    }

    private FieldSource fieldSource() {
        FieldSource source = FieldSource.byName(experiments.get(Experiments.FIELD_SOURCE));
        return source == null ? FieldSource.CPU : source;
    }

    private GasRenderer.Options rendererOptions() {
        return new GasRenderer.Options(!experiments.get(Experiments.NO_SKIP), experiments.get(Experiments.SHOW_EDGES),
                experiments.get(Experiments.TEMPORAL_SCALE), experiments.get(Experiments.TEMPORAL_HISTORY));
    }

    String stats() {
        if (!settings.enabled()) {
            return "Gas is off (/volumetrics enabled true)";
        }
        if (gas == null) {
            return "No level";
        }
        String gpu = "not measured (/volumetrics experiment gpu_time true)";
        if (renderer != null && experiments.get(Experiments.GPU_TIME)) {
            double march = renderer.gpuNanos(0) / 1e6;
            double accumulate = renderer.gpuNanos(1) / 1e6;
            double filter = renderer.gpuNanos(2) / 1e6;
            double composite = renderer.gpuNanos(3) / 1e6;
            gpu = String.format(Locale.ROOT, "%.3f ms (march %.3f, accumulate %.3f, filter %.3f, composite %.3f)",
                    march + accumulate + filter + composite, march, accumulate, filter, composite);
        }
        String temporalText = temporal()
                ? "temporal on (samples x" + experiments.get(Experiments.TEMPORAL_SCALE) + ", history "
                + experiments.get(Experiments.TEMPORAL_HISTORY) + ")" : "temporal off";
        RenderTarget screen = Minecraft.getInstance()./*? if >=26.1 {*//*gameRenderer.mainRenderTarget()*//*?} else {*/getMainRenderTarget()/*?}*/;
        String mainThread = MainThreadTime.reportAndReset();
        String wind = windFromServer ? String.format(Locale.ROOT, "wind: %.1f, %.1f b/s (server)", windX, windZ) : "wind: none from server";
        return "engine: " + experiments.get(Experiments.ENGINE) + (experiments.get(Experiments.SLEEP) ? "" : ", bricks never sleep")
                + "; " + gas.levels() + " levels, reach " + settings.reach() + "\nexperiments changed: " + experiments.changed()
                + "\n" + wind + "\n" + String.format(Locale.ROOT,
                "%d emitters near, %d in all; %d kinds of gas (pages %s), %d bricks held (%.1f MB); %d fogs drawn; "
                        + "simulation step %.2f ms; world scan %.3f ms a tick (scan thread %.1f us a section, %d results "
                        + "waiting, %d sections in flight), %d sections waiting near "
                        + "(and %d for their light), %d far (and %d); upload %.2f ms a step, %.2f ms for a window's light "
                        + "after a move, %d light updates waiting; quality %s at %dx%d, marched at %dx%d; %s; gas passes on GPU %s",
                gas.emitterCount(0), gas.emitterCount(gas.levels() - 1), gas.kindsInUse(),
                renderer == null ? "-" : renderer.pages(), gas.bricksHeld(), gas.bricksHeld() * 2048 / 1e6,
                renderer == null ? 0 : renderer.fogsDrawn(),
                gas.lastStepNanos() / 1e6, gas.scanNanos() / 1e6, gas.scanThreadNanosPerSection() / 1e3,
                gas.scanResultsWaiting(), gas.sectionsInFlight(),
                gas.waitingSections(0), gas.waitingForLight(0),
                gas.waitingSections(gas.levels() - 1), gas.waitingForLight(gas.levels() - 1),
                renderer == null ? 0 : renderer.uploadNanos() / 1e6, renderer == null ? 0 : renderer.lightMoveNanos() / 1e6,
                gas.lightUpdatesWaiting(),
                settings.quality().getSerializedName(), screen.width, screen.height,
                renderer == null ? 0 : renderer.marchWidth(), renderer == null ? 0 : renderer.marchHeight(), temporalText, gpu)
                + windowLines()
                + "\ncompute: " + (renderer == null ? "no renderer" : renderer.compute().line() + ", field source " + renderer.fieldSource().text())
                + "\ninputs: " + (renderer == null ? "no renderer" : renderer.inputs()) + "\n" + mainThread;
    }

    /**
     * One line a level: its recent step time (level k steps every 2^k base steps) split into nesting and snapshot, and
     * what the stepper did to its bricks.
     */
    private String windowLines() {
        StringBuilder lines = new StringBuilder();
        for (int window = 0; window < gas.levels(); window++) {
            WindowStepStats stats = gas.stepStats(window);
            StepStats bricks = stats.last();
            lines.append(String.format(Locale.ROOT,
                    "\nlevel %d (%d-block): step %.2f ms (nest %.2f, snapshot %.2f) | bricks visited %d changed %d settled %d asleep %d edge %d skipped %d",
                    window, gas.cellSize(window), stats.stepNanos() / 1e6, stats.nestNanos() / 1e6, stats.snapshotNanos() / 1e6,
                    bricks.visited(), bricks.changed(), bricks.settled(), bricks.asleep(), bricks.edge(), bricks.skipped()));
        }
        return lines.toString();
    }

    /** Empty on a server that does not have the mod: its registries are simply not there. */
    private Optional<Registry<Medium>> media() {
        return level == null ? Optional.empty() : level.registryAccess()./*? if >=26.1 {*//*lookup*//*?} else {*/registry/*?}*/(VolumetricsRegistries.MEDIUM);
    }

    /** The emitter definitions that are placed by block, each with its medium looked up. */
    private static List<BlockEmitterRule> blockRules(RegistryAccess registries) {
        Optional<Registry<EmitterDefinition>> emitters = registries./*? if >=26.1 {*//*lookup*//*?} else {*/registry/*?}*/(VolumetricsRegistries.EMITTER);
        Optional<Registry<Medium>> media = registries./*? if >=26.1 {*//*lookup*//*?} else {*/registry/*?}*/(VolumetricsRegistries.MEDIUM);
        if (emitters.isEmpty() || media.isEmpty()) {
            return List.of();
        }
        List<BlockEmitterRule> rules = new ArrayList<>();
        emitters.get().entrySet().forEach(entry -> {
            EmitterDefinition definition = entry.getValue();
            Medium medium = media.get()./*? if >=26.1 {*//*getValue*//*?} else {*/get/*?}*/(definition.medium());
            if (medium == null) {
                Volumetrics.LOGGER.warn("Emitter {} names a medium that does not exist: {}",
                        entry.getKey()./*? if >=26.1 {*//*identifier*//*?} else {*/location/*?}*/(), definition.medium()./*? if >=26.1 {*//*identifier*//*?} else {*/location/*?}*/());
            } else if (definition.placement() instanceof Placement.Block(var blocks, var state)) {
                rules.add(new BlockEmitterRule(entry.getKey()./*? if >=26.1 {*//*identifier*//*?} else {*/location/*?}*/(), blocks, state, medium,
                        definition.shape(), definition.offset(), definition.rate()));
            }
        });
        return rules;
    }

    private void closeGas() {
        if (renderer != null) {
            renderer.close();
            renderer = null;
        }
        if (gas != null) {
            //? if >=26.1 {
            /*worldChanges(Minecraft.getInstance()).volumetrics$listen(null);
            *///?} else {
            // The level the gas was made for, which is the one still in the field while this runs.
            worldChanges(level).volumetrics$listen(null);
            //?}
            gas.close();
            gas = null;
        }
    }

    /** The game's renderer as the mod's mixin has made it; see {@code GameRendererMixin}. */
    private static AfterLevelSource levelDrawn(Minecraft minecraft) {
        return (AfterLevelSource) minecraft.gameRenderer;
    }

    //? if >=26.1 {
    /*/^* The game's level extractor as the mod's mixin has made it; see {@code LevelExtractorMixin}. ^/
    private static WorldChangeSource worldChanges(Minecraft minecraft) {
        return (WorldChangeSource) minecraft.levelExtractor;
    }
    *///?} else {
    // The game's level as the mod's mixin has made it; see ClientLevelMixin.
    private static WorldChangeSource worldChanges(ClientLevel level) {
        return (WorldChangeSource) level;
    }

    // The texture that holds the level's depth once the level has been drawn. It is the main target's, except
    // with the graphics setting on Fabulous: there the game draws translucent things into targets of their own
    // and lays them over the main one at the end, wiping the main target's depth as it does. The target for
    // translucent blocks still has it then: a copy of the solid level's depth, and those blocks' own.
    private static int levelDepthTexture(Minecraft minecraft) {
        RenderTarget translucent = minecraft.levelRenderer.getTranslucentTarget();
        return (translucent != null ? translucent : minecraft.getMainRenderTarget()).getDepthTextureId();
    }

    // The game's lightmap for the level, as the number of its texture. The game keeps the texture to itself;
    // putting it where the game's own shaders find it, as the game does before it draws anything lit, leaves
    // that number where it can be read.
    private static int lightmapTexture(Minecraft minecraft) {
        minecraft.gameRenderer.lightTexture().turnOnLightLayer();
        return RenderSystem.getShaderTexture(LIGHTMAP_SHADER_TEXTURE);
    }
    //?}

    /** An emitter made with the debug command, and where it was last put: a handle does not tell. */
    private record DebugEmitter(GasEmitters.Handle handle, Vec3 base) {
        DebugEmitter movedBy(Vec3 offset) {
            Vec3 to = base.add(offset);
            handle.moveTo(to);
            return new DebugEmitter(handle, to);
        }
    }

    private void logBackendOnce() {
        if (backendLogged) {
            return;
        }
        backendLogged = true;
        //? if >=26.1 {
        /*DeviceInfo device = RenderSystem.getDevice().getDeviceInfo();
        Volumetrics.LOGGER.info("Volumetrics is rendering on {} ({}, {})", device.backendName(), device.name(), device.driverInfo());
        *///?} else {
        Volumetrics.LOGGER.info("Volumetrics is rendering on OpenGL ({}, {})", GlUtil.getRenderer(), GlUtil.getOpenGLVersion());
        //?}
    }
}
