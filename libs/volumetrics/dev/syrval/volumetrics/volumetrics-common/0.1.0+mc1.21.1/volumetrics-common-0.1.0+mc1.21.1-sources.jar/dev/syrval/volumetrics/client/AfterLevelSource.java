package dev.syrval.volumetrics.client;

//? if >=26.1 {
/*import org.joml.Matrix4fc;
*///?} else {
import java.util.function.Consumer;
//?}
import org.jspecify.annotations.Nullable;

/**
 * What the game's {@code GameRenderer} is once this mod's mixin has been applied to it: something that tells
 * when the level has been drawn. The listener is kept on the renderer itself, so there is nothing static between
 * the mixin and the mod.
 */
public interface AfterLevelSource {
    //? if >=26.1 {
    /*/^* Sets what is run each frame once the level has been drawn, in place of anything set before; null for nothing. ^/
    void volumetrics$afterLevel(@Nullable Runnable listener);

    /^*
     * The projection the level was last drawn with, view bobbing and the nausea warp multiplied into it: what the
     * game's shaders read as {@code ProjMat} while the level is drawn. The game keeps it nowhere else; the object is
     * the renderer's own and is written again each frame.
     ^/
    Matrix4fc volumetrics$levelProjection();
    *///?} else {
    // Sets who is told each frame once the level has been drawn, in place of anyone told before; null for nobody.
    void volumetrics$afterLevel(@Nullable Consumer<LevelView> listener);
    //?}
}
