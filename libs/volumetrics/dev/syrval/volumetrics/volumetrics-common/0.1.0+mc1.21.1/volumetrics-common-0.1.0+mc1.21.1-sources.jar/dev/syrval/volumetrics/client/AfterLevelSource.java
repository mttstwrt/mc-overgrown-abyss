package dev.syrval.volumetrics.client;

import java.util.function.Consumer;
import org.jspecify.annotations.Nullable;

/**
 * What the game's {@code GameRenderer} is once this mod's mixin has been applied to it: something that tells
 * when the level has been drawn. The listener is kept on the renderer itself, so there is nothing static between
 * the mixin and the mod.
 */
public interface AfterLevelSource {
    /** Sets who is told each frame once the level has been drawn, in place of anyone told before; null for nobody. */
    void volumetrics$afterLevel(@Nullable Consumer<LevelView> listener);
}
