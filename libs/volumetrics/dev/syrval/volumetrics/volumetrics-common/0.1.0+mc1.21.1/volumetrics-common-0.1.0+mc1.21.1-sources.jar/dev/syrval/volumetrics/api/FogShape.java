package dev.syrval.volumetrics.api;

/** The room a {@link Fog} fills, standing on the point it is anchored to and centred on it sideways. */
public sealed interface FogShape {
    /** Height in blocks, from the anchor up. */
    float height();

    /** How far the shape reaches from its anchor sideways, at most, in blocks. */
    float reach();

    /**
     * Upright and round: a cylinder when the two radii are the same, a cone, a funnel or a bowl's inside when they
     * are not. The radius changes evenly from the bottom to the top.
     */
    record Round(float bottomRadius, float topRadius, float height) implements FogShape {
        public Round {
            requirePositive(bottomRadius, "bottom radius");
            requirePositive(topRadius, "top radius");
            requirePositive(height, "height");
        }

        /** A cylinder. */
        public Round(float radius, float height) {
            this(radius, radius, height);
        }

        @Override
        public float reach() {
            return Math.max(bottomRadius, topRadius);
        }
    }

    /** A box, {@code width} along X and {@code depth} along Z. */
    record Box(float width, float height, float depth) implements FogShape {
        public Box {
            requirePositive(width, "width");
            requirePositive(height, "height");
            requirePositive(depth, "depth");
        }

        @Override
        public float reach() {
            return (float) Math.hypot(width / 2, depth / 2);
        }
    }

    private static void requirePositive(float value, String name) {
        if (!(value > 0) || !Float.isFinite(value)) {
            throw new IllegalArgumentException("A fog's " + name + " must be a positive number, got " + value);
        }
    }
}
