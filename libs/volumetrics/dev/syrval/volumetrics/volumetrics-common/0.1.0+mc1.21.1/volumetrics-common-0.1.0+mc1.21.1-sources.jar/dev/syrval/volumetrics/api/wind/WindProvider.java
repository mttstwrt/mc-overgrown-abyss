package dev.syrval.volumetrics.api.wind;

import net.minecraft.server.level.ServerLevel;
import org.jspecify.annotations.Nullable;

/**
 * Tells the library what the wind is. Server only: clients are sent the result, and a server without a provider
 * sends nothing, so that gas keeps moving on its own drift. Called on the server thread, about once a second for
 * each level, so it should be cheap. Values are clamped to 16 blocks per second and at most 64 areas are used.
 */
@FunctionalInterface
public interface WindProvider {
    /**
     * @param gameTime the level's game time in ticks
     * @return the wind of the level now, or null for no wind
     */
    @Nullable Wind windFor(ServerLevel level, long gameTime);
}
