package dev.syrval.volumetrics.client.dev;

//? if >=26.1 {
/*import com.mojang.blaze3d.pipeline.RenderTarget;
*///?} else {
import com.mojang.blaze3d.platform.NativeImage;
//?}
import dev.syrval.volumetrics.Volumetrics;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
//? if <26.1 {
import net.minecraft.Util;
//?}
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.player.LocalPlayer;
//? if >=26.1 {
/*import net.minecraft.util.Util;
*///?}
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

/**
 * Development aid for the phase gates, so that one can be shown without anyone at the keyboard. With
 * {@code -Dvolumetrics.capture=<file.png>} the client, once in a world, runs the commands in the file named by
 * {@code -Dvolumetrics.capture.script} as if typed, then after {@code -Dvolumetrics.capture.seconds} (20 by
 * default) saves what the level looks like, without hand or HUD, and quits. In the script, one command a line:
 *
 * <ul>
 *   <li>a plain line runs three seconds in, once the player and the first chunks are there;
 *   <li>{@code @40 command} runs 40 seconds in;
 *   <li>lines below a line of {@code ---} run a second before the capture;
 *   <li>{@code capture name} is not a command for the game: it saves a capture there and then, as
 *       {@code name.png} beside the final one, so that one run can show several views;
 *   <li>{@code glide x y z seconds} is not one either: it flies the player in a straight line from where they
 *       are to that place in that many seconds, for looking at the gas with the camera moving. The player must
 *       be allowed to fly, and nothing keeps them out of the ground;
 *   <li>{@code record name seconds} saves the level for that long, thirty times a second at half size, as
 *       numbered pictures in a folder {@code name} beside the final capture: the makings of a clip.
 * </ul>
 */
public final class GateCapture {
    private static final long NANOS_PER_SECOND = 1_000_000_000L;
    private static final long FIRST_COMMANDS_NANOS = 3 * NANOS_PER_SECOND;
    private static final String LAST_COMMANDS_MARK = "---";
    private static final String TIME_MARK = "@";
    private static final String CAPTURE = "capture ";
    //? if <26.1 {
    // "screen name" saves the whole frame like "capture", hand and HUD included, once the frame has been drawn to
    // the end: the check on what this mod leaves behind it, since whatever the game draws after the gas is drawn
    // with the OpenGL state the gas passes left.
    private static final String SCREEN = "screen ";
    //?}
    private static final String GLIDE = "glide ";
    private static final String RECORD = "record ";
    private static final long RECORD_FRAME_NANOS = NANOS_PER_SECOND / 30;

    private final Path output;
    /** In the order they are due. */
    private final List<Timed> commands;
    private final long settleNanos;
    private long firstFrameNanos;
    private int commandsRun;
    private boolean requested;
    //? if <26.1 {
    // Where to save the frame being drawn once it is whole, or null if nobody asked.
    private @Nullable Path screenFile;
    //?}
    private @Nullable Glide glide;
    private @Nullable Path recordFolder;
    private long recordUntilNanos;
    private long recordNextNanos;
    private int recordFrames;

    private GateCapture(Path output, List<Timed> commands, long settleNanos) {
        this.output = output;
        this.commands = commands;
        this.settleNanos = settleNanos;
    }

    private record Timed(long afterNanos, String command) {}

    private record Glide(Vec3 from, Vec3 to, long startNanos, long nanos) {
        /** @param text what follows the word glide: x, y, z and the seconds to take */
        static Glide parse(String text, Vec3 from, long startNanos) {
            String[] parts = text.strip().split("\\s+");
            Vec3 to = new Vec3(Double.parseDouble(parts[0]), Double.parseDouble(parts[1]), Double.parseDouble(parts[2]));
            return new Glide(from, to, startNanos, (long) (Double.parseDouble(parts[3]) * NANOS_PER_SECOND));
        }

        /** How much of the way is behind the player at a given time, 0 to 1. */
        double done(long nowNanos) {
            return Math.clamp((nowNanos - startNanos) / (double) nanos, 0.0, 1.0);
        }
    }

    public static @Nullable GateCapture fromSystemProperty() {
        String path = System.getProperty("volumetrics.capture");
        if (path == null) {
            return null;
        }
        long settleNanos = Long.getLong("volumetrics.capture.seconds", 20) * NANOS_PER_SECOND;
        return new GateCapture(Path.of(path), readScript(System.getProperty("volumetrics.capture.script"), settleNanos), settleNanos);
    }

    /** Once per client tick: moves the player along the glide under way, if there is one. */
    public void tick(Minecraft minecraft) {
        //? if <26.1 {
        if (screenFile != null) {
            // Between frames: the main target still holds the last one, drawn to the end.
            save(minecraft, screenFile, false);
            screenFile = null;
        }
        //?}
        LocalPlayer player = minecraft.player;
        if (glide == null || player == null) {
            return;
        }
        // Flying, or gravity would pull at the player between one tick's place and the next.
        if (!player.getAbilities().flying) {
            player.getAbilities().flying = true;
            player.onUpdateAbilities();
        }
        double done = glide.done(System.nanoTime());
        player.setPos(glide.from().lerp(glide.to(), done));
        player.setDeltaMovement(Vec3.ZERO);
        if (done >= 1.0) {
            glide = null;
        }
    }

    public void afterLevelRendered(Minecraft minecraft) {
        long now = System.nanoTime();
        if (firstFrameNanos == 0) {
            firstFrameNanos = now;
        }
        long elapsed = now - firstFrameNanos;
        while (minecraft.player != null && commandsRun < commands.size() && elapsed >= commands.get(commandsRun).afterNanos()) {
            String command = commands.get(commandsRun++).command();
            if (command.startsWith(CAPTURE)) {
                save(minecraft, output.resolveSibling(command.substring(CAPTURE.length()).strip() + ".png"), false);
            //? if <26.1 {
            } else if (command.startsWith(SCREEN)) {
                screenFile = output.resolveSibling(command.substring(SCREEN.length()).strip() + ".png");
            //?}
            } else if (command.startsWith(RECORD)) {
                startRecording(command.substring(RECORD.length()), now);
            } else if (command.startsWith(GLIDE)) {
                glide = Glide.parse(command.substring(GLIDE.length()), minecraft.player.position(), now);
                Volumetrics.LOGGER.info("Gate capture glides to {}", glide.to());
            } else {
                Volumetrics.LOGGER.info("Gate capture runs /{}", command);
                minecraft.player.connection.sendCommand(command);
            }
        }
        if (recordFolder != null) {
            record(minecraft, recordFolder, now);
        }
        if (requested || elapsed < settleNanos) {
            return;
        }
        requested = true;
        save(minecraft, output, true);
    }

    /** @param text what follows the word record: the folder's name and the seconds to record for */
    private void startRecording(String text, long now) {
        String[] parts = text.strip().split("\\s+");
        Path folder = output.resolveSibling(parts[0]);
        try {
            Files.createDirectories(folder);
        } catch (IOException e) {
            throw new UncheckedIOException("Could not make " + folder, e);
        }
        recordFolder = folder;
        recordUntilNanos = now + (long) (Double.parseDouble(parts[1]) * NANOS_PER_SECOND);
        recordNextNanos = now;
        recordFrames = 0;
    }

    private void record(Minecraft minecraft, Path folder, long now) {
        if (now >= recordUntilNanos) {
            Volumetrics.LOGGER.info("Recorded {} frames to {}", recordFrames, folder);
            recordFolder = null;
            return;
        }
        if (now < recordNextNanos) {
            return;
        }
        recordNextNanos = Math.max(recordNextNanos + RECORD_FRAME_NANOS, now);
        //? if >=26.1 {
        /*RenderTarget target = minecraft.gameRenderer.mainRenderTarget();
        int scale = target.width % 2 == 0 && target.height % 2 == 0 ? 2 : 1;
        Path file = folder.resolve(String.format(Locale.ROOT, "frame-%04d.png", recordFrames++));
        // Writing a picture takes longer than a frame; off this thread, as the game's own screenshots are.
        Screenshot.takeScreenshot(target, scale, image -> Util.ioPool().execute(() -> {
            try (image) {
                image.writeToFile(file);
            } catch (IOException e) {
                Volumetrics.LOGGER.error("Could not write {}", file, e);
            }
        }));
        *///?} else {
        Path file = folder.resolve(String.format(Locale.ROOT, "frame-%04d.png", recordFrames++));
        NativeImage full = Screenshot.takeScreenshot(minecraft.getMainRenderTarget());
        // Halving and writing a picture take longer than a frame; off this thread, as the game's own screenshots are.
        Util.ioPool().execute(() -> {
            try (full; NativeImage half = new NativeImage(full.getWidth() / 2, full.getHeight() / 2, false)) {
                full.resizeSubRectTo(0, 0, full.getWidth(), full.getHeight(), half);
                half.writeToFile(file);
            } catch (IOException e) {
                Volumetrics.LOGGER.error("Could not write {}", file, e);
            }
        });
        //?}
    }

    private static void save(Minecraft minecraft, Path file, boolean thenQuit) {
        //? if >=26.1 {
        /*Screenshot.takeScreenshot(minecraft.gameRenderer.mainRenderTarget(), image -> {
            try (image) {
                image.writeToFile(file);
                Volumetrics.LOGGER.info(thenQuit ? "Gate capture written to {}" : "View saved to {}", file);
            } catch (IOException e) {
                Volumetrics.LOGGER.error("Could not write gate capture to {}", file, e);
            }
            if (thenQuit) {
                minecraft.stop();
            }
        });
        *///?} else {
        try (NativeImage image = Screenshot.takeScreenshot(minecraft.getMainRenderTarget())) {
            image.writeToFile(file);
            Volumetrics.LOGGER.info(thenQuit ? "Gate capture written to {}" : "View saved to {}", file);
        } catch (IOException e) {
            Volumetrics.LOGGER.error("Could not write gate capture to {}", file, e);
        }
        if (thenQuit) {
            minecraft.stop();
        }
        //?}
    }

    private static List<Timed> readScript(@Nullable String path, long settleNanos) {
        if (path == null) {
            return List.of();
        }
        List<String> lines;
        try {
            lines = Files.readAllLines(Path.of(path));
        } catch (IOException e) {
            throw new UncheckedIOException("Could not read capture script " + path, e);
        }
        List<Timed> commands = new ArrayList<>();
        long due = FIRST_COMMANDS_NANOS;
        for (String line : lines) {
            String command = line.strip();
            if (command.isEmpty()) {
                continue;
            }
            if (command.equals(LAST_COMMANDS_MARK)) {
                due = settleNanos - NANOS_PER_SECOND;
            } else if (command.startsWith(TIME_MARK)) {
                String[] parts = command.substring(TIME_MARK.length()).split("\\s+", 2);
                commands.add(new Timed(Long.parseLong(parts[0]) * NANOS_PER_SECOND, parts[1]));
            } else {
                commands.add(new Timed(due, command));
            }
        }
        // A stable sort: commands due at the same moment keep the order they were written in.
        commands.sort(Comparator.comparingLong(Timed::afterNanos));
        return List.copyOf(commands);
    }
}
