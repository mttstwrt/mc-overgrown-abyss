package dev.syrval.volumetrics.sim;

import java.util.Arrays;

/** Moves the contents of a window array when the window itself moves through the world. */
public final class GridShift {
    private GridShift() {}

    /**
     * After the window origin moves by the given number of cells, the value that was at local cell
     * {@code (x + dx, y + dy, z + dz)} belongs at {@code (x, y, z)}. Cells that just entered get {@code fill}. Done in
     * place, a row of cells along X at a time: rows are visited in the order that reads each row before it is
     * written over, so nothing is allocated.
     */
    public static void shift(float[] cells, GridSize size, int dx, int dy, int dz, float fill) {
        Span spanX = Span.of(size.x(), dx);
        if (spanX.length() <= 0) {
            Arrays.fill(cells, fill);
            return;
        }
        int rows = size.y() * size.z();
        boolean ascending = dz + size.z() * dy >= 0;
        for (int i = 0; i < rows; i++) {
            int row = ascending ? i : rows - 1 - i;
            int y = row / size.z();
            int z = row % size.z();
            int start = size.index(0, y, z);
            if (!size.contains(0, y + dy, z + dz)) {
                Arrays.fill(cells, start, start + size.x(), fill);
                continue;
            }
            System.arraycopy(cells, size.index(spanX.from() + dx, y + dy, z + dz), cells, start + spanX.from(), spanX.length());
            Arrays.fill(cells, start, start + spanX.from(), fill);
            Arrays.fill(cells, start + spanX.from() + spanX.length(), start + size.x(), fill);
        }
    }

    public static void shift(byte[] cells, GridSize size, int dx, int dy, int dz, byte fill) {
        shift(cells, size, 1, dx, dy, dz, fill);
    }

    /** The same for an array that holds {@code bytesPerCell} bytes for each cell, one cell after the other. */
    public static void shift(byte[] cells, GridSize size, int bytesPerCell, int dx, int dy, int dz, byte fill) {
        Span spanX = Span.of(size.x(), dx);
        if (spanX.length() <= 0) {
            Arrays.fill(cells, fill);
            return;
        }
        int rows = size.y() * size.z();
        int rowBytes = size.x() * bytesPerCell;
        boolean ascending = dz + size.z() * dy >= 0;
        for (int i = 0; i < rows; i++) {
            int row = ascending ? i : rows - 1 - i;
            int y = row / size.z();
            int z = row % size.z();
            int start = size.index(0, y, z) * bytesPerCell;
            if (!size.contains(0, y + dy, z + dz)) {
                Arrays.fill(cells, start, start + rowBytes, fill);
                continue;
            }
            int from = start + spanX.from() * bytesPerCell;
            int length = spanX.length() * bytesPerCell;
            System.arraycopy(cells, size.index(spanX.from() + dx, y + dy, z + dz) * bytesPerCell, cells, from, length);
            Arrays.fill(cells, start, from, fill);
            Arrays.fill(cells, from + length, start + rowBytes, fill);
        }
    }

    /** The destination cells on one axis whose source cell is still inside the window. */
    private record Span(int from, int length) {
        static Span of(int cells, int delta) {
            int from = Math.max(0, -delta);
            int to = Math.min(cells, cells - delta);
            return new Span(from, to - from);
        }
    }
}
