package dev.syrval.volumetrics.sim;

import java.util.Arrays;

/** Moves the contents of a window array when the window itself moves through the world. */
public final class GridShift {
    private GridShift() {}

    /**
     * After the window origin moves by the given number of cells, the value that was at local cell
     * {@code (x + dx, y + dy, z + dz)} belongs at {@code (x, y, z)}. Cells that just entered get {@code fill}.
     */
    public static void shift(float[] cells, GridSize size, int dx, int dy, int dz, float fill) {
        float[] old = cells.clone();
        Arrays.fill(cells, fill);
        Span spanX = Span.of(size.x(), dx);
        if (spanX.length() <= 0) {
            return;
        }
        for (int y = 0; y < size.y(); y++) {
            for (int z = 0; z < size.z(); z++) {
                if (size.contains(0, y + dy, z + dz)) {
                    System.arraycopy(old, size.index(spanX.from() + dx, y + dy, z + dz),
                            cells, size.index(spanX.from(), y, z), spanX.length());
                }
            }
        }
    }

    public static void shift(byte[] cells, GridSize size, int dx, int dy, int dz, byte fill) {
        shift(cells, size, 1, dx, dy, dz, fill);
    }

    /** The same for an array that holds {@code bytesPerCell} bytes for each cell, one cell after the other. */
    public static void shift(byte[] cells, GridSize size, int bytesPerCell, int dx, int dy, int dz, byte fill) {
        byte[] old = cells.clone();
        Arrays.fill(cells, fill);
        Span spanX = Span.of(size.x(), dx);
        if (spanX.length() <= 0) {
            return;
        }
        for (int y = 0; y < size.y(); y++) {
            for (int z = 0; z < size.z(); z++) {
                if (size.contains(0, y + dy, z + dz)) {
                    System.arraycopy(old, size.index(spanX.from() + dx, y + dy, z + dz) * bytesPerCell,
                            cells, size.index(spanX.from(), y, z) * bytesPerCell, spanX.length() * bytesPerCell);
                }
            }
        }
    }

    /** The destination cells on one axis whose source cell is still inside the window. */
    private record Span(int from, int length) {
        static Span of(int cells, int delta) {
            int from = Math.max(0, -delta);
            int to = Math.min(cells, cells - delta);
            return new Span(from, to - from);
        }
    }
}
