package dev.syrval.volumetrics.client.render.gl;

import java.util.OptionalLong;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL33;
import org.lwjgl.opengl.GLCapabilities;

/**
 * A set of queries, each of which can be asked for the GPU's clock at the point in its work where the query is
 * written. The game's own timer measures one stretch at a time and is in use while the debug screen shows GPU
 * load; two such measurements may not overlap, where any number of these may.
 */
public final class GlTimestamps implements AutoCloseable {
    private final int[] queries;

    public GlTimestamps(int count) {
        this.queries = new int[count];
        GL15.glGenQueries(queries);
    }

    /** Whether this GPU and driver can do it: OpenGL 3.3, or the extension it came from. */
    public static boolean supported() {
        GLCapabilities capabilities = GL.getCapabilities();
        return capabilities.OpenGL33 || capabilities.GL_ARB_timer_query;
    }

    public void write(int index) {
        GL33.glQueryCounter(queries[index], GL33.GL_TIMESTAMP);
    }

    /** The clock at a query that has been written, in nanoseconds, or empty while the GPU has not got there yet. */
    public OptionalLong nanos(int index) {
        if (GL15.glGetQueryObjecti(queries[index], GL15.GL_QUERY_RESULT_AVAILABLE) == 0) {
            return OptionalLong.empty();
        }
        return OptionalLong.of(GL33.glGetQueryObjecti64(queries[index], GL15.GL_QUERY_RESULT));
    }

    @Override
    public void close() {
        GL15.glDeleteQueries(queries);
    }
}
