package dev.syrval.volumetrics.sim;

/**
 * A stand-in engine: the sources feed the gas and its decay applies, but nothing moves. For telling what the
 * simulation does from what the world and the stores do, and as the smallest example of a {@link SimEngine}.
 */
public final class DecayOnlyEngine implements SimEngine {
    public static final String NAME = "decay";
    private static final float MIN_DENSITY = 1f / 512f;

    private final GasStepper stepper = new GasStepper(MIN_DENSITY);

    public static SimEngine.Factory factory() {
        return (size, cellSize, coarser) -> new DecayOnlyEngine();
    }

    @Override
    public String name() {
        return NAME;
    }

    @Override
    public void step(EngineWindow window, WindowInputs inputs, float stepSeconds) {
        for (EngineWindow.Kind kind : window.kinds()) {
            if (kind.sources().isEmpty() && kind.store().isEmpty()) {
                continue;
            }
            MediumParams own = kind.properties().params();
            // No gravity, dispersion or drift: the stepper then only feeds and decays.
            MediumParams still = new MediumParams(0f, 0f, own.decay(), own.maxDensity());
            GasField field = window.workspace();
            kind.store().loadInto(field);
            stepper.step(field, window.occupancy(), still, window.placement(), kind.sources(), stepSeconds);
            kind.store().takeFrom(field);
        }
    }
}
