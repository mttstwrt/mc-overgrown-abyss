package dev.syrval.volumetrics.client.render.gl;

import com.mojang.blaze3d.platform.GlStateManager;
import dev.syrval.volumetrics.Volumetrics;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.server.packs.resources.ResourceProvider;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL31;
import org.lwjgl.system.MemoryStack;

/**
 * A shader program that draws over the whole of its target: this mod's fullscreen vertex shader and one of its
 * fragment shaders, read from {@code assets/volumetrics/shaders}.
 *
 * <p>The game's own shader class is not used. It has no uniform blocks and no defines, it resolves includes from
 * other namespaces differently on each loader, and a shader mod hooks it. Compiling the sources here needs
 * none of that and is the same everywhere.
 */
public final class GlProgram implements AutoCloseable {
    /** The GLSL version of the game's own shaders on this version of the game: what its OpenGL 3.2 context promises. */
    private static final String VERSION = "#version 150\n";
    private static final String VERTEX_SHADER = "core/gas_screen.vsh";
    private static final Pattern INCLUDE = Pattern.compile("(?m)^[ \\t]*#include[ \\t]*<volumetrics:([a-z0-9_./]+)>[ \\t]*$");
    /** An include including an include, this deep, is taken for a loop. */
    private static final int MAX_INCLUDE_DEPTH = 8;
    /**
     * Binding points are shared by everything that draws. These are high ones, out of the way of anything that
     * takes the first few and expects to find its buffers still there.
     */
    private static final int FIRST_BLOCK_BINDING = 24;

    private final int id;
    private final Map<String, Integer> samplerUnits = new HashMap<>();
    private final Map<String, Integer> blockBindings = new HashMap<>();
    private final Map<String, Integer> blockBytes = new HashMap<>();

    /**
     * @param fragmentShader path of the fragment shader under {@code assets/volumetrics/shaders}
     * @param defines        each becomes a {@code #define} at the top of the fragment shader
     */
    public GlProgram(ResourceProvider resources, String fragmentShader, Map<String, String> defines) {
        String header = VERSION + defines.entrySet().stream()
                .map(define -> "#define " + define.getKey() + " " + define.getValue() + "\n")
                .collect(Collectors.joining());
        int vertex = compile(GL20.GL_VERTEX_SHADER, VERTEX_SHADER, VERSION + source(resources, VERTEX_SHADER, 0));
        int fragment = compile(GL20.GL_FRAGMENT_SHADER, fragmentShader, header + source(resources, fragmentShader, 0));
        this.id = GlStateManager.glCreateProgram();
        GlStateManager.glAttachShader(id, vertex);
        GlStateManager.glAttachShader(id, fragment);
        GlStateManager.glLinkProgram(id);
        GlStateManager.glDeleteShader(vertex);
        GlStateManager.glDeleteShader(fragment);
        if (GlStateManager.glGetProgrami(id, GL20.GL_LINK_STATUS) == GL11.GL_FALSE) {
            String log = GlStateManager.glGetProgramInfoLog(id, 32768);
            GlStateManager.glDeleteProgram(id);
            throw new IllegalStateException("Could not link " + fragmentShader + ": " + log);
        }
        assignSamplers(fragmentShader);
        assignBlocks();
    }

    /** Makes this the program that draws. Whoever calls this puts the previous one back; see {@link ScreenPass}. */
    void use() {
        GlStateManager._glUseProgram(id);
    }

    /** Gives a sampler of the shader its texture. A sampler the shader does not use is not there, and nothing happens. */
    public void setTexture(String sampler, int texture) {
        Integer unit = samplerUnits.get(sampler);
        if (unit != null) {
            GlStateManager._activeTexture(GL13.GL_TEXTURE0 + unit);
            GlStateManager._bindTexture(texture);
        }
    }

    /** Gives a uniform block of the shader its contents. */
    public void setBlock(String block, GlUniformBuffer buffer) {
        Integer binding = blockBindings.get(block);
        if (binding == null) {
            throw new IllegalArgumentException("No uniform block " + block);
        }
        GL31.glBindBufferBase(GL31.GL_UNIFORM_BUFFER, binding, buffer.id());
    }

    /** The size of one of the shader's uniform blocks, which a buffer for it must have. */
    public int blockBytes(String block) {
        Integer bytes = blockBytes.get(block);
        if (bytes == null) {
            throw new IllegalArgumentException("No uniform block " + block);
        }
        return bytes;
    }

    @Override
    public void close() {
        GlStateManager.glDeleteProgram(id);
    }

    /** Every sampler gets a texture unit of its own, for good: the order the driver lists them in. */
    private void assignSamplers(String name) {
        int before = GlStateManager._getInteger(GL20.GL_CURRENT_PROGRAM);
        GlStateManager._glUseProgram(id);
        try (MemoryStack stack = MemoryStack.stackPush()) {
            IntBuffer size = stack.mallocInt(1);
            IntBuffer type = stack.mallocInt(1);
            int uniforms = GlStateManager.glGetProgrami(id, GL20.GL_ACTIVE_UNIFORMS);
            for (int index = 0; index < uniforms; index++) {
                String uniform = GL20.glGetActiveUniform(id, index, size, type);
                if (type.get(0) != GL20.GL_SAMPLER_2D) {
                    continue;
                }
                int unit = samplerUnits.size();
                // The game keeps track of this many units, and binding a texture to one beyond them fails.
                if (unit >= GlStateManager.TEXTURE_COUNT) {
                    throw new IllegalStateException(name + " reads more than " + GlStateManager.TEXTURE_COUNT + " textures");
                }
                samplerUnits.put(uniform, unit);
                GlStateManager._glUniform1i(GlStateManager._glGetUniformLocation(id, uniform), unit);
            }
        } finally {
            GlStateManager._glUseProgram(before);
        }
    }

    private void assignBlocks() {
        int blocks = GlStateManager.glGetProgrami(id, GL31.GL_ACTIVE_UNIFORM_BLOCKS);
        for (int index = 0; index < blocks; index++) {
            String block = GL31.glGetActiveUniformBlockName(id, index);
            GL31.glUniformBlockBinding(id, index, FIRST_BLOCK_BINDING + index);
            blockBindings.put(block, FIRST_BLOCK_BINDING + index);
            blockBytes.put(block, GL31.glGetActiveUniformBlocki(id, index, GL31.GL_UNIFORM_BLOCK_DATA_SIZE));
        }
    }

    private static int compile(int type, String name, String source) {
        int shader = GlStateManager.glCreateShader(type);
        GlStateManager.glShaderSource(shader, List.of(source));
        GlStateManager.glCompileShader(shader);
        if (GlStateManager.glGetShaderi(shader, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
            String log = GlStateManager.glGetShaderInfoLog(shader, 32768);
            GlStateManager.glDeleteShader(shader);
            throw new IllegalStateException("Could not compile " + name + ": " + log);
        }
        return shader;
    }

    /** A shader file with every {@code #include <volumetrics:file>} replaced by {@code shaders/include/file}. */
    private static String source(ResourceProvider resources, String path, int depth) {
        if (depth > MAX_INCLUDE_DEPTH) {
            throw new IllegalStateException("Shader includes go round in a circle at " + path);
        }
        String text;
        try (BufferedReader reader = resources.openAsReader(Volumetrics.id("shaders/" + path))) {
            text = reader.lines().collect(Collectors.joining("\n", "", "\n"));
        } catch (IOException e) {
            throw new UncheckedIOException("Could not read shader " + path, e);
        }
        Matcher include = INCLUDE.matcher(text);
        return include.replaceAll(found -> Matcher.quoteReplacement(source(resources, "include/" + found.group(1), depth + 1)));
    }
}
