package dev.syrval.volumetrics.sim;

import java.util.Arrays;

/**
 * How dense the air of a level is at each height, relative to the air at sea level. Gas with a {@link Buoyancy}
 * rises where it is lighter than this and sinks where it is heavier, so it settles at the height where the two
 * match. Plain data: one density per block from the bottom of the level to its top, decided by the server.
 */
public final class AmbientProfile {
    private final int seaLevel;
    private final int minY;
    // Density in the middle of each block, from minY up.
    private final float[] densities;
    private final boolean flat;

    private AmbientProfile(int seaLevel, int minY, float[] densities) {
        if (densities.length == 0) {
            throw new IllegalArgumentException("A profile needs at least one block");
        }
        boolean same = true;
        for (float density : densities) {
            if (!Float.isFinite(density) || density <= 0) {
                throw new IllegalArgumentException("Densities must be finite and positive, got " + density);
            }
            same &= density == densities[0];
        }
        this.seaLevel = seaLevel;
        this.minY = minY;
        this.densities = densities;
        this.flat = same;
    }

    /**
     * Air that thins with height as the real atmosphere does: 1 at sea level, and by a factor of e every
     * {@code scaleHeight} blocks higher.
     *
     * @param maxY the top block of the level, inclusive
     */
    public static AmbientProfile exponential(int seaLevel, int minY, int maxY, float scaleHeight) {
        if (!Float.isFinite(scaleHeight) || scaleHeight <= 0) {
            throw new IllegalArgumentException("Scale height must be finite and positive, got " + scaleHeight);
        }
        float[] densities = new float[blocks(minY, maxY)];
        for (int i = 0; i < densities.length; i++) {
            densities[i] = (float) Math.exp(-(minY + i + 0.5 - seaLevel) / scaleHeight);
        }
        return new AmbientProfile(seaLevel, minY, densities);
    }

    /** The same air at every height: nothing settles, and gas lighter or heavier than it rises or sinks throughout. */
    public static AmbientProfile flat(int seaLevel, int minY, int maxY) {
        float[] densities = new float[blocks(minY, maxY)];
        Arrays.fill(densities, 1f);
        return new AmbientProfile(seaLevel, minY, densities);
    }

    /** Any profile, one density for the middle of each block from {@code minY} up; the array is copied. */
    public static AmbientProfile of(int seaLevel, int minY, float[] densities) {
        return new AmbientProfile(seaLevel, minY, densities.clone());
    }

    public int seaLevel() {
        return seaLevel;
    }

    public int minY() {
        return minY;
    }

    /** The top block the profile covers, inclusive. */
    public int maxY() {
        return minY + densities.length - 1;
    }

    public boolean isFlat() {
        return flat;
    }

    /** One density per block from {@link #minY()} up, a copy. */
    public float[] densities() {
        return densities.clone();
    }

    /** The density at a height in blocks, between block middles in a straight line; below and above, the end values. */
    public float density(double y) {
        double at = y - 0.5 - minY;
        if (!(at > 0)) {
            return densities[0];
        }
        int below = (int) at;
        if (below >= densities.length - 1) {
            return densities[densities.length - 1];
        }
        float t = (float) (at - below);
        return densities[below] + (densities[below + 1] - densities[below]) * t;
    }

    /**
     * The lowest height at which the air is as dense as {@code density}, which is where gas of that density settles
     * in air that thins with height; NaN if the air is never that dense within the profile.
     */
    public double heightOf(float density) {
        if (densities.length == 1) {
            return densities[0] == density ? minY + 0.5 : Double.NaN;
        }
        for (int i = 0; i < densities.length - 1; i++) {
            float low = densities[i];
            float high = densities[i + 1];
            if (low == density) {
                return minY + i + 0.5;
            }
            if ((low - density) * (high - density) < 0) {
                return minY + i + 0.5 + (density - low) / (high - low);
            }
        }
        return densities[densities.length - 1] == density ? maxY() + 0.5 : Double.NaN;
    }

    private static int blocks(int minY, int maxY) {
        if (maxY < minY) {
            throw new IllegalArgumentException("Top " + maxY + " is below bottom " + minY);
        }
        return maxY - minY + 1;
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof AmbientProfile profile && seaLevel == profile.seaLevel && minY == profile.minY
                && Arrays.equals(densities, profile.densities);
    }

    @Override
    public int hashCode() {
        return 31 * (31 * seaLevel + minY) + Arrays.hashCode(densities);
    }

    @Override
    public String toString() {
        return "AmbientProfile[sea " + seaLevel + ", " + minY + ".." + maxY() + (flat ? ", flat]" : "]");
    }
}
