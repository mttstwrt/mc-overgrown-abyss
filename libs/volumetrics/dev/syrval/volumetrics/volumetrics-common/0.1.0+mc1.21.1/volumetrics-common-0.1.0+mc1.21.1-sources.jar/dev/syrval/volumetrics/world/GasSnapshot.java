package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.sim.BrickMask;
import dev.syrval.volumetrics.sim.CellRect;
import dev.syrval.volumetrics.sim.GasField;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import java.nio.ByteBuffer;
import org.jspecify.annotations.Nullable;

/**
 * The gas of one window after one simulation step, in the form the renderer uploads: four bytes a cell in grid
 * order, one for each medium slot. Written by the simulation thread, then handed over and only read; its storage
 * is reused once the renderer gives it back.
 */
public final class GasSnapshot {
    private final GridSize size;
    private final ByteBuffer cells;
    private final byte[] zeros;
    /** For each layer of bricks, the rectangle of cells its gas lies in, or null if it has none. */
    private final @Nullable CellRect[] layerBounds;
    private final boolean[] slotHasGas = new boolean[GasWorld.SLOTS];
    private final BrickMask bricks;
    private GridPlacement placement;

    GasSnapshot(GridSize size, GridPlacement placement) {
        this.size = size;
        this.cells = ByteBuffer.allocateDirect(size.cells() * GasWorld.SLOTS);
        this.zeros = new byte[size.x() * GasWorld.SLOTS];
        this.layerBounds = new CellRect[size.bricksY()];
        this.bricks = new BrickMask(size);
        this.placement = placement;
    }

    public GridPlacement placement() {
        return placement;
    }

    public boolean slotHasGas(int slot) {
        return slotHasGas[slot];
    }

    public boolean hasGas() {
        for (boolean hasGas : slotHasGas) {
            if (hasGas) {
                return true;
            }
        }
        return false;
    }

    /** The bricks that hold gas, or lie right next to some: all the renderer has to march through. */
    public BrickMask bricks() {
        return bricks;
    }

    /** The part of a slice that can hold gas, or null if the slice is empty. Every texel outside it is zero. */
    public @Nullable CellRect sliceBounds(int cellY) {
        return layerBounds[cellY / GridSize.BRICK];
    }

    /** Copies the texels of part of a slice, row by row along Z, to the start of a buffer. */
    public void copySlice(int cellY, CellRect area, ByteBuffer out) {
        int rowBytes = area.width() * GasWorld.SLOTS;
        for (int row = 0; row < area.depth(); row++) {
            out.put(row * rowBytes, cells, size.index(area.x(), cellY, area.z() + row) * GasWorld.SLOTS, rowBytes);
        }
    }

    /**
     * Simulation thread: replaces the contents with the current state of the fields. A null field is an unused
     * slot; {@code fullDensity} is the density of each slot that maps to a byte of 255. The work is in proportion
     * to the bricks that hold gas, not to the size of the window.
     */
    void write(GridPlacement placement, @Nullable GasField[] fields, float[] fullDensity) {
        this.placement = placement;
        bricks.clear();
        for (int slot = 0; slot < GasWorld.SLOTS; slot++) {
            slotHasGas[slot] = fields[slot] != null && !fields[slot].isEmpty();
        }
        for (int by = 0; by < size.bricksY(); by++) {
            // A reused buffer still holds an older step: what that wrote in this layer is wiped first.
            if (layerBounds[by] != null) {
                wipe(by, layerBounds[by]);
            }
            layerBounds[by] = writeLayer(by, fields, fullDensity);
        }
    }

    /** Writes the bricks of one layer that hold gas, and returns the rectangle of cells they lie in, or null. */
    private @Nullable CellRect writeLayer(int brickY, @Nullable GasField[] fields, float[] fullDensity) {
        int minX = size.bricksX();
        int maxX = -1;
        int minZ = size.bricksZ();
        int maxZ = -1;
        for (int bz = 0; bz < size.bricksZ(); bz++) {
            for (int bx = 0; bx < size.bricksX(); bx++) {
                boolean any = false;
                for (int slot = 0; slot < GasWorld.SLOTS; slot++) {
                    if (fields[slot] != null && fields[slot].brickHasGas(bx, brickY, bz)) {
                        fields[slot].quantizeBrick(bx, brickY, bz, fullDensity[slot], cells, slot, GasWorld.SLOTS);
                        any = true;
                    }
                }
                if (any) {
                    bricks.markBrick(cells, bx, brickY, bz);
                    minX = Math.min(minX, bx);
                    maxX = Math.max(maxX, bx);
                    minZ = Math.min(minZ, bz);
                    maxZ = Math.max(maxZ, bz);
                }
            }
        }
        if (maxX < 0) {
            return null;
        }
        return new CellRect(minX * GridSize.BRICK, minZ * GridSize.BRICK,
                (maxX - minX + 1) * GridSize.BRICK, (maxZ - minZ + 1) * GridSize.BRICK);
    }

    private void wipe(int brickY, CellRect area) {
        for (int y = brickY * GridSize.BRICK; y < (brickY + 1) * GridSize.BRICK; y++) {
            for (int row = 0; row < area.depth(); row++) {
                cells.put(size.index(area.x(), y, area.z() + row) * GasWorld.SLOTS, zeros, 0, area.width() * GasWorld.SLOTS);
            }
        }
    }
}
