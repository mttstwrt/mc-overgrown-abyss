package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.sim.BrickMask;
import dev.syrval.volumetrics.sim.CellRect;
import dev.syrval.volumetrics.sim.GasStore;
import dev.syrval.volumetrics.sim.GridPlacement;
import dev.syrval.volumetrics.sim.GridSize;
import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.Arrays;
import org.jspecify.annotations.Nullable;

/**
 * The gas of one window after one simulation step, in the form the renderer uploads. Each kind of gas has a slot;
 * four slots make a page, and a page is four bytes a cell, one for each of its slots, as the density textures hold
 * them. Only the bricks that hold gas are kept, page by page. Written by the simulation thread, then handed over and
 * only read; its storage is reused once the renderer gives it back.
 */
public final class GasSnapshot {
    /** Kinds of gas one page holds: one to each channel of a texel. */
    public static final int KINDS_PER_PAGE = 4;
    private static final int BRICK = GridSize.BRICK;
    private static final int BRICK_BYTES = GasStore.BRICK_CELLS * KINDS_PER_PAGE;
    /** Emptied bricks kept for reuse, at most. */
    private static final int SPARE_BRICKS = 512;

    private final GridSize size;
    /** By page and then by brick index: the brick's texels in that page, or null if it holds no gas there. */
    private final byte[][][] texels = new byte[BrickMask.MAX_PAGES][][];
    /** By page and then for each layer of bricks: the rectangle of cells its gas lies in, or null if it has none. */
    private final @Nullable CellRect[][] layerBounds = new CellRect[BrickMask.MAX_PAGES][];
    private final ArrayDeque<byte[]> spare = new ArrayDeque<>();
    private final byte[] zeros;
    private final boolean[] slotHasGas = new boolean[GasWorld.MAX_KINDS];
    private final BrickMask bricks;
    private GridPlacement placement;
    private int pages;

    GasSnapshot(GridSize size, GridPlacement placement) {
        this.size = size;
        this.zeros = new byte[size.x() * KINDS_PER_PAGE];
        this.bricks = new BrickMask(size);
        this.placement = placement;
    }

    public GridSize size() {
        return size;
    }

    public GridPlacement placement() {
        return placement;
    }

    /** How many pages the slots in use take up, whether or not they hold gas just now: four slots to a page. */
    public int pages() {
        return pages;
    }

    public boolean slotHasGas(int slot) {
        return slotHasGas[slot];
    }

    public boolean hasGas() {
        for (boolean hasGas : slotHasGas) {
            if (hasGas) {
                return true;
            }
        }
        return false;
    }

    /** For each brick, the pages that hold gas in it or right next to it: all the renderer has to march through. */
    public BrickMask bricks() {
        return bricks;
    }

    /** The part of a slice of a page that can hold gas, or null if it is empty. Every texel outside it is zero. */
    public @Nullable CellRect sliceBounds(int page, int cellY) {
        return page < pages && layerBounds[page] != null ? layerBounds[page][cellY / BRICK] : null;
    }

    /**
     * Writes the texels of part of a slice of a page to the start of a buffer, row by row along Z. The part's edges
     * must lie on the edges of bricks, as {@link #sliceBounds} and the unions of such parts do.
     */
    public void copySlice(int page, int cellY, CellRect area, ByteBuffer out) {
        int rowBytes = area.width() * KINDS_PER_PAGE;
        for (int row = 0; row < area.depth(); row++) {
            out.put(row * rowBytes, zeros, 0, rowBytes);
        }
        byte[][] pageTexels = page < pages ? texels[page] : null;
        if (pageTexels == null) {
            return;
        }
        int by = cellY / BRICK;
        int inBrickY = cellY % BRICK;
        int rowOfBrick = BRICK * KINDS_PER_PAGE;
        for (int bz = area.z() / BRICK; bz < (area.z() + area.depth()) / BRICK; bz++) {
            for (int bx = area.x() / BRICK; bx < (area.x() + area.width()) / BRICK; bx++) {
                byte[] brick = pageTexels[size.brickIndex(bx, by, bz)];
                if (brick == null) {
                    continue;
                }
                for (int z = 0; z < BRICK; z++) {
                    int to = ((bz * BRICK + z - area.z()) * area.width() + bx * BRICK - area.x()) * KINDS_PER_PAGE;
                    out.put(to, brick, GasStore.inBrick(0, inBrickY, z) * KINDS_PER_PAGE, rowOfBrick);
                }
            }
        }
    }

    /**
     * Simulation thread: replaces the contents with the gas of each slot. A null store is a slot not in use;
     * {@code fullDensity} is the density of each slot that maps to a byte of 255. The work is in proportion to the
     * bricks that hold gas, not to the size of the window.
     */
    void write(GridPlacement placement, @Nullable GasStore[] stores, float[] fullDensity) {
        this.placement = placement;
        releaseAll();
        bricks.clear();
        Arrays.fill(slotHasGas, false);
        pages = 0;
        for (int slot = 0; slot < stores.length; slot++) {
            GasStore store = stores[slot];
            if (store == null) {
                continue;
            }
            int page = slot / KINDS_PER_PAGE;
            pages = Math.max(pages, page + 1);
            if (store.isEmpty()) {
                continue;
            }
            slotHasGas[slot] = true;
            if (texels[page] == null) {
                texels[page] = new byte[size.brickCount()][];
            }
            byte[][] pageTexels = texels[page];
            for (int by = 0; by < size.bricksY(); by++) {
                for (int bz = 0; bz < size.bricksZ(); bz++) {
                    for (int bx = 0; bx < size.bricksX(); bx++) {
                        if (store.brickHasGas(bx, by, bz)) {
                            int index = size.brickIndex(bx, by, bz);
                            if (pageTexels[index] == null) {
                                pageTexels[index] = fresh();
                            }
                            store.quantizeBrick(bx, by, bz, fullDensity[slot], pageTexels[index], slot % KINDS_PER_PAGE, KINDS_PER_PAGE);
                        }
                    }
                }
            }
        }
        for (int page = 0; page < pages; page++) {
            if (layerBounds[page] == null) {
                layerBounds[page] = new CellRect[size.bricksY()];
            }
            for (int by = 0; by < size.bricksY(); by++) {
                layerBounds[page][by] = texels[page] == null ? null : writeLayer(page, by);
            }
        }
    }

    /** Marks the bricks of one layer of a page that hold gas, and returns the rectangle of cells they lie in, or null. */
    private @Nullable CellRect writeLayer(int page, int brickY) {
        int minX = size.bricksX();
        int maxX = -1;
        int minZ = size.bricksZ();
        int maxZ = -1;
        for (int bz = 0; bz < size.bricksZ(); bz++) {
            for (int bx = 0; bx < size.bricksX(); bx++) {
                byte[] brick = texels[page][size.brickIndex(bx, brickY, bz)];
                if (brick != null) {
                    bricks.markBrick(brick, page, bx, brickY, bz);
                    minX = Math.min(minX, bx);
                    maxX = Math.max(maxX, bx);
                    minZ = Math.min(minZ, bz);
                    maxZ = Math.max(maxZ, bz);
                }
            }
        }
        if (maxX < 0) {
            return null;
        }
        return new CellRect(minX * BRICK, minZ * BRICK, (maxX - minX + 1) * BRICK, (maxZ - minZ + 1) * BRICK);
    }

    private void releaseAll() {
        for (byte[][] pageTexels : texels) {
            if (pageTexels == null) {
                continue;
            }
            for (int index = 0; index < pageTexels.length; index++) {
                if (pageTexels[index] != null) {
                    if (spare.size() < SPARE_BRICKS) {
                        spare.add(pageTexels[index]);
                    }
                    pageTexels[index] = null;
                }
            }
        }
    }

    private byte[] fresh() {
        byte[] brick = spare.poll();
        if (brick == null) {
            return new byte[BRICK_BYTES];
        }
        Arrays.fill(brick, (byte) 0);
        return brick;
    }
}
