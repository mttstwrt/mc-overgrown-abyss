package dev.syrval.volumetrics.client.render;

import com.mojang.serialization.Codec;
import net.minecraft.util.StringRepresentable;

/**
 * How much work the GPU does to draw the gas. It changes how the gas is drawn, never what it does: the
 * simulation is the same at every setting.
 */
public enum Quality implements StringRepresentable {
    // Each has steps enough for a ray to reach the far end of the coarse window through gas all the way, and to go
    // some 500 blocks through fog.
    LOW("low", 3, 2f, 0.08f, 48, 4f, 0.25f, 20),
    MEDIUM("medium", 2, 1f, 0.05f, 80, 3f, 0.18f, 28),
    HIGH("high", 2, 0.5f, 0.03f, 128, 2f, 0.12f, 40);

    public static final Codec<Quality> CODEC = StringRepresentable.fromEnum(Quality::values);

    private final String name;
    private final int marchDivisor;
    private final float minStepBlocks;
    private final float stepGrowth;
    private final int maxSamples;
    private final float fogMinStepBlocks;
    private final float fogStepGrowth;
    private final int fogMaxSamples;

    Quality(String name, int marchDivisor, float minStepBlocks, float stepGrowth, int maxSamples,
            float fogMinStepBlocks, float fogStepGrowth, int fogMaxSamples) {
        this.name = name;
        this.marchDivisor = marchDivisor;
        this.minStepBlocks = minStepBlocks;
        this.stepGrowth = stepGrowth;
        this.maxSamples = maxSamples;
        this.fogMinStepBlocks = fogMinStepBlocks;
        this.fogStepGrowth = fogStepGrowth;
        this.fogMaxSamples = fogMaxSamples;
    }

    @Override
    public String getSerializedName() {
        return name;
    }

    /** The gas is marched at the screen's size divided by this, each way. */
    int marchDivisor() {
        return marchDivisor;
    }

    /** Length of a step along a ray near the camera, in blocks. */
    float minStepBlocks() {
        return minStepBlocks;
    }

    /** How much longer a step gets for each block of distance from the camera. */
    float stepGrowth() {
        return stepGrowth;
    }

    /** The most steps one ray takes through gas. */
    int maxSamples() {
        return maxSamples;
    }

    /** The same three for the stretches of a ray where there is fog and no simulated gas, whose steps can be longer. */
    float fogMinStepBlocks() {
        return fogMinStepBlocks;
    }

    float fogStepGrowth() {
        return fogStepGrowth;
    }

    int fogMaxSamples() {
        return fogMaxSamples;
    }
}
