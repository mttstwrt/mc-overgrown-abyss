package dev.syrval.volumetrics.client.render;

import com.mojang.serialization.Codec;
import net.minecraft.util.StringRepresentable;

/**
 * How much work the GPU does to draw the gas. It changes how the gas is drawn, never what it does: the
 * simulation is the same at every setting.
 */
public enum Quality implements StringRepresentable {
    // Each has steps enough for a ray to reach the far end of the coarse window through gas all the way.
    LOW("low", 3, 2f, 0.08f, 48),
    MEDIUM("medium", 2, 1f, 0.05f, 80),
    HIGH("high", 2, 0.5f, 0.03f, 128);

    public static final Codec<Quality> CODEC = StringRepresentable.fromEnum(Quality::values);

    private final String name;
    private final int marchDivisor;
    private final float minStepBlocks;
    private final float stepGrowth;
    private final int maxSamples;

    Quality(String name, int marchDivisor, float minStepBlocks, float stepGrowth, int maxSamples) {
        this.name = name;
        this.marchDivisor = marchDivisor;
        this.minStepBlocks = minStepBlocks;
        this.stepGrowth = stepGrowth;
        this.maxSamples = maxSamples;
    }

    @Override
    public String getSerializedName() {
        return name;
    }

    /** The gas is marched at the screen's size divided by this, each way. */
    int marchDivisor() {
        return marchDivisor;
    }

    /** Length of a step along a ray near the camera, in blocks. */
    float minStepBlocks() {
        return minStepBlocks;
    }

    /** How much longer a step gets for each block of distance from the camera. */
    float stepGrowth() {
        return stepGrowth;
    }

    /** The most steps one ray takes through gas. */
    int maxSamples() {
        return maxSamples;
    }
}
