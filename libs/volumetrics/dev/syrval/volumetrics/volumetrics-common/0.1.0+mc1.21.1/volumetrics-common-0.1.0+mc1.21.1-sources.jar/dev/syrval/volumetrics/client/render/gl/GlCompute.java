package dev.syrval.volumetrics.client.render.gl;

import dev.syrval.volumetrics.client.render.ComputeSupport;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GLCapabilities;
import org.lwjgl.system.MemoryUtil;

/**
 * Whether this OpenGL context can run compute shaders that store to images. The game asks for a 3.2 core context,
 * which most drivers answer with their newest core version, so the capabilities are read rather than assumed.
 */
public final class GlCompute {
    private GlCompute() {}

    /** What the context current on this thread can do; call on the render thread. */
    public static ComputeSupport detect() {
        GLCapabilities capabilities = GL.getCapabilities();
        int major = GL11.glGetInteger(GL30.GL_MAJOR_VERSION);
        int minor = GL11.glGetInteger(GL30.GL_MINOR_VERSION);
        boolean compute = capabilities.OpenGL43
                || capabilities.GL_ARB_compute_shader && capabilities.GL_ARB_shader_image_load_store;
        if (!compute || capabilities.glDispatchCompute == MemoryUtil.NULL) {
            return ComputeSupport.none("OpenGL " + major + "." + minor + " core context, needs 4.3");
        }
        return ComputeSupport.available(ComputeSupport.Backend.GL43,
                "OpenGL " + major + "." + minor + " (" + GL11.glGetString(GL11.GL_RENDERER) + ")");
    }
}
