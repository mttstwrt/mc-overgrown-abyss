package dev.syrval.volumetrics.ambient;

import net.minecraft.resources.ResourceLocation;
import org.jspecify.annotations.Nullable;

/**
 * The client's side of the air gas floats in: what the server last sent, and the state to use for a level, which is
 * the server's if it sent one for that dimension and the defaults otherwise. Holds immutable values behind a
 * volatile reference, so any thread may read it. Nothing in here touches client classes.
 */
public final class ClientAmbient {
    private static volatile @Nullable AmbientPayload received;

    private ClientAmbient() {}

    /** What the loaders' receivers call with a payload from the server. */
    public static void receive(AmbientPayload payload) {
        received = payload;
    }

    /** Forgets what a server sent, when the player is out of any level. */
    public static void clear() {
        received = null;
    }

    public static @Nullable AmbientPayload received() {
        return received;
    }

    /**
     * @param fromServer whether {@code state} is what the server sent, as against the defaults
     */
    public record Resolved(AmbientState state, boolean fromServer) {}

    /**
     * The state for a level. The sea level and heights are only used without a word from the server for this
     * dimension: the game's own for the client's level.
     */
    public static Resolved resolve(ResourceLocation dimension, int seaLevel, int minY, int maxY) {
        AmbientPayload payload = received;
        if (payload != null && payload.dimension().equals(dimension)) {
            return new Resolved(payload.state(), true);
        }
        return new Resolved(ServerSettings.DEFAULT.stateFor(dimension, seaLevel, minY, maxY), false);
    }
}
