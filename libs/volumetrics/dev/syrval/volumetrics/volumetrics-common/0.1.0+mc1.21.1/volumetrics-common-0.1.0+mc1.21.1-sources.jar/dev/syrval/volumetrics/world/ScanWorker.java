package dev.syrval.volumetrics.world;

import dev.syrval.volumetrics.Volumetrics;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.LockSupport;
import org.jspecify.annotations.Nullable;

/**
 * Scans chunk sections on a thread of its own. The client thread copies a section out of the world and hands the
 * copy in; the scan thread works out what the section comes to; the simulation thread takes the results at the start
 * of a step and writes them into its windows. Copies are scanned, and their results come back, in the order they were
 * handed in, so of two results for one section the later is the newer. Nobody waits: copies and results go through
 * lock-free queues, and the client thread wakes the scan thread once a tick.
 */
final class ScanWorker implements ScanResults, AutoCloseable {
    private final ConcurrentLinkedQueue<SectionCopy> copies = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<SectionResult> results = new ConcurrentLinkedQueue<>();
    /**
     * Copies handed in whose results have not yet been written into a window or dropped: counted up on the client
     * thread, down on the simulation thread, or on the scan thread for a scan that failed and so has no result.
     */
    private final AtomicInteger inFlight = new AtomicInteger();
    /** Sections scanned, and the scan thread's time for them, since the client thread last took the counts. */
    private final AtomicLong scanned = new AtomicLong();
    private final AtomicLong scanNanos = new AtomicLong();
    private volatile long nanosPerSectionSmoothed;
    private final int maxInFlight;
    private final Thread thread;
    private volatile boolean closed;

    /** For each window, what scans its sections and the scratch it does it in. Touched by the scan thread only. */
    private final SectionScanner[] scanners;

    /**
     * @param scanners    one for each window, the fine one first; the scan thread's from now on
     * @param maxInFlight how many copies may be handed in whose results have not been taken
     */
    ScanWorker(SectionScanner[] scanners, int maxInFlight) {
        this.scanners = scanners.clone();
        this.maxInFlight = maxInFlight;
        this.thread = new Thread(this::run, "Volumetrics scan");
        thread.setDaemon(true);
        thread.start();
    }

    /** Whether fewer copies are in flight than the most allowed. Client thread. */
    boolean hasRoom() {
        return inFlight.get() < maxInFlight;
    }

    /** Hands a copy to the scan thread, which starts on it after the next {@link #wake}. Client thread. */
    void submit(SectionCopy copy) {
        inFlight.incrementAndGet();
        copies.add(copy);
    }

    /** Lets the scan thread go on with what has been handed in. Client thread, once a tick. */
    void wake() {
        if (!copies.isEmpty()) {
            LockSupport.unpark(thread);
        }
    }

    /** Simulation thread. */
    @Override
    public @Nullable SectionResult poll() {
        return results.poll();
    }

    /** Simulation thread. */
    @Override
    public void done() {
        inFlight.decrementAndGet();
    }

    /** Copies handed in whose results have not yet been written into a window or dropped. */
    int inFlight() {
        return inFlight.get();
    }

    /** Sections scanned since this was last called. With {@link #takeScanNanos}, for the client thread's statistics. */
    long takeScanned() {
        return scanned.getAndSet(0);
    }

    /** The scan thread's time for the sections counted by {@link #takeScanned}, near enough. */
    long takeScanNanos() {
        return scanNanos.getAndSet(0);
    }

    /** Scan-thread time a section takes, smoothed over recent sections. */
    long nanosPerSection() {
        return nanosPerSectionSmoothed;
    }

    /** Results scanned and not yet taken. Counts them one by one: for the statistics only. */
    int resultsWaiting() {
        return results.size();
    }

    /** The scan thread finishes the section it is on, if any, and stops; nothing handed in is scanned after. */
    @Override
    public void close() {
        closed = true;
        copies.clear();
        LockSupport.unpark(thread);
    }

    private void run() {
        while (!closed) {
            SectionCopy copy = copies.poll();
            if (copy == null) {
                LockSupport.park(this);
                continue;
            }
            try {
                long start = System.nanoTime();
                SectionResult result = scanners[copy.window()].scan(copy);
                long nanos = System.nanoTime() - start;
                results.add(result);
                scanned.incrementAndGet();
                scanNanos.addAndGet(nanos);
                nanosPerSectionSmoothed += (nanos - nanosPerSectionSmoothed) / 64;
            } catch (RuntimeException e) {
                inFlight.decrementAndGet();
                Volumetrics.LOGGER.error("Scanning chunk section {} {} {} failed", copy.sectionX(), copy.sectionY(), copy.sectionZ(), e);
            }
        }
    }
}
